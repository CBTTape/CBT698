#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use DBD::Pg qw(:pg_types);
use bytes;
my ($rv, $rectype, $statement);
my %insert;
my %inserts;
my $dbh=DBI->connect("dbi:Pg:dbname=racf","","",{PrintError=>0, RaiseError=>1, AutoCommit=>0});
die "Unable to connect to database." unless defined($dbh);

#Table:ds_access
#delete all rows from the ds_access table
$dbh->do("delete from ds_access");
#Define the column names for the ds_access table to Perl
my $dsacc_name;
my $dsacc_vol;
my $dsacc_auth_id;
my $dsacc_access;
my $dsacc_access_cnt;
#Create and prepare the INSERT statement for ds_access
$statement="INSERT INTO ds_access (dsacc_name,dsacc_vol,dsacc_auth_id,dsacc_access,dsacc_access_cnt) VALUES (?,?,?,?,?)";
if (! defined($insert{"ds_access"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_access"}=0;
#Table:ds_bd
#delete all rows from the ds_bd table
$dbh->do("delete from ds_bd");
#Define the column names for the ds_bd table to Perl
my $dsbd_name;
my $dsbd_vol;
my $dsbd_generic;
my $dsbd_create_date;
my $dsbd_owner_id;
my $dsbd_lastref_date;
my $dsbd_lastchg_date;
my $dsbd_alter_cnt;
my $dsbd_control_cnt;
my $dsbd_update_cnt;
my $dsbd_read_cnt;
my $dsbd_uacc;
my $dsbd_grpds;
my $dsbd_audit_level;
my $dsbd_grp_id;
my $dsbd_ds_type;
my $dsbd_level;
my $dsbd_device_name;
my $dsbd_gaudit_level;
my $dsbd_install_data;
my $dsbd_audit_okqual;
my $dsbd_audit_faqual;
my $dsbd_gaudit_okqual;
my $dsbd_gaudit_faqual;
my $dsbd_warning;
my $dsbd_seclevel;
my $dsbd_notify_id;
my $dsbd_retention;
my $dsbd_erase;
my $dsbd_seclabel;
#Create and prepare the INSERT statement for ds_bd
$statement="INSERT INTO ds_bd (dsbd_name,dsbd_vol,dsbd_generic,dsbd_create_date,dsbd_owner_id,dsbd_lastref_date,dsbd_lastchg_date,dsbd_alter_cnt,dsbd_control_cnt,dsbd_update_cnt,dsbd_read_cnt,dsbd_uacc,dsbd_grpds,dsbd_audit_level,dsbd_grp_id,dsbd_ds_type,dsbd_level,dsbd_device_name,dsbd_gaudit_level,dsbd_install_data,dsbd_audit_okqual,dsbd_audit_faqual,dsbd_gaudit_okqual,dsbd_gaudit_faqual,dsbd_warning,dsbd_seclevel,dsbd_notify_id,dsbd_retention,dsbd_erase,dsbd_seclabel) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ds_bd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_bd"}=0;
#Table:ds_categories
#delete all rows from the ds_categories table
$dbh->do("delete from ds_categories");
#Define the column names for the ds_categories table to Perl
my $dscat_name;
my $dscat_vol;
my $dscat_category;
#Create and prepare the INSERT statement for ds_categories
$statement="INSERT INTO ds_categories (dscat_name,dscat_vol,dscat_category) VALUES (?,?,?)";
if (! defined($insert{"ds_categories"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_categories"}=0;
#Table:ds_cond_access
#delete all rows from the ds_cond_access table
$dbh->do("delete from ds_cond_access");
#Define the column names for the ds_cond_access table to Perl
my $dscacc_name;
my $dscacc_vol;
my $dscacc_catype;
my $dscacc_caname;
my $dscacc_auth_id;
my $dscacc_access;
my $dscacc_access_cnt;
my $dscacc_net_id;
#Create and prepare the INSERT statement for ds_cond_access
$statement="INSERT INTO ds_cond_access (dscacc_name,dscacc_vol,dscacc_catype,dscacc_caname,dscacc_auth_id,dscacc_access,dscacc_access_cnt,dscacc_net_id) VALUES (?,?,?,?,?,?,?,?)";
if (! defined($insert{"ds_cond_access"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_cond_access"}=0;
#Table:ds_dfp_data
#delete all rows from the ds_dfp_data table
$dbh->do("delete from ds_dfp_data");
#Define the column names for the ds_dfp_data table to Perl
my $dsdfp_name;
my $dsdfp_vol;
my $dsdfp_resowner_id;
#Create and prepare the INSERT statement for ds_dfp_data
$statement="INSERT INTO ds_dfp_data (dsdfp_name,dsdfp_vol,dsdfp_resowner_id) VALUES (?,?,?)";
if (! defined($insert{"ds_dfp_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_dfp_data"}=0;
#Table:ds_install_data
#delete all rows from the ds_install_data table
$dbh->do("delete from ds_install_data");
#Define the column names for the ds_install_data table to Perl
my $dsinstd_name;
my $dsinstd_vol;
my $dsinstd_usr_name;
my $dsinstd_usr_data;
my $dsinstd_usr_flag;
#Create and prepare the INSERT statement for ds_install_data
$statement="INSERT INTO ds_install_data (dsinstd_name,dsinstd_vol,dsinstd_usr_name,dsinstd_usr_data,dsinstd_usr_flag) VALUES (?,?,?,?,?)";
if (! defined($insert{"ds_install_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_install_data"}=0;
#Table:ds_tme_role
#delete all rows from the ds_tme_role table
$dbh->do("delete from ds_tme_role");
#Define the column names for the ds_tme_role table to Perl
my $dstme_name;
my $dstme_vol;
my $dstme_role_name;
my $dstme_access_auth;
my $dstme_cond_class;
my $dstme_cond_prof;
#Create and prepare the INSERT statement for ds_tme_role
$statement="INSERT INTO ds_tme_role (dstme_name,dstme_vol,dstme_role_name,dstme_access_auth,dstme_cond_class,dstme_cond_prof) VALUES (?,?,?,?,?,?)";
if (! defined($insert{"ds_tme_role"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_tme_role"}=0;
#Table:ds_volumes
#delete all rows from the ds_volumes table
$dbh->do("delete from ds_volumes");
#Define the column names for the ds_volumes table to Perl
my $dsvol_name;
my $dsvol_vol;
my $dsvol_vol_name;
#Create and prepare the INSERT statement for ds_volumes
$statement="INSERT INTO ds_volumes (dsvol_name,dsvol_vol,dsvol_vol_name) VALUES (?,?,?)";
if (! defined($insert{"ds_volumes"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ds_volumes"}=0;
#Table:genr_access
#delete all rows from the genr_access table
$dbh->do("delete from genr_access");
#Define the column names for the genr_access table to Perl
my $gracc_name;
my $gracc_class_name;
my $gracc_auth_id;
my $gracc_access;
my $gracc_access_cnt;
#Create and prepare the INSERT statement for genr_access
$statement="INSERT INTO genr_access (gracc_name,gracc_class_name,gracc_auth_id,gracc_access,gracc_access_cnt) VALUES (?,?,?,?,?)";
if (! defined($insert{"genr_access"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_access"}=0;
#Table:genr_bd
#delete all rows from the genr_bd table
$dbh->do("delete from genr_bd");
#Define the column names for the genr_bd table to Perl
my $grbd_name;
my $grbd_class_name;
my $grbd_generic;
my $grbd_class;
my $grbd_create_date;
my $grbd_owner_id;
my $grbd_lastref_date;
my $grbd_lastchg_date;
my $grbd_alter_cnt;
my $grbd_control_cnt;
my $grbd_update_cnt;
my $grbd_read_cnt;
my $grbd_uacc;
my $grbd_audit_level;
my $grbd_level;
my $grbd_gaudit_level;
my $grbd_install_data;
my $grbd_audit_okqual;
my $grbd_audit_faqual;
my $grbd_gaudit_okqual;
my $grbd_gaudit_faqual;
my $grbd_warning;
my $grbd_singleds;
my $grbd_auto;
my $grbd_tvtoc;
my $grbd_notify_id;
my $grbd_access_sun;
my $grbd_access_mon;
my $grbd_access_tue;
my $grbd_access_wed;
my $grbd_access_thu;
my $grbd_access_fri;
my $grbd_access_sat;
my $grbd_start_time;
my $grbd_end_time;
my $grbd_zone_offset;
my $grbd_zone_direct;
my $grbd_seclevel;
my $grbd_appl_data;
my $grbd_seclabel;
#Create and prepare the INSERT statement for genr_bd
$statement="INSERT INTO genr_bd (grbd_name,grbd_class_name,grbd_generic,grbd_class,grbd_create_date,grbd_owner_id,grbd_lastref_date,grbd_lastchg_date,grbd_alter_cnt,grbd_control_cnt,grbd_update_cnt,grbd_read_cnt,grbd_uacc,grbd_audit_level,grbd_level,grbd_gaudit_level,grbd_install_data,grbd_audit_okqual,grbd_audit_faqual,grbd_gaudit_okqual,grbd_gaudit_faqual,grbd_warning,grbd_singleds,grbd_auto,grbd_tvtoc,grbd_notify_id,grbd_access_sun,grbd_access_mon,grbd_access_tue,grbd_access_wed,grbd_access_thu,grbd_access_fri,grbd_access_sat,grbd_start_time,grbd_end_time,grbd_zone_offset,grbd_zone_direct,grbd_seclevel,grbd_appl_data,grbd_seclabel) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_bd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_bd"}=0;
#Table:genr_categories
#delete all rows from the genr_categories table
$dbh->do("delete from genr_categories");
#Define the column names for the genr_categories table to Perl
my $grcat_name;
my $grcat_class_name;
my $grcat_category;
#Create and prepare the INSERT statement for genr_categories
$statement="INSERT INTO genr_categories (grcat_name,grcat_class_name,grcat_category) VALUES (?,?,?)";
if (! defined($insert{"genr_categories"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_categories"}=0;
#Table:genr_cert_data
#delete all rows from the genr_cert_data table
$dbh->do("delete from genr_cert_data");
#Define the column names for the genr_cert_data table to Perl
my $grcert_name;
my $grcert_class_name;
my $grcert_start_date;
my $grcert_start_time;
my $grcert_end_date;
my $grcert_end_time;
my $grcert_key_type;
my $grcert_key_size;
my $grcert_last_serial;
my $grcert_ring_seqn;
#Create and prepare the INSERT statement for genr_cert_data
$statement="INSERT INTO genr_cert_data (grcert_name,grcert_class_name,grcert_start_date,grcert_start_time,grcert_end_date,grcert_end_time,grcert_key_type,grcert_key_size,grcert_last_serial,grcert_ring_seqn) VALUES (?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_cert_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_cert_data"}=0;
#Table:genr_certr_data
#delete all rows from the genr_certr_data table
$dbh->do("delete from genr_certr_data");
#Define the column names for the genr_certr_data table to Perl
my $certr_name;
my $certr_class_name;
my $certr_ring_name;
#Create and prepare the INSERT statement for genr_certr_data
$statement="INSERT INTO genr_certr_data (certr_name,certr_class_name,certr_ring_name) VALUES (?,?,?)";
if (! defined($insert{"genr_certr_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_certr_data"}=0;
#Table:genr_cond_access
#delete all rows from the genr_cond_access table
$dbh->do("delete from genr_cond_access");
#Define the column names for the genr_cond_access table to Perl
my $grcacc_name;
my $grcacc_class_name;
my $grcacc_catype;
my $grcacc_caname;
my $grcacc_auth_id;
my $grcacc_access;
my $grcacc_access_cnt;
my $grcacc_net_id;
#Create and prepare the INSERT statement for genr_cond_access
$statement="INSERT INTO genr_cond_access (grcacc_name,grcacc_class_name,grcacc_catype,grcacc_caname,grcacc_auth_id,grcacc_access,grcacc_access_cnt,grcacc_net_id) VALUES (?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_cond_access"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_cond_access"}=0;
#Table:genr_dlf_data
#delete all rows from the genr_dlf_data table
$dbh->do("delete from genr_dlf_data");
#Define the column names for the genr_dlf_data table to Perl
my $grdlf_name;
my $grdlf_class_name;
my $grdlf_retain;
#Create and prepare the INSERT statement for genr_dlf_data
$statement="INSERT INTO genr_dlf_data (grdlf_name,grdlf_class_name,grdlf_retain) VALUES (?,?,?)";
if (! defined($insert{"genr_dlf_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_dlf_data"}=0;
#Table:genr_dlf_job_names
#delete all rows from the genr_dlf_job_names table
$dbh->do("delete from genr_dlf_job_names");
#Define the column names for the genr_dlf_job_names table to Perl
my $grdlfj_name;
my $grdlfj_class_name;
my $grdlfj_job_name;
#Create and prepare the INSERT statement for genr_dlf_job_names
$statement="INSERT INTO genr_dlf_job_names (grdlfj_name,grdlfj_class_name,grdlfj_job_name) VALUES (?,?,?)";
if (! defined($insert{"genr_dlf_job_names"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_dlf_job_names"}=0;
#Table:genr_eim_data
#delete all rows from the genr_eim_data table
$dbh->do("delete from genr_eim_data");
#Define the column names for the genr_eim_data table to Perl
my $greim_name;
my $greim_class_name;
my $greim_domain_dn;
my $greim_enable;
my $greim_local_reg;
#Create and prepare the INSERT statement for genr_eim_data
$statement="INSERT INTO genr_eim_data (greim_name,greim_class_name,greim_domain_dn,greim_enable,greim_local_reg) VALUES (?,?,?,?,?)";
if (! defined($insert{"genr_eim_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_eim_data"}=0;
#Table:genr_filter_data
#delete all rows from the genr_filter_data table
$dbh->do("delete from genr_filter_data");
#Define the column names for the genr_filter_data table to Perl
my $grfltr_name;
my $grfltr_class_name;
my $grfltr_label;
my $grfltr_status;
my $grfltr_user;
my $grfltr_create_name;
#Create and prepare the INSERT statement for genr_filter_data
$statement="INSERT INTO genr_filter_data (grfltr_name,grfltr_class_name,grfltr_label,grfltr_status,grfltr_user,grfltr_create_name) VALUES (?,?,?,?,?,?)";
if (! defined($insert{"genr_filter_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_filter_data"}=0;
#Table:genr_install_data
#delete all rows from the genr_install_data table
$dbh->do("delete from genr_install_data");
#Define the column names for the genr_install_data table to Perl
my $grinstd_name;
my $grinstd_class_name;
my $grinstd_usr_name;
my $grinstd_usr_data;
my $grinstd_usr_flag;
#Create and prepare the INSERT statement for genr_install_data
$statement="INSERT INTO genr_install_data (grinstd_name,grinstd_class_name,grinstd_usr_name,grinstd_usr_data,grinstd_usr_flag) VALUES (?,?,?,?,?)";
if (! defined($insert{"genr_install_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_install_data"}=0;
#Table:genr_kerb_data
#delete all rows from the genr_kerb_data table
$dbh->do("delete from genr_kerb_data");
#Define the column names for the genr_kerb_data table to Perl
my $grkerb_name;
my $grkerb_class_name;
my $grkerb_kerbname;
my $grkerb_min_life;
my $grkerb_max_life;
my $grkerb_def_life;
my $grkerb_key_vers;
my $grkerb_encrpt_des;
my $grkerb_encrpt_des3;
my $grkerb_encrpt_desd;
#Create and prepare the INSERT statement for genr_kerb_data
$statement="INSERT INTO genr_kerb_data (grkerb_name,grkerb_class_name,grkerb_kerbname,grkerb_min_life,grkerb_max_life,grkerb_def_life,grkerb_key_vers,grkerb_encrpt_des,grkerb_encrpt_des3,grkerb_encrpt_desd) VALUES (?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_kerb_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_kerb_data"}=0;
#Table:genr_keyr_data
#delete all rows from the genr_keyr_data table
$dbh->do("delete from genr_keyr_data");
#Define the column names for the genr_keyr_data table to Perl
my $keyr_name;
my $keyr_class_name;
my $keyr_cert_name;
my $keyr_cert_usage;
my $keyr_cert_default;
my $keyr_cert_label;
#Create and prepare the INSERT statement for genr_keyr_data
$statement="INSERT INTO genr_keyr_data (keyr_name,keyr_class_name,keyr_cert_name,keyr_cert_usage,keyr_cert_default,keyr_cert_label) VALUES (?,?,?,?,?,?)";
if (! defined($insert{"genr_keyr_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_keyr_data"}=0;
#Table:genr_members
#delete all rows from the genr_members table
$dbh->do("delete from genr_members");
#Define the column names for the genr_members table to Perl
my $grmem_name;
my $grmem_class_name;
my $grmem_member;
my $grmem_global_acc;
my $grmem_pads_data;
my $grmem_vol_name;
my $grmem_vmevent_data;
my $grmem_seclevel;
my $grmem_category;
#Create and prepare the INSERT statement for genr_members
$statement="INSERT INTO genr_members (grmem_name,grmem_class_name,grmem_member,grmem_global_acc,grmem_pads_data,grmem_vol_name,grmem_vmevent_data,grmem_seclevel,grmem_category) VALUES (?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_members"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_members"}=0;
#Table:genr_proxy_data
#delete all rows from the genr_proxy_data table
$dbh->do("delete from genr_proxy_data");
#Define the column names for the genr_proxy_data table to Perl
my $grproxy_name;
my $grproxy_class_name;
my $grproxy_ldap_host;
my $grproxy_bind_dn;
#Create and prepare the INSERT statement for genr_proxy_data
$statement="INSERT INTO genr_proxy_data (grproxy_name,grproxy_class_name,grproxy_ldap_host,grproxy_bind_dn) VALUES (?,?,?,?)";
if (! defined($insert{"genr_proxy_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_proxy_data"}=0;
#Table:genr_session_data
#delete all rows from the genr_session_data table
$dbh->do("delete from genr_session_data");
#Define the column names for the genr_session_data table to Perl
my $grses_name;
my $grses_class_name;
my $grses_session_key;
my $grses_locked;
my $grses_key_date;
my $grses_key_interval;
my $grses_sls_fail;
my $grses_max_fail;
my $grses_convsec;
#Create and prepare the INSERT statement for genr_session_data
$statement="INSERT INTO genr_session_data (grses_name,grses_class_name,grses_session_key,grses_locked,grses_key_date,grses_key_interval,grses_sls_fail,grses_max_fail,grses_convsec) VALUES (?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_session_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_session_data"}=0;
#Table:genr_session_ent
#delete all rows from the genr_session_ent table
$dbh->do("delete from genr_session_ent");
#Define the column names for the genr_session_ent table to Perl
my $grsese_name;
my $grsese_class_name;
my $grsese_entity_name;
my $grsese_fail_cnt;
#Create and prepare the INSERT statement for genr_session_ent
$statement="INSERT INTO genr_session_ent (grsese_name,grsese_class_name,grsese_entity_name,grsese_fail_cnt) VALUES (?,?,?,?)";
if (! defined($insert{"genr_session_ent"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_session_ent"}=0;
#Table:genr_stdata_data
#delete all rows from the genr_stdata_data table
$dbh->do("delete from genr_stdata_data");
#Define the column names for the genr_stdata_data table to Perl
my $grst_name;
my $grst_class_name;
my $grst_user_id;
my $grst_group_id;
my $grst_trusted;
my $grst_privileged;
my $grst_trace;
#Create and prepare the INSERT statement for genr_stdata_data
$statement="INSERT INTO genr_stdata_data (grst_name,grst_class_name,grst_user_id,grst_group_id,grst_trusted,grst_privileged,grst_trace) VALUES (?,?,?,?,?,?,?)";
if (! defined($insert{"genr_stdata_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_stdata_data"}=0;
#Table:genr_svfmr_data
#delete all rows from the genr_svfmr_data table
$dbh->do("delete from genr_svfmr_data");
#Define the column names for the genr_svfmr_data table to Perl
my $grsv_name;
my $grsv_class_name;
my $grsv_script_name;
my $grsv_parm_name;
#Create and prepare the INSERT statement for genr_svfmr_data
$statement="INSERT INTO genr_svfmr_data (grsv_name,grsv_class_name,grsv_script_name,grsv_parm_name) VALUES (?,?,?,?)";
if (! defined($insert{"genr_svfmr_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_svfmr_data"}=0;
#Table:genr_tape_volumes
#delete all rows from the genr_tape_volumes table
$dbh->do("delete from genr_tape_volumes");
#Define the column names for the genr_tape_volumes table to Perl
my $grtvol_name;
my $grtvol_class_name;
my $grtvol_sequence;
my $grtvol_create_date;
my $grtvol_discrete;
my $grtvol_intern_name;
my $grtvol_intern_vols;
my $grtvol_create_name;
#Create and prepare the INSERT statement for genr_tape_volumes
$statement="INSERT INTO genr_tape_volumes (grtvol_name,grtvol_class_name,grtvol_sequence,grtvol_create_date,grtvol_discrete,grtvol_intern_name,grtvol_intern_vols,grtvol_create_name) VALUES (?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_tape_volumes"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tape_volumes"}=0;
#Table:genr_tme_children
#delete all rows from the genr_tme_children table
$dbh->do("delete from genr_tme_children");
#Define the column names for the genr_tme_children table to Perl
my $grtmec_name;
my $grtmec_class_name;
my $grtmec_children;
#Create and prepare the INSERT statement for genr_tme_children
$statement="INSERT INTO genr_tme_children (grtmec_name,grtmec_class_name,grtmec_children) VALUES (?,?,?)";
if (! defined($insert{"genr_tme_children"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tme_children"}=0;
#Table:genr_tme_data
#delete all rows from the genr_tme_data table
$dbh->do("delete from genr_tme_data");
#Define the column names for the genr_tme_data table to Perl
my $grtme_name;
my $grtme_class_name;
my $grtme_parent;
#Create and prepare the INSERT statement for genr_tme_data
$statement="INSERT INTO genr_tme_data (grtme_name,grtme_class_name,grtme_parent) VALUES (?,?,?)";
if (! defined($insert{"genr_tme_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tme_data"}=0;
#Table:genr_tme_group
#delete all rows from the genr_tme_group table
$dbh->do("delete from genr_tme_group");
#Define the column names for the genr_tme_group table to Perl
my $grtmeg_name;
my $grtmeg_class_name;
my $grtmeg_group;
#Create and prepare the INSERT statement for genr_tme_group
$statement="INSERT INTO genr_tme_group (grtmeg_name,grtmeg_class_name,grtmeg_group) VALUES (?,?,?)";
if (! defined($insert{"genr_tme_group"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tme_group"}=0;
#Table:genr_tme_resource
#delete all rows from the genr_tme_resource table
$dbh->do("delete from genr_tme_resource");
#Define the column names for the genr_tme_resource table to Perl
my $grtmer_name;
my $grtmer_class_name;
my $grtmer_origin_role;
my $grtmer_prof_class;
my $grtmer_prof_name;
my $grtmer_access_auth;
my $grtmer_cond_class;
my $grtmer_cond_prof;
#Create and prepare the INSERT statement for genr_tme_resource
$statement="INSERT INTO genr_tme_resource (grtmer_name,grtmer_class_name,grtmer_origin_role,grtmer_prof_class,grtmer_prof_name,grtmer_access_auth,grtmer_cond_class,grtmer_cond_prof) VALUES (?,?,?,?,?,?,?,?)";
if (! defined($insert{"genr_tme_resource"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tme_resource"}=0;
#Table:genr_tme_role
#delete all rows from the genr_tme_role table
$dbh->do("delete from genr_tme_role");
#Define the column names for the genr_tme_role table to Perl
my $grtmee_name;
my $grtmee_class_name;
my $grtmee_role_name;
my $grtmee_access_auth;
my $grtmee_cond_class;
my $grtmee_cond_prof;
#Create and prepare the INSERT statement for genr_tme_role
$statement="INSERT INTO genr_tme_role (grtmee_name,grtmee_class_name,grtmee_role_name,grtmee_access_auth,grtmee_cond_class,grtmee_cond_prof) VALUES (?,?,?,?,?,?)";
if (! defined($insert{"genr_tme_role"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_tme_role"}=0;
#Table:genr_volumes
#delete all rows from the genr_volumes table
$dbh->do("delete from genr_volumes");
#Define the column names for the genr_volumes table to Perl
my $grvol_name;
my $grvol_class_name;
my $grvol_vol_name;
#Create and prepare the INSERT statement for genr_volumes
$statement="INSERT INTO genr_volumes (grvol_name,grvol_class_name,grvol_vol_name) VALUES (?,?,?)";
if (! defined($insert{"genr_volumes"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"genr_volumes"}=0;
#Table:group_bd
#delete all rows from the group_bd table
$dbh->do("delete from group_bd");
#Define the column names for the group_bd table to Perl
my $gpbd_name;
my $gpbd_supgrp_id;
my $gpbd_create_date;
my $gpbd_owner_id;
my $gpbd_uacc;
my $gpbd_notermuacc;
my $gpbd_install_data;
my $gpbd_model;
my $gpbd_universal;
#Create and prepare the INSERT statement for group_bd
$statement="INSERT INTO group_bd (gpbd_name,gpbd_supgrp_id,gpbd_create_date,gpbd_owner_id,gpbd_uacc,gpbd_notermuacc,gpbd_install_data,gpbd_model,gpbd_universal) VALUES (?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"group_bd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_bd"}=0;
#Table:group_dfp_data
#delete all rows from the group_dfp_data table
$dbh->do("delete from group_dfp_data");
#Define the column names for the group_dfp_data table to Perl
my $gpdfp_name;
my $gpdfp_dataappl;
my $gpdfp_dataclas;
my $gpdfp_mgmtclas;
my $gpdfp_storclas;
#Create and prepare the INSERT statement for group_dfp_data
$statement="INSERT INTO group_dfp_data (gpdfp_name,gpdfp_dataappl,gpdfp_dataclas,gpdfp_mgmtclas,gpdfp_storclas) VALUES (?,?,?,?,?)";
if (! defined($insert{"group_dfp_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_dfp_data"}=0;
#Table:group_install_data
#delete all rows from the group_install_data table
$dbh->do("delete from group_install_data");
#Define the column names for the group_install_data table to Perl
my $gpinstd_name;
my $gpinstd_usr_name;
my $gpinstd_usr_data;
my $gpinstd_usr_flag;
#Create and prepare the INSERT statement for group_install_data
$statement="INSERT INTO group_install_data (gpinstd_name,gpinstd_usr_name,gpinstd_usr_data,gpinstd_usr_flag) VALUES (?,?,?,?)";
if (! defined($insert{"group_install_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_install_data"}=0;
#Table:group_members
#delete all rows from the group_members table
$dbh->do("delete from group_members");
#Define the column names for the group_members table to Perl
my $gpmem_name;
my $gpmem_member_id;
my $gpmem_auth;
#Create and prepare the INSERT statement for group_members
$statement="INSERT INTO group_members (gpmem_name,gpmem_member_id,gpmem_auth) VALUES (?,?,?)";
if (! defined($insert{"group_members"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_members"}=0;
#Table:group_omvs_data
#delete all rows from the group_omvs_data table
$dbh->do("delete from group_omvs_data");
#Define the column names for the group_omvs_data table to Perl
my $gpomvs_name;
my $gpomvs_gid;
#Create and prepare the INSERT statement for group_omvs_data
$statement="INSERT INTO group_omvs_data (gpomvs_name,gpomvs_gid) VALUES (?,?)";
if (! defined($insert{"group_omvs_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_omvs_data"}=0;
#Table:group_ovm_data
#delete all rows from the group_ovm_data table
$dbh->do("delete from group_ovm_data");
#Define the column names for the group_ovm_data table to Perl
my $gpovm_name;
my $gpovm_gid;
#Create and prepare the INSERT statement for group_ovm_data
$statement="INSERT INTO group_ovm_data (gpovm_name,gpovm_gid) VALUES (?,?)";
if (! defined($insert{"group_ovm_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_ovm_data"}=0;
#Table:group_subgroups
#delete all rows from the group_subgroups table
$dbh->do("delete from group_subgroups");
#Define the column names for the group_subgroups table to Perl
my $gpsgrp_name;
my $gpsgrp_subgrp_id;
#Create and prepare the INSERT statement for group_subgroups
$statement="INSERT INTO group_subgroups (gpsgrp_name,gpsgrp_subgrp_id) VALUES (?,?)";
if (! defined($insert{"group_subgroups"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_subgroups"}=0;
#Table:group_tme_role
#delete all rows from the group_tme_role table
$dbh->do("delete from group_tme_role");
#Define the column names for the group_tme_role table to Perl
my $gptme_name;
my $gptme_role;
#Create and prepare the INSERT statement for group_tme_role
$statement="INSERT INTO group_tme_role (gptme_name,gptme_role) VALUES (?,?)";
if (! defined($insert{"group_tme_role"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"group_tme_role"}=0;
#Table:user_bd
#delete all rows from the user_bd table
$dbh->do("delete from user_bd");
#Define the column names for the user_bd table to Perl
my $usbd_name;
my $usbd_create_date;
my $usbd_owner_id;
my $usbd_adsp;
my $usbd_special;
my $usbd_oper;
my $usbd_revoke;
my $usbd_grpacc;
my $usbd_pwd_interval;
my $usbd_pwd_date;
my $usbd_programmer;
my $usbd_defgrp_id;
my $usbd_lastjob_time;
my $usbd_lastjob_date;
my $usbd_install_data;
my $usbd_uaudit;
my $usbd_auditor;
my $usbd_nopwd;
my $usbd_oidcard;
my $usbd_pwd_gen;
my $usbd_revoke_cnt;
my $usbd_model;
my $usbd_seclevel;
my $usbd_revoke_date;
my $usbd_resume_date;
my $usbd_access_sun;
my $usbd_access_mon;
my $usbd_access_tue;
my $usbd_access_wed;
my $usbd_access_thu;
my $usbd_access_fri;
my $usbd_access_sat;
my $usbd_start_time;
my $usbd_end_time;
my $usbd_seclabel;
my $usbd_attribs;
#Create and prepare the INSERT statement for user_bd
$statement="INSERT INTO user_bd (usbd_name,usbd_create_date,usbd_owner_id,usbd_adsp,usbd_special,usbd_oper,usbd_revoke,usbd_grpacc,usbd_pwd_interval,usbd_pwd_date,usbd_programmer,usbd_defgrp_id,usbd_lastjob_time,usbd_lastjob_date,usbd_install_data,usbd_uaudit,usbd_auditor,usbd_nopwd,usbd_oidcard,usbd_pwd_gen,usbd_revoke_cnt,usbd_model,usbd_seclevel,usbd_revoke_date,usbd_resume_date,usbd_access_sun,usbd_access_mon,usbd_access_tue,usbd_access_wed,usbd_access_thu,usbd_access_fri,usbd_access_sat,usbd_start_time,usbd_end_time,usbd_seclabel,usbd_attribs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_bd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_bd"}=0;
#Table:user_categories
#delete all rows from the user_categories table
$dbh->do("delete from user_categories");
#Define the column names for the user_categories table to Perl
my $uscat_name;
my $uscat_category;
#Create and prepare the INSERT statement for user_categories
$statement="INSERT INTO user_categories (uscat_name,uscat_category) VALUES (?,?)";
if (! defined($insert{"user_categories"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_categories"}=0;
#Table:user_cert_data
#delete all rows from the user_cert_data table
$dbh->do("delete from user_cert_data");
#Define the column names for the user_cert_data table to Perl
my $uscert_name;
my $uscert_cert_name;
my $uscert_certlabl;
#Create and prepare the INSERT statement for user_cert_data
$statement="INSERT INTO user_cert_data (uscert_name,uscert_cert_name,uscert_certlabl) VALUES (?,?,?)";
if (! defined($insert{"user_cert_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_cert_data"}=0;
#Table:user_cics_data
#delete all rows from the user_cics_data table
$dbh->do("delete from user_cics_data");
#Define the column names for the user_cics_data table to Perl
my $uscics_name;
my $uscics_opident;
my $uscics_opprty;
my $uscics_noforce;
my $uscics_timeout;
#Create and prepare the INSERT statement for user_cics_data
$statement="INSERT INTO user_cics_data (uscics_name,uscics_opident,uscics_opprty,uscics_noforce,uscics_timeout) VALUES (?,?,?,?,?)";
if (! defined($insert{"user_cics_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_cics_data"}=0;
#Table:user_cics_opclass
#delete all rows from the user_cics_opclass table
$dbh->do("delete from user_cics_opclass");
#Define the column names for the user_cics_opclass table to Perl
my $uscopc_name;
my $uscopc_opclass;
#Create and prepare the INSERT statement for user_cics_opclass
$statement="INSERT INTO user_cics_opclass (uscopc_name,uscopc_opclass) VALUES (?,?)";
if (! defined($insert{"user_cics_opclass"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_cics_opclass"}=0;
#Table:user_classes
#delete all rows from the user_classes table
$dbh->do("delete from user_classes");
#Define the column names for the user_classes table to Perl
my $uscla_name;
my $uscla_class;
#Create and prepare the INSERT statement for user_classes
$statement="INSERT INTO user_classes (uscla_name,uscla_class) VALUES (?,?)";
if (! defined($insert{"user_classes"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_classes"}=0;
#Table:user_connect_data
#delete all rows from the user_connect_data table
$dbh->do("delete from user_connect_data");
#Define the column names for the user_connect_data table to Perl
my $uscon_name;
my $uscon_grp_id;
my $uscon_connect_date;
my $uscon_owner_id;
my $uscon_lastcon_time;
my $uscon_lastcon_date;
my $uscon_uacc;
my $uscon_init_cnt;
my $uscon_grp_adsp;
my $uscon_grp_special;
my $uscon_grp_oper;
my $uscon_revoke;
my $uscon_grp_acc;
my $uscon_notermuacc;
my $uscon_grp_audit;
my $uscon_revoke_date;
my $uscon_resume_date;
#Create and prepare the INSERT statement for user_connect_data
$statement="INSERT INTO user_connect_data (uscon_name,uscon_grp_id,uscon_connect_date,uscon_owner_id,uscon_lastcon_time,uscon_lastcon_date,uscon_uacc,uscon_init_cnt,uscon_grp_adsp,uscon_grp_special,uscon_grp_oper,uscon_revoke,uscon_grp_acc,uscon_notermuacc,uscon_grp_audit,uscon_revoke_date,uscon_resume_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_connect_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_connect_data"}=0;
#Table:user_dce_data
#delete all rows from the user_dce_data table
$dbh->do("delete from user_dce_data");
#Define the column names for the user_dce_data table to Perl
my $usdce_name;
my $usdce_uuid;
my $usdce_dce_name;
my $usdce_homecell;
my $usdce_homeuuid;
my $usdce_autologin;
#Create and prepare the INSERT statement for user_dce_data
$statement="INSERT INTO user_dce_data (usdce_name,usdce_uuid,usdce_dce_name,usdce_homecell,usdce_homeuuid,usdce_autologin) VALUES (?,?,?,?,?,?)";
if (! defined($insert{"user_dce_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_dce_data"}=0;
#Table:user_dfp_data
#delete all rows from the user_dfp_data table
$dbh->do("delete from user_dfp_data");
#Define the column names for the user_dfp_data table to Perl
my $usdfp_name;
my $usdfp_dataappl;
my $usdfp_dataclas;
my $usdfp_mgmtclas;
my $usdfp_storclas;
#Create and prepare the INSERT statement for user_dfp_data
$statement="INSERT INTO user_dfp_data (usdfp_name,usdfp_dataappl,usdfp_dataclas,usdfp_mgmtclas,usdfp_storclas) VALUES (?,?,?,?,?)";
if (! defined($insert{"user_dfp_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_dfp_data"}=0;
#Table:user_eim_data
#delete all rows from the user_eim_data table
$dbh->do("delete from user_eim_data");
#Define the column names for the user_eim_data table to Perl
my $useim_name;
my $useim_ldapprof;
#Create and prepare the INSERT statement for user_eim_data
$statement="INSERT INTO user_eim_data (useim_name,useim_ldapprof) VALUES (?,?)";
if (! defined($insert{"user_eim_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_eim_data"}=0;
#Table:user_groups
#delete all rows from the user_groups table
$dbh->do("delete from user_groups");
#Define the column names for the user_groups table to Perl
my $usgcon_name;
my $usgcon_grp_id;
#Create and prepare the INSERT statement for user_groups
$statement="INSERT INTO user_groups (usgcon_name,usgcon_grp_id) VALUES (?,?)";
if (! defined($insert{"user_groups"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_groups"}=0;
#Table:user_install_data
#delete all rows from the user_install_data table
$dbh->do("delete from user_install_data");
#Define the column names for the user_install_data table to Perl
my $usinstd_name;
my $usinstd_usr_name;
my $usinstd_usr_data;
my $usinstd_usr_flag;
#Create and prepare the INSERT statement for user_install_data
$statement="INSERT INTO user_install_data (usinstd_name,usinstd_usr_name,usinstd_usr_data,usinstd_usr_flag) VALUES (?,?,?,?)";
if (! defined($insert{"user_install_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_install_data"}=0;
#Table:user_kerb_data
#delete all rows from the user_kerb_data table
$dbh->do("delete from user_kerb_data");
#Define the column names for the user_kerb_data table to Perl
my $uskerb_name;
my $uskerb_kerbname;
my $uskerb_max_life;
my $uskerb_key_vers;
my $uskerb_encrpt_des;
my $uskerb_encrpt_des3;
my $uskerb_encrpt_desd;
#Create and prepare the INSERT statement for user_kerb_data
$statement="INSERT INTO user_kerb_data (uskerb_name,uskerb_kerbname,uskerb_max_life,uskerb_key_vers,uskerb_encrpt_des,uskerb_encrpt_des3,uskerb_encrpt_desd) VALUES (?,?,?,?,?,?,?)";
if (! defined($insert{"user_kerb_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_kerb_data"}=0;
#Table:user_language_data
#delete all rows from the user_language_data table
$dbh->do("delete from user_language_data");
#Define the column names for the user_language_data table to Perl
my $uslan_name;
my $uslan_primary;
my $uslan_secondary;
#Create and prepare the INSERT statement for user_language_data
$statement="INSERT INTO user_language_data (uslan_name,uslan_primary,uslan_secondary) VALUES (?,?,?)";
if (! defined($insert{"user_language_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_language_data"}=0;
#Table:user_lnotes_data
#delete all rows from the user_lnotes_data table
$dbh->do("delete from user_lnotes_data");
#Define the column names for the user_lnotes_data table to Perl
my $uslnot_name;
my $uslnot_sname;
#Create and prepare the INSERT statement for user_lnotes_data
$statement="INSERT INTO user_lnotes_data (uslnot_name,uslnot_sname) VALUES (?,?)";
if (! defined($insert{"user_lnotes_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_lnotes_data"}=0;
#Table:user_nds_data
#delete all rows from the user_nds_data table
$dbh->do("delete from user_nds_data");
#Define the column names for the user_nds_data table to Perl
my $usnds_name;
my $usnds_uname;
#Create and prepare the INSERT statement for user_nds_data
$statement="INSERT INTO user_nds_data (usnds_name,usnds_uname) VALUES (?,?)";
if (! defined($insert{"user_nds_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_nds_data"}=0;
#Table:user_netv_data
#delete all rows from the user_netv_data table
$dbh->do("delete from user_netv_data");
#Define the column names for the user_netv_data table to Perl
my $usnetv_name;
my $usnetv_ic;
my $usnetv_consname;
my $usnetv_ctl;
my $usnetv_msgrecvr;
my $usnetv_ngmfadmn;
my $usnetv_ngmfvspn;
#Create and prepare the INSERT statement for user_netv_data
$statement="INSERT INTO user_netv_data (usnetv_name,usnetv_ic,usnetv_consname,usnetv_ctl,usnetv_msgrecvr,usnetv_ngmfadmn,usnetv_ngmfvspn) VALUES (?,?,?,?,?,?,?)";
if (! defined($insert{"user_netv_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_netv_data"}=0;
#Table:user_netv_domains
#delete all rows from the user_netv_domains table
$dbh->do("delete from user_netv_domains");
#Define the column names for the user_netv_domains table to Perl
my $usndom_name;
my $usndom_domains;
#Create and prepare the INSERT statement for user_netv_domains
$statement="INSERT INTO user_netv_domains (usndom_name,usndom_domains) VALUES (?,?)";
if (! defined($insert{"user_netv_domains"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_netv_domains"}=0;
#Table:user_netv_opclass
#delete all rows from the user_netv_opclass table
$dbh->do("delete from user_netv_opclass");
#Define the column names for the user_netv_opclass table to Perl
my $usnopc_name;
my $usnopc_opclass;
#Create and prepare the INSERT statement for user_netv_opclass
$statement="INSERT INTO user_netv_opclass (usnopc_name,usnopc_opclass) VALUES (?,?)";
if (! defined($insert{"user_netv_opclass"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_netv_opclass"}=0;
#Table:user_nmap_data
#delete all rows from the user_nmap_data table
$dbh->do("delete from user_nmap_data");
#Define the column names for the user_nmap_data table to Perl
my $usnmap_name;
my $usnmap_label;
my $usnmap_map_name;
#Create and prepare the INSERT statement for user_nmap_data
$statement="INSERT INTO user_nmap_data (usnmap_name,usnmap_label,usnmap_map_name) VALUES (?,?,?)";
if (! defined($insert{"user_nmap_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_nmap_data"}=0;
#Table:user_omvs_data
#delete all rows from the user_omvs_data table
$dbh->do("delete from user_omvs_data");
#Define the column names for the user_omvs_data table to Perl
my $usomvs_name;
my $usomvs_uid;
my $usomvs_home_path;
my $usomvs_prog_name;
my $usomvs_cputimemax;
my $usomvs_assizemax;
my $usomvs_fileprocmax;
my $usomvs_procusermax;
my $usomvs_threadsmax;
my $usomvs_mmapareamax;
#Create and prepare the INSERT statement for user_omvs_data
$statement="INSERT INTO user_omvs_data (usomvs_name,usomvs_uid,usomvs_home_path,usomvs_prog_name,usomvs_cputimemax,usomvs_assizemax,usomvs_fileprocmax,usomvs_procusermax,usomvs_threadsmax,usomvs_mmapareamax) VALUES (?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_omvs_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_omvs_data"}=0;
#Table:user_operparm_data
#delete all rows from the user_operparm_data table
$dbh->do("delete from user_operparm_data");
#Define the column names for the user_operparm_data table to Perl
my $usopr_name;
my $usopr_storage;
my $usopr_masterauth;
my $usopr_allauth;
my $usopr_sysauth;
my $usopr_ioauth;
my $usopr_consauth;
my $usopr_infoauth;
my $usopr_timestamp;
my $usopr_systemid;
my $usopr_jobid;
my $usopr_msgid;
my $usopr_x;
my $usopr_wtor;
my $usopr_immediate;
my $usopr_critical;
my $usopr_eventual;
my $usopr_info;
my $usopr_nobrodcast;
my $usopr_all;
my $usopr_jobnames;
my $usopr_jobnamest;
my $usopr_sess;
my $usopr_sesst;
my $usopr_status;
my $usopr_routecode001;
my $usopr_routecode002;
my $usopr_routecode003;
my $usopr_routecode004;
my $usopr_routecode005;
my $usopr_routecode006;
my $usopr_routecode007;
my $usopr_routecode008;
my $usopr_routecode009;
my $usopr_routecode010;
my $usopr_routecode011;
my $usopr_routecode012;
my $usopr_routecode013;
my $usopr_routecode014;
my $usopr_routecode015;
my $usopr_routecode016;
my $usopr_routecode017;
my $usopr_routecode018;
my $usopr_routecode019;
my $usopr_routecode020;
my $usopr_routecode021;
my $usopr_routecode022;
my $usopr_routecode023;
my $usopr_routecode024;
my $usopr_routecode025;
my $usopr_routecode026;
my $usopr_routecode027;
my $usopr_routecode028;
my $usopr_routecode029;
my $usopr_routecode030;
my $usopr_routecode031;
my $usopr_routecode032;
my $usopr_routecode033;
my $usopr_routecode034;
my $usopr_routecode035;
my $usopr_routecode036;
my $usopr_routecode037;
my $usopr_routecode038;
my $usopr_routecode039;
my $usopr_routecode040;
my $usopr_routecode041;
my $usopr_routecode042;
my $usopr_routecode043;
my $usopr_routecode044;
my $usopr_routecode045;
my $usopr_routecode046;
my $usopr_routecode047;
my $usopr_routecode048;
my $usopr_routecode049;
my $usopr_routecode050;
my $usopr_routecode051;
my $usopr_routecode052;
my $usopr_routecode053;
my $usopr_routecode054;
my $usopr_routecode055;
my $usopr_routecode056;
my $usopr_routecode057;
my $usopr_routecode058;
my $usopr_routecode059;
my $usopr_routecode060;
my $usopr_routecode061;
my $usopr_routecode062;
my $usopr_routecode063;
my $usopr_routecode064;
my $usopr_routecode065;
my $usopr_routecode066;
my $usopr_routecode067;
my $usopr_routecode068;
my $usopr_routecode069;
my $usopr_routecode070;
my $usopr_routecode071;
my $usopr_routecode072;
my $usopr_routecode073;
my $usopr_routecode074;
my $usopr_routecode075;
my $usopr_routecode076;
my $usopr_routecode077;
my $usopr_routecode078;
my $usopr_routecode079;
my $usopr_routecode080;
my $usopr_routecode081;
my $usopr_routecode082;
my $usopr_routecode083;
my $usopr_routecode084;
my $usopr_routecode085;
my $usopr_routecode086;
my $usopr_routecode087;
my $usopr_routecode088;
my $usopr_routecode089;
my $usopr_routecode090;
my $usopr_routecode091;
my $usopr_routecode092;
my $usopr_routecode093;
my $usopr_routecode094;
my $usopr_routecode095;
my $usopr_routecode096;
my $usopr_routecode097;
my $usopr_routecode098;
my $usopr_routecode099;
my $usopr_routecode100;
my $usopr_routecode101;
my $usopr_routecode102;
my $usopr_routecode103;
my $usopr_routecode104;
my $usopr_routecode105;
my $usopr_routecode106;
my $usopr_routecode107;
my $usopr_routecode108;
my $usopr_routecode109;
my $usopr_routecode110;
my $usopr_routecode111;
my $usopr_routecode112;
my $usopr_routecode113;
my $usopr_routecode114;
my $usopr_routecode115;
my $usopr_routecode116;
my $usopr_routecode117;
my $usopr_routecode118;
my $usopr_routecode119;
my $usopr_routecode120;
my $usopr_routecode121;
my $usopr_routecode122;
my $usopr_routecode123;
my $usopr_routecode124;
my $usopr_routecode125;
my $usopr_routecode126;
my $usopr_routecode127;
my $usopr_routecode128;
my $usopr_logcmdresp;
my $usopr_migrationid;
my $usopr_delopermsg;
my $usopr_retrieve_key;
my $usopr_cmdsys;
my $usopr_ud;
my $usopr_altgrp_id;
my $usopr_auto;
#Create and prepare the INSERT statement for user_operparm_data
$statement="INSERT INTO user_operparm_data (usopr_name,usopr_storage,usopr_masterauth,usopr_allauth,usopr_sysauth,usopr_ioauth,usopr_consauth,usopr_infoauth,usopr_timestamp,usopr_systemid,usopr_jobid,usopr_msgid,usopr_x,usopr_wtor,usopr_immediate,usopr_critical,usopr_eventual,usopr_info,usopr_nobrodcast,usopr_all,usopr_jobnames,usopr_jobnamest,usopr_sess,usopr_sesst,usopr_status,usopr_routecode001,usopr_routecode002,usopr_routecode003,usopr_routecode004,usopr_routecode005,usopr_routecode006,usopr_routecode007,usopr_routecode008,usopr_routecode009,usopr_routecode010,usopr_routecode011,usopr_routecode012,usopr_routecode013,usopr_routecode014,usopr_routecode015,usopr_routecode016,usopr_routecode017,usopr_routecode018,usopr_routecode019,usopr_routecode020,usopr_routecode021,usopr_routecode022,usopr_routecode023,usopr_routecode024,usopr_routecode025,usopr_routecode026,usopr_routecode027,usopr_routecode028,usopr_routecode029,usopr_routecode030,usopr_routecode031,usopr_routecode032,usopr_routecode033,usopr_routecode034,usopr_routecode035,usopr_routecode036,usopr_routecode037,usopr_routecode038,usopr_routecode039,usopr_routecode040,usopr_routecode041,usopr_routecode042,usopr_routecode043,usopr_routecode044,usopr_routecode045,usopr_routecode046,usopr_routecode047,usopr_routecode048,usopr_routecode049,usopr_routecode050,usopr_routecode051,usopr_routecode052,usopr_routecode053,usopr_routecode054,usopr_routecode055,usopr_routecode056,usopr_routecode057,usopr_routecode058,usopr_routecode059,usopr_routecode060,usopr_routecode061,usopr_routecode062,usopr_routecode063,usopr_routecode064,usopr_routecode065,usopr_routecode066,usopr_routecode067,usopr_routecode068,usopr_routecode069,usopr_routecode070,usopr_routecode071,usopr_routecode072,usopr_routecode073,usopr_routecode074,usopr_routecode075,usopr_routecode076,usopr_routecode077,usopr_routecode078,usopr_routecode079,usopr_routecode080,usopr_routecode081,usopr_routecode082,usopr_routecode083,usopr_routecode084,usopr_routecode085,usopr_routecode086,usopr_routecode087,usopr_routecode088,usopr_routecode089,usopr_routecode090,usopr_routecode091,usopr_routecode092,usopr_routecode093,usopr_routecode094,usopr_routecode095,usopr_routecode096,usopr_routecode097,usopr_routecode098,usopr_routecode099,usopr_routecode100,usopr_routecode101,usopr_routecode102,usopr_routecode103,usopr_routecode104,usopr_routecode105,usopr_routecode106,usopr_routecode107,usopr_routecode108,usopr_routecode109,usopr_routecode110,usopr_routecode111,usopr_routecode112,usopr_routecode113,usopr_routecode114,usopr_routecode115,usopr_routecode116,usopr_routecode117,usopr_routecode118,usopr_routecode119,usopr_routecode120,usopr_routecode121,usopr_routecode122,usopr_routecode123,usopr_routecode124,usopr_routecode125,usopr_routecode126,usopr_routecode127,usopr_routecode128,usopr_logcmdresp,usopr_migrationid,usopr_delopermsg,usopr_retrieve_key,usopr_cmdsys,usopr_ud,usopr_altgrp_id,usopr_auto) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_operparm_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_operparm_data"}=0;
#Table:user_operparm_scop
#delete all rows from the user_operparm_scop table
$dbh->do("delete from user_operparm_scop");
#Define the column names for the user_operparm_scop table to Perl
my $usoprp_name;
my $usoprp_system;
#Create and prepare the INSERT statement for user_operparm_scop
$statement="INSERT INTO user_operparm_scop (usoprp_name,usoprp_system) VALUES (?,?)";
if (! defined($insert{"user_operparm_scop"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_operparm_scop"}=0;
#Table:user_ovm_data
#delete all rows from the user_ovm_data table
$dbh->do("delete from user_ovm_data");
#Define the column names for the user_ovm_data table to Perl
my $usovm_name;
my $usovm_uid;
my $usovm_home_path;
my $usovm_program;
my $usovm_fsroot;
#Create and prepare the INSERT statement for user_ovm_data
$statement="INSERT INTO user_ovm_data (usovm_name,usovm_uid,usovm_home_path,usovm_program,usovm_fsroot) VALUES (?,?,?,?,?)";
if (! defined($insert{"user_ovm_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_ovm_data"}=0;
#Table:user_proxy_data
#delete all rows from the user_proxy_data table
$dbh->do("delete from user_proxy_data");
#Define the column names for the user_proxy_data table to Perl
my $usproxy_name;
my $usproxy_ldap_host;
my $usproxy_bind_dn;
#Create and prepare the INSERT statement for user_proxy_data
$statement="INSERT INTO user_proxy_data (usproxy_name,usproxy_ldap_host,usproxy_bind_dn) VALUES (?,?,?)";
if (! defined($insert{"user_proxy_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_proxy_data"}=0;
#Table:user_rrsf_data
#delete all rows from the user_rrsf_data table
$dbh->do("delete from user_rrsf_data");
#Define the column names for the user_rrsf_data table to Perl
my $usrsf_name;
my $usrsf_targ_node;
my $usrsf_targ_user_id;
my $usrsf_version;
my $usrsf_peer;
my $usrsf_managing;
my $usrsf_managed;
my $usrsf_remote_pend;
my $usrsf_local_pend;
my $usrsf_pwd_sync;
my $usrsf_rem_refusal;
my $usrsf_define_date;
my $usrsf_define_time;
my $usrsf_accept_date;
my $usrsf_accept_time;
my $usrsf_creator_id;
#Create and prepare the INSERT statement for user_rrsf_data
$statement="INSERT INTO user_rrsf_data (usrsf_name,usrsf_targ_node,usrsf_targ_user_id,usrsf_version,usrsf_peer,usrsf_managing,usrsf_managed,usrsf_remote_pend,usrsf_local_pend,usrsf_pwd_sync,usrsf_rem_refusal,usrsf_define_date,usrsf_define_time,usrsf_accept_date,usrsf_accept_time,usrsf_creator_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_rrsf_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_rrsf_data"}=0;
#Table:user_tso_data
#delete all rows from the user_tso_data table
$dbh->do("delete from user_tso_data");
#Define the column names for the user_tso_data table to Perl
my $ustso_name;
my $ustso_account;
my $ustso_command;
my $ustso_dest;
my $ustso_hold_class;
my $ustso_job_class;
my $ustso_logon_proc;
my $ustso_logon_size;
my $ustso_msg_class;
my $ustso_logon_max;
my $ustso_perf_group;
my $ustso_sysout_class;
my $ustso_user_data;
my $ustso_unit_name;
my $ustso_seclabel;
#Create and prepare the INSERT statement for user_tso_data
$statement="INSERT INTO user_tso_data (ustso_name,ustso_account,ustso_command,ustso_dest,ustso_hold_class,ustso_job_class,ustso_logon_proc,ustso_logon_size,ustso_msg_class,ustso_logon_max,ustso_perf_group,ustso_sysout_class,ustso_user_data,ustso_unit_name,ustso_seclabel) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_tso_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_tso_data"}=0;
#Table:user_workattr_data
#delete all rows from the user_workattr_data table
$dbh->do("delete from user_workattr_data");
#Define the column names for the user_workattr_data table to Perl
my $uswrk_name;
my $uswrk_area_name;
my $uswrk_building;
my $uswrk_department;
my $uswrk_room;
my $uswrk_addr_line1;
my $uswrk_addr_line2;
my $uswrk_addr_line3;
my $uswrk_addr_line4;
my $uswrk_account;
#Create and prepare the INSERT statement for user_workattr_data
$statement="INSERT INTO user_workattr_data (uswrk_name,uswrk_area_name,uswrk_building,uswrk_department,uswrk_room,uswrk_addr_line1,uswrk_addr_line2,uswrk_addr_line3,uswrk_addr_line4,uswrk_account) VALUES (?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"user_workattr_data"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"user_workattr_data"}=0;
while(<>) {
	s/\x00/ /g; #change nulls to spaces
	if (0 == $. % 1000) { print "Processed $. lines.\n";}
	$rectype=substr($_,0,4);
	if ($rectype eq '0404') {
		$dsacc_name=substr($_,5,44);
		$dsacc_vol=substr($_,50,6);
		$dsacc_auth_id=substr($_,57,8);
		$dsacc_access=substr($_,66,8);
		$dsacc_access_cnt=substr($_,75,5);
		$rv=$insert{ds_access}->execute($dsacc_name,$dsacc_vol,$dsacc_auth_id,$dsacc_access,$dsacc_access_cnt);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_access"}++;
		next;
	}

	if ($rectype eq '0400') {
		$dsbd_name=substr($_,5,44);
		$dsbd_vol=substr($_,50,6);
		$dsbd_generic=substr($_,57,1);
		$dsbd_create_date=substr($_,62,10);
		$dsbd_owner_id=substr($_,73,8);
		$dsbd_lastref_date=substr($_,82,10);
		if ($dsbd_lastref_date eq ' ' x length($dsbd_lastref_date)) {
			undef $dsbd_lastref_date;
		}
		$dsbd_lastchg_date=substr($_,93,10);
		if ($dsbd_lastchg_date eq ' ' x length($dsbd_lastchg_date)) {
			undef $dsbd_lastchg_date;
		}
		$dsbd_alter_cnt=substr($_,104,5);
		$dsbd_control_cnt=substr($_,110,5);
		$dsbd_update_cnt=substr($_,116,5);
		$dsbd_read_cnt=substr($_,122,5);
		$dsbd_uacc=substr($_,128,8);
		$dsbd_grpds=substr($_,137,1);
		$dsbd_audit_level=substr($_,142,8);
		$dsbd_grp_id=substr($_,151,8);
		$dsbd_ds_type=substr($_,160,8);
		$dsbd_level=substr($_,169,3);
		$dsbd_device_name=substr($_,173,8);
		$dsbd_gaudit_level=substr($_,182,8);
		$dsbd_install_data=substr($_,191,254);
		$dsbd_audit_okqual=substr($_,447,8);
		$dsbd_audit_faqual=substr($_,456,8);
		$dsbd_gaudit_okqual=substr($_,465,8);
		$dsbd_gaudit_faqual=substr($_,474,8);
		$dsbd_warning=substr($_,483,1);
		$dsbd_seclevel=substr($_,488,3);
		$dsbd_notify_id=substr($_,492,8);
		$dsbd_retention=substr($_,501,5);
		$dsbd_erase=substr($_,507,1);
		$dsbd_seclabel=substr($_,512,8);
		$rv=$insert{ds_bd}->execute($dsbd_name,$dsbd_vol,$dsbd_generic,$dsbd_create_date,$dsbd_owner_id,$dsbd_lastref_date,$dsbd_lastchg_date,$dsbd_alter_cnt,$dsbd_control_cnt,$dsbd_update_cnt,$dsbd_read_cnt,$dsbd_uacc,$dsbd_grpds,$dsbd_audit_level,$dsbd_grp_id,$dsbd_ds_type,$dsbd_level,$dsbd_device_name,$dsbd_gaudit_level,$dsbd_install_data,$dsbd_audit_okqual,$dsbd_audit_faqual,$dsbd_gaudit_okqual,$dsbd_gaudit_faqual,$dsbd_warning,$dsbd_seclevel,$dsbd_notify_id,$dsbd_retention,$dsbd_erase,$dsbd_seclabel);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_bd"}++;
		next;
	}

	if ($rectype eq '0401') {
		$dscat_name=substr($_,5,44);
		$dscat_vol=substr($_,50,6);
		$dscat_category=substr($_,57,5);
		$rv=$insert{ds_categories}->execute($dscat_name,$dscat_vol,$dscat_category);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_categories"}++;
		next;
	}

	if ($rectype eq '0402') {
		$dscacc_name=substr($_,5,44);
		$dscacc_vol=substr($_,50,6);
		$dscacc_catype=substr($_,57,8);
		$dscacc_caname=substr($_,66,8);
		$dscacc_auth_id=substr($_,75,8);
		$dscacc_access=substr($_,84,8);
		$dscacc_access_cnt=substr($_,93,5);
		$dscacc_net_id=substr($_,99,8);
		$rv=$insert{ds_cond_access}->execute($dscacc_name,$dscacc_vol,$dscacc_catype,$dscacc_caname,$dscacc_auth_id,$dscacc_access,$dscacc_access_cnt,$dscacc_net_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_cond_access"}++;
		next;
	}

	if ($rectype eq '0410') {
		$dsdfp_name=substr($_,5,44);
		$dsdfp_vol=substr($_,50,6);
		$dsdfp_resowner_id=substr($_,57,8);
		$rv=$insert{ds_dfp_data}->execute($dsdfp_name,$dsdfp_vol,$dsdfp_resowner_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_dfp_data"}++;
		next;
	}

	if ($rectype eq '0405') {
		$dsinstd_name=substr($_,5,44);
		$dsinstd_vol=substr($_,50,6);
		$dsinstd_usr_name=substr($_,57,8);
		$dsinstd_usr_data=substr($_,66,254);
		$dsinstd_usr_flag=substr($_,322,8);
		$rv=$insert{ds_install_data}->execute($dsinstd_name,$dsinstd_vol,$dsinstd_usr_name,$dsinstd_usr_data,$dsinstd_usr_flag);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_install_data"}++;
		next;
	}

	if ($rectype eq '0421') {
		$dstme_name=substr($_,5,44);
		$dstme_vol=substr($_,50,6);
		$dstme_role_name=substr($_,57,246);
		$dstme_access_auth=substr($_,304,8);
		$dstme_cond_class=substr($_,313,8);
		$dstme_cond_prof=substr($_,322,246);
		$rv=$insert{ds_tme_role}->execute($dstme_name,$dstme_vol,$dstme_role_name,$dstme_access_auth,$dstme_cond_class,$dstme_cond_prof);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_tme_role"}++;
		next;
	}

	if ($rectype eq '0403') {
		$dsvol_name=substr($_,5,44);
		$dsvol_vol=substr($_,50,6);
		$dsvol_vol_name=substr($_,57,6);
		$rv=$insert{ds_volumes}->execute($dsvol_name,$dsvol_vol,$dsvol_vol_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ds_volumes"}++;
		next;
	}

	if ($rectype eq '0505') {
		$gracc_name=substr($_,5,246);
		$gracc_class_name=substr($_,252,8);
		$gracc_auth_id=substr($_,261,8);
		$gracc_access=substr($_,270,8);
		$gracc_access_cnt=substr($_,279,5);
		$rv=$insert{genr_access}->execute($gracc_name,$gracc_class_name,$gracc_auth_id,$gracc_access,$gracc_access_cnt);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_access"}++;
		next;
	}

	if ($rectype eq '0500') {
		$grbd_name=substr($_,5,246);
		$grbd_class_name=substr($_,252,8);
		$grbd_generic=substr($_,261,1);
		$grbd_class=substr($_,266,3);
		$grbd_create_date=substr($_,270,10);
		$grbd_owner_id=substr($_,281,8);
		$grbd_lastref_date=substr($_,290,10);
		if ($grbd_lastref_date eq ' ' x length($grbd_lastref_date)) {
			undef $grbd_lastref_date;
		}
		$grbd_lastchg_date=substr($_,301,10);
		if ($grbd_lastchg_date eq ' ' x length($grbd_lastchg_date)) {
			undef $grbd_lastchg_date;
		}
		$grbd_alter_cnt=substr($_,312,5);
		$grbd_control_cnt=substr($_,318,5);
		$grbd_update_cnt=substr($_,324,5);
		$grbd_read_cnt=substr($_,330,5);
		$grbd_uacc=substr($_,336,8);
		$grbd_audit_level=substr($_,345,8);
		$grbd_level=substr($_,354,3);
		$grbd_gaudit_level=substr($_,358,8);
		$grbd_install_data=substr($_,367,254);
		$grbd_audit_okqual=substr($_,623,8);
		$grbd_audit_faqual=substr($_,632,8);
		$grbd_gaudit_okqual=substr($_,641,8);
		$grbd_gaudit_faqual=substr($_,650,8);
		$grbd_warning=substr($_,659,1);
		$grbd_singleds=substr($_,664,1);
		$grbd_auto=substr($_,669,1);
		$grbd_tvtoc=substr($_,674,1);
		$grbd_notify_id=substr($_,679,8);
		$grbd_access_sun=substr($_,688,1);
		$grbd_access_mon=substr($_,693,1);
		$grbd_access_tue=substr($_,698,1);
		$grbd_access_wed=substr($_,703,1);
		$grbd_access_thu=substr($_,708,1);
		$grbd_access_fri=substr($_,713,1);
		$grbd_access_sat=substr($_,718,1);
		$grbd_start_time=substr($_,723,8);
		if ($grbd_start_time eq ' ' x length($grbd_start_time)) {
			undef $grbd_start_time;
		}
		$grbd_end_time=substr($_,732,8);
		if ($grbd_end_time eq ' ' x length($grbd_end_time)) {
			undef $grbd_end_time;
		}
		$grbd_zone_offset=substr($_,741,5);
		if ($grbd_zone_offset eq ' ' x length($grbd_zone_offset)) {
			undef $grbd_zone_offset;
		}
		$grbd_zone_direct=substr($_,747,1);
		$grbd_seclevel=substr($_,749,3);
		$grbd_appl_data=substr($_,753,254);
		$grbd_seclabel=substr($_,1009,8);
		$rv=$insert{genr_bd}->execute($grbd_name,$grbd_class_name,$grbd_generic,$grbd_class,$grbd_create_date,$grbd_owner_id,$grbd_lastref_date,$grbd_lastchg_date,$grbd_alter_cnt,$grbd_control_cnt,$grbd_update_cnt,$grbd_read_cnt,$grbd_uacc,$grbd_audit_level,$grbd_level,$grbd_gaudit_level,$grbd_install_data,$grbd_audit_okqual,$grbd_audit_faqual,$grbd_gaudit_okqual,$grbd_gaudit_faqual,$grbd_warning,$grbd_singleds,$grbd_auto,$grbd_tvtoc,$grbd_notify_id,$grbd_access_sun,$grbd_access_mon,$grbd_access_tue,$grbd_access_wed,$grbd_access_thu,$grbd_access_fri,$grbd_access_sat,$grbd_start_time,$grbd_end_time,$grbd_zone_offset,$grbd_zone_direct,$grbd_seclevel,$grbd_appl_data,$grbd_seclabel);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_bd"}++;
		next;
	}

	if ($rectype eq '0502') {
		$grcat_name=substr($_,5,246);
		$grcat_class_name=substr($_,252,8);
		$grcat_category=substr($_,261,5);
		$rv=$insert{genr_categories}->execute($grcat_name,$grcat_class_name,$grcat_category);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_categories"}++;
		next;
	}

	if ($rectype eq '0560') {
		$grcert_name=substr($_,5,246);
		$grcert_class_name=substr($_,252,8);
		$grcert_start_date=substr($_,261,10);
		if ($grcert_start_date eq ' ' x length($grcert_start_date)) {
			undef $grcert_start_date;
		}
		$grcert_start_time=substr($_,272,8);
		if ($grcert_start_time eq ' ' x length($grcert_start_time)) {
			undef $grcert_start_time;
		}
		$grcert_end_date=substr($_,281,10);
		if ($grcert_end_date eq ' ' x length($grcert_end_date)) {
			undef $grcert_end_date;
		}
		$grcert_end_time=substr($_,292,8);
		if ($grcert_end_time eq ' ' x length($grcert_end_time)) {
			undef $grcert_end_time;
		}
		$grcert_key_type=substr($_,301,8);
		$grcert_key_size=substr($_,310,10);
		$grcert_last_serial=substr($_,321,16);
		$grcert_ring_seqn=substr($_,338,10);
		$rv=$insert{genr_cert_data}->execute($grcert_name,$grcert_class_name,$grcert_start_date,$grcert_start_time,$grcert_end_date,$grcert_end_time,$grcert_key_type,$grcert_key_size,$grcert_last_serial,$grcert_ring_seqn);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_cert_data"}++;
		next;
	}

	if ($rectype eq '0561') {
		$certr_name=substr($_,5,246);
		$certr_class_name=substr($_,252,8);
		$certr_ring_name=substr($_,261,246);
		$rv=$insert{genr_certr_data}->execute($certr_name,$certr_class_name,$certr_ring_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_certr_data"}++;
		next;
	}

	if ($rectype eq '0507') {
		$grcacc_name=substr($_,5,246);
		$grcacc_class_name=substr($_,252,8);
		$grcacc_catype=substr($_,261,8);
		$grcacc_caname=substr($_,270,8);
		$grcacc_auth_id=substr($_,279,8);
		$grcacc_access=substr($_,288,8);
		$grcacc_access_cnt=substr($_,297,5);
		$grcacc_net_id=substr($_,303,8);
		$rv=$insert{genr_cond_access}->execute($grcacc_name,$grcacc_class_name,$grcacc_catype,$grcacc_caname,$grcacc_auth_id,$grcacc_access,$grcacc_access_cnt,$grcacc_net_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_cond_access"}++;
		next;
	}

	if ($rectype eq '0520') {
		$grdlf_name=substr($_,5,246);
		$grdlf_class_name=substr($_,252,8);
		$grdlf_retain=substr($_,261,1);
		$rv=$insert{genr_dlf_data}->execute($grdlf_name,$grdlf_class_name,$grdlf_retain);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_dlf_data"}++;
		next;
	}

	if ($rectype eq '0521') {
		$grdlfj_name=substr($_,5,246);
		$grdlfj_class_name=substr($_,252,8);
		$grdlfj_job_name=substr($_,261,8);
		$rv=$insert{genr_dlf_job_names}->execute($grdlfj_name,$grdlfj_class_name,$grdlfj_job_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_dlf_job_names"}++;
		next;
	}

	if ($rectype eq '05A0') {
		$greim_name=substr($_,5,246);
		$greim_class_name=substr($_,252,8);
		$greim_domain_dn=substr($_,261,1023);
		$greim_enable=substr($_,1285,1);
		$greim_local_reg=substr($_,1365,255);
		$rv=$insert{genr_eim_data}->execute($greim_name,$greim_class_name,$greim_domain_dn,$greim_enable,$greim_local_reg);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_eim_data"}++;
		next;
	}

	if ($rectype eq '0508') {
		$grfltr_name=substr($_,5,246);
		$grfltr_class_name=substr($_,252,8);
		$grfltr_label=substr($_,261,32);
		$grfltr_status=substr($_,294,8);
		$grfltr_user=substr($_,303,246);
		$grfltr_create_name=substr($_,550,511);
		$rv=$insert{genr_filter_data}->execute($grfltr_name,$grfltr_class_name,$grfltr_label,$grfltr_status,$grfltr_user,$grfltr_create_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_filter_data"}++;
		next;
	}

	if ($rectype eq '0506') {
		$grinstd_name=substr($_,5,246);
		$grinstd_class_name=substr($_,252,8);
		$grinstd_usr_name=substr($_,261,8);
		$grinstd_usr_data=substr($_,270,254);
		$grinstd_usr_flag=substr($_,526,8);
		$rv=$insert{genr_install_data}->execute($grinstd_name,$grinstd_class_name,$grinstd_usr_name,$grinstd_usr_data,$grinstd_usr_flag);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_install_data"}++;
		next;
	}

	if ($rectype eq '0580') {
		$grkerb_name=substr($_,5,246);
		$grkerb_class_name=substr($_,252,8);
		$grkerb_kerbname=substr($_,261,240);
		$grkerb_min_life=substr($_,502,10);
		if ($grkerb_min_life eq ' ' x length($grkerb_min_life)) {
			undef $grkerb_min_life;
		}
		$grkerb_max_life=substr($_,513,10);
		if ($grkerb_max_life eq ' ' x length($grkerb_max_life)) {
			undef $grkerb_max_life;
		}
		$grkerb_def_life=substr($_,524,10);
		if ($grkerb_def_life eq ' ' x length($grkerb_def_life)) {
			undef $grkerb_def_life;
		}
		$grkerb_key_vers=substr($_,535,3);
		if ($grkerb_key_vers eq ' ' x length($grkerb_key_vers)) {
			undef $grkerb_key_vers;
		}
		$grkerb_encrpt_des=substr($_,539,1);
		$grkerb_encrpt_des3=substr($_,544,1);
		$grkerb_encrpt_desd=substr($_,549,1);
		$rv=$insert{genr_kerb_data}->execute($grkerb_name,$grkerb_class_name,$grkerb_kerbname,$grkerb_min_life,$grkerb_max_life,$grkerb_def_life,$grkerb_key_vers,$grkerb_encrpt_des,$grkerb_encrpt_des3,$grkerb_encrpt_desd);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_kerb_data"}++;
		next;
	}

	if ($rectype eq '0562') {
		$keyr_name=substr($_,5,246);
		$keyr_class_name=substr($_,252,8);
		$keyr_cert_name=substr($_,261,246);
		$keyr_cert_usage=substr($_,508,8);
		$keyr_cert_default=substr($_,517,1);
		$keyr_cert_label=substr($_,522,32);
		$rv=$insert{genr_keyr_data}->execute($keyr_name,$keyr_class_name,$keyr_cert_name,$keyr_cert_usage,$keyr_cert_default,$keyr_cert_label);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_keyr_data"}++;
		next;
	}

	if ($rectype eq '0503') {
		$grmem_name=substr($_,5,246);
		$grmem_class_name=substr($_,252,8);
		$grmem_member=substr($_,261,254);
		$grmem_global_acc=substr($_,517,8);
		$grmem_pads_data=substr($_,526,8);
		$grmem_vol_name=substr($_,535,6);
		$grmem_vmevent_data=substr($_,542,5);
		$grmem_seclevel=substr($_,548,5);
		if ($grmem_seclevel eq ' ' x length($grmem_seclevel)) {
			undef $grmem_seclevel;
		}
		$grmem_category=substr($_,554,5);
		if ($grmem_category eq ' ' x length($grmem_category)) {
			undef $grmem_category;
		}
		$rv=$insert{genr_members}->execute($grmem_name,$grmem_class_name,$grmem_member,$grmem_global_acc,$grmem_pads_data,$grmem_vol_name,$grmem_vmevent_data,$grmem_seclevel,$grmem_category);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_members"}++;
		next;
	}

	if ($rectype eq '0590') {
		$grproxy_name=substr($_,5,246);
		$grproxy_class_name=substr($_,252,8);
		$grproxy_ldap_host=substr($_,261,1023);
		$grproxy_bind_dn=substr($_,1285,1023);
		$rv=$insert{genr_proxy_data}->execute($grproxy_name,$grproxy_class_name,$grproxy_ldap_host,$grproxy_bind_dn);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_proxy_data"}++;
		next;
	}

	if ($rectype eq '0510') {
		$grses_name=substr($_,5,246);
		$grses_class_name=substr($_,252,8);
		$grses_session_key=substr($_,261,8);
		$grses_locked=substr($_,270,1);
		$grses_key_date=substr($_,275,10);
		if ($grses_key_date eq ' ' x length($grses_key_date)) {
			undef $grses_key_date;
		}
		$grses_key_interval=substr($_,286,5);
		$grses_sls_fail=substr($_,292,5);
		$grses_max_fail=substr($_,298,5);
		$grses_convsec=substr($_,304,8);
		$rv=$insert{genr_session_data}->execute($grses_name,$grses_class_name,$grses_session_key,$grses_locked,$grses_key_date,$grses_key_interval,$grses_sls_fail,$grses_max_fail,$grses_convsec);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_session_data"}++;
		next;
	}

	if ($rectype eq '0511') {
		$grsese_name=substr($_,5,246);
		$grsese_class_name=substr($_,252,8);
		$grsese_entity_name=substr($_,261,35);
		$grsese_fail_cnt=substr($_,297,5);
		$rv=$insert{genr_session_ent}->execute($grsese_name,$grsese_class_name,$grsese_entity_name,$grsese_fail_cnt);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_session_ent"}++;
		next;
	}

	if ($rectype eq '0540') {
		$grst_name=substr($_,5,246);
		$grst_class_name=substr($_,252,8);
		$grst_user_id=substr($_,261,8);
		$grst_group_id=substr($_,270,8);
		$grst_trusted=substr($_,279,1);
		$grst_privileged=substr($_,284,1);
		$grst_trace=substr($_,289,1);
		$rv=$insert{genr_stdata_data}->execute($grst_name,$grst_class_name,$grst_user_id,$grst_group_id,$grst_trusted,$grst_privileged,$grst_trace);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_stdata_data"}++;
		next;
	}

	if ($rectype eq '0550') {
		$grsv_name=substr($_,5,246);
		$grsv_class_name=substr($_,252,8);
		$grsv_script_name=substr($_,261,8);
		$grsv_parm_name=substr($_,270,8);
		$rv=$insert{genr_svfmr_data}->execute($grsv_name,$grsv_class_name,$grsv_script_name,$grsv_parm_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_svfmr_data"}++;
		next;
	}

	if ($rectype eq '0501') {
		$grtvol_name=substr($_,5,246);
		$grtvol_class_name=substr($_,252,8);
		$grtvol_sequence=substr($_,261,5);
		$grtvol_create_date=substr($_,267,10);
		if ($grtvol_create_date eq ' ' x length($grtvol_create_date)) {
			undef $grtvol_create_date;
		}
		$grtvol_discrete=substr($_,278,1);
		$grtvol_intern_name=substr($_,283,44);
		$grtvol_intern_vols=substr($_,328,254);
		$grtvol_create_name=substr($_,584,44);
		$rv=$insert{genr_tape_volumes}->execute($grtvol_name,$grtvol_class_name,$grtvol_sequence,$grtvol_create_date,$grtvol_discrete,$grtvol_intern_name,$grtvol_intern_vols,$grtvol_create_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tape_volumes"}++;
		next;
	}

	if ($rectype eq '0571') {
		$grtmec_name=substr($_,5,246);
		$grtmec_class_name=substr($_,252,8);
		$grtmec_children=substr($_,261,246);
		$rv=$insert{genr_tme_children}->execute($grtmec_name,$grtmec_class_name,$grtmec_children);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tme_children"}++;
		next;
	}

	if ($rectype eq '0570') {
		$grtme_name=substr($_,5,246);
		$grtme_class_name=substr($_,252,8);
		$grtme_parent=substr($_,261,246);
		$rv=$insert{genr_tme_data}->execute($grtme_name,$grtme_class_name,$grtme_parent);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tme_data"}++;
		next;
	}

	if ($rectype eq '0573') {
		$grtmeg_name=substr($_,5,246);
		$grtmeg_class_name=substr($_,252,8);
		$grtmeg_group=substr($_,261,8);
		$rv=$insert{genr_tme_group}->execute($grtmeg_name,$grtmeg_class_name,$grtmeg_group);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tme_group"}++;
		next;
	}

	if ($rectype eq '0572') {
		$grtmer_name=substr($_,5,246);
		$grtmer_class_name=substr($_,252,8);
		$grtmer_origin_role=substr($_,261,246);
		$grtmer_prof_class=substr($_,508,8);
		$grtmer_prof_name=substr($_,517,246);
		$grtmer_access_auth=substr($_,764,8);
		$grtmer_cond_class=substr($_,773,8);
		$grtmer_cond_prof=substr($_,782,246);
		$rv=$insert{genr_tme_resource}->execute($grtmer_name,$grtmer_class_name,$grtmer_origin_role,$grtmer_prof_class,$grtmer_prof_name,$grtmer_access_auth,$grtmer_cond_class,$grtmer_cond_prof);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tme_resource"}++;
		next;
	}

	if ($rectype eq '0574') {
		$grtmee_name=substr($_,5,246);
		$grtmee_class_name=substr($_,252,8);
		$grtmee_role_name=substr($_,261,246);
		$grtmee_access_auth=substr($_,508,8);
		$grtmee_cond_class=substr($_,517,8);
		$grtmee_cond_prof=substr($_,526,246);
		$rv=$insert{genr_tme_role}->execute($grtmee_name,$grtmee_class_name,$grtmee_role_name,$grtmee_access_auth,$grtmee_cond_class,$grtmee_cond_prof);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_tme_role"}++;
		next;
	}

	if ($rectype eq '0504') {
		$grvol_name=substr($_,5,246);
		$grvol_class_name=substr($_,252,8);
		$grvol_vol_name=substr($_,261,6);
		$rv=$insert{genr_volumes}->execute($grvol_name,$grvol_class_name,$grvol_vol_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"genr_volumes"}++;
		next;
	}

	if ($rectype eq '0100') {
		$gpbd_name=substr($_,5,8);
		$gpbd_supgrp_id=substr($_,14,8);
		$gpbd_create_date=substr($_,23,10);
		$gpbd_owner_id=substr($_,34,8);
		$gpbd_uacc=substr($_,43,8);
		$gpbd_notermuacc=substr($_,52,1);
		$gpbd_install_data=substr($_,57,254);
		$gpbd_model=substr($_,313,44);
		$gpbd_universal=substr($_,358,1);
		$rv=$insert{group_bd}->execute($gpbd_name,$gpbd_supgrp_id,$gpbd_create_date,$gpbd_owner_id,$gpbd_uacc,$gpbd_notermuacc,$gpbd_install_data,$gpbd_model,$gpbd_universal);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_bd"}++;
		next;
	}

	if ($rectype eq '0110') {
		$gpdfp_name=substr($_,5,8);
		$gpdfp_dataappl=substr($_,14,8);
		$gpdfp_dataclas=substr($_,23,8);
		$gpdfp_mgmtclas=substr($_,32,8);
		$gpdfp_storclas=substr($_,41,8);
		$rv=$insert{group_dfp_data}->execute($gpdfp_name,$gpdfp_dataappl,$gpdfp_dataclas,$gpdfp_mgmtclas,$gpdfp_storclas);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_dfp_data"}++;
		next;
	}

	if ($rectype eq '0103') {
		$gpinstd_name=substr($_,5,8);
		$gpinstd_usr_name=substr($_,14,8);
		$gpinstd_usr_data=substr($_,23,254);
		$gpinstd_usr_flag=substr($_,279,8);
		$rv=$insert{group_install_data}->execute($gpinstd_name,$gpinstd_usr_name,$gpinstd_usr_data,$gpinstd_usr_flag);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_install_data"}++;
		next;
	}

	if ($rectype eq '0102') {
		$gpmem_name=substr($_,5,8);
		$gpmem_member_id=substr($_,14,8);
		$gpmem_auth=substr($_,23,8);
		$rv=$insert{group_members}->execute($gpmem_name,$gpmem_member_id,$gpmem_auth);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_members"}++;
		next;
	}

	if ($rectype eq '0120') {
		$gpomvs_name=substr($_,5,8);
		$gpomvs_gid=substr($_,14,10);
		if ($gpomvs_gid eq ' ' x length($gpomvs_gid)) {
			undef $gpomvs_gid;
		}
		$rv=$insert{group_omvs_data}->execute($gpomvs_name,$gpomvs_gid);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_omvs_data"}++;
		next;
	}

	if ($rectype eq '0130') {
		$gpovm_name=substr($_,5,8);
		$gpovm_gid=substr($_,14,10);
		if ($gpovm_gid eq ' ' x length($gpovm_gid)) {
			undef $gpovm_gid;
		}
		$rv=$insert{group_ovm_data}->execute($gpovm_name,$gpovm_gid);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_ovm_data"}++;
		next;
	}

	if ($rectype eq '0101') {
		$gpsgrp_name=substr($_,5,8);
		$gpsgrp_subgrp_id=substr($_,14,8);
		$rv=$insert{group_subgroups}->execute($gpsgrp_name,$gpsgrp_subgrp_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_subgroups"}++;
		next;
	}

	if ($rectype eq '0141') {
		$gptme_name=substr($_,5,8);
		$gptme_role=substr($_,14,246);
		$rv=$insert{group_tme_role}->execute($gptme_name,$gptme_role);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"group_tme_role"}++;
		next;
	}

	if ($rectype eq '0200') {
		$usbd_name=substr($_,5,8);
		$usbd_create_date=substr($_,14,10);
		$usbd_owner_id=substr($_,25,8);
		$usbd_adsp=substr($_,34,1);
		$usbd_special=substr($_,39,1);
		$usbd_oper=substr($_,44,1);
		$usbd_revoke=substr($_,49,1);
		$usbd_grpacc=substr($_,54,1);
		$usbd_pwd_interval=substr($_,59,3);
		$usbd_pwd_date=substr($_,63,10);
		if ($usbd_pwd_date eq ' ' x length($usbd_pwd_date)) {
			undef $usbd_pwd_date;
		}
		$usbd_programmer=substr($_,74,20);
		$usbd_defgrp_id=substr($_,95,8);
		$usbd_lastjob_time=substr($_,104,8);
		if ($usbd_lastjob_time eq ' ' x length($usbd_lastjob_time)) {
			undef $usbd_lastjob_time;
		}
		$usbd_lastjob_date=substr($_,113,10);
		if ($usbd_lastjob_date eq ' ' x length($usbd_lastjob_date)) {
			undef $usbd_lastjob_date;
		}
		$usbd_install_data=substr($_,124,254);
		$usbd_uaudit=substr($_,380,1);
		$usbd_auditor=substr($_,385,1);
		$usbd_nopwd=substr($_,390,1);
		$usbd_oidcard=substr($_,395,1);
		$usbd_pwd_gen=substr($_,400,3);
		$usbd_revoke_cnt=substr($_,404,3);
		$usbd_model=substr($_,408,44);
		$usbd_seclevel=substr($_,453,3);
		$usbd_revoke_date=substr($_,457,10);
		if ($usbd_revoke_date eq ' ' x length($usbd_revoke_date)) {
			undef $usbd_revoke_date;
		}
		$usbd_resume_date=substr($_,468,10);
		if ($usbd_resume_date eq ' ' x length($usbd_resume_date)) {
			undef $usbd_resume_date;
		}
		$usbd_access_sun=substr($_,479,1);
		$usbd_access_mon=substr($_,484,1);
		$usbd_access_tue=substr($_,489,1);
		$usbd_access_wed=substr($_,494,1);
		$usbd_access_thu=substr($_,499,1);
		$usbd_access_fri=substr($_,504,1);
		$usbd_access_sat=substr($_,509,1);
		$usbd_start_time=substr($_,514,8);
		if ($usbd_start_time eq ' ' x length($usbd_start_time)) {
			undef $usbd_start_time;
		}
		$usbd_end_time=substr($_,523,8);
		if ($usbd_end_time eq ' ' x length($usbd_end_time)) {
			undef $usbd_end_time;
		}
		$usbd_seclabel=substr($_,532,8);
		$usbd_attribs=substr($_,541,8);
		$rv=$insert{user_bd}->execute($usbd_name,$usbd_create_date,$usbd_owner_id,$usbd_adsp,$usbd_special,$usbd_oper,$usbd_revoke,$usbd_grpacc,$usbd_pwd_interval,$usbd_pwd_date,$usbd_programmer,$usbd_defgrp_id,$usbd_lastjob_time,$usbd_lastjob_date,$usbd_install_data,$usbd_uaudit,$usbd_auditor,$usbd_nopwd,$usbd_oidcard,$usbd_pwd_gen,$usbd_revoke_cnt,$usbd_model,$usbd_seclevel,$usbd_revoke_date,$usbd_resume_date,$usbd_access_sun,$usbd_access_mon,$usbd_access_tue,$usbd_access_wed,$usbd_access_thu,$usbd_access_fri,$usbd_access_sat,$usbd_start_time,$usbd_end_time,$usbd_seclabel,$usbd_attribs);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_bd"}++;
		next;
	}

	if ($rectype eq '0201') {
		$uscat_name=substr($_,5,8);
		$uscat_category=substr($_,14,5);
		$rv=$insert{user_categories}->execute($uscat_name,$uscat_category);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_categories"}++;
		next;
	}

	if ($rectype eq '0207') {
		$uscert_name=substr($_,5,8);
		$uscert_cert_name=substr($_,14,246);
		$uscert_certlabl=substr($_,261,32);
		$rv=$insert{user_cert_data}->execute($uscert_name,$uscert_cert_name,$uscert_certlabl);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_cert_data"}++;
		next;
	}

	if ($rectype eq '0230') {
		$uscics_name=substr($_,5,8);
		$uscics_opident=substr($_,14,3);
		$uscics_opprty=substr($_,18,5);
		$uscics_noforce=substr($_,24,1);
		$uscics_timeout=substr($_,29,5);
		$rv=$insert{user_cics_data}->execute($uscics_name,$uscics_opident,$uscics_opprty,$uscics_noforce,$uscics_timeout);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_cics_data"}++;
		next;
	}

	if ($rectype eq '0231') {
		$uscopc_name=substr($_,5,8);
		$uscopc_opclass=substr($_,14,3);
		$rv=$insert{user_cics_opclass}->execute($uscopc_name,$uscopc_opclass);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_cics_opclass"}++;
		next;
	}

	if ($rectype eq '0202') {
		$uscla_name=substr($_,5,8);
		$uscla_class=substr($_,14,8);
		$rv=$insert{user_classes}->execute($uscla_name,$uscla_class);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_classes"}++;
		next;
	}

	if ($rectype eq '0205') {
		$uscon_name=substr($_,5,8);
		$uscon_grp_id=substr($_,14,8);
		$uscon_connect_date=substr($_,23,10);
		$uscon_owner_id=substr($_,34,8);
		$uscon_lastcon_time=substr($_,43,8);
		if ($uscon_lastcon_time eq ' ' x length($uscon_lastcon_time)) {
			undef $uscon_lastcon_time;
		}
		$uscon_lastcon_date=substr($_,52,10);
		if ($uscon_lastcon_date eq ' ' x length($uscon_lastcon_date)) {
			undef $uscon_lastcon_date;
		}
		$uscon_uacc=substr($_,63,8);
		$uscon_init_cnt=substr($_,72,5);
		$uscon_grp_adsp=substr($_,78,1);
		$uscon_grp_special=substr($_,83,1);
		$uscon_grp_oper=substr($_,88,1);
		$uscon_revoke=substr($_,93,1);
		$uscon_grp_acc=substr($_,98,1);
		$uscon_notermuacc=substr($_,103,1);
		$uscon_grp_audit=substr($_,108,1);
		$uscon_revoke_date=substr($_,113,10);
		if ($uscon_revoke_date eq ' ' x length($uscon_revoke_date)) {
			undef $uscon_revoke_date;
		}
		$uscon_resume_date=substr($_,124,10);
		if ($uscon_resume_date eq ' ' x length($uscon_resume_date)) {
			undef $uscon_resume_date;
		}
		$rv=$insert{user_connect_data}->execute($uscon_name,$uscon_grp_id,$uscon_connect_date,$uscon_owner_id,$uscon_lastcon_time,$uscon_lastcon_date,$uscon_uacc,$uscon_init_cnt,$uscon_grp_adsp,$uscon_grp_special,$uscon_grp_oper,$uscon_revoke,$uscon_grp_acc,$uscon_notermuacc,$uscon_grp_audit,$uscon_revoke_date,$uscon_resume_date);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_connect_data"}++;
		next;
	}

	if ($rectype eq '0290') {
		$usdce_name=substr($_,5,8);
		$usdce_uuid=substr($_,14,36);
		$usdce_dce_name=substr($_,51,1023);
		$usdce_homecell=substr($_,1075,1023);
		$usdce_homeuuid=substr($_,2099,36);
		$usdce_autologin=substr($_,2136,1);
		$rv=$insert{user_dce_data}->execute($usdce_name,$usdce_uuid,$usdce_dce_name,$usdce_homecell,$usdce_homeuuid,$usdce_autologin);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_dce_data"}++;
		next;
	}

	if ($rectype eq '0210') {
		$usdfp_name=substr($_,5,8);
		$usdfp_dataappl=substr($_,14,8);
		$usdfp_dataclas=substr($_,23,8);
		$usdfp_mgmtclas=substr($_,32,8);
		$usdfp_storclas=substr($_,41,8);
		$rv=$insert{user_dfp_data}->execute($usdfp_name,$usdfp_dataappl,$usdfp_dataclas,$usdfp_mgmtclas,$usdfp_storclas);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_dfp_data"}++;
		next;
	}

	if ($rectype eq '02F0') {
		$useim_name=substr($_,5,8);
		$useim_ldapprof=substr($_,14,246);
		$rv=$insert{user_eim_data}->execute($useim_name,$useim_ldapprof);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_eim_data"}++;
		next;
	}

	if ($rectype eq '0203') {
		$usgcon_name=substr($_,5,8);
		$usgcon_grp_id=substr($_,14,8);
		$rv=$insert{user_groups}->execute($usgcon_name,$usgcon_grp_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_groups"}++;
		next;
	}

	if ($rectype eq '0204') {
		$usinstd_name=substr($_,5,8);
		$usinstd_usr_name=substr($_,14,8);
		$usinstd_usr_data=substr($_,23,254);
		$usinstd_usr_flag=substr($_,279,8);
		$rv=$insert{user_install_data}->execute($usinstd_name,$usinstd_usr_name,$usinstd_usr_data,$usinstd_usr_flag);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_install_data"}++;
		next;
	}

	if ($rectype eq '02D0') {
		$uskerb_name=substr($_,5,8);
		$uskerb_kerbname=substr($_,14,240);
		$uskerb_max_life=substr($_,255,10);
		if ($uskerb_max_life eq ' ' x length($uskerb_max_life)) {
			undef $uskerb_max_life;
		}
		$uskerb_key_vers=substr($_,266,3);
		if ($uskerb_key_vers eq ' ' x length($uskerb_key_vers)) {
			undef $uskerb_key_vers;
		}
		$uskerb_encrpt_des=substr($_,270,1);
		$uskerb_encrpt_des3=substr($_,275,1);
		$uskerb_encrpt_desd=substr($_,280,1);
		$rv=$insert{user_kerb_data}->execute($uskerb_name,$uskerb_kerbname,$uskerb_max_life,$uskerb_key_vers,$uskerb_encrpt_des,$uskerb_encrpt_des3,$uskerb_encrpt_desd);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_kerb_data"}++;
		next;
	}

	if ($rectype eq '0240') {
		$uslan_name=substr($_,5,8);
		$uslan_primary=substr($_,14,3);
		$uslan_secondary=substr($_,18,3);
		$rv=$insert{user_language_data}->execute($uslan_name,$uslan_primary,$uslan_secondary);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_language_data"}++;
		next;
	}

	if ($rectype eq '02B0') {
		$uslnot_name=substr($_,5,8);
		$uslnot_sname=substr($_,14,64);
		$rv=$insert{user_lnotes_data}->execute($uslnot_name,$uslnot_sname);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_lnotes_data"}++;
		next;
	}

	if ($rectype eq '02C0') {
		$usnds_name=substr($_,5,8);
		$usnds_uname=substr($_,14,246);
		$rv=$insert{user_nds_data}->execute($usnds_name,$usnds_uname);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_nds_data"}++;
		next;
	}

	if ($rectype eq '0280') {
		$usnetv_name=substr($_,5,8);
		$usnetv_ic=substr($_,14,254);
		$usnetv_consname=substr($_,270,8);
		$usnetv_ctl=substr($_,279,8);
		$usnetv_msgrecvr=substr($_,288,1);
		$usnetv_ngmfadmn=substr($_,293,1);
		$usnetv_ngmfvspn=substr($_,298,8);
		$rv=$insert{user_netv_data}->execute($usnetv_name,$usnetv_ic,$usnetv_consname,$usnetv_ctl,$usnetv_msgrecvr,$usnetv_ngmfadmn,$usnetv_ngmfvspn);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_netv_data"}++;
		next;
	}

	if ($rectype eq '0282') {
		$usndom_name=substr($_,5,8);
		$usndom_domains=substr($_,14,5);
		$rv=$insert{user_netv_domains}->execute($usndom_name,$usndom_domains);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_netv_domains"}++;
		next;
	}

	if ($rectype eq '0281') {
		$usnopc_name=substr($_,5,8);
		$usnopc_opclass=substr($_,14,5);
		$rv=$insert{user_netv_opclass}->execute($usnopc_name,$usnopc_opclass);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_netv_opclass"}++;
		next;
	}

	if ($rectype eq '0208') {
		$usnmap_name=substr($_,5,8);
		$usnmap_label=substr($_,14,32);
		$usnmap_map_name=substr($_,47,246);
		$rv=$insert{user_nmap_data}->execute($usnmap_name,$usnmap_label,$usnmap_map_name);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_nmap_data"}++;
		next;
	}

	if ($rectype eq '0270') {
		$usomvs_name=substr($_,5,8);
		$usomvs_uid=substr($_,14,10);
		if ($usomvs_uid eq ' ' x length($usomvs_uid)) {
			undef $usomvs_uid;
		}
		$usomvs_home_path=substr($_,25,1023);
		$usomvs_prog_name=substr($_,1049,1023);
		$usomvs_cputimemax=substr($_,2073,10);
		if ($usomvs_cputimemax eq ' ' x length($usomvs_cputimemax)) {
			undef $usomvs_cputimemax;
		}
		$usomvs_assizemax=substr($_,2084,10);
		if ($usomvs_assizemax eq ' ' x length($usomvs_assizemax)) {
			undef $usomvs_assizemax;
		}
		$usomvs_fileprocmax=substr($_,2095,10);
		if ($usomvs_fileprocmax eq ' ' x length($usomvs_fileprocmax)) {
			undef $usomvs_fileprocmax;
		}
		$usomvs_procusermax=substr($_,2106,10);
		if ($usomvs_procusermax eq ' ' x length($usomvs_procusermax)) {
			undef $usomvs_procusermax;
		}
		$usomvs_threadsmax=substr($_,2117,10);
		if ($usomvs_threadsmax eq ' ' x length($usomvs_threadsmax)) {
			undef $usomvs_threadsmax;
		}
		$usomvs_mmapareamax=substr($_,2128,10);
		if ($usomvs_mmapareamax eq ' ' x length($usomvs_mmapareamax)) {
			undef $usomvs_mmapareamax;
		}
		$rv=$insert{user_omvs_data}->execute($usomvs_name,$usomvs_uid,$usomvs_home_path,$usomvs_prog_name,$usomvs_cputimemax,$usomvs_assizemax,$usomvs_fileprocmax,$usomvs_procusermax,$usomvs_threadsmax,$usomvs_mmapareamax);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_omvs_data"}++;
		next;
	}

	if ($rectype eq '0250') {
		$usopr_name=substr($_,5,8);
		$usopr_storage=substr($_,14,5);
		$usopr_masterauth=substr($_,20,1);
		$usopr_allauth=substr($_,25,1);
		$usopr_sysauth=substr($_,30,1);
		$usopr_ioauth=substr($_,35,1);
		$usopr_consauth=substr($_,40,1);
		$usopr_infoauth=substr($_,45,1);
		$usopr_timestamp=substr($_,50,1);
		$usopr_systemid=substr($_,55,1);
		$usopr_jobid=substr($_,60,1);
		$usopr_msgid=substr($_,65,1);
		$usopr_x=substr($_,70,1);
		$usopr_wtor=substr($_,75,1);
		$usopr_immediate=substr($_,80,1);
		$usopr_critical=substr($_,85,1);
		$usopr_eventual=substr($_,90,1);
		$usopr_info=substr($_,95,1);
		$usopr_nobrodcast=substr($_,100,1);
		$usopr_all=substr($_,105,1);
		$usopr_jobnames=substr($_,110,1);
		$usopr_jobnamest=substr($_,115,1);
		$usopr_sess=substr($_,120,1);
		$usopr_sesst=substr($_,125,1);
		$usopr_status=substr($_,130,1);
		$usopr_routecode001=substr($_,135,1);
		$usopr_routecode002=substr($_,140,1);
		$usopr_routecode003=substr($_,145,1);
		$usopr_routecode004=substr($_,150,1);
		$usopr_routecode005=substr($_,155,1);
		$usopr_routecode006=substr($_,160,1);
		$usopr_routecode007=substr($_,165,1);
		$usopr_routecode008=substr($_,170,1);
		$usopr_routecode009=substr($_,175,1);
		$usopr_routecode010=substr($_,180,1);
		$usopr_routecode011=substr($_,185,1);
		$usopr_routecode012=substr($_,190,1);
		$usopr_routecode013=substr($_,195,1);
		$usopr_routecode014=substr($_,200,1);
		$usopr_routecode015=substr($_,205,1);
		$usopr_routecode016=substr($_,210,1);
		$usopr_routecode017=substr($_,215,1);
		$usopr_routecode018=substr($_,220,1);
		$usopr_routecode019=substr($_,225,1);
		$usopr_routecode020=substr($_,230,1);
		$usopr_routecode021=substr($_,235,1);
		$usopr_routecode022=substr($_,240,1);
		$usopr_routecode023=substr($_,245,1);
		$usopr_routecode024=substr($_,250,1);
		$usopr_routecode025=substr($_,255,1);
		$usopr_routecode026=substr($_,260,1);
		$usopr_routecode027=substr($_,265,1);
		$usopr_routecode028=substr($_,270,1);
		$usopr_routecode029=substr($_,275,1);
		$usopr_routecode030=substr($_,280,1);
		$usopr_routecode031=substr($_,285,1);
		$usopr_routecode032=substr($_,290,1);
		$usopr_routecode033=substr($_,295,1);
		$usopr_routecode034=substr($_,300,1);
		$usopr_routecode035=substr($_,305,1);
		$usopr_routecode036=substr($_,310,1);
		$usopr_routecode037=substr($_,315,1);
		$usopr_routecode038=substr($_,320,1);
		$usopr_routecode039=substr($_,325,1);
		$usopr_routecode040=substr($_,330,1);
		$usopr_routecode041=substr($_,335,1);
		$usopr_routecode042=substr($_,340,1);
		$usopr_routecode043=substr($_,345,1);
		$usopr_routecode044=substr($_,350,1);
		$usopr_routecode045=substr($_,355,1);
		$usopr_routecode046=substr($_,360,1);
		$usopr_routecode047=substr($_,365,1);
		$usopr_routecode048=substr($_,370,1);
		$usopr_routecode049=substr($_,375,1);
		$usopr_routecode050=substr($_,380,1);
		$usopr_routecode051=substr($_,385,1);
		$usopr_routecode052=substr($_,390,1);
		$usopr_routecode053=substr($_,395,1);
		$usopr_routecode054=substr($_,400,1);
		$usopr_routecode055=substr($_,405,1);
		$usopr_routecode056=substr($_,410,1);
		$usopr_routecode057=substr($_,415,1);
		$usopr_routecode058=substr($_,420,1);
		$usopr_routecode059=substr($_,425,1);
		$usopr_routecode060=substr($_,430,1);
		$usopr_routecode061=substr($_,435,1);
		$usopr_routecode062=substr($_,440,1);
		$usopr_routecode063=substr($_,445,1);
		$usopr_routecode064=substr($_,450,1);
		$usopr_routecode065=substr($_,455,1);
		$usopr_routecode066=substr($_,460,1);
		$usopr_routecode067=substr($_,465,1);
		$usopr_routecode068=substr($_,470,1);
		$usopr_routecode069=substr($_,475,1);
		$usopr_routecode070=substr($_,480,1);
		$usopr_routecode071=substr($_,485,1);
		$usopr_routecode072=substr($_,490,1);
		$usopr_routecode073=substr($_,495,1);
		$usopr_routecode074=substr($_,500,1);
		$usopr_routecode075=substr($_,505,1);
		$usopr_routecode076=substr($_,510,1);
		$usopr_routecode077=substr($_,515,1);
		$usopr_routecode078=substr($_,520,1);
		$usopr_routecode079=substr($_,525,1);
		$usopr_routecode080=substr($_,530,1);
		$usopr_routecode081=substr($_,535,1);
		$usopr_routecode082=substr($_,540,1);
		$usopr_routecode083=substr($_,545,1);
		$usopr_routecode084=substr($_,550,1);
		$usopr_routecode085=substr($_,555,1);
		$usopr_routecode086=substr($_,560,1);
		$usopr_routecode087=substr($_,565,1);
		$usopr_routecode088=substr($_,570,1);
		$usopr_routecode089=substr($_,575,1);
		$usopr_routecode090=substr($_,580,1);
		$usopr_routecode091=substr($_,585,1);
		$usopr_routecode092=substr($_,590,1);
		$usopr_routecode093=substr($_,595,1);
		$usopr_routecode094=substr($_,600,1);
		$usopr_routecode095=substr($_,605,1);
		$usopr_routecode096=substr($_,610,1);
		$usopr_routecode097=substr($_,615,1);
		$usopr_routecode098=substr($_,620,1);
		$usopr_routecode099=substr($_,625,1);
		$usopr_routecode100=substr($_,630,1);
		$usopr_routecode101=substr($_,635,1);
		$usopr_routecode102=substr($_,640,1);
		$usopr_routecode103=substr($_,645,1);
		$usopr_routecode104=substr($_,650,1);
		$usopr_routecode105=substr($_,655,1);
		$usopr_routecode106=substr($_,660,1);
		$usopr_routecode107=substr($_,665,1);
		$usopr_routecode108=substr($_,670,1);
		$usopr_routecode109=substr($_,675,1);
		$usopr_routecode110=substr($_,680,1);
		$usopr_routecode111=substr($_,685,1);
		$usopr_routecode112=substr($_,690,1);
		$usopr_routecode113=substr($_,695,1);
		$usopr_routecode114=substr($_,700,1);
		$usopr_routecode115=substr($_,705,1);
		$usopr_routecode116=substr($_,710,1);
		$usopr_routecode117=substr($_,715,1);
		$usopr_routecode118=substr($_,720,1);
		$usopr_routecode119=substr($_,725,1);
		$usopr_routecode120=substr($_,730,1);
		$usopr_routecode121=substr($_,735,1);
		$usopr_routecode122=substr($_,740,1);
		$usopr_routecode123=substr($_,745,1);
		$usopr_routecode124=substr($_,750,1);
		$usopr_routecode125=substr($_,755,1);
		$usopr_routecode126=substr($_,760,1);
		$usopr_routecode127=substr($_,765,1);
		$usopr_routecode128=substr($_,770,1);
		$usopr_logcmdresp=substr($_,775,8);
		$usopr_migrationid=substr($_,784,1);
		$usopr_delopermsg=substr($_,789,8);
		$usopr_retrieve_key=substr($_,798,8);
		$usopr_cmdsys=substr($_,807,8);
		$usopr_ud=substr($_,816,1);
		$usopr_altgrp_id=substr($_,821,8);
		$usopr_auto=substr($_,830,1);
		$rv=$insert{user_operparm_data}->execute($usopr_name,$usopr_storage,$usopr_masterauth,$usopr_allauth,$usopr_sysauth,$usopr_ioauth,$usopr_consauth,$usopr_infoauth,$usopr_timestamp,$usopr_systemid,$usopr_jobid,$usopr_msgid,$usopr_x,$usopr_wtor,$usopr_immediate,$usopr_critical,$usopr_eventual,$usopr_info,$usopr_nobrodcast,$usopr_all,$usopr_jobnames,$usopr_jobnamest,$usopr_sess,$usopr_sesst,$usopr_status,$usopr_routecode001,$usopr_routecode002,$usopr_routecode003,$usopr_routecode004,$usopr_routecode005,$usopr_routecode006,$usopr_routecode007,$usopr_routecode008,$usopr_routecode009,$usopr_routecode010,$usopr_routecode011,$usopr_routecode012,$usopr_routecode013,$usopr_routecode014,$usopr_routecode015,$usopr_routecode016,$usopr_routecode017,$usopr_routecode018,$usopr_routecode019,$usopr_routecode020,$usopr_routecode021,$usopr_routecode022,$usopr_routecode023,$usopr_routecode024,$usopr_routecode025,$usopr_routecode026,$usopr_routecode027,$usopr_routecode028,$usopr_routecode029,$usopr_routecode030,$usopr_routecode031,$usopr_routecode032,$usopr_routecode033,$usopr_routecode034,$usopr_routecode035,$usopr_routecode036,$usopr_routecode037,$usopr_routecode038,$usopr_routecode039,$usopr_routecode040,$usopr_routecode041,$usopr_routecode042,$usopr_routecode043,$usopr_routecode044,$usopr_routecode045,$usopr_routecode046,$usopr_routecode047,$usopr_routecode048,$usopr_routecode049,$usopr_routecode050,$usopr_routecode051,$usopr_routecode052,$usopr_routecode053,$usopr_routecode054,$usopr_routecode055,$usopr_routecode056,$usopr_routecode057,$usopr_routecode058,$usopr_routecode059,$usopr_routecode060,$usopr_routecode061,$usopr_routecode062,$usopr_routecode063,$usopr_routecode064,$usopr_routecode065,$usopr_routecode066,$usopr_routecode067,$usopr_routecode068,$usopr_routecode069,$usopr_routecode070,$usopr_routecode071,$usopr_routecode072,$usopr_routecode073,$usopr_routecode074,$usopr_routecode075,$usopr_routecode076,$usopr_routecode077,$usopr_routecode078,$usopr_routecode079,$usopr_routecode080,$usopr_routecode081,$usopr_routecode082,$usopr_routecode083,$usopr_routecode084,$usopr_routecode085,$usopr_routecode086,$usopr_routecode087,$usopr_routecode088,$usopr_routecode089,$usopr_routecode090,$usopr_routecode091,$usopr_routecode092,$usopr_routecode093,$usopr_routecode094,$usopr_routecode095,$usopr_routecode096,$usopr_routecode097,$usopr_routecode098,$usopr_routecode099,$usopr_routecode100,$usopr_routecode101,$usopr_routecode102,$usopr_routecode103,$usopr_routecode104,$usopr_routecode105,$usopr_routecode106,$usopr_routecode107,$usopr_routecode108,$usopr_routecode109,$usopr_routecode110,$usopr_routecode111,$usopr_routecode112,$usopr_routecode113,$usopr_routecode114,$usopr_routecode115,$usopr_routecode116,$usopr_routecode117,$usopr_routecode118,$usopr_routecode119,$usopr_routecode120,$usopr_routecode121,$usopr_routecode122,$usopr_routecode123,$usopr_routecode124,$usopr_routecode125,$usopr_routecode126,$usopr_routecode127,$usopr_routecode128,$usopr_logcmdresp,$usopr_migrationid,$usopr_delopermsg,$usopr_retrieve_key,$usopr_cmdsys,$usopr_ud,$usopr_altgrp_id,$usopr_auto);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_operparm_data"}++;
		next;
	}

	if ($rectype eq '0251') {
		$usoprp_name=substr($_,5,8);
		$usoprp_system=substr($_,14,8);
		$rv=$insert{user_operparm_scop}->execute($usoprp_name,$usoprp_system);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_operparm_scop"}++;
		next;
	}

	if ($rectype eq '02A0') {
		$usovm_name=substr($_,5,8);
		$usovm_uid=substr($_,14,10);
		if ($usovm_uid eq ' ' x length($usovm_uid)) {
			undef $usovm_uid;
		}
		$usovm_home_path=substr($_,25,1023);
		$usovm_program=substr($_,1049,1023);
		$usovm_fsroot=substr($_,2073,1023);
		$rv=$insert{user_ovm_data}->execute($usovm_name,$usovm_uid,$usovm_home_path,$usovm_program,$usovm_fsroot);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_ovm_data"}++;
		next;
	}

	if ($rectype eq '02E0') {
		$usproxy_name=substr($_,5,8);
		$usproxy_ldap_host=substr($_,14,1023);
		$usproxy_bind_dn=substr($_,1038,1023);
		$rv=$insert{user_proxy_data}->execute($usproxy_name,$usproxy_ldap_host,$usproxy_bind_dn);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_proxy_data"}++;
		next;
	}

	if ($rectype eq '0206') {
		$usrsf_name=substr($_,5,8);
		$usrsf_targ_node=substr($_,14,8);
		$usrsf_targ_user_id=substr($_,23,8);
		$usrsf_version=substr($_,32,3);
		$usrsf_peer=substr($_,36,1);
		$usrsf_managing=substr($_,41,1);
		$usrsf_managed=substr($_,46,1);
		$usrsf_remote_pend=substr($_,51,1);
		$usrsf_local_pend=substr($_,56,1);
		$usrsf_pwd_sync=substr($_,61,1);
		$usrsf_rem_refusal=substr($_,66,1);
		$usrsf_define_date=substr($_,71,10);
		$usrsf_define_time=substr($_,82,8);
		$usrsf_accept_date=substr($_,98,10);
		if ($usrsf_accept_date eq ' ' x length($usrsf_accept_date)) {
			undef $usrsf_accept_date;
		}
		$usrsf_accept_time=substr($_,109,8);
		if ($usrsf_accept_time eq ' ' x length($usrsf_accept_time)) {
			undef $usrsf_accept_time;
		}
		$usrsf_creator_id=substr($_,125,8);
		$rv=$insert{user_rrsf_data}->execute($usrsf_name,$usrsf_targ_node,$usrsf_targ_user_id,$usrsf_version,$usrsf_peer,$usrsf_managing,$usrsf_managed,$usrsf_remote_pend,$usrsf_local_pend,$usrsf_pwd_sync,$usrsf_rem_refusal,$usrsf_define_date,$usrsf_define_time,$usrsf_accept_date,$usrsf_accept_time,$usrsf_creator_id);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_rrsf_data"}++;
		next;
	}

	if ($rectype eq '0220') {
		$ustso_name=substr($_,5,8);
		$ustso_account=substr($_,14,40);
		$ustso_command=substr($_,55,80);
		$ustso_dest=substr($_,136,8);
		$ustso_hold_class=substr($_,145,1);
		$ustso_job_class=substr($_,147,1);
		$ustso_logon_proc=substr($_,149,8);
		$ustso_logon_size=substr($_,158,10);
		$ustso_msg_class=substr($_,169,1);
		$ustso_logon_max=substr($_,171,10);
		$ustso_perf_group=substr($_,182,10);
		$ustso_sysout_class=substr($_,193,1);
		$ustso_user_data=substr($_,195,8);
		$ustso_unit_name=substr($_,204,8);
		$ustso_seclabel=substr($_,213,8);
		$rv=$insert{user_tso_data}->execute($ustso_name,$ustso_account,$ustso_command,$ustso_dest,$ustso_hold_class,$ustso_job_class,$ustso_logon_proc,$ustso_logon_size,$ustso_msg_class,$ustso_logon_max,$ustso_perf_group,$ustso_sysout_class,$ustso_user_data,$ustso_unit_name,$ustso_seclabel);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_tso_data"}++;
		next;
	}

	if ($rectype eq '0260') {
		$uswrk_name=substr($_,5,8);
		$uswrk_area_name=substr($_,14,60);
		$uswrk_building=substr($_,75,60);
		$uswrk_department=substr($_,136,60);
		$uswrk_room=substr($_,197,60);
		$uswrk_addr_line1=substr($_,258,60);
		$uswrk_addr_line2=substr($_,319,60);
		$uswrk_addr_line3=substr($_,380,60);
		$uswrk_addr_line4=substr($_,441,60);
		$uswrk_account=substr($_,502,254);
		$rv=$insert{user_workattr_data}->execute($uswrk_name,$uswrk_area_name,$uswrk_building,$uswrk_department,$uswrk_room,$uswrk_addr_line1,$uswrk_addr_line2,$uswrk_addr_line3,$uswrk_addr_line4,$uswrk_account);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"user_workattr_data"}++;
		next;
	}

}
$dbh->commit;
$dbh->disconnect;
