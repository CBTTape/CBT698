#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use DBD::Pg qw(:pg_types);
use bytes;
my ($rv, $rectype, $statement);
my %insert;
my %inserts;
my $dbh=DBI->connect("dbi:Pg:dbname=racf","","",{PrintError=>0, RaiseError=>1, AutoCommit=>0});
die "Unable to connect to database." unless defined($dbh);

#Table:access
#delete all rows from the access table
$dbh->do("delete from access");
#Define the column names for the access table to Perl
my $acc_event_type;
my $acc_event_qual;
my $acc_time_written;
my $acc_date_written;
my $acc_system_smfid;
my $acc_violation;
my $acc_user_ndfnd;
my $acc_user_warning;
my $acc_evt_user_id;
my $acc_evt_grp_id;
my $acc_auth_normal;
my $acc_auth_special;
my $acc_auth_oper;
my $acc_auth_audit;
my $acc_auth_exit;
my $acc_auth_failsft;
my $acc_auth_bypass;
my $acc_auth_trusted;
my $acc_log_class;
my $acc_log_user;
my $acc_log_special;
my $acc_log_access;
my $acc_log_racinit;
my $acc_log_always;
my $acc_log_cmdviol;
my $acc_log_global;
my $acc_term_level;
my $acc_backout_fail;
my $acc_prof_same;
my $acc_term;
my $acc_job_name;
my $acc_read_time;
my $acc_read_date;
my $acc_smf_user_id;
my $acc_log_level;
my $acc_log_vmevent;
my $acc_log_logopt;
my $acc_log_secl;
my $acc_log_compatm;
my $acc_log_applaud;
my $acc_log_nonomvs;
my $acc_log_omvsnprv;
my $acc_auth_omvssu;
my $acc_auth_omvssys;
my $acc_usr_secl;
my $acc_racf_version;
my $acc_res_name;
my $acc_request;
my $acc_grant;
my $acc_level;
my $acc_vol;
my $acc_oldvol;
my $acc_class;
my $acc_appl;
my $acc_type;
my $acc_name;
my $acc_own_id;
my $acc_logstr;
my $acc_recvr;
my $acc_user_name;
my $acc_secl;
my $acc_utk_encr;
my $acc_utk_pre19;
my $acc_utk_verprof;
my $acc_utk_njeunusr;
my $acc_utk_logusr;
my $acc_utk_special;
my $acc_utk_default;
my $acc_utk_unknusr;
my $acc_utk_error;
my $acc_utk_trusted;
my $acc_utk_sesstype;
my $acc_utk_surrogat;
my $acc_utk_remote;
my $acc_utk_priv;
my $acc_utk_secl;
my $acc_utk_execnode;
my $acc_utk_suser_id;
my $acc_utk_snode;
my $acc_utk_sgrp_id;
my $acc_utk_spoe;
my $acc_utk_spclass;
my $acc_utk_user_id;
my $acc_utk_grp_id;
my $acc_utk_dft_grp;
my $acc_utk_dft_secl;
my $acc_rtk_encr;
my $acc_rtk_pre19;
my $acc_rtk_verprof;
my $acc_rtk_njeunusr;
my $acc_rtk_logusr;
my $acc_rtk_special;
my $acc_rtk_default;
my $acc_rtk_unknusr;
my $acc_rtk_error;
my $acc_rtk_trusted;
my $acc_rtk_sesstype;
my $acc_rtk_surrogat;
my $acc_rtk_remote;
my $acc_rtk_priv;
my $acc_rtk_secl;
my $acc_rtk_execnode;
my $acc_rtk_suser_id;
my $acc_rtk_snode;
my $acc_rtk_sgrp_id;
my $acc_rtk_spoe;
my $acc_rtk_spclass;
my $acc_rtk_user_id;
my $acc_rtk_grp_id;
my $acc_rtk_dft_grp;
my $acc_rtk_dft_secl;
my $acc_appc_link;
my $acc_dce_link;
my $acc_auth_type;
my $acc_pds_dsn;
my $acc_utk_netw;
my $acc_rtk_netw;
my $acc_x500_subject;
my $acc_x500_issuer;
#Create and prepare the INSERT statement for access
$statement="INSERT INTO access (acc_event_type,acc_event_qual,acc_time_written,acc_date_written,acc_system_smfid,acc_violation,acc_user_ndfnd,acc_user_warning,acc_evt_user_id,acc_evt_grp_id,acc_auth_normal,acc_auth_special,acc_auth_oper,acc_auth_audit,acc_auth_exit,acc_auth_failsft,acc_auth_bypass,acc_auth_trusted,acc_log_class,acc_log_user,acc_log_special,acc_log_access,acc_log_racinit,acc_log_always,acc_log_cmdviol,acc_log_global,acc_term_level,acc_backout_fail,acc_prof_same,acc_term,acc_job_name,acc_read_time,acc_read_date,acc_smf_user_id,acc_log_level,acc_log_vmevent,acc_log_logopt,acc_log_secl,acc_log_compatm,acc_log_applaud,acc_log_nonomvs,acc_log_omvsnprv,acc_auth_omvssu,acc_auth_omvssys,acc_usr_secl,acc_racf_version,acc_res_name,acc_request,acc_grant,acc_level,acc_vol,acc_oldvol,acc_class,acc_appl,acc_type,acc_name,acc_own_id,acc_logstr,acc_recvr,acc_user_name,acc_secl,acc_utk_encr,acc_utk_pre19,acc_utk_verprof,acc_utk_njeunusr,acc_utk_logusr,acc_utk_special,acc_utk_default,acc_utk_unknusr,acc_utk_error,acc_utk_trusted,acc_utk_sesstype,acc_utk_surrogat,acc_utk_remote,acc_utk_priv,acc_utk_secl,acc_utk_execnode,acc_utk_suser_id,acc_utk_snode,acc_utk_sgrp_id,acc_utk_spoe,acc_utk_spclass,acc_utk_user_id,acc_utk_grp_id,acc_utk_dft_grp,acc_utk_dft_secl,acc_rtk_encr,acc_rtk_pre19,acc_rtk_verprof,acc_rtk_njeunusr,acc_rtk_logusr,acc_rtk_special,acc_rtk_default,acc_rtk_unknusr,acc_rtk_error,acc_rtk_trusted,acc_rtk_sesstype,acc_rtk_surrogat,acc_rtk_remote,acc_rtk_priv,acc_rtk_secl,acc_rtk_execnode,acc_rtk_suser_id,acc_rtk_snode,acc_rtk_sgrp_id,acc_rtk_spoe,acc_rtk_spclass,acc_rtk_user_id,acc_rtk_grp_id,acc_rtk_dft_grp,acc_rtk_dft_secl,acc_appc_link,acc_dce_link,acc_auth_type,acc_pds_dsn,acc_utk_netw,acc_rtk_netw,acc_x500_subject,acc_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"access"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"access"}=0;
#Table:accr
#delete all rows from the accr table
$dbh->do("delete from accr");
#Define the column names for the accr table to Perl
my $accr_event_type;
my $accr_event_qual;
my $accr_time_written;
my $accr_date_written;
my $accr_system_smfid;
my $accr_violation;
my $accr_user_ndfnd;
my $accr_user_warning;
my $accr_evt_user_id;
my $accr_evt_grp_id;
my $accr_auth_normal;
my $accr_auth_special;
my $accr_auth_oper;
my $accr_auth_audit;
my $accr_auth_exit;
my $accr_auth_failsft;
my $accr_auth_bypass;
my $accr_auth_trusted;
my $accr_log_class;
my $accr_log_user;
my $accr_log_special;
my $accr_log_access;
my $accr_log_racinit;
my $accr_log_always;
my $accr_log_cmdviol;
my $accr_log_global;
my $accr_term_level;
my $accr_backout_fail;
my $accr_prof_same;
my $accr_term;
my $accr_job_name;
my $accr_read_time;
my $accr_read_date;
my $accr_smf_user_id;
my $accr_log_level;
my $accr_log_vmevent;
my $accr_log_logopt;
my $accr_log_secl;
my $accr_log_compatm;
my $accr_log_applaud;
my $accr_log_nonomvs;
my $accr_log_omvsnprv;
my $accr_auth_omvssu;
my $accr_auth_omvssys;
my $accr_usr_secl;
my $accr_racf_version;
my $accr_class;
my $accr_user_name;
my $accr_utk_encr;
my $accr_utk_pre19;
my $accr_utk_verprof;
my $accr_utk_njeunusr;
my $accr_utk_logusr;
my $accr_utk_special;
my $accr_utk_default;
my $accr_utk_unknusr;
my $accr_utk_error;
my $accr_utk_trusted;
my $accr_utk_sesstype;
my $accr_utk_surrogat;
my $accr_utk_remote;
my $accr_utk_priv;
my $accr_utk_secl;
my $accr_utk_execnode;
my $accr_utk_suser_id;
my $accr_utk_snode;
my $accr_utk_sgrp_id;
my $accr_utk_spoe;
my $accr_utk_spclass;
my $accr_utk_user_id;
my $accr_utk_grp_id;
my $accr_utk_dft_grp;
my $accr_utk_dft_secl;
my $accr_appc_link;
my $accr_audit_code;
my $accr_old_real_uid;
my $accr_old_eff_uid;
my $accr_old_saved_uid;
my $accr_old_real_gid;
my $accr_old_eff_gid;
my $accr_old_saved_gid;
my $accr_path_name;
my $accr_file1_id;
my $accr_dflt_process;
my $accr_utk_netw;
my $accr_x500_subject;
my $accr_x500_issuer;
#Create and prepare the INSERT statement for accr
$statement="INSERT INTO accr (accr_event_type,accr_event_qual,accr_time_written,accr_date_written,accr_system_smfid,accr_violation,accr_user_ndfnd,accr_user_warning,accr_evt_user_id,accr_evt_grp_id,accr_auth_normal,accr_auth_special,accr_auth_oper,accr_auth_audit,accr_auth_exit,accr_auth_failsft,accr_auth_bypass,accr_auth_trusted,accr_log_class,accr_log_user,accr_log_special,accr_log_access,accr_log_racinit,accr_log_always,accr_log_cmdviol,accr_log_global,accr_term_level,accr_backout_fail,accr_prof_same,accr_term,accr_job_name,accr_read_time,accr_read_date,accr_smf_user_id,accr_log_level,accr_log_vmevent,accr_log_logopt,accr_log_secl,accr_log_compatm,accr_log_applaud,accr_log_nonomvs,accr_log_omvsnprv,accr_auth_omvssu,accr_auth_omvssys,accr_usr_secl,accr_racf_version,accr_class,accr_user_name,accr_utk_encr,accr_utk_pre19,accr_utk_verprof,accr_utk_njeunusr,accr_utk_logusr,accr_utk_special,accr_utk_default,accr_utk_unknusr,accr_utk_error,accr_utk_trusted,accr_utk_sesstype,accr_utk_surrogat,accr_utk_remote,accr_utk_priv,accr_utk_secl,accr_utk_execnode,accr_utk_suser_id,accr_utk_snode,accr_utk_sgrp_id,accr_utk_spoe,accr_utk_spclass,accr_utk_user_id,accr_utk_grp_id,accr_utk_dft_grp,accr_utk_dft_secl,accr_appc_link,accr_audit_code,accr_old_real_uid,accr_old_eff_uid,accr_old_saved_uid,accr_old_real_gid,accr_old_eff_gid,accr_old_saved_gid,accr_path_name,accr_file1_id,accr_dflt_process,accr_utk_netw,accr_x500_subject,accr_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"accr"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"accr"}=0;
#Table:addgroup
#delete all rows from the addgroup table
$dbh->do("delete from addgroup");
#Define the column names for the addgroup table to Perl
my $ag_event_type;
my $ag_event_qual;
my $ag_time_written;
my $ag_date_written;
my $ag_system_smfid;
my $ag_violation;
my $ag_user_ndfnd;
my $ag_user_warning;
my $ag_evt_user_id;
my $ag_evt_grp_id;
my $ag_auth_normal;
my $ag_auth_special;
my $ag_auth_oper;
my $ag_auth_audit;
my $ag_auth_exit;
my $ag_auth_failsft;
my $ag_auth_bypass;
my $ag_auth_trusted;
my $ag_log_class;
my $ag_log_user;
my $ag_log_special;
my $ag_log_access;
my $ag_log_racinit;
my $ag_log_always;
my $ag_log_cmdviol;
my $ag_log_global;
my $ag_term_level;
my $ag_backout_fail;
my $ag_prof_same;
my $ag_term;
my $ag_job_name;
my $ag_read_time;
my $ag_read_date;
my $ag_smf_user_id;
my $ag_log_level;
my $ag_log_vmevent;
my $ag_log_logopt;
my $ag_log_secl;
my $ag_log_compatm;
my $ag_log_applaud;
my $ag_log_nonomvs;
my $ag_log_omvsnprv;
my $ag_auth_omvssu;
my $ag_auth_omvssys;
my $ag_usr_secl;
my $ag_racf_version;
my $ag_own_id;
my $ag_user_name;
my $ag_utk_encr;
my $ag_utk_pre19;
my $ag_utk_verprof;
my $ag_utk_njeunusr;
my $ag_utk_logusr;
my $ag_utk_special;
my $ag_utk_default;
my $ag_utk_unknusr;
my $ag_utk_error;
my $ag_utk_trusted;
my $ag_utk_sesstype;
my $ag_utk_surrogat;
my $ag_utk_remote;
my $ag_utk_priv;
my $ag_utk_secl;
my $ag_utk_execnode;
my $ag_utk_suser_id;
my $ag_utk_snode;
my $ag_utk_sgrp_id;
my $ag_utk_spoe;
my $ag_utk_spclass;
my $ag_utk_user_id;
my $ag_utk_grp_id;
my $ag_utk_dft_grp;
my $ag_utk_dft_secl;
my $ag_appc_link;
my $ag_grp_id;
my $ag_specified;
my $ag_failed;
my $ag_utk_netw;
my $ag_x500_subject;
my $ag_x500_issuer;
#Create and prepare the INSERT statement for addgroup
$statement="INSERT INTO addgroup (ag_event_type,ag_event_qual,ag_time_written,ag_date_written,ag_system_smfid,ag_violation,ag_user_ndfnd,ag_user_warning,ag_evt_user_id,ag_evt_grp_id,ag_auth_normal,ag_auth_special,ag_auth_oper,ag_auth_audit,ag_auth_exit,ag_auth_failsft,ag_auth_bypass,ag_auth_trusted,ag_log_class,ag_log_user,ag_log_special,ag_log_access,ag_log_racinit,ag_log_always,ag_log_cmdviol,ag_log_global,ag_term_level,ag_backout_fail,ag_prof_same,ag_term,ag_job_name,ag_read_time,ag_read_date,ag_smf_user_id,ag_log_level,ag_log_vmevent,ag_log_logopt,ag_log_secl,ag_log_compatm,ag_log_applaud,ag_log_nonomvs,ag_log_omvsnprv,ag_auth_omvssu,ag_auth_omvssys,ag_usr_secl,ag_racf_version,ag_own_id,ag_user_name,ag_utk_encr,ag_utk_pre19,ag_utk_verprof,ag_utk_njeunusr,ag_utk_logusr,ag_utk_special,ag_utk_default,ag_utk_unknusr,ag_utk_error,ag_utk_trusted,ag_utk_sesstype,ag_utk_surrogat,ag_utk_remote,ag_utk_priv,ag_utk_secl,ag_utk_execnode,ag_utk_suser_id,ag_utk_snode,ag_utk_sgrp_id,ag_utk_spoe,ag_utk_spclass,ag_utk_user_id,ag_utk_grp_id,ag_utk_dft_grp,ag_utk_dft_secl,ag_appc_link,ag_grp_id,ag_specified,ag_failed,ag_utk_netw,ag_x500_subject,ag_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"addgroup"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"addgroup"}=0;
#Table:addsd
#delete all rows from the addsd table
$dbh->do("delete from addsd");
#Define the column names for the addsd table to Perl
my $ad_event_type;
my $ad_event_qual;
my $ad_time_written;
my $ad_date_written;
my $ad_system_smfid;
my $ad_violation;
my $ad_user_ndfnd;
my $ad_user_warning;
my $ad_evt_user_id;
my $ad_evt_grp_id;
my $ad_auth_normal;
my $ad_auth_special;
my $ad_auth_oper;
my $ad_auth_audit;
my $ad_auth_exit;
my $ad_auth_failsft;
my $ad_auth_bypass;
my $ad_auth_trusted;
my $ad_log_class;
my $ad_log_user;
my $ad_log_special;
my $ad_log_access;
my $ad_log_racinit;
my $ad_log_always;
my $ad_log_cmdviol;
my $ad_log_global;
my $ad_term_level;
my $ad_backout_fail;
my $ad_prof_same;
my $ad_term;
my $ad_job_name;
my $ad_read_time;
my $ad_read_date;
my $ad_smf_user_id;
my $ad_log_level;
my $ad_log_vmevent;
my $ad_log_logopt;
my $ad_log_secl;
my $ad_log_compatm;
my $ad_log_applaud;
my $ad_log_nonomvs;
my $ad_log_omvsnprv;
my $ad_auth_omvssu;
my $ad_auth_omvssys;
my $ad_usr_secl;
my $ad_racf_version;
my $ad_own_id;
my $ad_user_name;
my $ad_secl;
my $ad_utk_encr;
my $ad_utk_pre19;
my $ad_utk_verprof;
my $ad_utk_njeunusr;
my $ad_utk_logusr;
my $ad_utk_special;
my $ad_utk_default;
my $ad_utk_unknusr;
my $ad_utk_error;
my $ad_utk_trusted;
my $ad_utk_sesstype;
my $ad_utk_surrogat;
my $ad_utk_remote;
my $ad_utk_priv;
my $ad_utk_secl;
my $ad_utk_execnode;
my $ad_utk_suser_id;
my $ad_utk_snode;
my $ad_utk_sgrp_id;
my $ad_utk_spoe;
my $ad_utk_spclass;
my $ad_utk_user_id;
my $ad_utk_grp_id;
my $ad_utk_dft_grp;
my $ad_utk_dft_secl;
my $ad_appc_link;
my $ad_secl_link;
my $ad_ds_name;
my $ad_specified;
my $ad_failed;
my $ad_utk_netw;
my $ad_x500_subject;
my $ad_x500_issuer;
#Create and prepare the INSERT statement for addsd
$statement="INSERT INTO addsd (ad_event_type,ad_event_qual,ad_time_written,ad_date_written,ad_system_smfid,ad_violation,ad_user_ndfnd,ad_user_warning,ad_evt_user_id,ad_evt_grp_id,ad_auth_normal,ad_auth_special,ad_auth_oper,ad_auth_audit,ad_auth_exit,ad_auth_failsft,ad_auth_bypass,ad_auth_trusted,ad_log_class,ad_log_user,ad_log_special,ad_log_access,ad_log_racinit,ad_log_always,ad_log_cmdviol,ad_log_global,ad_term_level,ad_backout_fail,ad_prof_same,ad_term,ad_job_name,ad_read_time,ad_read_date,ad_smf_user_id,ad_log_level,ad_log_vmevent,ad_log_logopt,ad_log_secl,ad_log_compatm,ad_log_applaud,ad_log_nonomvs,ad_log_omvsnprv,ad_auth_omvssu,ad_auth_omvssys,ad_usr_secl,ad_racf_version,ad_own_id,ad_user_name,ad_secl,ad_utk_encr,ad_utk_pre19,ad_utk_verprof,ad_utk_njeunusr,ad_utk_logusr,ad_utk_special,ad_utk_default,ad_utk_unknusr,ad_utk_error,ad_utk_trusted,ad_utk_sesstype,ad_utk_surrogat,ad_utk_remote,ad_utk_priv,ad_utk_secl,ad_utk_execnode,ad_utk_suser_id,ad_utk_snode,ad_utk_sgrp_id,ad_utk_spoe,ad_utk_spclass,ad_utk_user_id,ad_utk_grp_id,ad_utk_dft_grp,ad_utk_dft_secl,ad_appc_link,ad_secl_link,ad_ds_name,ad_specified,ad_failed,ad_utk_netw,ad_x500_subject,ad_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"addsd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"addsd"}=0;
#Table:adduser
#delete all rows from the adduser table
$dbh->do("delete from adduser");
#Define the column names for the adduser table to Perl
my $au_event_type;
my $au_event_qual;
my $au_time_written;
my $au_date_written;
my $au_system_smfid;
my $au_violation;
my $au_user_ndfnd;
my $au_user_warning;
my $au_evt_user_id;
my $au_evt_grp_id;
my $au_auth_normal;
my $au_auth_special;
my $au_auth_oper;
my $au_auth_audit;
my $au_auth_exit;
my $au_auth_failsft;
my $au_auth_bypass;
my $au_auth_trusted;
my $au_log_class;
my $au_log_user;
my $au_log_special;
my $au_log_access;
my $au_log_racinit;
my $au_log_always;
my $au_log_cmdviol;
my $au_log_global;
my $au_term_level;
my $au_backout_fail;
my $au_prof_same;
my $au_term;
my $au_job_name;
my $au_read_time;
my $au_read_date;
my $au_smf_user_id;
my $au_log_level;
my $au_log_vmevent;
my $au_log_logopt;
my $au_log_secl;
my $au_log_compatm;
my $au_log_applaud;
my $au_log_nonomvs;
my $au_log_omvsnprv;
my $au_auth_omvssu;
my $au_auth_omvssys;
my $au_usr_secl;
my $au_racf_version;
my $au_own_id;
my $au_user_name;
my $au_utk_encr;
my $au_utk_pre19;
my $au_utk_verprof;
my $au_utk_njeunusr;
my $au_utk_logusr;
my $au_utk_special;
my $au_utk_default;
my $au_utk_unknusr;
my $au_utk_error;
my $au_utk_trusted;
my $au_utk_sesstype;
my $au_utk_surrogat;
my $au_utk_remote;
my $au_utk_priv;
my $au_utk_secl;
my $au_utk_execnode;
my $au_utk_suser_id;
my $au_utk_snode;
my $au_utk_sgrp_id;
my $au_utk_spoe;
my $au_utk_spclass;
my $au_utk_user_id;
my $au_utk_grp_id;
my $au_utk_dft_grp;
my $au_utk_dft_secl;
my $au_appc_link;
my $au_noauth_clauth;
my $au_noauth_group;
my $au_user_id;
my $au_specified;
my $au_failed;
my $au_ignored;
my $au_utk_netw;
my $au_x500_subject;
my $au_x500_issuer;
#Create and prepare the INSERT statement for adduser
$statement="INSERT INTO adduser (au_event_type,au_event_qual,au_time_written,au_date_written,au_system_smfid,au_violation,au_user_ndfnd,au_user_warning,au_evt_user_id,au_evt_grp_id,au_auth_normal,au_auth_special,au_auth_oper,au_auth_audit,au_auth_exit,au_auth_failsft,au_auth_bypass,au_auth_trusted,au_log_class,au_log_user,au_log_special,au_log_access,au_log_racinit,au_log_always,au_log_cmdviol,au_log_global,au_term_level,au_backout_fail,au_prof_same,au_term,au_job_name,au_read_time,au_read_date,au_smf_user_id,au_log_level,au_log_vmevent,au_log_logopt,au_log_secl,au_log_compatm,au_log_applaud,au_log_nonomvs,au_log_omvsnprv,au_auth_omvssu,au_auth_omvssys,au_usr_secl,au_racf_version,au_own_id,au_user_name,au_utk_encr,au_utk_pre19,au_utk_verprof,au_utk_njeunusr,au_utk_logusr,au_utk_special,au_utk_default,au_utk_unknusr,au_utk_error,au_utk_trusted,au_utk_sesstype,au_utk_surrogat,au_utk_remote,au_utk_priv,au_utk_secl,au_utk_execnode,au_utk_suser_id,au_utk_snode,au_utk_sgrp_id,au_utk_spoe,au_utk_spclass,au_utk_user_id,au_utk_grp_id,au_utk_dft_grp,au_utk_dft_secl,au_appc_link,au_noauth_clauth,au_noauth_group,au_user_id,au_specified,au_failed,au_ignored,au_utk_netw,au_x500_subject,au_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"adduser"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"adduser"}=0;
#Table:addvol
#delete all rows from the addvol table
$dbh->do("delete from addvol");
#Define the column names for the addvol table to Perl
my $adv_event_type;
my $adv_event_qual;
my $adv_time_written;
my $adv_date_written;
my $adv_system_smfid;
my $adv_violation;
my $adv_user_ndfnd;
my $adv_user_warning;
my $adv_evt_user_id;
my $adv_evt_grp_id;
my $adv_auth_normal;
my $adv_auth_special;
my $adv_auth_oper;
my $adv_auth_audit;
my $adv_auth_exit;
my $adv_auth_failsft;
my $adv_auth_bypass;
my $adv_auth_trusted;
my $adv_log_class;
my $adv_log_user;
my $adv_log_special;
my $adv_log_access;
my $adv_log_racinit;
my $adv_log_always;
my $adv_log_cmdviol;
my $adv_log_global;
my $adv_term_level;
my $adv_backout_fail;
my $adv_prof_same;
my $adv_term;
my $adv_job_name;
my $adv_read_time;
my $adv_read_date;
my $adv_smf_user_id;
my $adv_log_level;
my $adv_log_vmevent;
my $adv_log_logopt;
my $adv_log_secl;
my $adv_log_compatm;
my $adv_log_applaud;
my $adv_log_nonomvs;
my $adv_log_omvsnprv;
my $adv_auth_omvssu;
my $adv_auth_omvssys;
my $adv_usr_secl;
my $adv_racf_version;
my $adv_res_name;
my $adv_grant;
my $adv_level;
my $adv_vol;
my $adv_oldvol;
my $adv_class;
my $adv_own_id;
my $adv_logstr;
my $adv_user_name;
my $adv_utk_encr;
my $adv_utk_pre19;
my $adv_utk_verprof;
my $adv_utk_njeunusr;
my $adv_utk_logusr;
my $adv_utk_special;
my $adv_utk_default;
my $adv_utk_unknusr;
my $adv_utk_error;
my $adv_utk_trusted;
my $adv_utk_sesstype;
my $adv_utk_surrogat;
my $adv_utk_remote;
my $adv_utk_priv;
my $adv_utk_secl;
my $adv_utk_execnode;
my $adv_utk_suser_id;
my $adv_utk_snode;
my $adv_utk_sgrp_id;
my $adv_utk_spoe;
my $adv_utk_spclass;
my $adv_utk_user_id;
my $adv_utk_grp_id;
my $adv_utk_dft_grp;
my $adv_utk_dft_secl;
my $adv_appc_link;
my $adv_specified;
my $adv_utk_netw;
my $adv_x500_subject;
my $adv_x500_issuer;
#Create and prepare the INSERT statement for addvol
$statement="INSERT INTO addvol (adv_event_type,adv_event_qual,adv_time_written,adv_date_written,adv_system_smfid,adv_violation,adv_user_ndfnd,adv_user_warning,adv_evt_user_id,adv_evt_grp_id,adv_auth_normal,adv_auth_special,adv_auth_oper,adv_auth_audit,adv_auth_exit,adv_auth_failsft,adv_auth_bypass,adv_auth_trusted,adv_log_class,adv_log_user,adv_log_special,adv_log_access,adv_log_racinit,adv_log_always,adv_log_cmdviol,adv_log_global,adv_term_level,adv_backout_fail,adv_prof_same,adv_term,adv_job_name,adv_read_time,adv_read_date,adv_smf_user_id,adv_log_level,adv_log_vmevent,adv_log_logopt,adv_log_secl,adv_log_compatm,adv_log_applaud,adv_log_nonomvs,adv_log_omvsnprv,adv_auth_omvssu,adv_auth_omvssys,adv_usr_secl,adv_racf_version,adv_res_name,adv_grant,adv_level,adv_vol,adv_oldvol,adv_class,adv_own_id,adv_logstr,adv_user_name,adv_utk_encr,adv_utk_pre19,adv_utk_verprof,adv_utk_njeunusr,adv_utk_logusr,adv_utk_special,adv_utk_default,adv_utk_unknusr,adv_utk_error,adv_utk_trusted,adv_utk_sesstype,adv_utk_surrogat,adv_utk_remote,adv_utk_priv,adv_utk_secl,adv_utk_execnode,adv_utk_suser_id,adv_utk_snode,adv_utk_sgrp_id,adv_utk_spoe,adv_utk_spclass,adv_utk_user_id,adv_utk_grp_id,adv_utk_dft_grp,adv_utk_dft_secl,adv_appc_link,adv_specified,adv_utk_netw,adv_x500_subject,adv_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"addvol"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"addvol"}=0;
#Table:altdsd
#delete all rows from the altdsd table
$dbh->do("delete from altdsd");
#Define the column names for the altdsd table to Perl
my $ald_event_type;
my $ald_event_qual;
my $ald_time_written;
my $ald_date_written;
my $ald_system_smfid;
my $ald_violation;
my $ald_user_ndfnd;
my $ald_user_warning;
my $ald_evt_user_id;
my $ald_evt_grp_id;
my $ald_auth_normal;
my $ald_auth_special;
my $ald_auth_oper;
my $ald_auth_audit;
my $ald_auth_exit;
my $ald_auth_failsft;
my $ald_auth_bypass;
my $ald_auth_trusted;
my $ald_log_class;
my $ald_log_user;
my $ald_log_special;
my $ald_log_access;
my $ald_log_racinit;
my $ald_log_always;
my $ald_log_cmdviol;
my $ald_log_global;
my $ald_term_level;
my $ald_backout_fail;
my $ald_prof_same;
my $ald_term;
my $ald_job_name;
my $ald_read_time;
my $ald_read_date;
my $ald_smf_user_id;
my $ald_log_level;
my $ald_log_vmevent;
my $ald_log_logopt;
my $ald_log_secl;
my $ald_log_compatm;
my $ald_log_applaud;
my $ald_log_nonomvs;
my $ald_log_omvsnprv;
my $ald_auth_omvssu;
my $ald_auth_omvssys;
my $ald_usr_secl;
my $ald_racf_version;
my $ald_own_id;
my $ald_user_name;
my $ald_old_secl;
my $ald_utk_encr;
my $ald_utk_pre19;
my $ald_utk_verprof;
my $ald_utk_njeunusr;
my $ald_utk_logusr;
my $ald_utk_special;
my $ald_utk_default;
my $ald_utk_unknusr;
my $ald_utk_error;
my $ald_utk_trusted;
my $ald_utk_sesstype;
my $ald_utk_surrogat;
my $ald_utk_remote;
my $ald_utk_priv;
my $ald_utk_secl;
my $ald_utk_execnode;
my $ald_utk_suser_id;
my $ald_utk_snode;
my $ald_utk_sgrp_id;
my $ald_utk_spoe;
my $ald_utk_spclass;
my $ald_utk_user_id;
my $ald_utk_grp_id;
my $ald_utk_dft_grp;
my $ald_utk_dft_secl;
my $ald_appc_link;
my $ald_secl_link;
my $ald_ds_name;
my $ald_specified;
my $ald_failed;
my $ald_ignored;
my $ald_utk_netw;
my $ald_x500_subject;
my $ald_x500_issuer;
#Create and prepare the INSERT statement for altdsd
$statement="INSERT INTO altdsd (ald_event_type,ald_event_qual,ald_time_written,ald_date_written,ald_system_smfid,ald_violation,ald_user_ndfnd,ald_user_warning,ald_evt_user_id,ald_evt_grp_id,ald_auth_normal,ald_auth_special,ald_auth_oper,ald_auth_audit,ald_auth_exit,ald_auth_failsft,ald_auth_bypass,ald_auth_trusted,ald_log_class,ald_log_user,ald_log_special,ald_log_access,ald_log_racinit,ald_log_always,ald_log_cmdviol,ald_log_global,ald_term_level,ald_backout_fail,ald_prof_same,ald_term,ald_job_name,ald_read_time,ald_read_date,ald_smf_user_id,ald_log_level,ald_log_vmevent,ald_log_logopt,ald_log_secl,ald_log_compatm,ald_log_applaud,ald_log_nonomvs,ald_log_omvsnprv,ald_auth_omvssu,ald_auth_omvssys,ald_usr_secl,ald_racf_version,ald_own_id,ald_user_name,ald_old_secl,ald_utk_encr,ald_utk_pre19,ald_utk_verprof,ald_utk_njeunusr,ald_utk_logusr,ald_utk_special,ald_utk_default,ald_utk_unknusr,ald_utk_error,ald_utk_trusted,ald_utk_sesstype,ald_utk_surrogat,ald_utk_remote,ald_utk_priv,ald_utk_secl,ald_utk_execnode,ald_utk_suser_id,ald_utk_snode,ald_utk_sgrp_id,ald_utk_spoe,ald_utk_spclass,ald_utk_user_id,ald_utk_grp_id,ald_utk_dft_grp,ald_utk_dft_secl,ald_appc_link,ald_secl_link,ald_ds_name,ald_specified,ald_failed,ald_ignored,ald_utk_netw,ald_x500_subject,ald_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"altdsd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"altdsd"}=0;
#Table:altgroup
#delete all rows from the altgroup table
$dbh->do("delete from altgroup");
#Define the column names for the altgroup table to Perl
my $alg_event_type;
my $alg_event_qual;
my $alg_time_written;
my $alg_date_written;
my $alg_system_smfid;
my $alg_violation;
my $alg_user_ndfnd;
my $alg_user_warning;
my $alg_evt_user_id;
my $alg_evt_grp_id;
my $alg_auth_normal;
my $alg_auth_special;
my $alg_auth_oper;
my $alg_auth_audit;
my $alg_auth_exit;
my $alg_auth_failsft;
my $alg_auth_bypass;
my $alg_auth_trusted;
my $alg_log_class;
my $alg_log_user;
my $alg_log_special;
my $alg_log_access;
my $alg_log_racinit;
my $alg_log_always;
my $alg_log_cmdviol;
my $alg_log_global;
my $alg_term_level;
my $alg_backout_fail;
my $alg_prof_same;
my $alg_term;
my $alg_job_name;
my $alg_read_time;
my $alg_read_date;
my $alg_smf_user_id;
my $alg_log_level;
my $alg_log_vmevent;
my $alg_log_logopt;
my $alg_log_secl;
my $alg_log_compatm;
my $alg_log_applaud;
my $alg_log_nonomvs;
my $alg_log_omvsnprv;
my $alg_auth_omvssu;
my $alg_auth_omvssys;
my $alg_usr_secl;
my $alg_racf_version;
my $alg_own_id;
my $alg_user_name;
my $alg_utk_encr;
my $alg_utk_pre19;
my $alg_utk_verprof;
my $alg_utk_njeunusr;
my $alg_utk_logusr;
my $alg_utk_special;
my $alg_utk_default;
my $alg_utk_unknusr;
my $alg_utk_error;
my $alg_utk_trusted;
my $alg_utk_sesstype;
my $alg_utk_surrogat;
my $alg_utk_remote;
my $alg_utk_priv;
my $alg_utk_secl;
my $alg_utk_execnode;
my $alg_utk_suser_id;
my $alg_utk_snode;
my $alg_utk_sgrp_id;
my $alg_utk_spoe;
my $alg_utk_spclass;
my $alg_utk_user_id;
my $alg_utk_grp_id;
my $alg_utk_dft_grp;
my $alg_utk_dft_secl;
my $alg_appc_link;
my $alg_grp_id;
my $alg_specified;
my $alg_failed;
my $alg_ignored;
my $alg_utk_netw;
my $alg_x500_subject;
my $alg_x500_issuer;
#Create and prepare the INSERT statement for altgroup
$statement="INSERT INTO altgroup (alg_event_type,alg_event_qual,alg_time_written,alg_date_written,alg_system_smfid,alg_violation,alg_user_ndfnd,alg_user_warning,alg_evt_user_id,alg_evt_grp_id,alg_auth_normal,alg_auth_special,alg_auth_oper,alg_auth_audit,alg_auth_exit,alg_auth_failsft,alg_auth_bypass,alg_auth_trusted,alg_log_class,alg_log_user,alg_log_special,alg_log_access,alg_log_racinit,alg_log_always,alg_log_cmdviol,alg_log_global,alg_term_level,alg_backout_fail,alg_prof_same,alg_term,alg_job_name,alg_read_time,alg_read_date,alg_smf_user_id,alg_log_level,alg_log_vmevent,alg_log_logopt,alg_log_secl,alg_log_compatm,alg_log_applaud,alg_log_nonomvs,alg_log_omvsnprv,alg_auth_omvssu,alg_auth_omvssys,alg_usr_secl,alg_racf_version,alg_own_id,alg_user_name,alg_utk_encr,alg_utk_pre19,alg_utk_verprof,alg_utk_njeunusr,alg_utk_logusr,alg_utk_special,alg_utk_default,alg_utk_unknusr,alg_utk_error,alg_utk_trusted,alg_utk_sesstype,alg_utk_surrogat,alg_utk_remote,alg_utk_priv,alg_utk_secl,alg_utk_execnode,alg_utk_suser_id,alg_utk_snode,alg_utk_sgrp_id,alg_utk_spoe,alg_utk_spclass,alg_utk_user_id,alg_utk_grp_id,alg_utk_dft_grp,alg_utk_dft_secl,alg_appc_link,alg_grp_id,alg_specified,alg_failed,alg_ignored,alg_utk_netw,alg_x500_subject,alg_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"altgroup"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"altgroup"}=0;
#Table:altuser
#delete all rows from the altuser table
$dbh->do("delete from altuser");
#Define the column names for the altuser table to Perl
my $alu_event_type;
my $alu_event_qual;
my $alu_time_written;
my $alu_date_written;
my $alu_system_smfid;
my $alu_violation;
my $alu_user_ndfnd;
my $alu_user_warning;
my $alu_evt_user_id;
my $alu_evt_grp_id;
my $alu_auth_normal;
my $alu_auth_special;
my $alu_auth_oper;
my $alu_auth_audit;
my $alu_auth_exit;
my $alu_auth_failsft;
my $alu_auth_bypass;
my $alu_auth_trusted;
my $alu_log_class;
my $alu_log_user;
my $alu_log_special;
my $alu_log_access;
my $alu_log_racinit;
my $alu_log_always;
my $alu_log_cmdviol;
my $alu_log_global;
my $alu_term_level;
my $alu_backout_fail;
my $alu_prof_same;
my $alu_term;
my $alu_job_name;
my $alu_read_time;
my $alu_read_date;
my $alu_smf_user_id;
my $alu_log_level;
my $alu_log_vmevent;
my $alu_log_logopt;
my $alu_log_secl;
my $alu_log_compatm;
my $alu_log_applaud;
my $alu_log_nonomvs;
my $alu_log_omvsnprv;
my $alu_auth_omvssu;
my $alu_auth_omvssys;
my $alu_usr_secl;
my $alu_racf_version;
my $alu_own_id;
my $alu_user_name;
my $alu_old_secl;
my $alu_utk_encr;
my $alu_utk_pre19;
my $alu_utk_verprof;
my $alu_utk_njeunusr;
my $alu_utk_logusr;
my $alu_utk_special;
my $alu_utk_default;
my $alu_utk_unknusr;
my $alu_utk_error;
my $alu_utk_trusted;
my $alu_utk_sesstype;
my $alu_utk_surrogat;
my $alu_utk_remote;
my $alu_utk_priv;
my $alu_utk_secl;
my $alu_utk_execnode;
my $alu_utk_suser_id;
my $alu_utk_snode;
my $alu_utk_sgrp_id;
my $alu_utk_spoe;
my $alu_utk_spclass;
my $alu_utk_user_id;
my $alu_utk_grp_id;
my $alu_utk_dft_grp;
my $alu_utk_dft_secl;
my $alu_appc_link;
my $alu_noauth_clauth;
my $alu_noauth_group;
my $alu_noauth_prof;
my $alu_user_id;
my $alu_specified;
my $alu_failed;
my $alu_ignored;
my $alu_utk_netw;
my $alu_x500_subject;
my $alu_x500_issuer;
#Create and prepare the INSERT statement for altuser
$statement="INSERT INTO altuser (alu_event_type,alu_event_qual,alu_time_written,alu_date_written,alu_system_smfid,alu_violation,alu_user_ndfnd,alu_user_warning,alu_evt_user_id,alu_evt_grp_id,alu_auth_normal,alu_auth_special,alu_auth_oper,alu_auth_audit,alu_auth_exit,alu_auth_failsft,alu_auth_bypass,alu_auth_trusted,alu_log_class,alu_log_user,alu_log_special,alu_log_access,alu_log_racinit,alu_log_always,alu_log_cmdviol,alu_log_global,alu_term_level,alu_backout_fail,alu_prof_same,alu_term,alu_job_name,alu_read_time,alu_read_date,alu_smf_user_id,alu_log_level,alu_log_vmevent,alu_log_logopt,alu_log_secl,alu_log_compatm,alu_log_applaud,alu_log_nonomvs,alu_log_omvsnprv,alu_auth_omvssu,alu_auth_omvssys,alu_usr_secl,alu_racf_version,alu_own_id,alu_user_name,alu_old_secl,alu_utk_encr,alu_utk_pre19,alu_utk_verprof,alu_utk_njeunusr,alu_utk_logusr,alu_utk_special,alu_utk_default,alu_utk_unknusr,alu_utk_error,alu_utk_trusted,alu_utk_sesstype,alu_utk_surrogat,alu_utk_remote,alu_utk_priv,alu_utk_secl,alu_utk_execnode,alu_utk_suser_id,alu_utk_snode,alu_utk_sgrp_id,alu_utk_spoe,alu_utk_spclass,alu_utk_user_id,alu_utk_grp_id,alu_utk_dft_grp,alu_utk_dft_secl,alu_appc_link,alu_noauth_clauth,alu_noauth_group,alu_noauth_prof,alu_user_id,alu_specified,alu_failed,alu_ignored,alu_utk_netw,alu_x500_subject,alu_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"altuser"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"altuser"}=0;
#Table:appclu
#delete all rows from the appclu table
$dbh->do("delete from appclu");
#Define the column names for the appclu table to Perl
my $appc_event_type;
my $appc_event_qual;
my $appc_time_written;
my $appc_date_written;
my $appc_system_smfid;
my $appc_violation;
my $appc_user_ndfnd;
my $appc_user_warning;
my $appc_evt_user_id;
my $appc_evt_grp_id;
my $appc_auth_normal;
my $appc_auth_special;
my $appc_auth_oper;
my $appc_auth_audit;
my $appc_auth_exit;
my $appc_auth_failsft;
my $appc_auth_bypass;
my $appc_auth_trusted;
my $appc_log_class;
my $appc_log_user;
my $appc_log_special;
my $appc_log_access;
my $appc_log_racinit;
my $appc_log_always;
my $appc_log_cmdviol;
my $appc_log_global;
my $appc_term_level;
my $appc_backout_fail;
my $appc_prof_same;
my $appc_term;
my $appc_job_name;
my $appc_read_time;
my $appc_read_date;
my $appc_smf_user_id;
my $appc_log_level;
my $appc_log_vmevent;
my $appc_log_logopt;
my $appc_log_secl;
my $appc_log_compatm;
my $appc_log_applaud;
my $appc_log_nonomvs;
my $appc_log_omvsnprv;
my $appc_auth_omvssu;
my $appc_auth_omvssys;
my $appc_usr_secl;
my $appc_racf_version;
my $appc_res_name;
my $appc_class;
my $appc_type;
my $appc_name;
my $appc_own_id;
my $appc_user_name;
my $appc_utk_encr;
my $appc_utk_pre19;
my $appc_utk_verprof;
my $appc_utk_njeunusr;
my $appc_utk_logusr;
my $appc_utk_special;
my $appc_utk_default;
my $appc_utk_unknusr;
my $appc_utk_error;
my $appc_utk_trusted;
my $appc_utk_sesstype;
my $appc_utk_surrogat;
my $appc_utk_remote;
my $appc_utk_priv;
my $appc_utk_secl;
my $appc_utk_execnode;
my $appc_utk_suser_id;
my $appc_utk_snode;
my $appc_utk_sgrp_id;
my $appc_utk_spoe;
my $appc_utk_spclass;
my $appc_utk_user_id;
my $appc_utk_grp_id;
my $appc_utk_dft_grp;
my $appc_utk_dft_secl;
my $appc_appc_link;
my $appc_utk_netw;
my $appc_x500_subject;
my $appc_x500_issuer;
#Create and prepare the INSERT statement for appclu
$statement="INSERT INTO appclu (appc_event_type,appc_event_qual,appc_time_written,appc_date_written,appc_system_smfid,appc_violation,appc_user_ndfnd,appc_user_warning,appc_evt_user_id,appc_evt_grp_id,appc_auth_normal,appc_auth_special,appc_auth_oper,appc_auth_audit,appc_auth_exit,appc_auth_failsft,appc_auth_bypass,appc_auth_trusted,appc_log_class,appc_log_user,appc_log_special,appc_log_access,appc_log_racinit,appc_log_always,appc_log_cmdviol,appc_log_global,appc_term_level,appc_backout_fail,appc_prof_same,appc_term,appc_job_name,appc_read_time,appc_read_date,appc_smf_user_id,appc_log_level,appc_log_vmevent,appc_log_logopt,appc_log_secl,appc_log_compatm,appc_log_applaud,appc_log_nonomvs,appc_log_omvsnprv,appc_auth_omvssu,appc_auth_omvssys,appc_usr_secl,appc_racf_version,appc_res_name,appc_class,appc_type,appc_name,appc_own_id,appc_user_name,appc_utk_encr,appc_utk_pre19,appc_utk_verprof,appc_utk_njeunusr,appc_utk_logusr,appc_utk_special,appc_utk_default,appc_utk_unknusr,appc_utk_error,appc_utk_trusted,appc_utk_sesstype,appc_utk_surrogat,appc_utk_remote,appc_utk_priv,appc_utk_secl,appc_utk_execnode,appc_utk_suser_id,appc_utk_snode,appc_utk_sgrp_id,appc_utk_spoe,appc_utk_spclass,appc_utk_user_id,appc_utk_grp_id,appc_utk_dft_grp,appc_utk_dft_secl,appc_appc_link,appc_utk_netw,appc_x500_subject,appc_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"appclu"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"appclu"}=0;
#Table:chaudit
#delete all rows from the chaudit table
$dbh->do("delete from chaudit");
#Define the column names for the chaudit table to Perl
my $caud_event_type;
my $caud_event_qual;
my $caud_time_written;
my $caud_date_written;
my $caud_system_smfid;
my $caud_violation;
my $caud_user_ndfnd;
my $caud_user_warning;
my $caud_evt_user_id;
my $caud_evt_grp_id;
my $caud_auth_normal;
my $caud_auth_special;
my $caud_auth_oper;
my $caud_auth_audit;
my $caud_auth_exit;
my $caud_auth_failsft;
my $caud_auth_bypass;
my $caud_auth_trusted;
my $caud_log_class;
my $caud_log_user;
my $caud_log_special;
my $caud_log_access;
my $caud_log_racinit;
my $caud_log_always;
my $caud_log_cmdviol;
my $caud_log_global;
my $caud_term_level;
my $caud_backout_fail;
my $caud_prof_same;
my $caud_term;
my $caud_job_name;
my $caud_read_time;
my $caud_read_date;
my $caud_smf_user_id;
my $caud_log_level;
my $caud_log_vmevent;
my $caud_log_logopt;
my $caud_log_secl;
my $caud_log_compatm;
my $caud_log_applaud;
my $caud_log_nonomvs;
my $caud_log_omvsnprv;
my $caud_auth_omvssu;
my $caud_auth_omvssys;
my $caud_usr_secl;
my $caud_racf_version;
my $caud_class;
my $caud_user_name;
my $caud_utk_encr;
my $caud_utk_pre19;
my $caud_utk_verprof;
my $caud_utk_njeunusr;
my $caud_utk_logusr;
my $caud_utk_special;
my $caud_utk_default;
my $caud_utk_unknusr;
my $caud_utk_error;
my $caud_utk_trusted;
my $caud_utk_sesstype;
my $caud_utk_surrogat;
my $caud_utk_remote;
my $caud_utk_priv;
my $caud_utk_secl;
my $caud_utk_execnode;
my $caud_utk_suser_id;
my $caud_utk_snode;
my $caud_utk_sgrp_id;
my $caud_utk_spoe;
my $caud_utk_spclass;
my $caud_utk_user_id;
my $caud_utk_grp_id;
my $caud_utk_dft_grp;
my $caud_utk_dft_secl;
my $caud_appc_link;
my $caud_audit_code;
my $caud_old_real_uid;
my $caud_old_eff_uid;
my $caud_old_saved_uid;
my $caud_old_real_gid;
my $caud_old_eff_gid;
my $caud_old_saved_gid;
my $caud_path_name;
my $caud_file_id;
my $caud_file_own_uid;
my $caud_file_own_gid;
my $caud_request_read;
my $caud_request_write;
my $caud_request_exec;
my $caud_uold_read;
my $caud_uold_write;
my $caud_uold_exec;
my $caud_aold_read;
my $caud_aold_write;
my $caud_aold_exec;
my $caud_unew_read;
my $caud_unew_write;
my $caud_unew_exec;
my $caud_anew_read;
my $caud_anew_write;
my $caud_anew_exec;
my $caud_filepool;
my $caud_filespace;
my $caud_inode;
my $caud_scid;
my $caud_dce_link;
my $caud_auth_type;
my $caud_dflt_process;
my $caud_utk_netw;
my $caud_x500_subject;
my $caud_x500_issuer;
#Create and prepare the INSERT statement for chaudit
$statement="INSERT INTO chaudit (caud_event_type,caud_event_qual,caud_time_written,caud_date_written,caud_system_smfid,caud_violation,caud_user_ndfnd,caud_user_warning,caud_evt_user_id,caud_evt_grp_id,caud_auth_normal,caud_auth_special,caud_auth_oper,caud_auth_audit,caud_auth_exit,caud_auth_failsft,caud_auth_bypass,caud_auth_trusted,caud_log_class,caud_log_user,caud_log_special,caud_log_access,caud_log_racinit,caud_log_always,caud_log_cmdviol,caud_log_global,caud_term_level,caud_backout_fail,caud_prof_same,caud_term,caud_job_name,caud_read_time,caud_read_date,caud_smf_user_id,caud_log_level,caud_log_vmevent,caud_log_logopt,caud_log_secl,caud_log_compatm,caud_log_applaud,caud_log_nonomvs,caud_log_omvsnprv,caud_auth_omvssu,caud_auth_omvssys,caud_usr_secl,caud_racf_version,caud_class,caud_user_name,caud_utk_encr,caud_utk_pre19,caud_utk_verprof,caud_utk_njeunusr,caud_utk_logusr,caud_utk_special,caud_utk_default,caud_utk_unknusr,caud_utk_error,caud_utk_trusted,caud_utk_sesstype,caud_utk_surrogat,caud_utk_remote,caud_utk_priv,caud_utk_secl,caud_utk_execnode,caud_utk_suser_id,caud_utk_snode,caud_utk_sgrp_id,caud_utk_spoe,caud_utk_spclass,caud_utk_user_id,caud_utk_grp_id,caud_utk_dft_grp,caud_utk_dft_secl,caud_appc_link,caud_audit_code,caud_old_real_uid,caud_old_eff_uid,caud_old_saved_uid,caud_old_real_gid,caud_old_eff_gid,caud_old_saved_gid,caud_path_name,caud_file_id,caud_file_own_uid,caud_file_own_gid,caud_request_read,caud_request_write,caud_request_exec,caud_uold_read,caud_uold_write,caud_uold_exec,caud_aold_read,caud_aold_write,caud_aold_exec,caud_unew_read,caud_unew_write,caud_unew_exec,caud_anew_read,caud_anew_write,caud_anew_exec,caud_filepool,caud_filespace,caud_inode,caud_scid,caud_dce_link,caud_auth_type,caud_dflt_process,caud_utk_netw,caud_x500_subject,caud_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chaudit"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chaudit"}=0;
#Table:chdir
#delete all rows from the chdir table
$dbh->do("delete from chdir");
#Define the column names for the chdir table to Perl
my $cdir_event_type;
my $cdir_event_qual;
my $cdir_time_written;
my $cdir_date_written;
my $cdir_system_smfid;
my $cdir_violation;
my $cdir_user_ndfnd;
my $cdir_user_warning;
my $cdir_evt_user_id;
my $cdir_evt_grp_id;
my $cdir_auth_normal;
my $cdir_auth_special;
my $cdir_auth_oper;
my $cdir_auth_audit;
my $cdir_auth_exit;
my $cdir_auth_failsft;
my $cdir_auth_bypass;
my $cdir_auth_trusted;
my $cdir_log_class;
my $cdir_log_user;
my $cdir_log_special;
my $cdir_log_access;
my $cdir_log_racinit;
my $cdir_log_always;
my $cdir_log_cmdviol;
my $cdir_log_global;
my $cdir_term_level;
my $cdir_backout_fail;
my $cdir_prof_same;
my $cdir_term;
my $cdir_job_name;
my $cdir_read_time;
my $cdir_read_date;
my $cdir_smf_user_id;
my $cdir_log_level;
my $cdir_log_vmevent;
my $cdir_log_logopt;
my $cdir_log_secl;
my $cdir_log_compatm;
my $cdir_log_applaud;
my $cdir_log_nonomvs;
my $cdir_log_omvsnprv;
my $cdir_auth_omvssu;
my $cdir_auth_omvssys;
my $cdir_usr_secl;
my $cdir_racf_version;
my $cdir_class;
my $cdir_user_name;
my $cdir_utk_encr;
my $cdir_utk_pre19;
my $cdir_utk_verprof;
my $cdir_utk_njeunusr;
my $cdir_utk_logusr;
my $cdir_utk_special;
my $cdir_utk_default;
my $cdir_utk_unknusr;
my $cdir_utk_error;
my $cdir_utk_trusted;
my $cdir_utk_sesstype;
my $cdir_utk_surrogat;
my $cdir_utk_remote;
my $cdir_utk_priv;
my $cdir_utk_secl;
my $cdir_utk_execnode;
my $cdir_utk_suser_id;
my $cdir_utk_snode;
my $cdir_utk_sgrp_id;
my $cdir_utk_spoe;
my $cdir_utk_spclass;
my $cdir_utk_user_id;
my $cdir_utk_grp_id;
my $cdir_utk_dft_grp;
my $cdir_utk_dft_secl;
my $cdir_appc_link;
my $cdir_audit_code;
my $cdir_old_real_uid;
my $cdir_old_eff_uid;
my $cdir_old_saved_uid;
my $cdir_old_real_gid;
my $cdir_old_eff_gid;
my $cdir_old_saved_gid;
my $cdir_path_name;
my $cdir_file_id;
my $cdir_file_own_uid;
my $cdir_file_own_gid;
my $cdir_dce_link;
my $cdir_auth_type;
my $cdir_dflt_process;
my $cdir_utk_netw;
my $cdir_x500_subject;
my $cdir_x500_issuer;
#Create and prepare the INSERT statement for chdir
$statement="INSERT INTO chdir (cdir_event_type,cdir_event_qual,cdir_time_written,cdir_date_written,cdir_system_smfid,cdir_violation,cdir_user_ndfnd,cdir_user_warning,cdir_evt_user_id,cdir_evt_grp_id,cdir_auth_normal,cdir_auth_special,cdir_auth_oper,cdir_auth_audit,cdir_auth_exit,cdir_auth_failsft,cdir_auth_bypass,cdir_auth_trusted,cdir_log_class,cdir_log_user,cdir_log_special,cdir_log_access,cdir_log_racinit,cdir_log_always,cdir_log_cmdviol,cdir_log_global,cdir_term_level,cdir_backout_fail,cdir_prof_same,cdir_term,cdir_job_name,cdir_read_time,cdir_read_date,cdir_smf_user_id,cdir_log_level,cdir_log_vmevent,cdir_log_logopt,cdir_log_secl,cdir_log_compatm,cdir_log_applaud,cdir_log_nonomvs,cdir_log_omvsnprv,cdir_auth_omvssu,cdir_auth_omvssys,cdir_usr_secl,cdir_racf_version,cdir_class,cdir_user_name,cdir_utk_encr,cdir_utk_pre19,cdir_utk_verprof,cdir_utk_njeunusr,cdir_utk_logusr,cdir_utk_special,cdir_utk_default,cdir_utk_unknusr,cdir_utk_error,cdir_utk_trusted,cdir_utk_sesstype,cdir_utk_surrogat,cdir_utk_remote,cdir_utk_priv,cdir_utk_secl,cdir_utk_execnode,cdir_utk_suser_id,cdir_utk_snode,cdir_utk_sgrp_id,cdir_utk_spoe,cdir_utk_spclass,cdir_utk_user_id,cdir_utk_grp_id,cdir_utk_dft_grp,cdir_utk_dft_secl,cdir_appc_link,cdir_audit_code,cdir_old_real_uid,cdir_old_eff_uid,cdir_old_saved_uid,cdir_old_real_gid,cdir_old_eff_gid,cdir_old_saved_gid,cdir_path_name,cdir_file_id,cdir_file_own_uid,cdir_file_own_gid,cdir_dce_link,cdir_auth_type,cdir_dflt_process,cdir_utk_netw,cdir_x500_subject,cdir_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chdir"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chdir"}=0;
#Table:chkfown
#delete all rows from the chkfown table
$dbh->do("delete from chkfown");
#Define the column names for the chkfown table to Perl
my $cfow_event_type;
my $cfow_event_qual;
my $cfow_time_written;
my $cfow_date_written;
my $cfow_system_smfid;
my $cfow_violation;
my $cfow_user_ndfnd;
my $cfow_user_warning;
my $cfow_evt_user_id;
my $cfow_evt_grp_id;
my $cfow_auth_normal;
my $cfow_auth_special;
my $cfow_auth_oper;
my $cfow_auth_audit;
my $cfow_auth_exit;
my $cfow_auth_failsft;
my $cfow_auth_bypass;
my $cfow_auth_trusted;
my $cfow_log_class;
my $cfow_log_user;
my $cfow_log_special;
my $cfow_log_access;
my $cfow_log_racinit;
my $cfow_log_always;
my $cfow_log_cmdviol;
my $cfow_log_global;
my $cfow_term_level;
my $cfow_backout_fail;
my $cfow_prof_same;
my $cfow_term;
my $cfow_job_name;
my $cfow_read_time;
my $cfow_read_date;
my $cfow_smf_user_id;
my $cfow_log_level;
my $cfow_log_vmevent;
my $cfow_log_logopt;
my $cfow_log_secl;
my $cfow_log_compatm;
my $cfow_log_applaud;
my $cfow_log_nonomvs;
my $cfow_log_omvsnprv;
my $cfow_auth_omvssu;
my $cfow_auth_omvssys;
my $cfow_usr_secl;
my $cfow_racf_version;
my $cfow_class;
my $cfow_user_name;
my $cfow_utk_encr;
my $cfow_utk_pre19;
my $cfow_utk_verprof;
my $cfow_utk_njeunusr;
my $cfow_utk_logusr;
my $cfow_utk_special;
my $cfow_utk_default;
my $cfow_utk_unknusr;
my $cfow_utk_error;
my $cfow_utk_trusted;
my $cfow_utk_sesstype;
my $cfow_utk_surrogat;
my $cfow_utk_remote;
my $cfow_utk_priv;
my $cfow_utk_secl;
my $cfow_utk_execnode;
my $cfow_utk_suser_id;
my $cfow_utk_snode;
my $cfow_utk_sgrp_id;
my $cfow_utk_spoe;
my $cfow_utk_spclass;
my $cfow_utk_user_id;
my $cfow_utk_grp_id;
my $cfow_utk_dft_grp;
my $cfow_utk_dft_secl;
my $cfow_appc_link;
my $cfow_audit_code;
my $cfow_old_real_uid;
my $cfow_old_eff_uid;
my $cfow_old_saved_uid;
my $cfow_old_real_gid;
my $cfow_old_eff_gid;
my $cfow_old_saved_gid;
my $cfow_path_name;
my $cfow_file_id;
my $cfow_file_own_uid;
my $cfow_file_own_gid;
my $cfow_filepool;
my $cfow_filespace;
my $cfow_inode;
my $cfow_scid;
my $cfow_dce_link;
my $cfow_auth_type;
my $cfow_dflt_process;
my $cfow_utk_netw;
my $cfow_x500_subject;
my $cfow_x500_issuer;
#Create and prepare the INSERT statement for chkfown
$statement="INSERT INTO chkfown (cfow_event_type,cfow_event_qual,cfow_time_written,cfow_date_written,cfow_system_smfid,cfow_violation,cfow_user_ndfnd,cfow_user_warning,cfow_evt_user_id,cfow_evt_grp_id,cfow_auth_normal,cfow_auth_special,cfow_auth_oper,cfow_auth_audit,cfow_auth_exit,cfow_auth_failsft,cfow_auth_bypass,cfow_auth_trusted,cfow_log_class,cfow_log_user,cfow_log_special,cfow_log_access,cfow_log_racinit,cfow_log_always,cfow_log_cmdviol,cfow_log_global,cfow_term_level,cfow_backout_fail,cfow_prof_same,cfow_term,cfow_job_name,cfow_read_time,cfow_read_date,cfow_smf_user_id,cfow_log_level,cfow_log_vmevent,cfow_log_logopt,cfow_log_secl,cfow_log_compatm,cfow_log_applaud,cfow_log_nonomvs,cfow_log_omvsnprv,cfow_auth_omvssu,cfow_auth_omvssys,cfow_usr_secl,cfow_racf_version,cfow_class,cfow_user_name,cfow_utk_encr,cfow_utk_pre19,cfow_utk_verprof,cfow_utk_njeunusr,cfow_utk_logusr,cfow_utk_special,cfow_utk_default,cfow_utk_unknusr,cfow_utk_error,cfow_utk_trusted,cfow_utk_sesstype,cfow_utk_surrogat,cfow_utk_remote,cfow_utk_priv,cfow_utk_secl,cfow_utk_execnode,cfow_utk_suser_id,cfow_utk_snode,cfow_utk_sgrp_id,cfow_utk_spoe,cfow_utk_spclass,cfow_utk_user_id,cfow_utk_grp_id,cfow_utk_dft_grp,cfow_utk_dft_secl,cfow_appc_link,cfow_audit_code,cfow_old_real_uid,cfow_old_eff_uid,cfow_old_saved_uid,cfow_old_real_gid,cfow_old_eff_gid,cfow_old_saved_gid,cfow_path_name,cfow_file_id,cfow_file_own_uid,cfow_file_own_gid,cfow_filepool,cfow_filespace,cfow_inode,cfow_scid,cfow_dce_link,cfow_auth_type,cfow_dflt_process,cfow_utk_netw,cfow_x500_subject,cfow_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chkfown"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chkfown"}=0;
#Table:chkpriv
#delete all rows from the chkpriv table
$dbh->do("delete from chkpriv");
#Define the column names for the chkpriv table to Perl
my $cprv_event_type;
my $cprv_event_qual;
my $cprv_time_written;
my $cprv_date_written;
my $cprv_system_smfid;
my $cprv_violation;
my $cprv_user_ndfnd;
my $cprv_user_warning;
my $cprv_evt_user_id;
my $cprv_evt_grp_id;
my $cprv_auth_normal;
my $cprv_auth_special;
my $cprv_auth_oper;
my $cprv_auth_audit;
my $cprv_auth_exit;
my $cprv_auth_failsft;
my $cprv_auth_bypass;
my $cprv_auth_trusted;
my $cprv_log_class;
my $cprv_log_user;
my $cprv_log_special;
my $cprv_log_access;
my $cprv_log_racinit;
my $cprv_log_always;
my $cprv_log_cmdviol;
my $cprv_log_global;
my $cprv_term_level;
my $cprv_backout_fail;
my $cprv_prof_same;
my $cprv_term;
my $cprv_job_name;
my $cprv_read_time;
my $cprv_read_date;
my $cprv_smf_user_id;
my $cprv_log_level;
my $cprv_log_vmevent;
my $cprv_log_logopt;
my $cprv_log_secl;
my $cprv_log_compatm;
my $cprv_log_applaud;
my $cprv_log_nonomvs;
my $cprv_log_omvsnprv;
my $cprv_auth_omvssu;
my $cprv_auth_omvssys;
my $cprv_usr_secl;
my $cprv_racf_version;
my $cprv_class;
my $cprv_user_name;
my $cprv_utk_encr;
my $cprv_utk_pre19;
my $cprv_utk_verprof;
my $cprv_utk_njeunusr;
my $cprv_utk_logusr;
my $cprv_utk_special;
my $cprv_utk_default;
my $cprv_utk_unknusr;
my $cprv_utk_error;
my $cprv_utk_trusted;
my $cprv_utk_sesstype;
my $cprv_utk_surrogat;
my $cprv_utk_remote;
my $cprv_utk_priv;
my $cprv_utk_secl;
my $cprv_utk_execnode;
my $cprv_utk_suser_id;
my $cprv_utk_snode;
my $cprv_utk_sgrp_id;
my $cprv_utk_spoe;
my $cprv_utk_spclass;
my $cprv_utk_user_id;
my $cprv_utk_grp_id;
my $cprv_utk_dft_grp;
my $cprv_utk_dft_secl;
my $cprv_appc_link;
my $cprv_audit_code;
my $cprv_old_real_uid;
my $cprv_old_eff_uid;
my $cprv_old_saved_uid;
my $cprv_old_real_gid;
my $cprv_old_eff_gid;
my $cprv_old_saved_gid;
my $cprv_dce_link;
my $cprv_auth_type;
my $cprv_dflt_process;
my $cprv_utk_netw;
my $cprv_x500_subject;
my $cprv_x500_issuer;
#Create and prepare the INSERT statement for chkpriv
$statement="INSERT INTO chkpriv (cprv_event_type,cprv_event_qual,cprv_time_written,cprv_date_written,cprv_system_smfid,cprv_violation,cprv_user_ndfnd,cprv_user_warning,cprv_evt_user_id,cprv_evt_grp_id,cprv_auth_normal,cprv_auth_special,cprv_auth_oper,cprv_auth_audit,cprv_auth_exit,cprv_auth_failsft,cprv_auth_bypass,cprv_auth_trusted,cprv_log_class,cprv_log_user,cprv_log_special,cprv_log_access,cprv_log_racinit,cprv_log_always,cprv_log_cmdviol,cprv_log_global,cprv_term_level,cprv_backout_fail,cprv_prof_same,cprv_term,cprv_job_name,cprv_read_time,cprv_read_date,cprv_smf_user_id,cprv_log_level,cprv_log_vmevent,cprv_log_logopt,cprv_log_secl,cprv_log_compatm,cprv_log_applaud,cprv_log_nonomvs,cprv_log_omvsnprv,cprv_auth_omvssu,cprv_auth_omvssys,cprv_usr_secl,cprv_racf_version,cprv_class,cprv_user_name,cprv_utk_encr,cprv_utk_pre19,cprv_utk_verprof,cprv_utk_njeunusr,cprv_utk_logusr,cprv_utk_special,cprv_utk_default,cprv_utk_unknusr,cprv_utk_error,cprv_utk_trusted,cprv_utk_sesstype,cprv_utk_surrogat,cprv_utk_remote,cprv_utk_priv,cprv_utk_secl,cprv_utk_execnode,cprv_utk_suser_id,cprv_utk_snode,cprv_utk_sgrp_id,cprv_utk_spoe,cprv_utk_spclass,cprv_utk_user_id,cprv_utk_grp_id,cprv_utk_dft_grp,cprv_utk_dft_secl,cprv_appc_link,cprv_audit_code,cprv_old_real_uid,cprv_old_eff_uid,cprv_old_saved_uid,cprv_old_real_gid,cprv_old_eff_gid,cprv_old_saved_gid,cprv_dce_link,cprv_auth_type,cprv_dflt_process,cprv_utk_netw,cprv_x500_subject,cprv_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chkpriv"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chkpriv"}=0;
#Table:chmod
#delete all rows from the chmod table
$dbh->do("delete from chmod");
#Define the column names for the chmod table to Perl
my $cmod_event_type;
my $cmod_event_qual;
my $cmod_time_written;
my $cmod_date_written;
my $cmod_system_smfid;
my $cmod_violation;
my $cmod_user_ndfnd;
my $cmod_user_warning;
my $cmod_evt_user_id;
my $cmod_evt_grp_id;
my $cmod_auth_normal;
my $cmod_auth_special;
my $cmod_auth_oper;
my $cmod_auth_audit;
my $cmod_auth_exit;
my $cmod_auth_failsft;
my $cmod_auth_bypass;
my $cmod_auth_trusted;
my $cmod_log_class;
my $cmod_log_user;
my $cmod_log_special;
my $cmod_log_access;
my $cmod_log_racinit;
my $cmod_log_always;
my $cmod_log_cmdviol;
my $cmod_log_global;
my $cmod_term_level;
my $cmod_backout_fail;
my $cmod_prof_same;
my $cmod_term;
my $cmod_job_name;
my $cmod_read_time;
my $cmod_read_date;
my $cmod_smf_user_id;
my $cmod_log_level;
my $cmod_log_vmevent;
my $cmod_log_logopt;
my $cmod_log_secl;
my $cmod_log_compatm;
my $cmod_log_applaud;
my $cmod_log_nonomvs;
my $cmod_log_omvsnprv;
my $cmod_auth_omvssu;
my $cmod_auth_omvssys;
my $cmod_usr_secl;
my $cmod_racf_version;
my $cmod_class;
my $cmod_user_name;
my $cmod_utk_encr;
my $cmod_utk_pre19;
my $cmod_utk_verprof;
my $cmod_utk_njeunusr;
my $cmod_utk_logusr;
my $cmod_utk_special;
my $cmod_utk_default;
my $cmod_utk_unknusr;
my $cmod_utk_error;
my $cmod_utk_trusted;
my $cmod_utk_sesstype;
my $cmod_utk_surrogat;
my $cmod_utk_remote;
my $cmod_utk_priv;
my $cmod_utk_secl;
my $cmod_utk_execnode;
my $cmod_utk_suser_id;
my $cmod_utk_snode;
my $cmod_utk_sgrp_id;
my $cmod_utk_spoe;
my $cmod_utk_spclass;
my $cmod_utk_user_id;
my $cmod_utk_grp_id;
my $cmod_utk_dft_grp;
my $cmod_utk_dft_secl;
my $cmod_appc_link;
my $cmod_audit_code;
my $cmod_old_real_uid;
my $cmod_old_eff_uid;
my $cmod_old_saved_uid;
my $cmod_old_real_gid;
my $cmod_old_eff_gid;
my $cmod_old_saved_gid;
my $cmod_path_name;
my $cmod_file_id;
my $cmod_file_own_uid;
my $cmod_file_own_gid;
my $cmod_old_s_isgid;
my $cmod_old_s_isuid;
my $cmod_old_s_isvtx;
my $cmod_old_own_read;
my $cmod_old_own_write;
my $cmod_old_own_exec;
my $cmod_old_grp_read;
my $cmod_old_grp_write;
my $cmod_old_grp_exec;
my $cmod_old_oth_read;
my $cmod_old_oth_write;
my $cmod_old_oth_exec;
my $cmod_new_s_isgid;
my $cmod_new_s_isuid;
my $cmod_new_s_isvtx;
my $cmod_new_own_read;
my $cmod_new_own_write;
my $cmod_new_own_exec;
my $cmod_new_grp_read;
my $cmod_new_grp_write;
my $cmod_new_grp_exec;
my $cmod_new_oth_read;
my $cmod_new_oth_write;
my $cmod_new_oth_exec;
my $cmod_req_s_isgid;
my $cmod_req_s_isuid;
my $cmod_req_s_isvtx;
my $cmod_req_own_read;
my $cmod_req_own_write;
my $cmod_req_own_exec;
my $cmod_req_grp_read;
my $cmod_req_grp_write;
my $cmod_req_grp_exec;
my $cmod_req_oth_read;
my $cmod_req_oth_write;
my $cmod_req_oth_exec;
my $cmod_filepool;
my $cmod_filespace;
my $cmod_inode;
my $cmod_scid;
my $cmod_dce_link;
my $cmod_auth_type;
my $cmod_dflt_process;
my $cmod_utk_netw;
my $cmod_x500_subject;
my $cmod_x500_issuer;
#Create and prepare the INSERT statement for chmod
$statement="INSERT INTO chmod (cmod_event_type,cmod_event_qual,cmod_time_written,cmod_date_written,cmod_system_smfid,cmod_violation,cmod_user_ndfnd,cmod_user_warning,cmod_evt_user_id,cmod_evt_grp_id,cmod_auth_normal,cmod_auth_special,cmod_auth_oper,cmod_auth_audit,cmod_auth_exit,cmod_auth_failsft,cmod_auth_bypass,cmod_auth_trusted,cmod_log_class,cmod_log_user,cmod_log_special,cmod_log_access,cmod_log_racinit,cmod_log_always,cmod_log_cmdviol,cmod_log_global,cmod_term_level,cmod_backout_fail,cmod_prof_same,cmod_term,cmod_job_name,cmod_read_time,cmod_read_date,cmod_smf_user_id,cmod_log_level,cmod_log_vmevent,cmod_log_logopt,cmod_log_secl,cmod_log_compatm,cmod_log_applaud,cmod_log_nonomvs,cmod_log_omvsnprv,cmod_auth_omvssu,cmod_auth_omvssys,cmod_usr_secl,cmod_racf_version,cmod_class,cmod_user_name,cmod_utk_encr,cmod_utk_pre19,cmod_utk_verprof,cmod_utk_njeunusr,cmod_utk_logusr,cmod_utk_special,cmod_utk_default,cmod_utk_unknusr,cmod_utk_error,cmod_utk_trusted,cmod_utk_sesstype,cmod_utk_surrogat,cmod_utk_remote,cmod_utk_priv,cmod_utk_secl,cmod_utk_execnode,cmod_utk_suser_id,cmod_utk_snode,cmod_utk_sgrp_id,cmod_utk_spoe,cmod_utk_spclass,cmod_utk_user_id,cmod_utk_grp_id,cmod_utk_dft_grp,cmod_utk_dft_secl,cmod_appc_link,cmod_audit_code,cmod_old_real_uid,cmod_old_eff_uid,cmod_old_saved_uid,cmod_old_real_gid,cmod_old_eff_gid,cmod_old_saved_gid,cmod_path_name,cmod_file_id,cmod_file_own_uid,cmod_file_own_gid,cmod_old_s_isgid,cmod_old_s_isuid,cmod_old_s_isvtx,cmod_old_own_read,cmod_old_own_write,cmod_old_own_exec,cmod_old_grp_read,cmod_old_grp_write,cmod_old_grp_exec,cmod_old_oth_read,cmod_old_oth_write,cmod_old_oth_exec,cmod_new_s_isgid,cmod_new_s_isuid,cmod_new_s_isvtx,cmod_new_own_read,cmod_new_own_write,cmod_new_own_exec,cmod_new_grp_read,cmod_new_grp_write,cmod_new_grp_exec,cmod_new_oth_read,cmod_new_oth_write,cmod_new_oth_exec,cmod_req_s_isgid,cmod_req_s_isuid,cmod_req_s_isvtx,cmod_req_own_read,cmod_req_own_write,cmod_req_own_exec,cmod_req_grp_read,cmod_req_grp_write,cmod_req_grp_exec,cmod_req_oth_read,cmod_req_oth_write,cmod_req_oth_exec,cmod_filepool,cmod_filespace,cmod_inode,cmod_scid,cmod_dce_link,cmod_auth_type,cmod_dflt_process,cmod_utk_netw,cmod_x500_subject,cmod_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chmod"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chmod"}=0;
#Table:chown
#delete all rows from the chown table
$dbh->do("delete from chown");
#Define the column names for the chown table to Perl
my $cown_event_type;
my $cown_event_qual;
my $cown_time_written;
my $cown_date_written;
my $cown_system_smfid;
my $cown_violation;
my $cown_user_ndfnd;
my $cown_user_warning;
my $cown_evt_user_id;
my $cown_evt_grp_id;
my $cown_auth_normal;
my $cown_auth_special;
my $cown_auth_oper;
my $cown_auth_audit;
my $cown_auth_exit;
my $cown_auth_failsft;
my $cown_auth_bypass;
my $cown_auth_trusted;
my $cown_log_class;
my $cown_log_user;
my $cown_log_special;
my $cown_log_access;
my $cown_log_racinit;
my $cown_log_always;
my $cown_log_cmdviol;
my $cown_log_global;
my $cown_term_level;
my $cown_backout_fail;
my $cown_prof_same;
my $cown_term;
my $cown_job_name;
my $cown_read_time;
my $cown_read_date;
my $cown_smf_user_id;
my $cown_log_level;
my $cown_log_vmevent;
my $cown_log_logopt;
my $cown_log_secl;
my $cown_log_compatm;
my $cown_log_applaud;
my $cown_log_nonomvs;
my $cown_log_omvsnprv;
my $cown_auth_omvssu;
my $cown_auth_omvssys;
my $cown_usr_secl;
my $cown_racf_version;
my $cown_class;
my $cown_user_name;
my $cown_utk_encr;
my $cown_utk_pre19;
my $cown_utk_verprof;
my $cown_utk_njeunusr;
my $cown_utk_logusr;
my $cown_utk_special;
my $cown_utk_default;
my $cown_utk_unknusr;
my $cown_utk_error;
my $cown_utk_trusted;
my $cown_utk_sesstype;
my $cown_utk_surrogat;
my $cown_utk_remote;
my $cown_utk_priv;
my $cown_utk_secl;
my $cown_utk_execnode;
my $cown_utk_suser_id;
my $cown_utk_snode;
my $cown_utk_sgrp_id;
my $cown_utk_spoe;
my $cown_utk_spclass;
my $cown_utk_user_id;
my $cown_utk_grp_id;
my $cown_utk_dft_grp;
my $cown_utk_dft_secl;
my $cown_appc_link;
my $cown_audit_code;
my $cown_old_real_uid;
my $cown_old_eff_uid;
my $cown_old_saved_uid;
my $cown_old_real_gid;
my $cown_old_eff_gid;
my $cown_old_saved_gid;
my $cown_path_name;
my $cown_file_id;
my $cown_file_own_uid;
my $cown_file_own_gid;
my $cown_uid;
my $cown_gid;
my $cown_filepool;
my $cown_filespace;
my $cown_inode;
my $cown_scid;
my $cown_dce_link;
my $cown_auth_type;
my $cown_dflt_process;
my $cown_utk_netw;
my $cown_x500_subject;
my $cown_x500_issuer;
#Create and prepare the INSERT statement for chown
$statement="INSERT INTO chown (cown_event_type,cown_event_qual,cown_time_written,cown_date_written,cown_system_smfid,cown_violation,cown_user_ndfnd,cown_user_warning,cown_evt_user_id,cown_evt_grp_id,cown_auth_normal,cown_auth_special,cown_auth_oper,cown_auth_audit,cown_auth_exit,cown_auth_failsft,cown_auth_bypass,cown_auth_trusted,cown_log_class,cown_log_user,cown_log_special,cown_log_access,cown_log_racinit,cown_log_always,cown_log_cmdviol,cown_log_global,cown_term_level,cown_backout_fail,cown_prof_same,cown_term,cown_job_name,cown_read_time,cown_read_date,cown_smf_user_id,cown_log_level,cown_log_vmevent,cown_log_logopt,cown_log_secl,cown_log_compatm,cown_log_applaud,cown_log_nonomvs,cown_log_omvsnprv,cown_auth_omvssu,cown_auth_omvssys,cown_usr_secl,cown_racf_version,cown_class,cown_user_name,cown_utk_encr,cown_utk_pre19,cown_utk_verprof,cown_utk_njeunusr,cown_utk_logusr,cown_utk_special,cown_utk_default,cown_utk_unknusr,cown_utk_error,cown_utk_trusted,cown_utk_sesstype,cown_utk_surrogat,cown_utk_remote,cown_utk_priv,cown_utk_secl,cown_utk_execnode,cown_utk_suser_id,cown_utk_snode,cown_utk_sgrp_id,cown_utk_spoe,cown_utk_spclass,cown_utk_user_id,cown_utk_grp_id,cown_utk_dft_grp,cown_utk_dft_secl,cown_appc_link,cown_audit_code,cown_old_real_uid,cown_old_eff_uid,cown_old_saved_uid,cown_old_real_gid,cown_old_eff_gid,cown_old_saved_gid,cown_path_name,cown_file_id,cown_file_own_uid,cown_file_own_gid,cown_uid,cown_gid,cown_filepool,cown_filespace,cown_inode,cown_scid,cown_dce_link,cown_auth_type,cown_dflt_process,cown_utk_netw,cown_x500_subject,cown_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"chown"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"chown"}=0;
#Table:ckown2
#delete all rows from the ckown2 table
$dbh->do("delete from ckown2");
#Define the column names for the ckown2 table to Perl
my $cko2_event_type;
my $cko2_event_qual;
my $cko2_time_written;
my $cko2_date_written;
my $cko2_system_smfid;
my $cko2_violation;
my $cko2_user_ndfnd;
my $cko2_user_warning;
my $cko2_evt_user_id;
my $cko2_evt_grp_id;
my $cko2_auth_normal;
my $cko2_auth_special;
my $cko2_auth_oper;
my $cko2_auth_audit;
my $cko2_auth_exit;
my $cko2_auth_failsft;
my $cko2_auth_bypass;
my $cko2_auth_trusted;
my $cko2_log_class;
my $cko2_log_user;
my $cko2_log_special;
my $cko2_log_access;
my $cko2_log_racinit;
my $cko2_log_always;
my $cko2_log_cmdviol;
my $cko2_log_global;
my $cko2_term_level;
my $cko2_backout_fail;
my $cko2_prof_same;
my $cko2_term;
my $cko2_job_name;
my $cko2_read_time;
my $cko2_read_date;
my $cko2_smf_user_id;
my $cko2_log_level;
my $cko2_log_vmevent;
my $cko2_log_logopt;
my $cko2_log_secl;
my $cko2_log_compatm;
my $cko2_log_applaud;
my $cko2_log_nonomvs;
my $cko2_log_omvsnprv;
my $cko2_auth_omvssu;
my $cko2_auth_omvssys;
my $cko2_usr_secl;
my $cko2_racf_version;
my $cko2_class;
my $cko2_user_name;
my $cko2_utk_encr;
my $cko2_utk_pre19;
my $cko2_utk_verprof;
my $cko2_utk_njeunusr;
my $cko2_utk_logusr;
my $cko2_utk_special;
my $cko2_utk_default;
my $cko2_utk_unknusr;
my $cko2_utk_error;
my $cko2_utk_trusted;
my $cko2_utk_sesstype;
my $cko2_utk_surrogat;
my $cko2_utk_remote;
my $cko2_utk_priv;
my $cko2_utk_secl;
my $cko2_utk_execnode;
my $cko2_utk_suser_id;
my $cko2_utk_snode;
my $cko2_utk_sgrp_id;
my $cko2_utk_spoe;
my $cko2_utk_spclass;
my $cko2_utk_user_id;
my $cko2_utk_grp_id;
my $cko2_utk_dft_grp;
my $cko2_utk_dft_secl;
my $cko2_appc_link;
my $cko2_audit_code;
my $cko2_old_real_uid;
my $cko2_old_eff_uid;
my $cko2_old_saved_uid;
my $cko2_old_real_gid;
my $cko2_old_eff_gid;
my $cko2_old_saved_gid;
my $cko2_path_name;
my $cko2_file1_id;
my $cko2_file1_own_uid;
my $cko2_file1_own_gid;
my $cko2_file2_id;
my $cko2_file2_own_uid;
my $cko2_file2_own_gid;
my $cko2_dce_link;
my $cko2_auth_type;
my $cko2_dflt_process;
my $cko2_utk_netw;
my $cko2_x500_subject;
my $cko2_x500_issuer;
#Create and prepare the INSERT statement for ckown2
$statement="INSERT INTO ckown2 (cko2_event_type,cko2_event_qual,cko2_time_written,cko2_date_written,cko2_system_smfid,cko2_violation,cko2_user_ndfnd,cko2_user_warning,cko2_evt_user_id,cko2_evt_grp_id,cko2_auth_normal,cko2_auth_special,cko2_auth_oper,cko2_auth_audit,cko2_auth_exit,cko2_auth_failsft,cko2_auth_bypass,cko2_auth_trusted,cko2_log_class,cko2_log_user,cko2_log_special,cko2_log_access,cko2_log_racinit,cko2_log_always,cko2_log_cmdviol,cko2_log_global,cko2_term_level,cko2_backout_fail,cko2_prof_same,cko2_term,cko2_job_name,cko2_read_time,cko2_read_date,cko2_smf_user_id,cko2_log_level,cko2_log_vmevent,cko2_log_logopt,cko2_log_secl,cko2_log_compatm,cko2_log_applaud,cko2_log_nonomvs,cko2_log_omvsnprv,cko2_auth_omvssu,cko2_auth_omvssys,cko2_usr_secl,cko2_racf_version,cko2_class,cko2_user_name,cko2_utk_encr,cko2_utk_pre19,cko2_utk_verprof,cko2_utk_njeunusr,cko2_utk_logusr,cko2_utk_special,cko2_utk_default,cko2_utk_unknusr,cko2_utk_error,cko2_utk_trusted,cko2_utk_sesstype,cko2_utk_surrogat,cko2_utk_remote,cko2_utk_priv,cko2_utk_secl,cko2_utk_execnode,cko2_utk_suser_id,cko2_utk_snode,cko2_utk_sgrp_id,cko2_utk_spoe,cko2_utk_spclass,cko2_utk_user_id,cko2_utk_grp_id,cko2_utk_dft_grp,cko2_utk_dft_secl,cko2_appc_link,cko2_audit_code,cko2_old_real_uid,cko2_old_eff_uid,cko2_old_saved_uid,cko2_old_real_gid,cko2_old_eff_gid,cko2_old_saved_gid,cko2_path_name,cko2_file1_id,cko2_file1_own_uid,cko2_file1_own_gid,cko2_file2_id,cko2_file2_own_uid,cko2_file2_own_gid,cko2_dce_link,cko2_auth_type,cko2_dflt_process,cko2_utk_netw,cko2_x500_subject,cko2_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ckown2"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ckown2"}=0;
#Table:clasname
#delete all rows from the clasname table
$dbh->do("delete from clasname");
#Define the column names for the clasname table to Perl
my $rinc_event_type;
my $rinc_reserved_01;
my $rinc_time_written;
my $rinc_date_written;
my $rinc_system_smfid;
my $rinc_class_name;
my $rinc_stats;
my $rinc_audit;
my $rinc_active;
my $rinc_generic;
my $rinc_gencmd;
my $rinc_global;
my $rinc_raclist;
my $rinc_genlist;
my $rinc_log_options;
#Create and prepare the INSERT statement for clasname
$statement="INSERT INTO clasname (rinc_event_type,rinc_reserved_01,rinc_time_written,rinc_date_written,rinc_system_smfid,rinc_class_name,rinc_stats,rinc_audit,rinc_active,rinc_generic,rinc_gencmd,rinc_global,rinc_raclist,rinc_genlist,rinc_log_options) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"clasname"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"clasname"}=0;
#Table:clrsetid
#delete all rows from the clrsetid table
$dbh->do("delete from clrsetid");
#Define the column names for the clrsetid table to Perl
my $csid_event_type;
my $csid_event_qual;
my $csid_time_written;
my $csid_date_written;
my $csid_system_smfid;
my $csid_violation;
my $csid_user_ndfnd;
my $csid_user_warning;
my $csid_evt_user_id;
my $csid_evt_grp_id;
my $csid_auth_normal;
my $csid_auth_special;
my $csid_auth_oper;
my $csid_auth_audit;
my $csid_auth_exit;
my $csid_auth_failsft;
my $csid_auth_bypass;
my $csid_auth_trusted;
my $csid_log_class;
my $csid_log_user;
my $csid_log_special;
my $csid_log_access;
my $csid_log_racinit;
my $csid_log_always;
my $csid_log_cmdviol;
my $csid_log_global;
my $csid_term_level;
my $csid_backout_fail;
my $csid_prof_same;
my $csid_term;
my $csid_job_name;
my $csid_read_time;
my $csid_read_date;
my $csid_smf_user_id;
my $csid_log_level;
my $csid_log_vmevent;
my $csid_log_logopt;
my $csid_log_secl;
my $csid_log_compatm;
my $csid_log_applaud;
my $csid_log_nonomvs;
my $csid_log_omvsnprv;
my $csid_auth_omvssu;
my $csid_auth_omvssys;
my $csid_usr_secl;
my $csid_racf_version;
my $csid_class;
my $csid_user_name;
my $csid_utk_encr;
my $csid_utk_pre19;
my $csid_utk_verprof;
my $csid_utk_njeunusr;
my $csid_utk_logusr;
my $csid_utk_special;
my $csid_utk_default;
my $csid_utk_unknusr;
my $csid_utk_error;
my $csid_utk_trusted;
my $csid_utk_sesstype;
my $csid_utk_surrogat;
my $csid_utk_remote;
my $csid_utk_priv;
my $csid_utk_secl;
my $csid_utk_execnode;
my $csid_utk_suser_id;
my $csid_utk_snode;
my $csid_utk_sgrp_id;
my $csid_utk_spoe;
my $csid_utk_spclass;
my $csid_utk_user_id;
my $csid_utk_grp_id;
my $csid_utk_dft_grp;
my $csid_utk_dft_secl;
my $csid_appc_link;
my $csid_audit_code;
my $csid_old_real_uid;
my $csid_old_eff_uid;
my $csid_old_saved_uid;
my $csid_old_real_gid;
my $csid_old_eff_gid;
my $csid_old_saved_gid;
my $csid_path_name;
my $csid_file_id;
my $csid_file_own_uid;
my $csid_file_own_gid;
my $csid_old_s_isgid;
my $csid_old_s_isuid;
my $csid_old_s_isvtx;
my $csid_old_own_read;
my $csid_old_own_write;
my $csid_old_own_exec;
my $csid_old_grp_read;
my $csid_old_grp_write;
my $csid_old_grp_exec;
my $csid_old_oth_read;
my $csid_old_oth_write;
my $csid_old_oth_exec;
my $csid_new_s_isgid;
my $csid_new_s_isuid;
my $csid_new_s_isvtx;
my $csid_new_own_read;
my $csid_new_own_write;
my $csid_new_own_exec;
my $csid_new_grp_read;
my $csid_new_grp_write;
my $csid_new_grp_exec;
my $csid_new_oth_read;
my $csid_new_oth_write;
my $csid_new_oth_exec;
my $csid_dflt_process;
my $csid_utk_netw;
my $csid_x500_subject;
my $csid_x500_issuer;
#Create and prepare the INSERT statement for clrsetid
$statement="INSERT INTO clrsetid (csid_event_type,csid_event_qual,csid_time_written,csid_date_written,csid_system_smfid,csid_violation,csid_user_ndfnd,csid_user_warning,csid_evt_user_id,csid_evt_grp_id,csid_auth_normal,csid_auth_special,csid_auth_oper,csid_auth_audit,csid_auth_exit,csid_auth_failsft,csid_auth_bypass,csid_auth_trusted,csid_log_class,csid_log_user,csid_log_special,csid_log_access,csid_log_racinit,csid_log_always,csid_log_cmdviol,csid_log_global,csid_term_level,csid_backout_fail,csid_prof_same,csid_term,csid_job_name,csid_read_time,csid_read_date,csid_smf_user_id,csid_log_level,csid_log_vmevent,csid_log_logopt,csid_log_secl,csid_log_compatm,csid_log_applaud,csid_log_nonomvs,csid_log_omvsnprv,csid_auth_omvssu,csid_auth_omvssys,csid_usr_secl,csid_racf_version,csid_class,csid_user_name,csid_utk_encr,csid_utk_pre19,csid_utk_verprof,csid_utk_njeunusr,csid_utk_logusr,csid_utk_special,csid_utk_default,csid_utk_unknusr,csid_utk_error,csid_utk_trusted,csid_utk_sesstype,csid_utk_surrogat,csid_utk_remote,csid_utk_priv,csid_utk_secl,csid_utk_execnode,csid_utk_suser_id,csid_utk_snode,csid_utk_sgrp_id,csid_utk_spoe,csid_utk_spclass,csid_utk_user_id,csid_utk_grp_id,csid_utk_dft_grp,csid_utk_dft_secl,csid_appc_link,csid_audit_code,csid_old_real_uid,csid_old_eff_uid,csid_old_saved_uid,csid_old_real_gid,csid_old_eff_gid,csid_old_saved_gid,csid_path_name,csid_file_id,csid_file_own_uid,csid_file_own_gid,csid_old_s_isgid,csid_old_s_isuid,csid_old_s_isvtx,csid_old_own_read,csid_old_own_write,csid_old_own_exec,csid_old_grp_read,csid_old_grp_write,csid_old_grp_exec,csid_old_oth_read,csid_old_oth_write,csid_old_oth_exec,csid_new_s_isgid,csid_new_s_isuid,csid_new_s_isvtx,csid_new_own_read,csid_new_own_write,csid_new_own_exec,csid_new_grp_read,csid_new_grp_write,csid_new_grp_exec,csid_new_oth_read,csid_new_oth_write,csid_new_oth_exec,csid_dflt_process,csid_utk_netw,csid_x500_subject,csid_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"clrsetid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"clrsetid"}=0;
#Table:connect
#delete all rows from the connect table
$dbh->do("delete from connect");
#Define the column names for the connect table to Perl
my $con_event_type;
my $con_event_qual;
my $con_time_written;
my $con_date_written;
my $con_system_smfid;
my $con_violation;
my $con_user_ndfnd;
my $con_user_warning;
my $con_evt_user_id;
my $con_evt_grp_id;
my $con_auth_normal;
my $con_auth_special;
my $con_auth_oper;
my $con_auth_audit;
my $con_auth_exit;
my $con_auth_failsft;
my $con_auth_bypass;
my $con_auth_trusted;
my $con_log_class;
my $con_log_user;
my $con_log_special;
my $con_log_access;
my $con_log_racinit;
my $con_log_always;
my $con_log_cmdviol;
my $con_log_global;
my $con_term_level;
my $con_backout_fail;
my $con_prof_same;
my $con_term;
my $con_job_name;
my $con_read_time;
my $con_read_date;
my $con_smf_user_id;
my $con_log_level;
my $con_log_vmevent;
my $con_log_logopt;
my $con_log_secl;
my $con_log_compatm;
my $con_log_applaud;
my $con_log_nonomvs;
my $con_log_omvsnprv;
my $con_auth_omvssu;
my $con_auth_omvssys;
my $con_usr_secl;
my $con_racf_version;
my $con_own_id;
my $con_user_name;
my $con_utk_encr;
my $con_utk_pre19;
my $con_utk_verprof;
my $con_utk_njeunusr;
my $con_utk_logusr;
my $con_utk_special;
my $con_utk_default;
my $con_utk_unknusr;
my $con_utk_error;
my $con_utk_trusted;
my $con_utk_sesstype;
my $con_utk_surrogat;
my $con_utk_remote;
my $con_utk_priv;
my $con_utk_secl;
my $con_utk_execnode;
my $con_utk_suser_id;
my $con_utk_snode;
my $con_utk_sgrp_id;
my $con_utk_spoe;
my $con_utk_spclass;
my $con_utk_user_id;
my $con_utk_grp_id;
my $con_utk_dft_grp;
my $con_utk_dft_secl;
my $con_appc_link;
my $con_user_id;
my $con_specified;
my $con_failed;
my $con_utk_netw;
my $con_x500_subject;
my $con_x500_issuer;
#Create and prepare the INSERT statement for connect
$statement="INSERT INTO connect (con_event_type,con_event_qual,con_time_written,con_date_written,con_system_smfid,con_violation,con_user_ndfnd,con_user_warning,con_evt_user_id,con_evt_grp_id,con_auth_normal,con_auth_special,con_auth_oper,con_auth_audit,con_auth_exit,con_auth_failsft,con_auth_bypass,con_auth_trusted,con_log_class,con_log_user,con_log_special,con_log_access,con_log_racinit,con_log_always,con_log_cmdviol,con_log_global,con_term_level,con_backout_fail,con_prof_same,con_term,con_job_name,con_read_time,con_read_date,con_smf_user_id,con_log_level,con_log_vmevent,con_log_logopt,con_log_secl,con_log_compatm,con_log_applaud,con_log_nonomvs,con_log_omvsnprv,con_auth_omvssu,con_auth_omvssys,con_usr_secl,con_racf_version,con_own_id,con_user_name,con_utk_encr,con_utk_pre19,con_utk_verprof,con_utk_njeunusr,con_utk_logusr,con_utk_special,con_utk_default,con_utk_unknusr,con_utk_error,con_utk_trusted,con_utk_sesstype,con_utk_surrogat,con_utk_remote,con_utk_priv,con_utk_secl,con_utk_execnode,con_utk_suser_id,con_utk_snode,con_utk_sgrp_id,con_utk_spoe,con_utk_spclass,con_utk_user_id,con_utk_grp_id,con_utk_dft_grp,con_utk_dft_secl,con_appc_link,con_user_id,con_specified,con_failed,con_utk_netw,con_x500_subject,con_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"connect"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"connect"}=0;
#Table:daccess
#delete all rows from the daccess table
$dbh->do("delete from daccess");
#Define the column names for the daccess table to Perl
my $dacc_event_type;
my $dacc_event_qual;
my $dacc_time_written;
my $dacc_date_written;
my $dacc_system_smfid;
my $dacc_violation;
my $dacc_user_ndfnd;
my $dacc_user_warning;
my $dacc_evt_user_id;
my $dacc_evt_grp_id;
my $dacc_auth_normal;
my $dacc_auth_special;
my $dacc_auth_oper;
my $dacc_auth_audit;
my $dacc_auth_exit;
my $dacc_auth_failsft;
my $dacc_auth_bypass;
my $dacc_auth_trusted;
my $dacc_log_class;
my $dacc_log_user;
my $dacc_log_special;
my $dacc_log_access;
my $dacc_log_racinit;
my $dacc_log_always;
my $dacc_log_cmdviol;
my $dacc_log_global;
my $dacc_term_level;
my $dacc_backout_fail;
my $dacc_prof_same;
my $dacc_term;
my $dacc_job_name;
my $dacc_read_time;
my $dacc_read_date;
my $dacc_smf_user_id;
my $dacc_log_level;
my $dacc_log_vmevent;
my $dacc_log_logopt;
my $dacc_log_secl;
my $dacc_log_compatm;
my $dacc_log_applaud;
my $dacc_log_nonomvs;
my $dacc_log_omvsnprv;
my $dacc_auth_omvssu;
my $dacc_auth_omvssys;
my $dacc_usr_secl;
my $dacc_racf_version;
my $dacc_class;
my $dacc_user_name;
my $dacc_utk_encr;
my $dacc_utk_pre19;
my $dacc_utk_verprof;
my $dacc_utk_njeunusr;
my $dacc_utk_logusr;
my $dacc_utk_special;
my $dacc_utk_default;
my $dacc_utk_unknusr;
my $dacc_utk_error;
my $dacc_utk_trusted;
my $dacc_utk_sesstype;
my $dacc_utk_surrogat;
my $dacc_utk_remote;
my $dacc_utk_priv;
my $dacc_utk_secl;
my $dacc_utk_execnode;
my $dacc_utk_suser_id;
my $dacc_utk_snode;
my $dacc_utk_sgrp_id;
my $dacc_utk_spoe;
my $dacc_utk_spclass;
my $dacc_utk_user_id;
my $dacc_utk_grp_id;
my $dacc_utk_dft_grp;
my $dacc_utk_dft_secl;
my $dacc_appc_link;
my $dacc_audit_code;
my $dacc_old_real_uid;
my $dacc_old_eff_uid;
my $dacc_old_saved_uid;
my $dacc_old_real_gid;
my $dacc_old_eff_gid;
my $dacc_old_saved_gid;
my $dacc_path_name;
my $dacc_file_id;
my $dacc_file_own_uid;
my $dacc_file_own_gid;
my $dacc_request_read;
my $dacc_request_write;
my $dacc_request_exec;
my $dacc_request_dsrch;
my $dacc_access_type;
my $dacc_allowed_read;
my $dacc_allowed_write;
my $dacc_allowed_exec;
my $dacc_request_path2;
my $dacc_symlink;
my $dacc_file_name;
my $dacc_path_type;
my $dacc_filepool;
my $dacc_filespace;
my $dacc_inode;
my $dacc_scid;
my $dacc_dce_link;
my $dacc_auth_type;
my $dacc_dflt_process;
my $dacc_utk_netw;
my $dacc_x500_subject;
my $dacc_x500_issuer;
#Create and prepare the INSERT statement for daccess
$statement="INSERT INTO daccess (dacc_event_type,dacc_event_qual,dacc_time_written,dacc_date_written,dacc_system_smfid,dacc_violation,dacc_user_ndfnd,dacc_user_warning,dacc_evt_user_id,dacc_evt_grp_id,dacc_auth_normal,dacc_auth_special,dacc_auth_oper,dacc_auth_audit,dacc_auth_exit,dacc_auth_failsft,dacc_auth_bypass,dacc_auth_trusted,dacc_log_class,dacc_log_user,dacc_log_special,dacc_log_access,dacc_log_racinit,dacc_log_always,dacc_log_cmdviol,dacc_log_global,dacc_term_level,dacc_backout_fail,dacc_prof_same,dacc_term,dacc_job_name,dacc_read_time,dacc_read_date,dacc_smf_user_id,dacc_log_level,dacc_log_vmevent,dacc_log_logopt,dacc_log_secl,dacc_log_compatm,dacc_log_applaud,dacc_log_nonomvs,dacc_log_omvsnprv,dacc_auth_omvssu,dacc_auth_omvssys,dacc_usr_secl,dacc_racf_version,dacc_class,dacc_user_name,dacc_utk_encr,dacc_utk_pre19,dacc_utk_verprof,dacc_utk_njeunusr,dacc_utk_logusr,dacc_utk_special,dacc_utk_default,dacc_utk_unknusr,dacc_utk_error,dacc_utk_trusted,dacc_utk_sesstype,dacc_utk_surrogat,dacc_utk_remote,dacc_utk_priv,dacc_utk_secl,dacc_utk_execnode,dacc_utk_suser_id,dacc_utk_snode,dacc_utk_sgrp_id,dacc_utk_spoe,dacc_utk_spclass,dacc_utk_user_id,dacc_utk_grp_id,dacc_utk_dft_grp,dacc_utk_dft_secl,dacc_appc_link,dacc_audit_code,dacc_old_real_uid,dacc_old_eff_uid,dacc_old_saved_uid,dacc_old_real_gid,dacc_old_eff_gid,dacc_old_saved_gid,dacc_path_name,dacc_file_id,dacc_file_own_uid,dacc_file_own_gid,dacc_request_read,dacc_request_write,dacc_request_exec,dacc_request_dsrch,dacc_access_type,dacc_allowed_read,dacc_allowed_write,dacc_allowed_exec,dacc_request_path2,dacc_symlink,dacc_file_name,dacc_path_type,dacc_filepool,dacc_filespace,dacc_inode,dacc_scid,dacc_dce_link,dacc_auth_type,dacc_dflt_process,dacc_utk_netw,dacc_x500_subject,dacc_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"daccess"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"daccess"}=0;
#Table:define
#delete all rows from the define table
$dbh->do("delete from define");
#Define the column names for the define table to Perl
my $def_event_type;
my $def_event_qual;
my $def_time_written;
my $def_date_written;
my $def_system_smfid;
my $def_violation;
my $def_user_ndfnd;
my $def_user_warning;
my $def_evt_user_id;
my $def_evt_grp_id;
my $def_auth_normal;
my $def_auth_special;
my $def_auth_oper;
my $def_auth_audit;
my $def_auth_exit;
my $def_auth_failsft;
my $def_auth_bypass;
my $def_auth_trusted;
my $def_log_class;
my $def_log_user;
my $def_log_special;
my $def_log_access;
my $def_log_racinit;
my $def_log_always;
my $def_log_cmdviol;
my $def_log_global;
my $def_term_level;
my $def_backout_fail;
my $def_prof_same;
my $def_term;
my $def_job_name;
my $def_read_time;
my $def_read_date;
my $def_smf_user_id;
my $def_log_level;
my $def_log_vmevent;
my $def_log_logopt;
my $def_log_secl;
my $def_log_compatm;
my $def_log_applaud;
my $def_log_nonomvs;
my $def_log_omvsnprv;
my $def_auth_omvssu;
my $def_auth_omvssys;
my $def_usr_secl;
my $def_racf_version;
my $def_res_name;
my $def_level;
my $def_vol;
my $def_class;
my $def_model_name;
my $def_model_vol;
my $def_own_id;
my $def_logstr;
my $def_user_name;
my $def_utk_encr;
my $def_utk_pre19;
my $def_utk_verprof;
my $def_utk_njeunusr;
my $def_utk_logusr;
my $def_utk_special;
my $def_utk_default;
my $def_utk_unknusr;
my $def_utk_error;
my $def_utk_trusted;
my $def_utk_sesstype;
my $def_utk_surrogat;
my $def_utk_remote;
my $def_utk_priv;
my $def_utk_secl;
my $def_utk_execnode;
my $def_utk_suser_id;
my $def_utk_snode;
my $def_utk_sgrp_id;
my $def_utk_spoe;
my $def_utk_spclass;
my $def_utk_user_id;
my $def_utk_grp_id;
my $def_utk_dft_grp;
my $def_utk_dft_secl;
my $def_appc_link;
my $def_specified;
my $def_utk_netw;
my $def_x500_subject;
my $def_x500_issuer;
#Create and prepare the INSERT statement for define
$statement="INSERT INTO define (def_event_type,def_event_qual,def_time_written,def_date_written,def_system_smfid,def_violation,def_user_ndfnd,def_user_warning,def_evt_user_id,def_evt_grp_id,def_auth_normal,def_auth_special,def_auth_oper,def_auth_audit,def_auth_exit,def_auth_failsft,def_auth_bypass,def_auth_trusted,def_log_class,def_log_user,def_log_special,def_log_access,def_log_racinit,def_log_always,def_log_cmdviol,def_log_global,def_term_level,def_backout_fail,def_prof_same,def_term,def_job_name,def_read_time,def_read_date,def_smf_user_id,def_log_level,def_log_vmevent,def_log_logopt,def_log_secl,def_log_compatm,def_log_applaud,def_log_nonomvs,def_log_omvsnprv,def_auth_omvssu,def_auth_omvssys,def_usr_secl,def_racf_version,def_res_name,def_level,def_vol,def_class,def_model_name,def_model_vol,def_own_id,def_logstr,def_user_name,def_utk_encr,def_utk_pre19,def_utk_verprof,def_utk_njeunusr,def_utk_logusr,def_utk_special,def_utk_default,def_utk_unknusr,def_utk_error,def_utk_trusted,def_utk_sesstype,def_utk_surrogat,def_utk_remote,def_utk_priv,def_utk_secl,def_utk_execnode,def_utk_suser_id,def_utk_snode,def_utk_sgrp_id,def_utk_spoe,def_utk_spclass,def_utk_user_id,def_utk_grp_id,def_utk_dft_grp,def_utk_dft_secl,def_appc_link,def_specified,def_utk_netw,def_x500_subject,def_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"define"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"define"}=0;
#Table:deldsd
#delete all rows from the deldsd table
$dbh->do("delete from deldsd");
#Define the column names for the deldsd table to Perl
my $deld_event_type;
my $deld_event_qual;
my $deld_time_written;
my $deld_date_written;
my $deld_system_smfid;
my $deld_violation;
my $deld_user_ndfnd;
my $deld_user_warning;
my $deld_evt_user_id;
my $deld_evt_grp_id;
my $deld_auth_normal;
my $deld_auth_special;
my $deld_auth_oper;
my $deld_auth_audit;
my $deld_auth_exit;
my $deld_auth_failsft;
my $deld_auth_bypass;
my $deld_auth_trusted;
my $deld_log_class;
my $deld_log_user;
my $deld_log_special;
my $deld_log_access;
my $deld_log_racinit;
my $deld_log_always;
my $deld_log_cmdviol;
my $deld_log_global;
my $deld_term_level;
my $deld_backout_fail;
my $deld_prof_same;
my $deld_term;
my $deld_job_name;
my $deld_read_time;
my $deld_read_date;
my $deld_smf_user_id;
my $deld_log_level;
my $deld_log_vmevent;
my $deld_log_logopt;
my $deld_log_secl;
my $deld_log_compatm;
my $deld_log_applaud;
my $deld_log_nonomvs;
my $deld_log_omvsnprv;
my $deld_auth_omvssu;
my $deld_auth_omvssys;
my $deld_usr_secl;
my $deld_racf_version;
my $deld_own_id;
my $deld_user_name;
my $deld_old_secl;
my $deld_utk_encr;
my $deld_utk_pre19;
my $deld_utk_verprof;
my $deld_utk_njeunusr;
my $deld_utk_logusr;
my $deld_utk_special;
my $deld_utk_default;
my $deld_utk_unknusr;
my $deld_utk_error;
my $deld_utk_trusted;
my $deld_utk_sesstype;
my $deld_utk_surrogat;
my $deld_utk_remote;
my $deld_utk_priv;
my $deld_utk_secl;
my $deld_utk_execnode;
my $deld_utk_suser_id;
my $deld_utk_snode;
my $deld_utk_sgrp_id;
my $deld_utk_spoe;
my $deld_utk_spclass;
my $deld_utk_user_id;
my $deld_utk_grp_id;
my $deld_utk_dft_grp;
my $deld_utk_dft_secl;
my $deld_appc_link;
my $deld_secl_link;
my $deld_ds_name;
my $deld_specified;
my $deld_failed;
my $deld_utk_netw;
my $deld_x500_subject;
my $deld_x500_issuer;
#Create and prepare the INSERT statement for deldsd
$statement="INSERT INTO deldsd (deld_event_type,deld_event_qual,deld_time_written,deld_date_written,deld_system_smfid,deld_violation,deld_user_ndfnd,deld_user_warning,deld_evt_user_id,deld_evt_grp_id,deld_auth_normal,deld_auth_special,deld_auth_oper,deld_auth_audit,deld_auth_exit,deld_auth_failsft,deld_auth_bypass,deld_auth_trusted,deld_log_class,deld_log_user,deld_log_special,deld_log_access,deld_log_racinit,deld_log_always,deld_log_cmdviol,deld_log_global,deld_term_level,deld_backout_fail,deld_prof_same,deld_term,deld_job_name,deld_read_time,deld_read_date,deld_smf_user_id,deld_log_level,deld_log_vmevent,deld_log_logopt,deld_log_secl,deld_log_compatm,deld_log_applaud,deld_log_nonomvs,deld_log_omvsnprv,deld_auth_omvssu,deld_auth_omvssys,deld_usr_secl,deld_racf_version,deld_own_id,deld_user_name,deld_old_secl,deld_utk_encr,deld_utk_pre19,deld_utk_verprof,deld_utk_njeunusr,deld_utk_logusr,deld_utk_special,deld_utk_default,deld_utk_unknusr,deld_utk_error,deld_utk_trusted,deld_utk_sesstype,deld_utk_surrogat,deld_utk_remote,deld_utk_priv,deld_utk_secl,deld_utk_execnode,deld_utk_suser_id,deld_utk_snode,deld_utk_sgrp_id,deld_utk_spoe,deld_utk_spclass,deld_utk_user_id,deld_utk_grp_id,deld_utk_dft_grp,deld_utk_dft_secl,deld_appc_link,deld_secl_link,deld_ds_name,deld_specified,deld_failed,deld_utk_netw,deld_x500_subject,deld_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"deldsd"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"deldsd"}=0;
#Table:delfacl
#delete all rows from the delfacl table
$dbh->do("delete from delfacl");
#Define the column names for the delfacl table to Perl
my $dacl_event_type;
my $dacl_event_qual;
my $dacl_time_written;
my $dacl_date_written;
my $dacl_system_smfid;
my $dacl_violation;
my $dacl_user_ndfnd;
my $dacl_user_warning;
my $dacl_evt_user_id;
my $dacl_evt_grp_id;
my $dacl_auth_normal;
my $dacl_auth_special;
my $dacl_auth_oper;
my $dacl_auth_audit;
my $dacl_auth_exit;
my $dacl_auth_failsft;
my $dacl_auth_bypass;
my $dacl_auth_trusted;
my $dacl_log_class;
my $dacl_log_user;
my $dacl_log_special;
my $dacl_log_access;
my $dacl_log_racinit;
my $dacl_log_always;
my $dacl_log_cmdviol;
my $dacl_log_global;
my $dacl_term_level;
my $dacl_backout_fail;
my $dacl_prof_same;
my $dacl_term;
my $dacl_job_name;
my $dacl_read_time;
my $dacl_read_date;
my $dacl_smf_user_id;
my $dacl_log_level;
my $dacl_log_vmevent;
my $dacl_log_logopt;
my $dacl_log_secl;
my $dacl_log_compatm;
my $dacl_log_applaud;
my $dacl_log_nonomvs;
my $dacl_log_omvsnprv;
my $dacl_auth_omvssu;
my $dacl_auth_omvssys;
my $dacl_usr_secl;
my $dacl_racf_version;
my $dacl_class;
my $dacl_user_name;
my $dacl_utk_encr;
my $dacl_utk_pre19;
my $dacl_utk_verprof;
my $dacl_utk_njeunusr;
my $dacl_utk_logusr;
my $dacl_utk_special;
my $dacl_utk_default;
my $dacl_utk_unknusr;
my $dacl_utk_error;
my $dacl_utk_trusted;
my $dacl_utk_sesstype;
my $dacl_utk_surrogat;
my $dacl_utk_remote;
my $dacl_utk_priv;
my $dacl_utk_secl;
my $dacl_utk_execnode;
my $dacl_utk_suser_id;
my $dacl_utk_snode;
my $dacl_utk_sgrp_id;
my $dacl_utk_spoe;
my $dacl_utk_spclass;
my $dacl_utk_user_id;
my $dacl_utk_grp_id;
my $dacl_utk_dft_grp;
my $dacl_utk_dft_secl;
my $dacl_appc_link;
my $dacl_audit_code;
my $dacl_old_real_uid;
my $dacl_old_eff_uid;
my $dacl_old_saved_uid;
my $dacl_old_real_gid;
my $dacl_old_eff_gid;
my $dacl_old_saved_gid;
my $dacl_path_name;
my $dacl_file_id;
my $dacl_file_own_uid;
my $dacl_file_own_gid;
my $dacl_filepool;
my $dacl_filespace;
my $dacl_inode;
my $dacl_scid;
my $dacl_dce_link;
my $dacl_auth_type;
my $dacl_dflt_process;
my $dacl_utk_netw;
my $dacl_x500_subject;
my $dacl_x500_issuer;
my $dacl_acl_type;
#Create and prepare the INSERT statement for delfacl
$statement="INSERT INTO delfacl (dacl_event_type,dacl_event_qual,dacl_time_written,dacl_date_written,dacl_system_smfid,dacl_violation,dacl_user_ndfnd,dacl_user_warning,dacl_evt_user_id,dacl_evt_grp_id,dacl_auth_normal,dacl_auth_special,dacl_auth_oper,dacl_auth_audit,dacl_auth_exit,dacl_auth_failsft,dacl_auth_bypass,dacl_auth_trusted,dacl_log_class,dacl_log_user,dacl_log_special,dacl_log_access,dacl_log_racinit,dacl_log_always,dacl_log_cmdviol,dacl_log_global,dacl_term_level,dacl_backout_fail,dacl_prof_same,dacl_term,dacl_job_name,dacl_read_time,dacl_read_date,dacl_smf_user_id,dacl_log_level,dacl_log_vmevent,dacl_log_logopt,dacl_log_secl,dacl_log_compatm,dacl_log_applaud,dacl_log_nonomvs,dacl_log_omvsnprv,dacl_auth_omvssu,dacl_auth_omvssys,dacl_usr_secl,dacl_racf_version,dacl_class,dacl_user_name,dacl_utk_encr,dacl_utk_pre19,dacl_utk_verprof,dacl_utk_njeunusr,dacl_utk_logusr,dacl_utk_special,dacl_utk_default,dacl_utk_unknusr,dacl_utk_error,dacl_utk_trusted,dacl_utk_sesstype,dacl_utk_surrogat,dacl_utk_remote,dacl_utk_priv,dacl_utk_secl,dacl_utk_execnode,dacl_utk_suser_id,dacl_utk_snode,dacl_utk_sgrp_id,dacl_utk_spoe,dacl_utk_spclass,dacl_utk_user_id,dacl_utk_grp_id,dacl_utk_dft_grp,dacl_utk_dft_secl,dacl_appc_link,dacl_audit_code,dacl_old_real_uid,dacl_old_eff_uid,dacl_old_saved_uid,dacl_old_real_gid,dacl_old_eff_gid,dacl_old_saved_gid,dacl_path_name,dacl_file_id,dacl_file_own_uid,dacl_file_own_gid,dacl_filepool,dacl_filespace,dacl_inode,dacl_scid,dacl_dce_link,dacl_auth_type,dacl_dflt_process,dacl_utk_netw,dacl_x500_subject,dacl_x500_issuer,dacl_acl_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"delfacl"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"delfacl"}=0;
#Table:delgroup
#delete all rows from the delgroup table
$dbh->do("delete from delgroup");
#Define the column names for the delgroup table to Perl
my $delg_event_type;
my $delg_event_qual;
my $delg_time_written;
my $delg_date_written;
my $delg_system_smfid;
my $delg_violation;
my $delg_user_ndfnd;
my $delg_user_warning;
my $delg_evt_user_id;
my $delg_evt_grp_id;
my $delg_auth_normal;
my $delg_auth_special;
my $delg_auth_oper;
my $delg_auth_audit;
my $delg_auth_exit;
my $delg_auth_failsft;
my $delg_auth_bypass;
my $delg_auth_trusted;
my $delg_log_class;
my $delg_log_user;
my $delg_log_special;
my $delg_log_access;
my $delg_log_racinit;
my $delg_log_always;
my $delg_log_cmdviol;
my $delg_log_global;
my $delg_term_level;
my $delg_backout_fail;
my $delg_prof_same;
my $delg_term;
my $delg_job_name;
my $delg_read_time;
my $delg_read_date;
my $delg_smf_user_id;
my $delg_log_level;
my $delg_log_vmevent;
my $delg_log_logopt;
my $delg_log_secl;
my $delg_log_compatm;
my $delg_log_applaud;
my $delg_log_nonomvs;
my $delg_log_omvsnprv;
my $delg_auth_omvssu;
my $delg_auth_omvssys;
my $delg_usr_secl;
my $delg_racf_version;
my $delg_own_id;
my $delg_user_name;
my $delg_utk_encr;
my $delg_utk_pre19;
my $delg_utk_verprof;
my $delg_utk_njeunusr;
my $delg_utk_logusr;
my $delg_utk_special;
my $delg_utk_default;
my $delg_utk_unknusr;
my $delg_utk_error;
my $delg_utk_trusted;
my $delg_utk_sesstype;
my $delg_utk_surrogat;
my $delg_utk_remote;
my $delg_utk_priv;
my $delg_utk_secl;
my $delg_utk_execnode;
my $delg_utk_suser_id;
my $delg_utk_snode;
my $delg_utk_sgrp_id;
my $delg_utk_spoe;
my $delg_utk_spclass;
my $delg_utk_user_id;
my $delg_utk_grp_id;
my $delg_utk_dft_grp;
my $delg_utk_dft_secl;
my $delg_appc_link;
my $delg_grp_id;
my $delg_specified;
my $delg_utk_netw;
my $delg_x500_subject;
my $delg_x500_issuer;
#Create and prepare the INSERT statement for delgroup
$statement="INSERT INTO delgroup (delg_event_type,delg_event_qual,delg_time_written,delg_date_written,delg_system_smfid,delg_violation,delg_user_ndfnd,delg_user_warning,delg_evt_user_id,delg_evt_grp_id,delg_auth_normal,delg_auth_special,delg_auth_oper,delg_auth_audit,delg_auth_exit,delg_auth_failsft,delg_auth_bypass,delg_auth_trusted,delg_log_class,delg_log_user,delg_log_special,delg_log_access,delg_log_racinit,delg_log_always,delg_log_cmdviol,delg_log_global,delg_term_level,delg_backout_fail,delg_prof_same,delg_term,delg_job_name,delg_read_time,delg_read_date,delg_smf_user_id,delg_log_level,delg_log_vmevent,delg_log_logopt,delg_log_secl,delg_log_compatm,delg_log_applaud,delg_log_nonomvs,delg_log_omvsnprv,delg_auth_omvssu,delg_auth_omvssys,delg_usr_secl,delg_racf_version,delg_own_id,delg_user_name,delg_utk_encr,delg_utk_pre19,delg_utk_verprof,delg_utk_njeunusr,delg_utk_logusr,delg_utk_special,delg_utk_default,delg_utk_unknusr,delg_utk_error,delg_utk_trusted,delg_utk_sesstype,delg_utk_surrogat,delg_utk_remote,delg_utk_priv,delg_utk_secl,delg_utk_execnode,delg_utk_suser_id,delg_utk_snode,delg_utk_sgrp_id,delg_utk_spoe,delg_utk_spclass,delg_utk_user_id,delg_utk_grp_id,delg_utk_dft_grp,delg_utk_dft_secl,delg_appc_link,delg_grp_id,delg_specified,delg_utk_netw,delg_x500_subject,delg_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"delgroup"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"delgroup"}=0;
#Table:delres
#delete all rows from the delres table
$dbh->do("delete from delres");
#Define the column names for the delres table to Perl
my $delr_event_type;
my $delr_event_qual;
my $delr_time_written;
my $delr_date_written;
my $delr_system_smfid;
my $delr_violation;
my $delr_user_ndfnd;
my $delr_user_warning;
my $delr_evt_user_id;
my $delr_evt_grp_id;
my $delr_auth_normal;
my $delr_auth_special;
my $delr_auth_oper;
my $delr_auth_audit;
my $delr_auth_exit;
my $delr_auth_failsft;
my $delr_auth_bypass;
my $delr_auth_trusted;
my $delr_log_class;
my $delr_log_user;
my $delr_log_special;
my $delr_log_access;
my $delr_log_racinit;
my $delr_log_always;
my $delr_log_cmdviol;
my $delr_log_global;
my $delr_term_level;
my $delr_backout_fail;
my $delr_prof_same;
my $delr_term;
my $delr_job_name;
my $delr_read_time;
my $delr_read_date;
my $delr_smf_user_id;
my $delr_log_level;
my $delr_log_vmevent;
my $delr_log_logopt;
my $delr_log_secl;
my $delr_log_compatm;
my $delr_log_applaud;
my $delr_log_nonomvs;
my $delr_log_omvsnprv;
my $delr_auth_omvssu;
my $delr_auth_omvssys;
my $delr_usr_secl;
my $delr_racf_version;
my $delr_res_name;
my $delr_level;
my $delr_vol;
my $delr_class;
my $delr_own_id;
my $delr_logstr;
my $delr_user_name;
my $delr_utk_encr;
my $delr_utk_pre19;
my $delr_utk_verprof;
my $delr_utk_njeunusr;
my $delr_utk_logusr;
my $delr_utk_special;
my $delr_utk_default;
my $delr_utk_unknusr;
my $delr_utk_error;
my $delr_utk_trusted;
my $delr_utk_sesstype;
my $delr_utk_surrogat;
my $delr_utk_remote;
my $delr_utk_priv;
my $delr_utk_secl;
my $delr_utk_execnode;
my $delr_utk_suser_id;
my $delr_utk_snode;
my $delr_utk_sgrp_id;
my $delr_utk_spoe;
my $delr_utk_spclass;
my $delr_utk_user_id;
my $delr_utk_grp_id;
my $delr_utk_dft_grp;
my $delr_utk_dft_secl;
my $delr_appc_link;
my $delr_specified;
my $delr_utk_netw;
my $delr_x500_subject;
my $delr_x500_issuer;
#Create and prepare the INSERT statement for delres
$statement="INSERT INTO delres (delr_event_type,delr_event_qual,delr_time_written,delr_date_written,delr_system_smfid,delr_violation,delr_user_ndfnd,delr_user_warning,delr_evt_user_id,delr_evt_grp_id,delr_auth_normal,delr_auth_special,delr_auth_oper,delr_auth_audit,delr_auth_exit,delr_auth_failsft,delr_auth_bypass,delr_auth_trusted,delr_log_class,delr_log_user,delr_log_special,delr_log_access,delr_log_racinit,delr_log_always,delr_log_cmdviol,delr_log_global,delr_term_level,delr_backout_fail,delr_prof_same,delr_term,delr_job_name,delr_read_time,delr_read_date,delr_smf_user_id,delr_log_level,delr_log_vmevent,delr_log_logopt,delr_log_secl,delr_log_compatm,delr_log_applaud,delr_log_nonomvs,delr_log_omvsnprv,delr_auth_omvssu,delr_auth_omvssys,delr_usr_secl,delr_racf_version,delr_res_name,delr_level,delr_vol,delr_class,delr_own_id,delr_logstr,delr_user_name,delr_utk_encr,delr_utk_pre19,delr_utk_verprof,delr_utk_njeunusr,delr_utk_logusr,delr_utk_special,delr_utk_default,delr_utk_unknusr,delr_utk_error,delr_utk_trusted,delr_utk_sesstype,delr_utk_surrogat,delr_utk_remote,delr_utk_priv,delr_utk_secl,delr_utk_execnode,delr_utk_suser_id,delr_utk_snode,delr_utk_sgrp_id,delr_utk_spoe,delr_utk_spclass,delr_utk_user_id,delr_utk_grp_id,delr_utk_dft_grp,delr_utk_dft_secl,delr_appc_link,delr_specified,delr_utk_netw,delr_x500_subject,delr_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"delres"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"delres"}=0;
#Table:deluser
#delete all rows from the deluser table
$dbh->do("delete from deluser");
#Define the column names for the deluser table to Perl
my $delu_event_type;
my $delu_event_qual;
my $delu_time_written;
my $delu_date_written;
my $delu_system_smfid;
my $delu_violation;
my $delu_user_ndfnd;
my $delu_user_warning;
my $delu_evt_user_id;
my $delu_evt_grp_id;
my $delu_auth_normal;
my $delu_auth_special;
my $delu_auth_oper;
my $delu_auth_audit;
my $delu_auth_exit;
my $delu_auth_failsft;
my $delu_auth_bypass;
my $delu_auth_trusted;
my $delu_log_class;
my $delu_log_user;
my $delu_log_special;
my $delu_log_access;
my $delu_log_racinit;
my $delu_log_always;
my $delu_log_cmdviol;
my $delu_log_global;
my $delu_term_level;
my $delu_backout_fail;
my $delu_prof_same;
my $delu_term;
my $delu_job_name;
my $delu_read_time;
my $delu_read_date;
my $delu_smf_user_id;
my $delu_log_level;
my $delu_log_vmevent;
my $delu_log_logopt;
my $delu_log_secl;
my $delu_log_compatm;
my $delu_log_applaud;
my $delu_log_nonomvs;
my $delu_log_omvsnprv;
my $delu_auth_omvssu;
my $delu_auth_omvssys;
my $delu_usr_secl;
my $delu_racf_version;
my $delu_own_id;
my $delu_user_name;
my $delu_utk_encr;
my $delu_utk_pre19;
my $delu_utk_verprof;
my $delu_utk_njeunusr;
my $delu_utk_logusr;
my $delu_utk_special;
my $delu_utk_default;
my $delu_utk_unknusr;
my $delu_utk_error;
my $delu_utk_trusted;
my $delu_utk_sesstype;
my $delu_utk_surrogat;
my $delu_utk_remote;
my $delu_utk_priv;
my $delu_utk_secl;
my $delu_utk_execnode;
my $delu_utk_suser_id;
my $delu_utk_snode;
my $delu_utk_sgrp_id;
my $delu_utk_spoe;
my $delu_utk_spclass;
my $delu_utk_user_id;
my $delu_utk_grp_id;
my $delu_utk_dft_grp;
my $delu_utk_dft_secl;
my $delu_appc_link;
my $delu_user_id;
my $delu_specified;
my $delu_utk_netw;
my $delu_x500_subject;
my $delu_x500_issuer;
#Create and prepare the INSERT statement for deluser
$statement="INSERT INTO deluser (delu_event_type,delu_event_qual,delu_time_written,delu_date_written,delu_system_smfid,delu_violation,delu_user_ndfnd,delu_user_warning,delu_evt_user_id,delu_evt_grp_id,delu_auth_normal,delu_auth_special,delu_auth_oper,delu_auth_audit,delu_auth_exit,delu_auth_failsft,delu_auth_bypass,delu_auth_trusted,delu_log_class,delu_log_user,delu_log_special,delu_log_access,delu_log_racinit,delu_log_always,delu_log_cmdviol,delu_log_global,delu_term_level,delu_backout_fail,delu_prof_same,delu_term,delu_job_name,delu_read_time,delu_read_date,delu_smf_user_id,delu_log_level,delu_log_vmevent,delu_log_logopt,delu_log_secl,delu_log_compatm,delu_log_applaud,delu_log_nonomvs,delu_log_omvsnprv,delu_auth_omvssu,delu_auth_omvssys,delu_usr_secl,delu_racf_version,delu_own_id,delu_user_name,delu_utk_encr,delu_utk_pre19,delu_utk_verprof,delu_utk_njeunusr,delu_utk_logusr,delu_utk_special,delu_utk_default,delu_utk_unknusr,delu_utk_error,delu_utk_trusted,delu_utk_sesstype,delu_utk_surrogat,delu_utk_remote,delu_utk_priv,delu_utk_secl,delu_utk_execnode,delu_utk_suser_id,delu_utk_snode,delu_utk_sgrp_id,delu_utk_spoe,delu_utk_spclass,delu_utk_user_id,delu_utk_grp_id,delu_utk_dft_grp,delu_utk_dft_secl,delu_appc_link,delu_user_id,delu_specified,delu_utk_netw,delu_x500_subject,delu_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"deluser"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"deluser"}=0;
#Table:delvol
#delete all rows from the delvol table
$dbh->do("delete from delvol");
#Define the column names for the delvol table to Perl
my $delv_event_type;
my $delv_event_qual;
my $delv_time_written;
my $delv_date_written;
my $delv_system_smfid;
my $delv_violation;
my $delv_user_ndfnd;
my $delv_user_warning;
my $delv_evt_user_id;
my $delv_evt_grp_id;
my $delv_auth_normal;
my $delv_auth_special;
my $delv_auth_oper;
my $delv_auth_audit;
my $delv_auth_exit;
my $delv_auth_failsft;
my $delv_auth_bypass;
my $delv_auth_trusted;
my $delv_log_class;
my $delv_log_user;
my $delv_log_special;
my $delv_log_access;
my $delv_log_racinit;
my $delv_log_always;
my $delv_log_cmdviol;
my $delv_log_global;
my $delv_term_level;
my $delv_backout_fail;
my $delv_prof_same;
my $delv_term;
my $delv_job_name;
my $delv_read_time;
my $delv_read_date;
my $delv_smf_user_id;
my $delv_log_level;
my $delv_log_vmevent;
my $delv_log_logopt;
my $delv_log_secl;
my $delv_log_compatm;
my $delv_log_applaud;
my $delv_log_nonomvs;
my $delv_log_omvsnprv;
my $delv_auth_omvssu;
my $delv_auth_omvssys;
my $delv_usr_secl;
my $delv_racf_version;
my $delv_res_name;
my $delv_level;
my $delv_vol;
my $delv_class;
my $delv_own_id;
my $delv_logstr;
my $delv_user_name;
my $delv_utk_encr;
my $delv_utk_pre19;
my $delv_utk_verprof;
my $delv_utk_njeunusr;
my $delv_utk_logusr;
my $delv_utk_special;
my $delv_utk_default;
my $delv_utk_unknusr;
my $delv_utk_error;
my $delv_utk_trusted;
my $delv_utk_sesstype;
my $delv_utk_surrogat;
my $delv_utk_remote;
my $delv_utk_priv;
my $delv_utk_secl;
my $delv_utk_execnode;
my $delv_utk_suser_id;
my $delv_utk_snode;
my $delv_utk_sgrp_id;
my $delv_utk_spoe;
my $delv_utk_spclass;
my $delv_utk_user_id;
my $delv_utk_grp_id;
my $delv_utk_dft_grp;
my $delv_utk_dft_secl;
my $delv_appc_link;
my $delv_specified;
my $delv_utk_netw;
my $delv_x500_subject;
my $delv_x500_issuer;
#Create and prepare the INSERT statement for delvol
$statement="INSERT INTO delvol (delv_event_type,delv_event_qual,delv_time_written,delv_date_written,delv_system_smfid,delv_violation,delv_user_ndfnd,delv_user_warning,delv_evt_user_id,delv_evt_grp_id,delv_auth_normal,delv_auth_special,delv_auth_oper,delv_auth_audit,delv_auth_exit,delv_auth_failsft,delv_auth_bypass,delv_auth_trusted,delv_log_class,delv_log_user,delv_log_special,delv_log_access,delv_log_racinit,delv_log_always,delv_log_cmdviol,delv_log_global,delv_term_level,delv_backout_fail,delv_prof_same,delv_term,delv_job_name,delv_read_time,delv_read_date,delv_smf_user_id,delv_log_level,delv_log_vmevent,delv_log_logopt,delv_log_secl,delv_log_compatm,delv_log_applaud,delv_log_nonomvs,delv_log_omvsnprv,delv_auth_omvssu,delv_auth_omvssys,delv_usr_secl,delv_racf_version,delv_res_name,delv_level,delv_vol,delv_class,delv_own_id,delv_logstr,delv_user_name,delv_utk_encr,delv_utk_pre19,delv_utk_verprof,delv_utk_njeunusr,delv_utk_logusr,delv_utk_special,delv_utk_default,delv_utk_unknusr,delv_utk_error,delv_utk_trusted,delv_utk_sesstype,delv_utk_surrogat,delv_utk_remote,delv_utk_priv,delv_utk_secl,delv_utk_execnode,delv_utk_suser_id,delv_utk_snode,delv_utk_sgrp_id,delv_utk_spoe,delv_utk_spclass,delv_utk_user_id,delv_utk_grp_id,delv_utk_dft_grp,delv_utk_dft_secl,delv_appc_link,delv_specified,delv_utk_netw,delv_x500_subject,delv_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"delvol"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"delvol"}=0;
#Table:dirsrch
#delete all rows from the dirsrch table
$dbh->do("delete from dirsrch");
#Define the column names for the dirsrch table to Perl
my $dsch_event_type;
my $dsch_event_qual;
my $dsch_time_written;
my $dsch_date_written;
my $dsch_system_smfid;
my $dsch_violation;
my $dsch_user_ndfnd;
my $dsch_user_warning;
my $dsch_evt_user_id;
my $dsch_evt_grp_id;
my $dsch_auth_normal;
my $dsch_auth_special;
my $dsch_auth_oper;
my $dsch_auth_audit;
my $dsch_auth_exit;
my $dsch_auth_failsft;
my $dsch_auth_bypass;
my $dsch_auth_trusted;
my $dsch_log_class;
my $dsch_log_user;
my $dsch_log_special;
my $dsch_log_access;
my $dsch_log_racinit;
my $dsch_log_always;
my $dsch_log_cmdviol;
my $dsch_log_global;
my $dsch_term_level;
my $dsch_backout_fail;
my $dsch_prof_same;
my $dsch_term;
my $dsch_job_name;
my $dsch_read_time;
my $dsch_read_date;
my $dsch_smf_user_id;
my $dsch_log_level;
my $dsch_log_vmevent;
my $dsch_log_logopt;
my $dsch_log_secl;
my $dsch_log_compatm;
my $dsch_log_applaud;
my $dsch_log_nonomvs;
my $dsch_log_omvsnprv;
my $dsch_auth_omvssu;
my $dsch_auth_omvssys;
my $dsch_usr_secl;
my $dsch_racf_version;
my $dsch_class;
my $dsch_user_name;
my $dsch_utk_encr;
my $dsch_utk_pre19;
my $dsch_utk_verprof;
my $dsch_utk_njeunusr;
my $dsch_utk_logusr;
my $dsch_utk_special;
my $dsch_utk_default;
my $dsch_utk_unknusr;
my $dsch_utk_error;
my $dsch_utk_trusted;
my $dsch_utk_sesstype;
my $dsch_utk_surrogat;
my $dsch_utk_remote;
my $dsch_utk_priv;
my $dsch_utk_secl;
my $dsch_utk_execnode;
my $dsch_utk_suser_id;
my $dsch_utk_snode;
my $dsch_utk_sgrp_id;
my $dsch_utk_spoe;
my $dsch_utk_spclass;
my $dsch_utk_user_id;
my $dsch_utk_grp_id;
my $dsch_utk_dft_grp;
my $dsch_utk_dft_secl;
my $dsch_appc_link;
my $dsch_audit_code;
my $dsch_old_real_uid;
my $dsch_old_eff_uid;
my $dsch_old_saved_uid;
my $dsch_old_real_gid;
my $dsch_old_eff_gid;
my $dsch_old_saved_gid;
my $dsch_path_name;
my $dsch_file_id;
my $dsch_file_own_uid;
my $dsch_file_own_gid;
my $dsch_request_read;
my $dsch_request_write;
my $dsch_request_exec;
my $dsch_request_dsrch;
my $dsch_access_type;
my $dsch_allowed_read;
my $dsch_allowed_write;
my $dsch_allowed_exec;
my $dsch_request_path2;
my $dsch_service_code;
my $dsch_hfs_ds_name;
my $dsch_symlink;
my $dsch_file_name;
my $dsch_path_type;
my $dsch_filepool;
my $dsch_filespace;
my $dsch_inode;
my $dsch_scid;
my $dsch_dce_link;
my $dsch_auth_type;
my $dsch_dflt_process;
my $dsch_utk_netw;
my $dsch_x500_subject;
my $dsch_x500_issuer;
#Create and prepare the INSERT statement for dirsrch
$statement="INSERT INTO dirsrch (dsch_event_type,dsch_event_qual,dsch_time_written,dsch_date_written,dsch_system_smfid,dsch_violation,dsch_user_ndfnd,dsch_user_warning,dsch_evt_user_id,dsch_evt_grp_id,dsch_auth_normal,dsch_auth_special,dsch_auth_oper,dsch_auth_audit,dsch_auth_exit,dsch_auth_failsft,dsch_auth_bypass,dsch_auth_trusted,dsch_log_class,dsch_log_user,dsch_log_special,dsch_log_access,dsch_log_racinit,dsch_log_always,dsch_log_cmdviol,dsch_log_global,dsch_term_level,dsch_backout_fail,dsch_prof_same,dsch_term,dsch_job_name,dsch_read_time,dsch_read_date,dsch_smf_user_id,dsch_log_level,dsch_log_vmevent,dsch_log_logopt,dsch_log_secl,dsch_log_compatm,dsch_log_applaud,dsch_log_nonomvs,dsch_log_omvsnprv,dsch_auth_omvssu,dsch_auth_omvssys,dsch_usr_secl,dsch_racf_version,dsch_class,dsch_user_name,dsch_utk_encr,dsch_utk_pre19,dsch_utk_verprof,dsch_utk_njeunusr,dsch_utk_logusr,dsch_utk_special,dsch_utk_default,dsch_utk_unknusr,dsch_utk_error,dsch_utk_trusted,dsch_utk_sesstype,dsch_utk_surrogat,dsch_utk_remote,dsch_utk_priv,dsch_utk_secl,dsch_utk_execnode,dsch_utk_suser_id,dsch_utk_snode,dsch_utk_sgrp_id,dsch_utk_spoe,dsch_utk_spclass,dsch_utk_user_id,dsch_utk_grp_id,dsch_utk_dft_grp,dsch_utk_dft_secl,dsch_appc_link,dsch_audit_code,dsch_old_real_uid,dsch_old_eff_uid,dsch_old_saved_uid,dsch_old_real_gid,dsch_old_eff_gid,dsch_old_saved_gid,dsch_path_name,dsch_file_id,dsch_file_own_uid,dsch_file_own_gid,dsch_request_read,dsch_request_write,dsch_request_exec,dsch_request_dsrch,dsch_access_type,dsch_allowed_read,dsch_allowed_write,dsch_allowed_exec,dsch_request_path2,dsch_service_code,dsch_hfs_ds_name,dsch_symlink,dsch_file_name,dsch_path_type,dsch_filepool,dsch_filespace,dsch_inode,dsch_scid,dsch_dce_link,dsch_auth_type,dsch_dflt_process,dsch_utk_netw,dsch_x500_subject,dsch_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"dirsrch"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"dirsrch"}=0;
#Table:dsaf
#delete all rows from the dsaf table
$dbh->do("delete from dsaf");
#Define the column names for the dsaf table to Perl
my $dsaf_event_type;
my $dsaf_reserved_01;
my $dsaf_time_written;
my $dsaf_date_written;
my $dsaf_system_smfid;
my $dsaf_secl_link;
my $dsaf_violation;
my $dsaf_user_ndfnd;
my $dsaf_user_warning;
my $dsaf_evt_user_id;
my $dsaf_evt_grp_id;
my $dsaf_auth_normal;
my $dsaf_auth_special;
my $dsaf_auth_oper;
my $dsaf_auth_audit;
my $dsaf_auth_exit;
my $dsaf_auth_failsft;
my $dsaf_auth_bypass;
my $dsaf_auth_trusted;
my $dsaf_log_class;
my $dsaf_log_user;
my $dsaf_log_special;
my $dsaf_log_access;
my $dsaf_log_racinit;
my $dsaf_log_always;
my $dsaf_log_cmdviol;
my $dsaf_log_global;
my $dsaf_term_level;
my $dsaf_backout_fail;
my $dsaf_prof_same;
my $dsaf_term;
my $dsaf_job_name;
my $dsaf_read_time;
my $dsaf_read_date;
my $dsaf_smf_user_id;
my $dsaf_log_level;
my $dsaf_log_logopt;
my $dsaf_log_secl;
my $dsaf_log_compatm;
my $dsaf_log_applaud;
my $dsaf_usr_secl;
my $dsaf_data_set;
#Create and prepare the INSERT statement for dsaf
$statement="INSERT INTO dsaf (dsaf_event_type,dsaf_reserved_01,dsaf_time_written,dsaf_date_written,dsaf_system_smfid,dsaf_secl_link,dsaf_violation,dsaf_user_ndfnd,dsaf_user_warning,dsaf_evt_user_id,dsaf_evt_grp_id,dsaf_auth_normal,dsaf_auth_special,dsaf_auth_oper,dsaf_auth_audit,dsaf_auth_exit,dsaf_auth_failsft,dsaf_auth_bypass,dsaf_auth_trusted,dsaf_log_class,dsaf_log_user,dsaf_log_special,dsaf_log_access,dsaf_log_racinit,dsaf_log_always,dsaf_log_cmdviol,dsaf_log_global,dsaf_term_level,dsaf_backout_fail,dsaf_prof_same,dsaf_term,dsaf_job_name,dsaf_read_time,dsaf_read_date,dsaf_smf_user_id,dsaf_log_level,dsaf_log_logopt,dsaf_log_secl,dsaf_log_compatm,dsaf_log_applaud,dsaf_usr_secl,dsaf_data_set) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"dsaf"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"dsaf"}=0;
#Table:exesetid
#delete all rows from the exesetid table
$dbh->do("delete from exesetid");
#Define the column names for the exesetid table to Perl
my $esid_event_type;
my $esid_event_qual;
my $esid_time_written;
my $esid_date_written;
my $esid_system_smfid;
my $esid_violation;
my $esid_user_ndfnd;
my $esid_user_warning;
my $esid_evt_user_id;
my $esid_evt_grp_id;
my $esid_auth_normal;
my $esid_auth_special;
my $esid_auth_oper;
my $esid_auth_audit;
my $esid_auth_exit;
my $esid_auth_failsft;
my $esid_auth_bypass;
my $esid_auth_trusted;
my $esid_log_class;
my $esid_log_user;
my $esid_log_special;
my $esid_log_access;
my $esid_log_racinit;
my $esid_log_always;
my $esid_log_cmdviol;
my $esid_log_global;
my $esid_term_level;
my $esid_backout_fail;
my $esid_prof_same;
my $esid_term;
my $esid_job_name;
my $esid_read_time;
my $esid_read_date;
my $esid_smf_user_id;
my $esid_log_level;
my $esid_log_vmevent;
my $esid_log_logopt;
my $esid_log_secl;
my $esid_log_compatm;
my $esid_log_applaud;
my $esid_log_nonomvs;
my $esid_log_omvsnprv;
my $esid_auth_omvssu;
my $esid_auth_omvssys;
my $esid_usr_secl;
my $esid_racf_version;
my $esid_class;
my $esid_user_name;
my $esid_utk_encr;
my $esid_utk_pre19;
my $esid_utk_verprof;
my $esid_utk_njeunusr;
my $esid_utk_logusr;
my $esid_utk_special;
my $esid_utk_default;
my $esid_utk_unknusr;
my $esid_utk_error;
my $esid_utk_trusted;
my $esid_utk_sesstype;
my $esid_utk_surrogat;
my $esid_utk_remote;
my $esid_utk_priv;
my $esid_utk_secl;
my $esid_utk_execnode;
my $esid_utk_suser_id;
my $esid_utk_snode;
my $esid_utk_sgrp_id;
my $esid_utk_spoe;
my $esid_utk_spclass;
my $esid_utk_user_id;
my $esid_utk_grp_id;
my $esid_utk_dft_grp;
my $esid_utk_dft_secl;
my $esid_appc_link;
my $esid_audit_code;
my $esid_old_real_uid;
my $esid_old_eff_uid;
my $esid_old_saved_uid;
my $esid_old_real_gid;
my $esid_old_eff_gid;
my $esid_old_saved_gid;
my $esid_new_real_uid;
my $esid_new_eff_uid;
my $esid_new_saved_uid;
my $esid_new_real_gid;
my $esid_new_eff_gid;
my $esid_new_saved_gid;
my $esid_uid;
my $esid_gid;
my $esid_dflt_process;
my $esid_utk_netw;
my $esid_x500_subject;
my $esid_x500_issuer;
#Create and prepare the INSERT statement for exesetid
$statement="INSERT INTO exesetid (esid_event_type,esid_event_qual,esid_time_written,esid_date_written,esid_system_smfid,esid_violation,esid_user_ndfnd,esid_user_warning,esid_evt_user_id,esid_evt_grp_id,esid_auth_normal,esid_auth_special,esid_auth_oper,esid_auth_audit,esid_auth_exit,esid_auth_failsft,esid_auth_bypass,esid_auth_trusted,esid_log_class,esid_log_user,esid_log_special,esid_log_access,esid_log_racinit,esid_log_always,esid_log_cmdviol,esid_log_global,esid_term_level,esid_backout_fail,esid_prof_same,esid_term,esid_job_name,esid_read_time,esid_read_date,esid_smf_user_id,esid_log_level,esid_log_vmevent,esid_log_logopt,esid_log_secl,esid_log_compatm,esid_log_applaud,esid_log_nonomvs,esid_log_omvsnprv,esid_auth_omvssu,esid_auth_omvssys,esid_usr_secl,esid_racf_version,esid_class,esid_user_name,esid_utk_encr,esid_utk_pre19,esid_utk_verprof,esid_utk_njeunusr,esid_utk_logusr,esid_utk_special,esid_utk_default,esid_utk_unknusr,esid_utk_error,esid_utk_trusted,esid_utk_sesstype,esid_utk_surrogat,esid_utk_remote,esid_utk_priv,esid_utk_secl,esid_utk_execnode,esid_utk_suser_id,esid_utk_snode,esid_utk_sgrp_id,esid_utk_spoe,esid_utk_spclass,esid_utk_user_id,esid_utk_grp_id,esid_utk_dft_grp,esid_utk_dft_secl,esid_appc_link,esid_audit_code,esid_old_real_uid,esid_old_eff_uid,esid_old_saved_uid,esid_old_real_gid,esid_old_eff_gid,esid_old_saved_gid,esid_new_real_uid,esid_new_eff_uid,esid_new_saved_uid,esid_new_real_gid,esid_new_eff_gid,esid_new_saved_gid,esid_uid,esid_gid,esid_dflt_process,esid_utk_netw,esid_x500_subject,esid_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"exesetid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"exesetid"}=0;
#Table:faccess
#delete all rows from the faccess table
$dbh->do("delete from faccess");
#Define the column names for the faccess table to Perl
my $facc_event_type;
my $facc_event_qual;
my $facc_time_written;
my $facc_date_written;
my $facc_system_smfid;
my $facc_violation;
my $facc_user_ndfnd;
my $facc_user_warning;
my $facc_evt_user_id;
my $facc_evt_grp_id;
my $facc_auth_normal;
my $facc_auth_special;
my $facc_auth_oper;
my $facc_auth_audit;
my $facc_auth_exit;
my $facc_auth_failsft;
my $facc_auth_bypass;
my $facc_auth_trusted;
my $facc_log_class;
my $facc_log_user;
my $facc_log_special;
my $facc_log_access;
my $facc_log_racinit;
my $facc_log_always;
my $facc_log_cmdviol;
my $facc_log_global;
my $facc_term_level;
my $facc_backout_fail;
my $facc_prof_same;
my $facc_term;
my $facc_job_name;
my $facc_read_time;
my $facc_read_date;
my $facc_smf_user_id;
my $facc_log_level;
my $facc_log_vmevent;
my $facc_log_logopt;
my $facc_log_secl;
my $facc_log_compatm;
my $facc_log_applaud;
my $facc_log_nonomvs;
my $facc_log_omvsnprv;
my $facc_auth_omvssu;
my $facc_auth_omvssys;
my $facc_usr_secl;
my $facc_racf_version;
my $facc_class;
my $facc_user_name;
my $facc_utk_encr;
my $facc_utk_pre19;
my $facc_utk_verprof;
my $facc_utk_njeunusr;
my $facc_utk_logusr;
my $facc_utk_special;
my $facc_utk_default;
my $facc_utk_unknusr;
my $facc_utk_error;
my $facc_utk_trusted;
my $facc_utk_sesstype;
my $facc_utk_surrogat;
my $facc_utk_remote;
my $facc_utk_priv;
my $facc_utk_secl;
my $facc_utk_execnode;
my $facc_utk_suser_id;
my $facc_utk_snode;
my $facc_utk_sgrp_id;
my $facc_utk_spoe;
my $facc_utk_spclass;
my $facc_utk_user_id;
my $facc_utk_grp_id;
my $facc_utk_dft_grp;
my $facc_utk_dft_secl;
my $facc_appc_link;
my $facc_audit_code;
my $facc_old_real_uid;
my $facc_old_eff_uid;
my $facc_old_saved_uid;
my $facc_old_real_gid;
my $facc_old_eff_gid;
my $facc_old_saved_gid;
my $facc_path_name;
my $facc_file_id;
my $facc_file_own_uid;
my $facc_file_own_gid;
my $facc_request_read;
my $facc_request_write;
my $facc_request_exec;
my $facc_request_dsrch;
my $facc_access_type;
my $facc_allowed_read;
my $facc_allowed_write;
my $facc_allowed_exec;
my $facc_request_path2;
my $facc_file_name;
my $facc_path_type;
my $facc_filepool;
my $facc_filespace;
my $facc_inode;
my $facc_scid;
my $facc_dce_link;
my $facc_auth_type;
my $facc_dflt_process;
my $facc_utk_netw;
my $facc_x500_subject;
my $facc_x500_issuer;
#Create and prepare the INSERT statement for faccess
$statement="INSERT INTO faccess (facc_event_type,facc_event_qual,facc_time_written,facc_date_written,facc_system_smfid,facc_violation,facc_user_ndfnd,facc_user_warning,facc_evt_user_id,facc_evt_grp_id,facc_auth_normal,facc_auth_special,facc_auth_oper,facc_auth_audit,facc_auth_exit,facc_auth_failsft,facc_auth_bypass,facc_auth_trusted,facc_log_class,facc_log_user,facc_log_special,facc_log_access,facc_log_racinit,facc_log_always,facc_log_cmdviol,facc_log_global,facc_term_level,facc_backout_fail,facc_prof_same,facc_term,facc_job_name,facc_read_time,facc_read_date,facc_smf_user_id,facc_log_level,facc_log_vmevent,facc_log_logopt,facc_log_secl,facc_log_compatm,facc_log_applaud,facc_log_nonomvs,facc_log_omvsnprv,facc_auth_omvssu,facc_auth_omvssys,facc_usr_secl,facc_racf_version,facc_class,facc_user_name,facc_utk_encr,facc_utk_pre19,facc_utk_verprof,facc_utk_njeunusr,facc_utk_logusr,facc_utk_special,facc_utk_default,facc_utk_unknusr,facc_utk_error,facc_utk_trusted,facc_utk_sesstype,facc_utk_surrogat,facc_utk_remote,facc_utk_priv,facc_utk_secl,facc_utk_execnode,facc_utk_suser_id,facc_utk_snode,facc_utk_sgrp_id,facc_utk_spoe,facc_utk_spclass,facc_utk_user_id,facc_utk_grp_id,facc_utk_dft_grp,facc_utk_dft_secl,facc_appc_link,facc_audit_code,facc_old_real_uid,facc_old_eff_uid,facc_old_saved_uid,facc_old_real_gid,facc_old_eff_gid,facc_old_saved_gid,facc_path_name,facc_file_id,facc_file_own_uid,facc_file_own_gid,facc_request_read,facc_request_write,facc_request_exec,facc_request_dsrch,facc_access_type,facc_allowed_read,facc_allowed_write,facc_allowed_exec,facc_request_path2,facc_file_name,facc_path_type,facc_filepool,facc_filespace,facc_inode,facc_scid,facc_dce_link,facc_auth_type,facc_dflt_process,facc_utk_netw,facc_x500_subject,facc_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"faccess"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"faccess"}=0;
#Table:general
#delete all rows from the general table
$dbh->do("delete from general");
#Define the column names for the general table to Perl
my $gen_event_type;
my $gen_event_qual;
my $gen_time_written;
my $gen_date_written;
my $gen_system_smfid;
my $gen_violation;
my $gen_user_ndfnd;
my $gen_user_warning;
my $gen_evt_user_id;
my $gen_evt_grp_id;
my $gen_auth_normal;
my $gen_auth_special;
my $gen_auth_oper;
my $gen_auth_audit;
my $gen_auth_exit;
my $gen_auth_failsft;
my $gen_auth_bypass;
my $gen_auth_trusted;
my $gen_log_class;
my $gen_log_user;
my $gen_log_special;
my $gen_log_access;
my $gen_log_racinit;
my $gen_log_always;
my $gen_log_cmdviol;
my $gen_log_global;
my $gen_term_level;
my $gen_backout_fail;
my $gen_prof_same;
my $gen_term;
my $gen_job_name;
my $gen_read_time;
my $gen_read_date;
my $gen_smf_user_id;
my $gen_log_level;
my $gen_log_vmevent;
my $gen_log_logopt;
my $gen_log_secl;
my $gen_log_compatm;
my $gen_log_applaud;
my $gen_log_nonomvs;
my $gen_log_omvsnprv;
my $gen_auth_omvssu;
my $gen_auth_omvssys;
my $gen_usr_secl;
my $gen_racf_version;
my $gen_class;
my $gen_logstr;
my $gen_user_name;
my $gen_utk_encr;
my $gen_utk_pre19;
my $gen_utk_verprof;
my $gen_utk_njeunusr;
my $gen_utk_logusr;
my $gen_utk_special;
my $gen_utk_default;
my $gen_utk_unknusr;
my $gen_utk_error;
my $gen_utk_trusted;
my $gen_utk_sesstype;
my $gen_utk_surrogat;
my $gen_utk_remote;
my $gen_utk_priv;
my $gen_utk_secl;
my $gen_utk_execnode;
my $gen_utk_suser_id;
my $gen_utk_snode;
my $gen_utk_sgrp_id;
my $gen_utk_spoe;
my $gen_utk_spclass;
my $gen_utk_user_id;
my $gen_utk_grp_id;
my $gen_utk_dft_grp;
my $gen_utk_dft_secl;
my $gen_appc_link;
my $gen_utk_netw;
my $gen_x500_subject;
my $gen_x500_issuer;
#Create and prepare the INSERT statement for general
$statement="INSERT INTO general (gen_event_type,gen_event_qual,gen_time_written,gen_date_written,gen_system_smfid,gen_violation,gen_user_ndfnd,gen_user_warning,gen_evt_user_id,gen_evt_grp_id,gen_auth_normal,gen_auth_special,gen_auth_oper,gen_auth_audit,gen_auth_exit,gen_auth_failsft,gen_auth_bypass,gen_auth_trusted,gen_log_class,gen_log_user,gen_log_special,gen_log_access,gen_log_racinit,gen_log_always,gen_log_cmdviol,gen_log_global,gen_term_level,gen_backout_fail,gen_prof_same,gen_term,gen_job_name,gen_read_time,gen_read_date,gen_smf_user_id,gen_log_level,gen_log_vmevent,gen_log_logopt,gen_log_secl,gen_log_compatm,gen_log_applaud,gen_log_nonomvs,gen_log_omvsnprv,gen_auth_omvssu,gen_auth_omvssys,gen_usr_secl,gen_racf_version,gen_class,gen_logstr,gen_user_name,gen_utk_encr,gen_utk_pre19,gen_utk_verprof,gen_utk_njeunusr,gen_utk_logusr,gen_utk_special,gen_utk_default,gen_utk_unknusr,gen_utk_error,gen_utk_trusted,gen_utk_sesstype,gen_utk_surrogat,gen_utk_remote,gen_utk_priv,gen_utk_secl,gen_utk_execnode,gen_utk_suser_id,gen_utk_snode,gen_utk_sgrp_id,gen_utk_spoe,gen_utk_spclass,gen_utk_user_id,gen_utk_grp_id,gen_utk_dft_grp,gen_utk_dft_secl,gen_appc_link,gen_utk_netw,gen_x500_subject,gen_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"general"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"general"}=0;
#Table:getpsent
#delete all rows from the getpsent table
$dbh->do("delete from getpsent");
#Define the column names for the getpsent table to Perl
my $gpst_event_type;
my $gpst_event_qual;
my $gpst_time_written;
my $gpst_date_written;
my $gpst_system_smfid;
my $gpst_violation;
my $gpst_user_ndfnd;
my $gpst_user_warning;
my $gpst_evt_user_id;
my $gpst_evt_grp_id;
my $gpst_auth_normal;
my $gpst_auth_special;
my $gpst_auth_oper;
my $gpst_auth_audit;
my $gpst_auth_exit;
my $gpst_auth_failsft;
my $gpst_auth_bypass;
my $gpst_auth_trusted;
my $gpst_log_class;
my $gpst_log_user;
my $gpst_log_special;
my $gpst_log_access;
my $gpst_log_racinit;
my $gpst_log_always;
my $gpst_log_cmdviol;
my $gpst_log_global;
my $gpst_term_level;
my $gpst_backout_fail;
my $gpst_prof_same;
my $gpst_term;
my $gpst_job_name;
my $gpst_read_time;
my $gpst_read_date;
my $gpst_smf_user_id;
my $gpst_log_level;
my $gpst_log_vmevent;
my $gpst_log_logopt;
my $gpst_log_secl;
my $gpst_log_compatm;
my $gpst_log_applaud;
my $gpst_log_nonomvs;
my $gpst_log_omvsnprv;
my $gpst_auth_omvssu;
my $gpst_auth_omvssys;
my $gpst_usr_secl;
my $gpst_racf_version;
my $gpst_class;
my $gpst_user_name;
my $gpst_utk_encr;
my $gpst_utk_pre19;
my $gpst_utk_verprof;
my $gpst_utk_njeunusr;
my $gpst_utk_logusr;
my $gpst_utk_special;
my $gpst_utk_default;
my $gpst_utk_unknusr;
my $gpst_utk_error;
my $gpst_utk_trusted;
my $gpst_utk_sesstype;
my $gpst_utk_surrogat;
my $gpst_utk_remote;
my $gpst_utk_priv;
my $gpst_utk_secl;
my $gpst_utk_execnode;
my $gpst_utk_suser_id;
my $gpst_utk_snode;
my $gpst_utk_sgrp_id;
my $gpst_utk_spoe;
my $gpst_utk_spclass;
my $gpst_utk_user_id;
my $gpst_utk_grp_id;
my $gpst_utk_dft_grp;
my $gpst_utk_dft_secl;
my $gpst_appc_link;
my $gpst_audit_code;
my $gpst_old_real_uid;
my $gpst_old_eff_uid;
my $gpst_old_saved_uid;
my $gpst_old_real_gid;
my $gpst_old_eff_gid;
my $gpst_old_saved_gid;
my $gpst_tgt_real_uid;
my $gpst_tgt_eff_uid;
my $gpst_tgt_sav_uid;
my $gpst_tgt_pid;
my $gpst_dflt_process;
my $gpst_utk_netw;
my $gpst_x500_subject;
my $gpst_x500_issuer;
#Create and prepare the INSERT statement for getpsent
$statement="INSERT INTO getpsent (gpst_event_type,gpst_event_qual,gpst_time_written,gpst_date_written,gpst_system_smfid,gpst_violation,gpst_user_ndfnd,gpst_user_warning,gpst_evt_user_id,gpst_evt_grp_id,gpst_auth_normal,gpst_auth_special,gpst_auth_oper,gpst_auth_audit,gpst_auth_exit,gpst_auth_failsft,gpst_auth_bypass,gpst_auth_trusted,gpst_log_class,gpst_log_user,gpst_log_special,gpst_log_access,gpst_log_racinit,gpst_log_always,gpst_log_cmdviol,gpst_log_global,gpst_term_level,gpst_backout_fail,gpst_prof_same,gpst_term,gpst_job_name,gpst_read_time,gpst_read_date,gpst_smf_user_id,gpst_log_level,gpst_log_vmevent,gpst_log_logopt,gpst_log_secl,gpst_log_compatm,gpst_log_applaud,gpst_log_nonomvs,gpst_log_omvsnprv,gpst_auth_omvssu,gpst_auth_omvssys,gpst_usr_secl,gpst_racf_version,gpst_class,gpst_user_name,gpst_utk_encr,gpst_utk_pre19,gpst_utk_verprof,gpst_utk_njeunusr,gpst_utk_logusr,gpst_utk_special,gpst_utk_default,gpst_utk_unknusr,gpst_utk_error,gpst_utk_trusted,gpst_utk_sesstype,gpst_utk_surrogat,gpst_utk_remote,gpst_utk_priv,gpst_utk_secl,gpst_utk_execnode,gpst_utk_suser_id,gpst_utk_snode,gpst_utk_sgrp_id,gpst_utk_spoe,gpst_utk_spclass,gpst_utk_user_id,gpst_utk_grp_id,gpst_utk_dft_grp,gpst_utk_dft_secl,gpst_appc_link,gpst_audit_code,gpst_old_real_uid,gpst_old_eff_uid,gpst_old_saved_uid,gpst_old_real_gid,gpst_old_eff_gid,gpst_old_saved_gid,gpst_tgt_real_uid,gpst_tgt_eff_uid,gpst_tgt_sav_uid,gpst_tgt_pid,gpst_dflt_process,gpst_utk_netw,gpst_x500_subject,gpst_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"getpsent"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"getpsent"}=0;
#Table:initacee
#delete all rows from the initacee table
$dbh->do("delete from initacee");
#Define the column names for the initacee table to Perl
my $inta_event_type;
my $inta_event_qual;
my $inta_time_written;
my $inta_date_written;
my $inta_system_smfid;
my $inta_violation;
my $inta_user_ndfnd;
my $inta_user_warning;
my $inta_evt_user_id;
my $inta_evt_grp_id;
my $inta_auth_normal;
my $inta_auth_special;
my $inta_auth_oper;
my $inta_auth_audit;
my $inta_auth_exit;
my $inta_auth_failsft;
my $inta_auth_bypass;
my $inta_auth_trusted;
my $inta_log_class;
my $inta_log_user;
my $inta_log_special;
my $inta_log_access;
my $inta_log_racinit;
my $inta_log_always;
my $inta_log_cmdviol;
my $inta_log_global;
my $inta_term_level;
my $inta_backout_fail;
my $inta_prof_same;
my $inta_term;
my $inta_job_name;
my $inta_read_time;
my $inta_read_date;
my $inta_smf_user_id;
my $inta_log_level;
my $inta_log_vmevent;
my $inta_log_logopt;
my $inta_log_secl;
my $inta_log_compatm;
my $inta_log_applaud;
my $inta_log_nonomvs;
my $inta_log_omvsnprv;
my $inta_auth_omvssu;
my $inta_auth_omvssys;
my $inta_usr_secl;
my $inta_racf_version;
my $inta_user_name;
my $inta_utk_encr;
my $inta_utk_pre19;
my $inta_utk_verprof;
my $inta_utk_njeunusr;
my $inta_utk_logusr;
my $inta_utk_special;
my $inta_utk_default;
my $inta_utk_unknusr;
my $inta_utk_error;
my $inta_utk_trusted;
my $inta_utk_sesstype;
my $inta_utk_surrogat;
my $inta_utk_remote;
my $inta_utk_priv;
my $inta_utk_secl;
my $inta_utk_execnode;
my $inta_utk_suser_id;
my $inta_utk_snode;
my $inta_utk_sgrp_id;
my $inta_utk_spoe;
my $inta_utk_spclass;
my $inta_utk_user_id;
my $inta_utk_grp_id;
my $inta_utk_dft_grp;
my $inta_utk_dft_secl;
my $inta_serial_number;
my $inta_issuers_dn;
my $inta_utk_netw;
my $inta_x500_subject;
my $inta_x500_issuer;
#Create and prepare the INSERT statement for initacee
$statement="INSERT INTO initacee (inta_event_type,inta_event_qual,inta_time_written,inta_date_written,inta_system_smfid,inta_violation,inta_user_ndfnd,inta_user_warning,inta_evt_user_id,inta_evt_grp_id,inta_auth_normal,inta_auth_special,inta_auth_oper,inta_auth_audit,inta_auth_exit,inta_auth_failsft,inta_auth_bypass,inta_auth_trusted,inta_log_class,inta_log_user,inta_log_special,inta_log_access,inta_log_racinit,inta_log_always,inta_log_cmdviol,inta_log_global,inta_term_level,inta_backout_fail,inta_prof_same,inta_term,inta_job_name,inta_read_time,inta_read_date,inta_smf_user_id,inta_log_level,inta_log_vmevent,inta_log_logopt,inta_log_secl,inta_log_compatm,inta_log_applaud,inta_log_nonomvs,inta_log_omvsnprv,inta_auth_omvssu,inta_auth_omvssys,inta_usr_secl,inta_racf_version,inta_user_name,inta_utk_encr,inta_utk_pre19,inta_utk_verprof,inta_utk_njeunusr,inta_utk_logusr,inta_utk_special,inta_utk_default,inta_utk_unknusr,inta_utk_error,inta_utk_trusted,inta_utk_sesstype,inta_utk_surrogat,inta_utk_remote,inta_utk_priv,inta_utk_secl,inta_utk_execnode,inta_utk_suser_id,inta_utk_snode,inta_utk_sgrp_id,inta_utk_spoe,inta_utk_spclass,inta_utk_user_id,inta_utk_grp_id,inta_utk_dft_grp,inta_utk_dft_secl,inta_serial_number,inta_issuers_dn,inta_utk_netw,inta_x500_subject,inta_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"initacee"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"initacee"}=0;
#Table:initoedp
#delete all rows from the initoedp table
$dbh->do("delete from initoedp");
#Define the column names for the initoedp table to Perl
my $ioep_event_type;
my $ioep_event_qual;
my $ioep_time_written;
my $ioep_date_written;
my $ioep_system_smfid;
my $ioep_violation;
my $ioep_user_ndfnd;
my $ioep_user_warning;
my $ioep_evt_user_id;
my $ioep_evt_grp_id;
my $ioep_auth_normal;
my $ioep_auth_special;
my $ioep_auth_oper;
my $ioep_auth_audit;
my $ioep_auth_exit;
my $ioep_auth_failsft;
my $ioep_auth_bypass;
my $ioep_auth_trusted;
my $ioep_log_class;
my $ioep_log_user;
my $ioep_log_special;
my $ioep_log_access;
my $ioep_log_racinit;
my $ioep_log_always;
my $ioep_log_cmdviol;
my $ioep_log_global;
my $ioep_term_level;
my $ioep_backout_fail;
my $ioep_prof_same;
my $ioep_term;
my $ioep_job_name;
my $ioep_read_time;
my $ioep_read_date;
my $ioep_smf_user_id;
my $ioep_log_level;
my $ioep_log_vmevent;
my $ioep_log_logopt;
my $ioep_log_secl;
my $ioep_log_compatm;
my $ioep_log_applaud;
my $ioep_log_nonomvs;
my $ioep_log_omvsnprv;
my $ioep_auth_omvssu;
my $ioep_auth_omvssys;
my $ioep_usr_secl;
my $ioep_racf_version;
my $ioep_class;
my $ioep_user_name;
my $ioep_utk_encr;
my $ioep_utk_pre19;
my $ioep_utk_verprof;
my $ioep_utk_njeunusr;
my $ioep_utk_logusr;
my $ioep_utk_special;
my $ioep_utk_default;
my $ioep_utk_unknusr;
my $ioep_utk_error;
my $ioep_utk_trusted;
my $ioep_utk_sesstype;
my $ioep_utk_surrogat;
my $ioep_utk_remote;
my $ioep_utk_priv;
my $ioep_utk_secl;
my $ioep_utk_execnode;
my $ioep_utk_suser_id;
my $ioep_utk_snode;
my $ioep_utk_sgrp_id;
my $ioep_utk_spoe;
my $ioep_utk_spclass;
my $ioep_utk_user_id;
my $ioep_utk_grp_id;
my $ioep_utk_dft_grp;
my $ioep_utk_dft_secl;
my $ioep_appc_link;
my $ioep_audit_code;
my $ioep_old_real_uid;
my $ioep_old_eff_uid;
my $ioep_old_saved_uid;
my $ioep_old_real_gid;
my $ioep_old_eff_gid;
my $ioep_old_saved_gid;
my $ioep_dflt_process;
my $ioep_utk_netw;
my $ioep_x500_subject;
my $ioep_x500_issuer;
#Create and prepare the INSERT statement for initoedp
$statement="INSERT INTO initoedp (ioep_event_type,ioep_event_qual,ioep_time_written,ioep_date_written,ioep_system_smfid,ioep_violation,ioep_user_ndfnd,ioep_user_warning,ioep_evt_user_id,ioep_evt_grp_id,ioep_auth_normal,ioep_auth_special,ioep_auth_oper,ioep_auth_audit,ioep_auth_exit,ioep_auth_failsft,ioep_auth_bypass,ioep_auth_trusted,ioep_log_class,ioep_log_user,ioep_log_special,ioep_log_access,ioep_log_racinit,ioep_log_always,ioep_log_cmdviol,ioep_log_global,ioep_term_level,ioep_backout_fail,ioep_prof_same,ioep_term,ioep_job_name,ioep_read_time,ioep_read_date,ioep_smf_user_id,ioep_log_level,ioep_log_vmevent,ioep_log_logopt,ioep_log_secl,ioep_log_compatm,ioep_log_applaud,ioep_log_nonomvs,ioep_log_omvsnprv,ioep_auth_omvssu,ioep_auth_omvssys,ioep_usr_secl,ioep_racf_version,ioep_class,ioep_user_name,ioep_utk_encr,ioep_utk_pre19,ioep_utk_verprof,ioep_utk_njeunusr,ioep_utk_logusr,ioep_utk_special,ioep_utk_default,ioep_utk_unknusr,ioep_utk_error,ioep_utk_trusted,ioep_utk_sesstype,ioep_utk_surrogat,ioep_utk_remote,ioep_utk_priv,ioep_utk_secl,ioep_utk_execnode,ioep_utk_suser_id,ioep_utk_snode,ioep_utk_sgrp_id,ioep_utk_spoe,ioep_utk_spclass,ioep_utk_user_id,ioep_utk_grp_id,ioep_utk_dft_grp,ioep_utk_dft_secl,ioep_appc_link,ioep_audit_code,ioep_old_real_uid,ioep_old_eff_uid,ioep_old_saved_uid,ioep_old_real_gid,ioep_old_eff_gid,ioep_old_saved_gid,ioep_dflt_process,ioep_utk_netw,ioep_x500_subject,ioep_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"initoedp"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"initoedp"}=0;
#Table:ipcchk
#delete all rows from the ipcchk table
$dbh->do("delete from ipcchk");
#Define the column names for the ipcchk table to Perl
my $ichk_event_type;
my $ichk_event_qual;
my $ichk_time_written;
my $ichk_date_written;
my $ichk_system_smfid;
my $ichk_violation;
my $ichk_user_ndfnd;
my $ichk_user_warning;
my $ichk_evt_user_id;
my $ichk_evt_grp_id;
my $ichk_auth_normal;
my $ichk_auth_special;
my $ichk_auth_oper;
my $ichk_auth_audit;
my $ichk_auth_exit;
my $ichk_auth_failsft;
my $ichk_auth_bypass;
my $ichk_auth_trusted;
my $ichk_log_class;
my $ichk_log_user;
my $ichk_log_special;
my $ichk_log_access;
my $ichk_log_racinit;
my $ichk_log_always;
my $ichk_log_cmdviol;
my $ichk_log_global;
my $ichk_term_level;
my $ichk_backout_fail;
my $ichk_prof_same;
my $ichk_term;
my $ichk_job_name;
my $ichk_read_time;
my $ichk_read_date;
my $ichk_smf_user_id;
my $ichk_log_level;
my $ichk_log_vmevent;
my $ichk_log_logopt;
my $ichk_log_secl;
my $ichk_log_compatm;
my $ichk_log_applaud;
my $ichk_log_nonomvs;
my $ichk_log_omvsnprv;
my $ichk_auth_omvssu;
my $ichk_auth_omvssys;
my $ichk_usr_secl;
my $ichk_racf_version;
my $ichk_class;
my $ichk_user_name;
my $ichk_utk_encr;
my $ichk_utk_pre19;
my $ichk_utk_verprof;
my $ichk_utk_njeunusr;
my $ichk_utk_logusr;
my $ichk_utk_special;
my $ichk_utk_default;
my $ichk_utk_unknusr;
my $ichk_utk_error;
my $ichk_utk_trusted;
my $ichk_utk_sesstype;
my $ichk_utk_surrogat;
my $ichk_utk_remote;
my $ichk_utk_priv;
my $ichk_utk_secl;
my $ichk_utk_execnode;
my $ichk_utk_suser_id;
my $ichk_utk_snode;
my $ichk_utk_sgrp_id;
my $ichk_utk_spoe;
my $ichk_utk_spclass;
my $ichk_utk_user_id;
my $ichk_utk_grp_id;
my $ichk_utk_dft_grp;
my $ichk_utk_dft_secl;
my $ichk_appc_link;
my $ichk_audit_code;
my $ichk_old_real_uid;
my $ichk_old_eff_uid;
my $ichk_old_saved_uid;
my $ichk_old_real_gid;
my $ichk_old_eff_gid;
my $ichk_old_saved_gid;
my $ichk_key_own_uid;
my $ichk_key_own_gid;
my $ichk_request_read;
my $ichk_request_write;
my $ichk_request_exec;
my $ichk_reserved_01;
my $ichk_access_type;
my $ichk_allowed_read;
my $ichk_allowed_write;
my $ichk_reserved_02;
my $ichk_key;
my $ichk_id;
my $ichk_creator_uid;
my $ichk_creator_gid;
my $ichk_dflt_process;
my $ichk_utk_netw;
my $ichk_x500_subject;
my $ichk_x500_issuer;
#Create and prepare the INSERT statement for ipcchk
$statement="INSERT INTO ipcchk (ichk_event_type,ichk_event_qual,ichk_time_written,ichk_date_written,ichk_system_smfid,ichk_violation,ichk_user_ndfnd,ichk_user_warning,ichk_evt_user_id,ichk_evt_grp_id,ichk_auth_normal,ichk_auth_special,ichk_auth_oper,ichk_auth_audit,ichk_auth_exit,ichk_auth_failsft,ichk_auth_bypass,ichk_auth_trusted,ichk_log_class,ichk_log_user,ichk_log_special,ichk_log_access,ichk_log_racinit,ichk_log_always,ichk_log_cmdviol,ichk_log_global,ichk_term_level,ichk_backout_fail,ichk_prof_same,ichk_term,ichk_job_name,ichk_read_time,ichk_read_date,ichk_smf_user_id,ichk_log_level,ichk_log_vmevent,ichk_log_logopt,ichk_log_secl,ichk_log_compatm,ichk_log_applaud,ichk_log_nonomvs,ichk_log_omvsnprv,ichk_auth_omvssu,ichk_auth_omvssys,ichk_usr_secl,ichk_racf_version,ichk_class,ichk_user_name,ichk_utk_encr,ichk_utk_pre19,ichk_utk_verprof,ichk_utk_njeunusr,ichk_utk_logusr,ichk_utk_special,ichk_utk_default,ichk_utk_unknusr,ichk_utk_error,ichk_utk_trusted,ichk_utk_sesstype,ichk_utk_surrogat,ichk_utk_remote,ichk_utk_priv,ichk_utk_secl,ichk_utk_execnode,ichk_utk_suser_id,ichk_utk_snode,ichk_utk_sgrp_id,ichk_utk_spoe,ichk_utk_spclass,ichk_utk_user_id,ichk_utk_grp_id,ichk_utk_dft_grp,ichk_utk_dft_secl,ichk_appc_link,ichk_audit_code,ichk_old_real_uid,ichk_old_eff_uid,ichk_old_saved_uid,ichk_old_real_gid,ichk_old_eff_gid,ichk_old_saved_gid,ichk_key_own_uid,ichk_key_own_gid,ichk_request_read,ichk_request_write,ichk_request_exec,ichk_reserved_01,ichk_access_type,ichk_allowed_read,ichk_allowed_write,ichk_reserved_02,ichk_key,ichk_id,ichk_creator_uid,ichk_creator_gid,ichk_dflt_process,ichk_utk_netw,ichk_x500_subject,ichk_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ipcchk"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ipcchk"}=0;
#Table:ipcctl
#delete all rows from the ipcctl table
$dbh->do("delete from ipcctl");
#Define the column names for the ipcctl table to Perl
my $ictl_event_type;
my $ictl_event_qual;
my $ictl_time_written;
my $ictl_date_written;
my $ictl_system_smfid;
my $ictl_violation;
my $ictl_user_ndfnd;
my $ictl_user_warning;
my $ictl_evt_user_id;
my $ictl_evt_grp_id;
my $ictl_auth_normal;
my $ictl_auth_special;
my $ictl_auth_oper;
my $ictl_auth_audit;
my $ictl_auth_exit;
my $ictl_auth_failsft;
my $ictl_auth_bypass;
my $ictl_auth_trusted;
my $ictl_log_class;
my $ictl_log_user;
my $ictl_log_special;
my $ictl_log_access;
my $ictl_log_racinit;
my $ictl_log_always;
my $ictl_log_cmdviol;
my $ictl_log_global;
my $ictl_term_level;
my $ictl_backout_fail;
my $ictl_prof_same;
my $ictl_term;
my $ictl_job_name;
my $ictl_read_time;
my $ictl_read_date;
my $ictl_smf_user_id;
my $ictl_log_level;
my $ictl_log_vmevent;
my $ictl_log_logopt;
my $ictl_log_secl;
my $ictl_log_compatm;
my $ictl_log_applaud;
my $ictl_log_nonomvs;
my $ictl_log_omvsnprv;
my $ictl_auth_omvssu;
my $ictl_auth_omvssys;
my $ictl_usr_secl;
my $ictl_racf_version;
my $ictl_class;
my $ictl_user_name;
my $ictl_utk_encr;
my $ictl_utk_pre19;
my $ictl_utk_verprof;
my $ictl_utk_njeunusr;
my $ictl_utk_logusr;
my $ictl_utk_special;
my $ictl_utk_default;
my $ictl_utk_unknusr;
my $ictl_utk_error;
my $ictl_utk_trusted;
my $ictl_utk_sesstype;
my $ictl_utk_surrogat;
my $ictl_utk_remote;
my $ictl_utk_priv;
my $ictl_utk_secl;
my $ictl_utk_execnode;
my $ictl_utk_suser_id;
my $ictl_utk_snode;
my $ictl_utk_sgrp_id;
my $ictl_utk_spoe;
my $ictl_utk_spclass;
my $ictl_utk_user_id;
my $ictl_utk_grp_id;
my $ictl_utk_dft_grp;
my $ictl_utk_dft_secl;
my $ictl_appc_link;
my $ictl_audit_code;
my $ictl_old_real_uid;
my $ictl_old_eff_uid;
my $ictl_old_saved_uid;
my $ictl_old_real_gid;
my $ictl_old_eff_gid;
my $ictl_old_saved_gid;
my $ictl_key_own_uid;
my $ictl_key_own_gid;
my $ictl_uid;
my $ictl_gid;
my $ictl_reserved_01;
my $ictl_reserved_02;
my $ictl_reserved_03;
my $ictl_old_own_read;
my $ictl_old_own_write;
my $ictl_old_own_exec;
my $ictl_old_grp_read;
my $ictl_old_grp_write;
my $ictl_old_grp_exec;
my $ictl_old_oth_read;
my $ictl_old_oth_write;
my $ictl_old_oth_exec;
my $ictl_reserved_04;
my $ictl_reserved_05;
my $ictl_reserved_06;
my $ictl_new_own_read;
my $ictl_new_own_write;
my $ictl_new_own_exec;
my $ictl_new_grp_read;
my $ictl_new_grp_write;
my $ictl_new_grp_exec;
my $ictl_new_oth_read;
my $ictl_new_oth_write;
my $ictl_new_oth_exec;
my $ictl_service_code;
my $ictl_reserved_07;
my $ictl_reserved_08;
my $ictl_reserved_09;
my $ictl_req_own_read;
my $ictl_req_own_write;
my $ictl_req_own_exec;
my $ictl_req_grp_read;
my $ictl_req_grp_write;
my $ictl_req_grp_exec;
my $ictl_req_oth_read;
my $ictl_req_oth_write;
my $ictl_req_oth_exec;
my $ictl_key;
my $ictl_id;
my $ictl_creator_uid;
my $ictl_creator_gid;
my $ictl_dflt_process;
my $ictl_utk_netw;
my $ictl_x500_subject;
my $ictl_x500_issuer;
#Create and prepare the INSERT statement for ipcctl
$statement="INSERT INTO ipcctl (ictl_event_type,ictl_event_qual,ictl_time_written,ictl_date_written,ictl_system_smfid,ictl_violation,ictl_user_ndfnd,ictl_user_warning,ictl_evt_user_id,ictl_evt_grp_id,ictl_auth_normal,ictl_auth_special,ictl_auth_oper,ictl_auth_audit,ictl_auth_exit,ictl_auth_failsft,ictl_auth_bypass,ictl_auth_trusted,ictl_log_class,ictl_log_user,ictl_log_special,ictl_log_access,ictl_log_racinit,ictl_log_always,ictl_log_cmdviol,ictl_log_global,ictl_term_level,ictl_backout_fail,ictl_prof_same,ictl_term,ictl_job_name,ictl_read_time,ictl_read_date,ictl_smf_user_id,ictl_log_level,ictl_log_vmevent,ictl_log_logopt,ictl_log_secl,ictl_log_compatm,ictl_log_applaud,ictl_log_nonomvs,ictl_log_omvsnprv,ictl_auth_omvssu,ictl_auth_omvssys,ictl_usr_secl,ictl_racf_version,ictl_class,ictl_user_name,ictl_utk_encr,ictl_utk_pre19,ictl_utk_verprof,ictl_utk_njeunusr,ictl_utk_logusr,ictl_utk_special,ictl_utk_default,ictl_utk_unknusr,ictl_utk_error,ictl_utk_trusted,ictl_utk_sesstype,ictl_utk_surrogat,ictl_utk_remote,ictl_utk_priv,ictl_utk_secl,ictl_utk_execnode,ictl_utk_suser_id,ictl_utk_snode,ictl_utk_sgrp_id,ictl_utk_spoe,ictl_utk_spclass,ictl_utk_user_id,ictl_utk_grp_id,ictl_utk_dft_grp,ictl_utk_dft_secl,ictl_appc_link,ictl_audit_code,ictl_old_real_uid,ictl_old_eff_uid,ictl_old_saved_uid,ictl_old_real_gid,ictl_old_eff_gid,ictl_old_saved_gid,ictl_key_own_uid,ictl_key_own_gid,ictl_uid,ictl_gid,ictl_reserved_01,ictl_reserved_02,ictl_reserved_03,ictl_old_own_read,ictl_old_own_write,ictl_old_own_exec,ictl_old_grp_read,ictl_old_grp_write,ictl_old_grp_exec,ictl_old_oth_read,ictl_old_oth_write,ictl_old_oth_exec,ictl_reserved_04,ictl_reserved_05,ictl_reserved_06,ictl_new_own_read,ictl_new_own_write,ictl_new_own_exec,ictl_new_grp_read,ictl_new_grp_write,ictl_new_grp_exec,ictl_new_oth_read,ictl_new_oth_write,ictl_new_oth_exec,ictl_service_code,ictl_reserved_07,ictl_reserved_08,ictl_reserved_09,ictl_req_own_read,ictl_req_own_write,ictl_req_own_exec,ictl_req_grp_read,ictl_req_grp_write,ictl_req_grp_exec,ictl_req_oth_read,ictl_req_oth_write,ictl_req_oth_exec,ictl_key,ictl_id,ictl_creator_uid,ictl_creator_gid,ictl_dflt_process,ictl_utk_netw,ictl_x500_subject,ictl_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ipcctl"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ipcctl"}=0;
#Table:ipcget
#delete all rows from the ipcget table
$dbh->do("delete from ipcget");
#Define the column names for the ipcget table to Perl
my $iget_event_type;
my $iget_event_qual;
my $iget_time_written;
my $iget_date_written;
my $iget_system_smfid;
my $iget_violation;
my $iget_user_ndfnd;
my $iget_user_warning;
my $iget_evt_user_id;
my $iget_evt_grp_id;
my $iget_auth_normal;
my $iget_auth_special;
my $iget_auth_oper;
my $iget_auth_audit;
my $iget_auth_exit;
my $iget_auth_failsft;
my $iget_auth_bypass;
my $iget_auth_trusted;
my $iget_log_class;
my $iget_log_user;
my $iget_log_special;
my $iget_log_access;
my $iget_log_racinit;
my $iget_log_always;
my $iget_log_cmdviol;
my $iget_log_global;
my $iget_term_level;
my $iget_backout_fail;
my $iget_prof_same;
my $iget_term;
my $iget_job_name;
my $iget_read_time;
my $iget_read_date;
my $iget_smf_user_id;
my $iget_log_level;
my $iget_log_vmevent;
my $iget_log_logopt;
my $iget_log_secl;
my $iget_log_compatm;
my $iget_log_applaud;
my $iget_log_nonomvs;
my $iget_log_omvsnprv;
my $iget_auth_omvssu;
my $iget_auth_omvssys;
my $iget_usr_secl;
my $iget_racf_version;
my $iget_class;
my $iget_user_name;
my $iget_utk_encr;
my $iget_utk_pre19;
my $iget_utk_verprof;
my $iget_utk_njeunusr;
my $iget_utk_logusr;
my $iget_utk_special;
my $iget_utk_default;
my $iget_utk_unknusr;
my $iget_utk_error;
my $iget_utk_trusted;
my $iget_utk_sesstype;
my $iget_utk_surrogat;
my $iget_utk_remote;
my $iget_utk_priv;
my $iget_utk_secl;
my $iget_utk_execnode;
my $iget_utk_suser_id;
my $iget_utk_snode;
my $iget_utk_sgrp_id;
my $iget_utk_spoe;
my $iget_utk_spclass;
my $iget_utk_user_id;
my $iget_utk_grp_id;
my $iget_utk_dft_grp;
my $iget_utk_dft_secl;
my $iget_appc_link;
my $iget_audit_code;
my $iget_old_real_uid;
my $iget_old_eff_uid;
my $iget_old_saved_uid;
my $iget_old_real_gid;
my $iget_old_eff_gid;
my $iget_old_saved_gid;
my $iget_key_own_uid;
my $iget_key_own_gid;
my $iget_reserved_01;
my $iget_reserved_02;
my $iget_reserved_03;
my $iget_req_own_read;
my $iget_req_own_write;
my $iget_req_own_exec;
my $iget_req_grp_read;
my $iget_req_grp_write;
my $iget_req_grp_exec;
my $iget_req_oth_read;
my $iget_req_oth_write;
my $iget_req_oth_exec;
my $iget_key;
my $iget_id;
my $iget_creator_uid;
my $iget_creator_gid;
my $iget_dflt_process;
my $iget_utk_netw;
my $iget_x500_subject;
my $iget_x500_issuer;
#Create and prepare the INSERT statement for ipcget
$statement="INSERT INTO ipcget (iget_event_type,iget_event_qual,iget_time_written,iget_date_written,iget_system_smfid,iget_violation,iget_user_ndfnd,iget_user_warning,iget_evt_user_id,iget_evt_grp_id,iget_auth_normal,iget_auth_special,iget_auth_oper,iget_auth_audit,iget_auth_exit,iget_auth_failsft,iget_auth_bypass,iget_auth_trusted,iget_log_class,iget_log_user,iget_log_special,iget_log_access,iget_log_racinit,iget_log_always,iget_log_cmdviol,iget_log_global,iget_term_level,iget_backout_fail,iget_prof_same,iget_term,iget_job_name,iget_read_time,iget_read_date,iget_smf_user_id,iget_log_level,iget_log_vmevent,iget_log_logopt,iget_log_secl,iget_log_compatm,iget_log_applaud,iget_log_nonomvs,iget_log_omvsnprv,iget_auth_omvssu,iget_auth_omvssys,iget_usr_secl,iget_racf_version,iget_class,iget_user_name,iget_utk_encr,iget_utk_pre19,iget_utk_verprof,iget_utk_njeunusr,iget_utk_logusr,iget_utk_special,iget_utk_default,iget_utk_unknusr,iget_utk_error,iget_utk_trusted,iget_utk_sesstype,iget_utk_surrogat,iget_utk_remote,iget_utk_priv,iget_utk_secl,iget_utk_execnode,iget_utk_suser_id,iget_utk_snode,iget_utk_sgrp_id,iget_utk_spoe,iget_utk_spclass,iget_utk_user_id,iget_utk_grp_id,iget_utk_dft_grp,iget_utk_dft_secl,iget_appc_link,iget_audit_code,iget_old_real_uid,iget_old_eff_uid,iget_old_saved_uid,iget_old_real_gid,iget_old_eff_gid,iget_old_saved_gid,iget_key_own_uid,iget_key_own_gid,iget_reserved_01,iget_reserved_02,iget_reserved_03,iget_req_own_read,iget_req_own_write,iget_req_own_exec,iget_req_grp_read,iget_req_grp_write,iget_req_grp_exec,iget_req_oth_read,iget_req_oth_write,iget_req_oth_exec,iget_key,iget_id,iget_creator_uid,iget_creator_gid,iget_dflt_process,iget_utk_netw,iget_x500_subject,iget_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ipcget"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ipcget"}=0;
#Table:jobinit
#delete all rows from the jobinit table
$dbh->do("delete from jobinit");
#Define the column names for the jobinit table to Perl
my $init_event_type;
my $init_event_qual;
my $init_time_written;
my $init_date_written;
my $init_system_smfid;
my $init_violation;
my $init_user_ndfnd;
my $init_user_warning;
my $init_evt_user_id;
my $init_evt_grp_id;
my $init_auth_normal;
my $init_auth_special;
my $init_auth_oper;
my $init_auth_audit;
my $init_auth_exit;
my $init_auth_failsft;
my $init_auth_bypass;
my $init_auth_trusted;
my $init_log_class;
my $init_log_user;
my $init_log_special;
my $init_log_access;
my $init_log_racinit;
my $init_log_always;
my $init_log_cmdviol;
my $init_log_global;
my $init_term_level;
my $init_backout_fail;
my $init_prof_same;
my $init_term;
my $init_job_name;
my $init_read_time;
my $init_read_date;
my $init_smf_user_id;
my $init_log_level;
my $init_log_vmevent;
my $init_log_logopt;
my $init_log_secl;
my $init_log_compatm;
my $init_log_applaud;
my $init_log_nonomvs;
my $init_log_omvsnprv;
my $init_auth_omvssu;
my $init_auth_omvssys;
my $init_usr_secl;
my $init_racf_version;
my $init_appl;
my $init_logstr;
my $init_bad_jobname;
my $init_user_name;
my $init_utk_encr;
my $init_utk_pre19;
my $init_utk_verprof;
my $init_utk_njeunusr;
my $init_utk_logusr;
my $init_utk_special;
my $init_utk_default;
my $init_utk_unknusr;
my $init_utk_error;
my $init_utk_trusted;
my $init_utk_sesstype;
my $init_utk_surrogat;
my $init_utk_remote;
my $init_utk_priv;
my $init_utk_secl;
my $init_utk_execnode;
my $init_utk_suser_id;
my $init_utk_snode;
my $init_utk_sgrp_id;
my $init_utk_spoe;
my $init_utk_spclass;
my $init_utk_user_id;
my $init_utk_grp_id;
my $init_utk_dft_grp;
my $init_utk_dft_secl;
my $init_appc_link;
my $init_utk_netw;
my $init_res_name;
my $init_class;
my $init_x500_subject;
my $init_x500_issuer;
#Create and prepare the INSERT statement for jobinit
$statement="INSERT INTO jobinit (init_event_type,init_event_qual,init_time_written,init_date_written,init_system_smfid,init_violation,init_user_ndfnd,init_user_warning,init_evt_user_id,init_evt_grp_id,init_auth_normal,init_auth_special,init_auth_oper,init_auth_audit,init_auth_exit,init_auth_failsft,init_auth_bypass,init_auth_trusted,init_log_class,init_log_user,init_log_special,init_log_access,init_log_racinit,init_log_always,init_log_cmdviol,init_log_global,init_term_level,init_backout_fail,init_prof_same,init_term,init_job_name,init_read_time,init_read_date,init_smf_user_id,init_log_level,init_log_vmevent,init_log_logopt,init_log_secl,init_log_compatm,init_log_applaud,init_log_nonomvs,init_log_omvsnprv,init_auth_omvssu,init_auth_omvssys,init_usr_secl,init_racf_version,init_appl,init_logstr,init_bad_jobname,init_user_name,init_utk_encr,init_utk_pre19,init_utk_verprof,init_utk_njeunusr,init_utk_logusr,init_utk_special,init_utk_default,init_utk_unknusr,init_utk_error,init_utk_trusted,init_utk_sesstype,init_utk_surrogat,init_utk_remote,init_utk_priv,init_utk_secl,init_utk_execnode,init_utk_suser_id,init_utk_snode,init_utk_sgrp_id,init_utk_spoe,init_utk_spclass,init_utk_user_id,init_utk_grp_id,init_utk_dft_grp,init_utk_dft_secl,init_appc_link,init_utk_netw,init_res_name,init_class,init_x500_subject,init_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"jobinit"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"jobinit"}=0;
#Table:kill
#delete all rows from the kill table
$dbh->do("delete from kill");
#Define the column names for the kill table to Perl
my $kill_event_type;
my $kill_event_qual;
my $kill_time_written;
my $kill_date_written;
my $kill_system_smfid;
my $kill_violation;
my $kill_user_ndfnd;
my $kill_user_warning;
my $kill_evt_user_id;
my $kill_evt_grp_id;
my $kill_auth_normal;
my $kill_auth_special;
my $kill_auth_oper;
my $kill_auth_audit;
my $kill_auth_exit;
my $kill_auth_failsft;
my $kill_auth_bypass;
my $kill_auth_trusted;
my $kill_log_class;
my $kill_log_user;
my $kill_log_special;
my $kill_log_access;
my $kill_log_racinit;
my $kill_log_always;
my $kill_log_cmdviol;
my $kill_log_global;
my $kill_term_level;
my $kill_backout_fail;
my $kill_prof_same;
my $kill_term;
my $kill_job_name;
my $kill_read_time;
my $kill_read_date;
my $kill_smf_user_id;
my $kill_log_level;
my $kill_log_vmevent;
my $kill_log_logopt;
my $kill_log_secl;
my $kill_log_compatm;
my $kill_log_applaud;
my $kill_log_nonomvs;
my $kill_log_omvsnprv;
my $kill_auth_omvssu;
my $kill_auth_omvssys;
my $kill_usr_secl;
my $kill_racf_version;
my $kill_class;
my $kill_user_name;
my $kill_utk_encr;
my $kill_utk_pre19;
my $kill_utk_verprof;
my $kill_utk_njeunusr;
my $kill_utk_logusr;
my $kill_utk_special;
my $kill_utk_default;
my $kill_utk_unknusr;
my $kill_utk_error;
my $kill_utk_trusted;
my $kill_utk_sesstype;
my $kill_utk_surrogat;
my $kill_utk_remote;
my $kill_utk_priv;
my $kill_utk_secl;
my $kill_utk_execnode;
my $kill_utk_suser_id;
my $kill_utk_snode;
my $kill_utk_sgrp_id;
my $kill_utk_spoe;
my $kill_utk_spclass;
my $kill_utk_user_id;
my $kill_utk_grp_id;
my $kill_utk_dft_grp;
my $kill_utk_dft_secl;
my $kill_appc_link;
my $kill_audit_code;
my $kill_old_real_uid;
my $kill_old_eff_uid;
my $kill_old_saved_uid;
my $kill_old_real_gid;
my $kill_old_eff_gid;
my $kill_old_saved_gid;
my $kill_tgt_real_uid;
my $kill_tgt_eff_uid;
my $kill_tgt_sav_uid;
my $kill_tgt_pid;
my $kill_signal_code;
my $kill_dflt_process;
my $kill_utk_netw;
my $kill_x500_subject;
my $kill_x500_issuer;
#Create and prepare the INSERT statement for kill
$statement="INSERT INTO kill (kill_event_type,kill_event_qual,kill_time_written,kill_date_written,kill_system_smfid,kill_violation,kill_user_ndfnd,kill_user_warning,kill_evt_user_id,kill_evt_grp_id,kill_auth_normal,kill_auth_special,kill_auth_oper,kill_auth_audit,kill_auth_exit,kill_auth_failsft,kill_auth_bypass,kill_auth_trusted,kill_log_class,kill_log_user,kill_log_special,kill_log_access,kill_log_racinit,kill_log_always,kill_log_cmdviol,kill_log_global,kill_term_level,kill_backout_fail,kill_prof_same,kill_term,kill_job_name,kill_read_time,kill_read_date,kill_smf_user_id,kill_log_level,kill_log_vmevent,kill_log_logopt,kill_log_secl,kill_log_compatm,kill_log_applaud,kill_log_nonomvs,kill_log_omvsnprv,kill_auth_omvssu,kill_auth_omvssys,kill_usr_secl,kill_racf_version,kill_class,kill_user_name,kill_utk_encr,kill_utk_pre19,kill_utk_verprof,kill_utk_njeunusr,kill_utk_logusr,kill_utk_special,kill_utk_default,kill_utk_unknusr,kill_utk_error,kill_utk_trusted,kill_utk_sesstype,kill_utk_surrogat,kill_utk_remote,kill_utk_priv,kill_utk_secl,kill_utk_execnode,kill_utk_suser_id,kill_utk_snode,kill_utk_sgrp_id,kill_utk_spoe,kill_utk_spclass,kill_utk_user_id,kill_utk_grp_id,kill_utk_dft_grp,kill_utk_dft_secl,kill_appc_link,kill_audit_code,kill_old_real_uid,kill_old_eff_uid,kill_old_saved_uid,kill_old_real_gid,kill_old_eff_gid,kill_old_saved_gid,kill_tgt_real_uid,kill_tgt_eff_uid,kill_tgt_sav_uid,kill_tgt_pid,kill_signal_code,kill_dflt_process,kill_utk_netw,kill_x500_subject,kill_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"kill"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"kill"}=0;
#Table:kticket
#delete all rows from the kticket table
$dbh->do("delete from kticket");
#Define the column names for the kticket table to Perl
my $ktkt_event_type;
my $ktkt_event_qual;
my $ktkt_time_written;
my $ktkt_date_written;
my $ktkt_system_smfid;
my $ktkt_violation;
my $ktkt_user_ndfnd;
my $ktkt_user_warning;
my $ktkt_evt_user_id;
my $ktkt_evt_grp_id;
my $ktkt_auth_normal;
my $ktkt_auth_special;
my $ktkt_auth_oper;
my $ktkt_auth_audit;
my $ktkt_auth_exit;
my $ktkt_auth_failsft;
my $ktkt_auth_bypass;
my $ktkt_auth_trusted;
my $ktkt_log_class;
my $ktkt_log_user;
my $ktkt_log_special;
my $ktkt_log_access;
my $ktkt_log_racinit;
my $ktkt_log_always;
my $ktkt_log_cmdviol;
my $ktkt_log_global;
my $ktkt_term_level;
my $ktkt_backout_fail;
my $ktkt_prof_same;
my $ktkt_term;
my $ktkt_job_name;
my $ktkt_read_time;
my $ktkt_read_date;
my $ktkt_smf_user_id;
my $ktkt_log_level;
my $ktkt_log_vmevent;
my $ktkt_log_logopt;
my $ktkt_log_secl;
my $ktkt_log_compatm;
my $ktkt_log_applaud;
my $ktkt_log_nonomvs;
my $ktkt_log_omvsnprv;
my $ktkt_auth_omvssu;
my $ktkt_auth_omvssys;
my $ktkt_usr_secl;
my $ktkt_racf_version;
my $ktkt_principal;
my $ktkt_login_source;
my $ktkt_kdc_stat_code;
#Create and prepare the INSERT statement for kticket
$statement="INSERT INTO kticket (ktkt_event_type,ktkt_event_qual,ktkt_time_written,ktkt_date_written,ktkt_system_smfid,ktkt_violation,ktkt_user_ndfnd,ktkt_user_warning,ktkt_evt_user_id,ktkt_evt_grp_id,ktkt_auth_normal,ktkt_auth_special,ktkt_auth_oper,ktkt_auth_audit,ktkt_auth_exit,ktkt_auth_failsft,ktkt_auth_bypass,ktkt_auth_trusted,ktkt_log_class,ktkt_log_user,ktkt_log_special,ktkt_log_access,ktkt_log_racinit,ktkt_log_always,ktkt_log_cmdviol,ktkt_log_global,ktkt_term_level,ktkt_backout_fail,ktkt_prof_same,ktkt_term,ktkt_job_name,ktkt_read_time,ktkt_read_date,ktkt_smf_user_id,ktkt_log_level,ktkt_log_vmevent,ktkt_log_logopt,ktkt_log_secl,ktkt_log_compatm,ktkt_log_applaud,ktkt_log_nonomvs,ktkt_log_omvsnprv,ktkt_auth_omvssu,ktkt_auth_omvssys,ktkt_usr_secl,ktkt_racf_version,ktkt_principal,ktkt_login_source,ktkt_kdc_stat_code) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"kticket"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"kticket"}=0;
#Table:link
#delete all rows from the link table
$dbh->do("delete from link");
#Define the column names for the link table to Perl
my $link_event_type;
my $link_event_qual;
my $link_time_written;
my $link_date_written;
my $link_system_smfid;
my $link_violation;
my $link_user_ndfnd;
my $link_user_warning;
my $link_evt_user_id;
my $link_evt_grp_id;
my $link_auth_normal;
my $link_auth_special;
my $link_auth_oper;
my $link_auth_audit;
my $link_auth_exit;
my $link_auth_failsft;
my $link_auth_bypass;
my $link_auth_trusted;
my $link_log_class;
my $link_log_user;
my $link_log_special;
my $link_log_access;
my $link_log_racinit;
my $link_log_always;
my $link_log_cmdviol;
my $link_log_global;
my $link_term_level;
my $link_backout_fail;
my $link_prof_same;
my $link_term;
my $link_job_name;
my $link_read_time;
my $link_read_date;
my $link_smf_user_id;
my $link_log_level;
my $link_log_vmevent;
my $link_log_logopt;
my $link_log_secl;
my $link_log_compatm;
my $link_log_applaud;
my $link_log_nonomvs;
my $link_log_omvsnprv;
my $link_auth_omvssu;
my $link_auth_omvssys;
my $link_usr_secl;
my $link_racf_version;
my $link_class;
my $link_user_name;
my $link_utk_encr;
my $link_utk_pre19;
my $link_utk_verprof;
my $link_utk_njeunusr;
my $link_utk_logusr;
my $link_utk_special;
my $link_utk_default;
my $link_utk_unknusr;
my $link_utk_error;
my $link_utk_trusted;
my $link_utk_sesstype;
my $link_utk_surrogat;
my $link_utk_remote;
my $link_utk_priv;
my $link_utk_secl;
my $link_utk_execnode;
my $link_utk_suser_id;
my $link_utk_snode;
my $link_utk_sgrp_id;
my $link_utk_spoe;
my $link_utk_spclass;
my $link_utk_user_id;
my $link_utk_grp_id;
my $link_utk_dft_grp;
my $link_utk_dft_secl;
my $link_appc_link;
my $link_audit_code;
my $link_old_real_uid;
my $link_old_eff_uid;
my $link_old_saved_uid;
my $link_old_real_gid;
my $link_old_eff_gid;
my $link_old_saved_gid;
my $link_path_name;
my $link_file_id;
my $link_file_own_uid;
my $link_file_own_gid;
my $link_request_path2;
my $link_path_type;
my $link_filepool;
my $link_filespace;
my $link_inode;
my $link_scid;
my $link_dce_link;
my $link_auth_type;
my $link_dflt_process;
my $link_utk_netw;
my $link_x500_subject;
my $link_x500_issuer;
#Create and prepare the INSERT statement for link
$statement="INSERT INTO link (link_event_type,link_event_qual,link_time_written,link_date_written,link_system_smfid,link_violation,link_user_ndfnd,link_user_warning,link_evt_user_id,link_evt_grp_id,link_auth_normal,link_auth_special,link_auth_oper,link_auth_audit,link_auth_exit,link_auth_failsft,link_auth_bypass,link_auth_trusted,link_log_class,link_log_user,link_log_special,link_log_access,link_log_racinit,link_log_always,link_log_cmdviol,link_log_global,link_term_level,link_backout_fail,link_prof_same,link_term,link_job_name,link_read_time,link_read_date,link_smf_user_id,link_log_level,link_log_vmevent,link_log_logopt,link_log_secl,link_log_compatm,link_log_applaud,link_log_nonomvs,link_log_omvsnprv,link_auth_omvssu,link_auth_omvssys,link_usr_secl,link_racf_version,link_class,link_user_name,link_utk_encr,link_utk_pre19,link_utk_verprof,link_utk_njeunusr,link_utk_logusr,link_utk_special,link_utk_default,link_utk_unknusr,link_utk_error,link_utk_trusted,link_utk_sesstype,link_utk_surrogat,link_utk_remote,link_utk_priv,link_utk_secl,link_utk_execnode,link_utk_suser_id,link_utk_snode,link_utk_sgrp_id,link_utk_spoe,link_utk_spclass,link_utk_user_id,link_utk_grp_id,link_utk_dft_grp,link_utk_dft_secl,link_appc_link,link_audit_code,link_old_real_uid,link_old_eff_uid,link_old_saved_uid,link_old_real_gid,link_old_eff_gid,link_old_saved_gid,link_path_name,link_file_id,link_file_own_uid,link_file_own_gid,link_request_path2,link_path_type,link_filepool,link_filespace,link_inode,link_scid,link_dce_link,link_auth_type,link_dflt_process,link_utk_netw,link_x500_subject,link_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"link"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"link"}=0;
#Table:mkdir
#delete all rows from the mkdir table
$dbh->do("delete from mkdir");
#Define the column names for the mkdir table to Perl
my $mdir_event_type;
my $mdir_event_qual;
my $mdir_time_written;
my $mdir_date_written;
my $mdir_system_smfid;
my $mdir_violation;
my $mdir_user_ndfnd;
my $mdir_user_warning;
my $mdir_evt_user_id;
my $mdir_evt_grp_id;
my $mdir_auth_normal;
my $mdir_auth_special;
my $mdir_auth_oper;
my $mdir_auth_audit;
my $mdir_auth_exit;
my $mdir_auth_failsft;
my $mdir_auth_bypass;
my $mdir_auth_trusted;
my $mdir_log_class;
my $mdir_log_user;
my $mdir_log_special;
my $mdir_log_access;
my $mdir_log_racinit;
my $mdir_log_always;
my $mdir_log_cmdviol;
my $mdir_log_global;
my $mdir_term_level;
my $mdir_backout_fail;
my $mdir_prof_same;
my $mdir_term;
my $mdir_job_name;
my $mdir_read_time;
my $mdir_read_date;
my $mdir_smf_user_id;
my $mdir_log_level;
my $mdir_log_vmevent;
my $mdir_log_logopt;
my $mdir_log_secl;
my $mdir_log_compatm;
my $mdir_log_applaud;
my $mdir_log_nonomvs;
my $mdir_log_omvsnprv;
my $mdir_auth_omvssu;
my $mdir_auth_omvssys;
my $mdir_usr_secl;
my $mdir_racf_version;
my $mdir_class;
my $mdir_user_name;
my $mdir_utk_encr;
my $mdir_utk_pre19;
my $mdir_utk_verprof;
my $mdir_utk_njeunusr;
my $mdir_utk_logusr;
my $mdir_utk_special;
my $mdir_utk_default;
my $mdir_utk_unknusr;
my $mdir_utk_error;
my $mdir_utk_trusted;
my $mdir_utk_sesstype;
my $mdir_utk_surrogat;
my $mdir_utk_remote;
my $mdir_utk_priv;
my $mdir_utk_secl;
my $mdir_utk_execnode;
my $mdir_utk_suser_id;
my $mdir_utk_snode;
my $mdir_utk_sgrp_id;
my $mdir_utk_spoe;
my $mdir_utk_spclass;
my $mdir_utk_user_id;
my $mdir_utk_grp_id;
my $mdir_utk_dft_grp;
my $mdir_utk_dft_secl;
my $mdir_appc_link;
my $mdir_audit_code;
my $mdir_old_real_uid;
my $mdir_old_eff_uid;
my $mdir_old_saved_uid;
my $mdir_old_real_gid;
my $mdir_old_eff_gid;
my $mdir_old_saved_gid;
my $mdir_path_name;
my $mdir_file_id;
my $mdir_file_own_uid;
my $mdir_file_own_gid;
my $mdir_old_s_isgid;
my $mdir_old_s_isuid;
my $mdir_old_s_isvtx;
my $mdir_old_own_read;
my $mdir_old_own_write;
my $mdir_old_own_exec;
my $mdir_old_grp_read;
my $mdir_old_grp_write;
my $mdir_old_grp_exec;
my $mdir_old_oth_read;
my $mdir_old_oth_write;
my $mdir_old_oth_exec;
my $mdir_new_s_isgid;
my $mdir_new_s_isuid;
my $mdir_new_s_isvtx;
my $mdir_new_own_read;
my $mdir_new_own_write;
my $mdir_new_own_exec;
my $mdir_new_grp_read;
my $mdir_new_grp_write;
my $mdir_new_grp_exec;
my $mdir_new_oth_read;
my $mdir_new_oth_write;
my $mdir_new_oth_exec;
my $mdir_unew_read;
my $mdir_unew_write;
my $mdir_unew_exec;
my $mdir_anew_read;
my $mdir_anew_write;
my $mdir_anew_exec;
my $mdir_req_s_isgid;
my $mdir_req_s_isuid;
my $mdir_req_s_isvtx;
my $mdir_req_own_read;
my $mdir_req_own_write;
my $mdir_req_own_exec;
my $mdir_req_grp_read;
my $mdir_req_grp_write;
my $mdir_req_grp_exec;
my $mdir_req_oth_read;
my $mdir_req_oth_write;
my $mdir_req_oth_exec;
my $mdir_filepool;
my $mdir_filespace;
my $mdir_inode;
my $mdir_scid;
my $mdir_dflt_process;
my $mdir_utk_netw;
my $mdir_x500_subject;
my $mdir_x500_issuer;
#Create and prepare the INSERT statement for mkdir
$statement="INSERT INTO mkdir (mdir_event_type,mdir_event_qual,mdir_time_written,mdir_date_written,mdir_system_smfid,mdir_violation,mdir_user_ndfnd,mdir_user_warning,mdir_evt_user_id,mdir_evt_grp_id,mdir_auth_normal,mdir_auth_special,mdir_auth_oper,mdir_auth_audit,mdir_auth_exit,mdir_auth_failsft,mdir_auth_bypass,mdir_auth_trusted,mdir_log_class,mdir_log_user,mdir_log_special,mdir_log_access,mdir_log_racinit,mdir_log_always,mdir_log_cmdviol,mdir_log_global,mdir_term_level,mdir_backout_fail,mdir_prof_same,mdir_term,mdir_job_name,mdir_read_time,mdir_read_date,mdir_smf_user_id,mdir_log_level,mdir_log_vmevent,mdir_log_logopt,mdir_log_secl,mdir_log_compatm,mdir_log_applaud,mdir_log_nonomvs,mdir_log_omvsnprv,mdir_auth_omvssu,mdir_auth_omvssys,mdir_usr_secl,mdir_racf_version,mdir_class,mdir_user_name,mdir_utk_encr,mdir_utk_pre19,mdir_utk_verprof,mdir_utk_njeunusr,mdir_utk_logusr,mdir_utk_special,mdir_utk_default,mdir_utk_unknusr,mdir_utk_error,mdir_utk_trusted,mdir_utk_sesstype,mdir_utk_surrogat,mdir_utk_remote,mdir_utk_priv,mdir_utk_secl,mdir_utk_execnode,mdir_utk_suser_id,mdir_utk_snode,mdir_utk_sgrp_id,mdir_utk_spoe,mdir_utk_spclass,mdir_utk_user_id,mdir_utk_grp_id,mdir_utk_dft_grp,mdir_utk_dft_secl,mdir_appc_link,mdir_audit_code,mdir_old_real_uid,mdir_old_eff_uid,mdir_old_saved_uid,mdir_old_real_gid,mdir_old_eff_gid,mdir_old_saved_gid,mdir_path_name,mdir_file_id,mdir_file_own_uid,mdir_file_own_gid,mdir_old_s_isgid,mdir_old_s_isuid,mdir_old_s_isvtx,mdir_old_own_read,mdir_old_own_write,mdir_old_own_exec,mdir_old_grp_read,mdir_old_grp_write,mdir_old_grp_exec,mdir_old_oth_read,mdir_old_oth_write,mdir_old_oth_exec,mdir_new_s_isgid,mdir_new_s_isuid,mdir_new_s_isvtx,mdir_new_own_read,mdir_new_own_write,mdir_new_own_exec,mdir_new_grp_read,mdir_new_grp_write,mdir_new_grp_exec,mdir_new_oth_read,mdir_new_oth_write,mdir_new_oth_exec,mdir_unew_read,mdir_unew_write,mdir_unew_exec,mdir_anew_read,mdir_anew_write,mdir_anew_exec,mdir_req_s_isgid,mdir_req_s_isuid,mdir_req_s_isvtx,mdir_req_own_read,mdir_req_own_write,mdir_req_own_exec,mdir_req_grp_read,mdir_req_grp_write,mdir_req_grp_exec,mdir_req_oth_read,mdir_req_oth_write,mdir_req_oth_exec,mdir_filepool,mdir_filespace,mdir_inode,mdir_scid,mdir_dflt_process,mdir_utk_netw,mdir_x500_subject,mdir_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"mkdir"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"mkdir"}=0;
#Table:mknod
#delete all rows from the mknod table
$dbh->do("delete from mknod");
#Define the column names for the mknod table to Perl
my $mnod_event_type;
my $mnod_event_qual;
my $mnod_time_written;
my $mnod_date_written;
my $mnod_system_smfid;
my $mnod_violation;
my $mnod_user_ndfnd;
my $mnod_user_warning;
my $mnod_evt_user_id;
my $mnod_evt_grp_id;
my $mnod_auth_normal;
my $mnod_auth_special;
my $mnod_auth_oper;
my $mnod_auth_audit;
my $mnod_auth_exit;
my $mnod_auth_failsft;
my $mnod_auth_bypass;
my $mnod_auth_trusted;
my $mnod_log_class;
my $mnod_log_user;
my $mnod_log_special;
my $mnod_log_access;
my $mnod_log_racinit;
my $mnod_log_always;
my $mnod_log_cmdviol;
my $mnod_log_global;
my $mnod_term_level;
my $mnod_backout_fail;
my $mnod_prof_same;
my $mnod_term;
my $mnod_job_name;
my $mnod_read_time;
my $mnod_read_date;
my $mnod_smf_user_id;
my $mnod_log_level;
my $mnod_log_vmevent;
my $mnod_log_logopt;
my $mnod_log_secl;
my $mnod_log_compatm;
my $mnod_log_applaud;
my $mnod_log_nonomvs;
my $mnod_log_omvsnprv;
my $mnod_auth_omvssu;
my $mnod_auth_omvssys;
my $mnod_usr_secl;
my $mnod_racf_version;
my $mnod_class;
my $mnod_user_name;
my $mnod_utk_encr;
my $mnod_utk_pre19;
my $mnod_utk_verprof;
my $mnod_utk_njeunusr;
my $mnod_utk_logusr;
my $mnod_utk_special;
my $mnod_utk_default;
my $mnod_utk_unknusr;
my $mnod_utk_error;
my $mnod_utk_trusted;
my $mnod_utk_sesstype;
my $mnod_utk_surrogat;
my $mnod_utk_remote;
my $mnod_utk_priv;
my $mnod_utk_secl;
my $mnod_utk_execnode;
my $mnod_utk_suser_id;
my $mnod_utk_snode;
my $mnod_utk_sgrp_id;
my $mnod_utk_spoe;
my $mnod_utk_spclass;
my $mnod_utk_user_id;
my $mnod_utk_grp_id;
my $mnod_utk_dft_grp;
my $mnod_utk_dft_secl;
my $mnod_appc_link;
my $mnod_audit_code;
my $mnod_old_real_uid;
my $mnod_old_eff_uid;
my $mnod_old_saved_uid;
my $mnod_old_real_gid;
my $mnod_old_eff_gid;
my $mnod_old_saved_gid;
my $mnod_path_name;
my $mnod_file_id;
my $mnod_file_own_uid;
my $mnod_file_own_gid;
my $mnod_old_s_isgid;
my $mnod_old_s_isuid;
my $mnod_old_s_isvtx;
my $mnod_old_own_read;
my $mnod_old_own_write;
my $mnod_old_own_exec;
my $mnod_old_grp_read;
my $mnod_old_grp_write;
my $mnod_old_grp_exec;
my $mnod_old_oth_read;
my $mnod_old_oth_write;
my $mnod_old_oth_exec;
my $mnod_new_s_isgid;
my $mnod_new_s_isuid;
my $mnod_new_s_isvtx;
my $mnod_new_own_read;
my $mnod_new_own_write;
my $mnod_new_own_exec;
my $mnod_new_grp_read;
my $mnod_new_grp_write;
my $mnod_new_grp_exec;
my $mnod_new_oth_read;
my $mnod_new_oth_write;
my $mnod_new_oth_exec;
my $mnod_unew_read;
my $mnod_unew_write;
my $mnod_unew_exec;
my $mnod_anew_read;
my $mnod_anew_write;
my $mnod_anew_exec;
my $mnod_req_s_isgid;
my $mnod_req_s_isuid;
my $mnod_req_s_isvtx;
my $mnod_req_own_read;
my $mnod_req_own_write;
my $mnod_req_own_exec;
my $mnod_req_grp_read;
my $mnod_req_grp_write;
my $mnod_req_grp_exec;
my $mnod_req_oth_read;
my $mnod_req_oth_write;
my $mnod_req_oth_exec;
my $mnod_filepool;
my $mnod_filespace;
my $mnod_inode;
my $mnod_scid;
my $mnod_dflt_process;
my $mnod_utk_netw;
my $mnod_x500_subject;
my $mnod_x500_issuer;
#Create and prepare the INSERT statement for mknod
$statement="INSERT INTO mknod (mnod_event_type,mnod_event_qual,mnod_time_written,mnod_date_written,mnod_system_smfid,mnod_violation,mnod_user_ndfnd,mnod_user_warning,mnod_evt_user_id,mnod_evt_grp_id,mnod_auth_normal,mnod_auth_special,mnod_auth_oper,mnod_auth_audit,mnod_auth_exit,mnod_auth_failsft,mnod_auth_bypass,mnod_auth_trusted,mnod_log_class,mnod_log_user,mnod_log_special,mnod_log_access,mnod_log_racinit,mnod_log_always,mnod_log_cmdviol,mnod_log_global,mnod_term_level,mnod_backout_fail,mnod_prof_same,mnod_term,mnod_job_name,mnod_read_time,mnod_read_date,mnod_smf_user_id,mnod_log_level,mnod_log_vmevent,mnod_log_logopt,mnod_log_secl,mnod_log_compatm,mnod_log_applaud,mnod_log_nonomvs,mnod_log_omvsnprv,mnod_auth_omvssu,mnod_auth_omvssys,mnod_usr_secl,mnod_racf_version,mnod_class,mnod_user_name,mnod_utk_encr,mnod_utk_pre19,mnod_utk_verprof,mnod_utk_njeunusr,mnod_utk_logusr,mnod_utk_special,mnod_utk_default,mnod_utk_unknusr,mnod_utk_error,mnod_utk_trusted,mnod_utk_sesstype,mnod_utk_surrogat,mnod_utk_remote,mnod_utk_priv,mnod_utk_secl,mnod_utk_execnode,mnod_utk_suser_id,mnod_utk_snode,mnod_utk_sgrp_id,mnod_utk_spoe,mnod_utk_spclass,mnod_utk_user_id,mnod_utk_grp_id,mnod_utk_dft_grp,mnod_utk_dft_secl,mnod_appc_link,mnod_audit_code,mnod_old_real_uid,mnod_old_eff_uid,mnod_old_saved_uid,mnod_old_real_gid,mnod_old_eff_gid,mnod_old_saved_gid,mnod_path_name,mnod_file_id,mnod_file_own_uid,mnod_file_own_gid,mnod_old_s_isgid,mnod_old_s_isuid,mnod_old_s_isvtx,mnod_old_own_read,mnod_old_own_write,mnod_old_own_exec,mnod_old_grp_read,mnod_old_grp_write,mnod_old_grp_exec,mnod_old_oth_read,mnod_old_oth_write,mnod_old_oth_exec,mnod_new_s_isgid,mnod_new_s_isuid,mnod_new_s_isvtx,mnod_new_own_read,mnod_new_own_write,mnod_new_own_exec,mnod_new_grp_read,mnod_new_grp_write,mnod_new_grp_exec,mnod_new_oth_read,mnod_new_oth_write,mnod_new_oth_exec,mnod_unew_read,mnod_unew_write,mnod_unew_exec,mnod_anew_read,mnod_anew_write,mnod_anew_exec,mnod_req_s_isgid,mnod_req_s_isuid,mnod_req_s_isvtx,mnod_req_own_read,mnod_req_own_write,mnod_req_own_exec,mnod_req_grp_read,mnod_req_grp_write,mnod_req_grp_exec,mnod_req_oth_read,mnod_req_oth_write,mnod_req_oth_exec,mnod_filepool,mnod_filespace,mnod_inode,mnod_scid,mnod_dflt_process,mnod_utk_netw,mnod_x500_subject,mnod_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"mknod"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"mknod"}=0;
#Table:mntfsys
#delete all rows from the mntfsys table
$dbh->do("delete from mntfsys");
#Define the column names for the mntfsys table to Perl
my $mfs_event_type;
my $mfs_event_qual;
my $mfs_time_written;
my $mfs_date_written;
my $mfs_system_smfid;
my $mfs_violation;
my $mfs_user_ndfnd;
my $mfs_user_warning;
my $mfs_evt_user_id;
my $mfs_evt_grp_id;
my $mfs_auth_normal;
my $mfs_auth_special;
my $mfs_auth_oper;
my $mfs_auth_audit;
my $mfs_auth_exit;
my $mfs_auth_failsft;
my $mfs_auth_bypass;
my $mfs_auth_trusted;
my $mfs_log_class;
my $mfs_log_user;
my $mfs_log_special;
my $mfs_log_access;
my $mfs_log_racinit;
my $mfs_log_always;
my $mfs_log_cmdviol;
my $mfs_log_global;
my $mfs_term_level;
my $mfs_backout_fail;
my $mfs_prof_same;
my $mfs_term;
my $mfs_job_name;
my $mfs_read_time;
my $mfs_read_date;
my $mfs_smf_user_id;
my $mfs_log_level;
my $mfs_log_vmevent;
my $mfs_log_logopt;
my $mfs_log_secl;
my $mfs_log_compatm;
my $mfs_log_applaud;
my $mfs_log_nonomvs;
my $mfs_log_omvsnprv;
my $mfs_auth_omvssu;
my $mfs_auth_omvssys;
my $mfs_usr_secl;
my $mfs_racf_version;
my $mfs_class;
my $mfs_user_name;
my $mfs_utk_encr;
my $mfs_utk_pre19;
my $mfs_utk_verprof;
my $mfs_utk_njeunusr;
my $mfs_utk_logusr;
my $mfs_utk_special;
my $mfs_utk_default;
my $mfs_utk_unknusr;
my $mfs_utk_error;
my $mfs_utk_trusted;
my $mfs_utk_sesstype;
my $mfs_utk_surrogat;
my $mfs_utk_remote;
my $mfs_utk_priv;
my $mfs_utk_secl;
my $mfs_utk_execnode;
my $mfs_utk_suser_id;
my $mfs_utk_snode;
my $mfs_utk_sgrp_id;
my $mfs_utk_spoe;
my $mfs_utk_spclass;
my $mfs_utk_user_id;
my $mfs_utk_grp_id;
my $mfs_utk_dft_grp;
my $mfs_utk_dft_secl;
my $mfs_appc_link;
my $mfs_audit_code;
my $mfs_old_real_uid;
my $mfs_old_eff_uid;
my $mfs_old_saved_uid;
my $mfs_old_real_gid;
my $mfs_old_eff_gid;
my $mfs_old_saved_gid;
my $mfs_path_name;
my $mfs_file_id;
my $mfs_file_own_uid;
my $mfs_file_own_gid;
my $mfs_hfs_ds_name;
my $mfs_dce_link;
my $mfs_auth_type;
my $mfs_dflt_process;
my $mfs_utk_netw;
my $mfs_x500_subject;
my $mfs_x500_issuer;
#Create and prepare the INSERT statement for mntfsys
$statement="INSERT INTO mntfsys (mfs_event_type,mfs_event_qual,mfs_time_written,mfs_date_written,mfs_system_smfid,mfs_violation,mfs_user_ndfnd,mfs_user_warning,mfs_evt_user_id,mfs_evt_grp_id,mfs_auth_normal,mfs_auth_special,mfs_auth_oper,mfs_auth_audit,mfs_auth_exit,mfs_auth_failsft,mfs_auth_bypass,mfs_auth_trusted,mfs_log_class,mfs_log_user,mfs_log_special,mfs_log_access,mfs_log_racinit,mfs_log_always,mfs_log_cmdviol,mfs_log_global,mfs_term_level,mfs_backout_fail,mfs_prof_same,mfs_term,mfs_job_name,mfs_read_time,mfs_read_date,mfs_smf_user_id,mfs_log_level,mfs_log_vmevent,mfs_log_logopt,mfs_log_secl,mfs_log_compatm,mfs_log_applaud,mfs_log_nonomvs,mfs_log_omvsnprv,mfs_auth_omvssu,mfs_auth_omvssys,mfs_usr_secl,mfs_racf_version,mfs_class,mfs_user_name,mfs_utk_encr,mfs_utk_pre19,mfs_utk_verprof,mfs_utk_njeunusr,mfs_utk_logusr,mfs_utk_special,mfs_utk_default,mfs_utk_unknusr,mfs_utk_error,mfs_utk_trusted,mfs_utk_sesstype,mfs_utk_surrogat,mfs_utk_remote,mfs_utk_priv,mfs_utk_secl,mfs_utk_execnode,mfs_utk_suser_id,mfs_utk_snode,mfs_utk_sgrp_id,mfs_utk_spoe,mfs_utk_spclass,mfs_utk_user_id,mfs_utk_grp_id,mfs_utk_dft_grp,mfs_utk_dft_secl,mfs_appc_link,mfs_audit_code,mfs_old_real_uid,mfs_old_eff_uid,mfs_old_saved_uid,mfs_old_real_gid,mfs_old_eff_gid,mfs_old_saved_gid,mfs_path_name,mfs_file_id,mfs_file_own_uid,mfs_file_own_gid,mfs_hfs_ds_name,mfs_dce_link,mfs_auth_type,mfs_dflt_process,mfs_utk_netw,mfs_x500_subject,mfs_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"mntfsys"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"mntfsys"}=0;
#Table:openfile
#delete all rows from the openfile table
$dbh->do("delete from openfile");
#Define the column names for the openfile table to Perl
my $open_event_type;
my $open_event_qual;
my $open_time_written;
my $open_date_written;
my $open_system_smfid;
my $open_violation;
my $open_user_ndfnd;
my $open_user_warning;
my $open_evt_user_id;
my $open_evt_grp_id;
my $open_auth_normal;
my $open_auth_special;
my $open_auth_oper;
my $open_auth_audit;
my $open_auth_exit;
my $open_auth_failsft;
my $open_auth_bypass;
my $open_auth_trusted;
my $open_log_class;
my $open_log_user;
my $open_log_special;
my $open_log_access;
my $open_log_racinit;
my $open_log_always;
my $open_log_cmdviol;
my $open_log_global;
my $open_term_level;
my $open_backout_fail;
my $open_prof_same;
my $open_term;
my $open_job_name;
my $open_read_time;
my $open_read_date;
my $open_smf_user_id;
my $open_log_level;
my $open_log_vmevent;
my $open_log_logopt;
my $open_log_secl;
my $open_log_compatm;
my $open_log_applaud;
my $open_log_nonomvs;
my $open_log_omvsnprv;
my $open_auth_omvssu;
my $open_auth_omvssys;
my $open_usr_secl;
my $open_racf_version;
my $open_class;
my $open_user_name;
my $open_utk_encr;
my $open_utk_pre19;
my $open_utk_verprof;
my $open_utk_njeunusr;
my $open_utk_logusr;
my $open_utk_special;
my $open_utk_default;
my $open_utk_unknusr;
my $open_utk_error;
my $open_utk_trusted;
my $open_utk_sesstype;
my $open_utk_surrogat;
my $open_utk_remote;
my $open_utk_priv;
my $open_utk_secl;
my $open_utk_execnode;
my $open_utk_suser_id;
my $open_utk_snode;
my $open_utk_sgrp_id;
my $open_utk_spoe;
my $open_utk_spclass;
my $open_utk_user_id;
my $open_utk_grp_id;
my $open_utk_dft_grp;
my $open_utk_dft_secl;
my $open_appc_link;
my $open_audit_code;
my $open_old_real_uid;
my $open_old_eff_uid;
my $open_old_saved_uid;
my $open_old_real_gid;
my $open_old_eff_gid;
my $open_old_saved_gid;
my $open_path_name;
my $open_file_id;
my $open_file_own_uid;
my $open_file_own_gid;
my $open_old_s_isgid;
my $open_old_s_isuid;
my $open_old_s_isvtx;
my $open_old_own_read;
my $open_old_own_write;
my $open_old_own_exec;
my $open_old_grp_read;
my $open_old_grp_write;
my $open_old_grp_exec;
my $open_old_oth_read;
my $open_old_oth_write;
my $open_old_oth_exec;
my $open_new_s_isgid;
my $open_new_s_isuid;
my $open_new_s_isvtx;
my $open_new_own_read;
my $open_new_own_write;
my $open_new_own_exec;
my $open_new_grp_read;
my $open_new_grp_write;
my $open_new_grp_exec;
my $open_new_oth_read;
my $open_new_oth_write;
my $open_new_oth_exec;
my $open_unew_read;
my $open_unew_write;
my $open_unew_exec;
my $open_anew_read;
my $open_anew_write;
my $open_anew_exec;
my $open_req_s_isgid;
my $open_req_s_isuid;
my $open_req_s_isvtx;
my $open_req_own_read;
my $open_req_own_write;
my $open_req_own_exec;
my $open_req_grp_read;
my $open_req_grp_write;
my $open_req_grp_exec;
my $open_req_oth_read;
my $open_req_oth_write;
my $open_req_oth_exec;
my $open_filepool;
my $open_filespace;
my $open_inode;
my $open_scid;
my $open_dflt_process;
my $open_utk_netw;
my $open_x500_subject;
my $open_x500_issuer;
#Create and prepare the INSERT statement for openfile
$statement="INSERT INTO openfile (open_event_type,open_event_qual,open_time_written,open_date_written,open_system_smfid,open_violation,open_user_ndfnd,open_user_warning,open_evt_user_id,open_evt_grp_id,open_auth_normal,open_auth_special,open_auth_oper,open_auth_audit,open_auth_exit,open_auth_failsft,open_auth_bypass,open_auth_trusted,open_log_class,open_log_user,open_log_special,open_log_access,open_log_racinit,open_log_always,open_log_cmdviol,open_log_global,open_term_level,open_backout_fail,open_prof_same,open_term,open_job_name,open_read_time,open_read_date,open_smf_user_id,open_log_level,open_log_vmevent,open_log_logopt,open_log_secl,open_log_compatm,open_log_applaud,open_log_nonomvs,open_log_omvsnprv,open_auth_omvssu,open_auth_omvssys,open_usr_secl,open_racf_version,open_class,open_user_name,open_utk_encr,open_utk_pre19,open_utk_verprof,open_utk_njeunusr,open_utk_logusr,open_utk_special,open_utk_default,open_utk_unknusr,open_utk_error,open_utk_trusted,open_utk_sesstype,open_utk_surrogat,open_utk_remote,open_utk_priv,open_utk_secl,open_utk_execnode,open_utk_suser_id,open_utk_snode,open_utk_sgrp_id,open_utk_spoe,open_utk_spclass,open_utk_user_id,open_utk_grp_id,open_utk_dft_grp,open_utk_dft_secl,open_appc_link,open_audit_code,open_old_real_uid,open_old_eff_uid,open_old_saved_uid,open_old_real_gid,open_old_eff_gid,open_old_saved_gid,open_path_name,open_file_id,open_file_own_uid,open_file_own_gid,open_old_s_isgid,open_old_s_isuid,open_old_s_isvtx,open_old_own_read,open_old_own_write,open_old_own_exec,open_old_grp_read,open_old_grp_write,open_old_grp_exec,open_old_oth_read,open_old_oth_write,open_old_oth_exec,open_new_s_isgid,open_new_s_isuid,open_new_s_isvtx,open_new_own_read,open_new_own_write,open_new_own_exec,open_new_grp_read,open_new_grp_write,open_new_grp_exec,open_new_oth_read,open_new_oth_write,open_new_oth_exec,open_unew_read,open_unew_write,open_unew_exec,open_anew_read,open_anew_write,open_anew_exec,open_req_s_isgid,open_req_s_isuid,open_req_s_isvtx,open_req_own_read,open_req_own_write,open_req_own_exec,open_req_grp_read,open_req_grp_write,open_req_grp_exec,open_req_oth_read,open_req_oth_write,open_req_oth_exec,open_filepool,open_filespace,open_inode,open_scid,open_dflt_process,open_utk_netw,open_x500_subject,open_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"openfile"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"openfile"}=0;
#Table:openstty
#delete all rows from the openstty table
$dbh->do("delete from openstty");
#Define the column names for the openstty table to Perl
my $osty_event_type;
my $osty_event_qual;
my $osty_time_written;
my $osty_date_written;
my $osty_system_smfid;
my $osty_violation;
my $osty_user_ndfnd;
my $osty_user_warning;
my $osty_evt_user_id;
my $osty_evt_grp_id;
my $osty_auth_normal;
my $osty_auth_special;
my $osty_auth_oper;
my $osty_auth_audit;
my $osty_auth_exit;
my $osty_auth_failsft;
my $osty_auth_bypass;
my $osty_auth_trusted;
my $osty_log_class;
my $osty_log_user;
my $osty_log_special;
my $osty_log_access;
my $osty_log_racinit;
my $osty_log_always;
my $osty_log_cmdviol;
my $osty_log_global;
my $osty_term_level;
my $osty_backout_fail;
my $osty_prof_same;
my $osty_term;
my $osty_job_name;
my $osty_read_time;
my $osty_read_date;
my $osty_smf_user_id;
my $osty_log_level;
my $osty_log_vmevent;
my $osty_log_logopt;
my $osty_log_secl;
my $osty_log_compatm;
my $osty_log_applaud;
my $osty_log_nonomvs;
my $osty_log_omvsnprv;
my $osty_auth_omvssu;
my $osty_auth_omvssys;
my $osty_usr_secl;
my $osty_racf_version;
my $osty_class;
my $osty_user_name;
my $osty_utk_encr;
my $osty_utk_pre19;
my $osty_utk_verprof;
my $osty_utk_njeunusr;
my $osty_utk_logusr;
my $osty_utk_special;
my $osty_utk_default;
my $osty_utk_unknusr;
my $osty_utk_error;
my $osty_utk_trusted;
my $osty_utk_sesstype;
my $osty_utk_surrogat;
my $osty_utk_remote;
my $osty_utk_priv;
my $osty_utk_secl;
my $osty_utk_execnode;
my $osty_utk_suser_id;
my $osty_utk_snode;
my $osty_utk_sgrp_id;
my $osty_utk_spoe;
my $osty_utk_spclass;
my $osty_utk_user_id;
my $osty_utk_grp_id;
my $osty_utk_dft_grp;
my $osty_utk_dft_secl;
my $osty_appc_link;
my $osty_audit_code;
my $osty_old_real_uid;
my $osty_old_eff_uid;
my $osty_old_saved_uid;
my $osty_old_real_gid;
my $osty_old_eff_gid;
my $osty_old_saved_gid;
my $osty_tgt_real_uid;
my $osty_tgt_eff_uid;
my $osty_tgt_sav_uid;
my $osty_tgt_pid;
my $osty_dflt_process;
my $osty_utk_netw;
my $osty_x500_subject;
my $osty_x500_issuer;
#Create and prepare the INSERT statement for openstty
$statement="INSERT INTO openstty (osty_event_type,osty_event_qual,osty_time_written,osty_date_written,osty_system_smfid,osty_violation,osty_user_ndfnd,osty_user_warning,osty_evt_user_id,osty_evt_grp_id,osty_auth_normal,osty_auth_special,osty_auth_oper,osty_auth_audit,osty_auth_exit,osty_auth_failsft,osty_auth_bypass,osty_auth_trusted,osty_log_class,osty_log_user,osty_log_special,osty_log_access,osty_log_racinit,osty_log_always,osty_log_cmdviol,osty_log_global,osty_term_level,osty_backout_fail,osty_prof_same,osty_term,osty_job_name,osty_read_time,osty_read_date,osty_smf_user_id,osty_log_level,osty_log_vmevent,osty_log_logopt,osty_log_secl,osty_log_compatm,osty_log_applaud,osty_log_nonomvs,osty_log_omvsnprv,osty_auth_omvssu,osty_auth_omvssys,osty_usr_secl,osty_racf_version,osty_class,osty_user_name,osty_utk_encr,osty_utk_pre19,osty_utk_verprof,osty_utk_njeunusr,osty_utk_logusr,osty_utk_special,osty_utk_default,osty_utk_unknusr,osty_utk_error,osty_utk_trusted,osty_utk_sesstype,osty_utk_surrogat,osty_utk_remote,osty_utk_priv,osty_utk_secl,osty_utk_execnode,osty_utk_suser_id,osty_utk_snode,osty_utk_sgrp_id,osty_utk_spoe,osty_utk_spclass,osty_utk_user_id,osty_utk_grp_id,osty_utk_dft_grp,osty_utk_dft_secl,osty_appc_link,osty_audit_code,osty_old_real_uid,osty_old_eff_uid,osty_old_saved_uid,osty_old_real_gid,osty_old_eff_gid,osty_old_saved_gid,osty_tgt_real_uid,osty_tgt_eff_uid,osty_tgt_sav_uid,osty_tgt_pid,osty_dflt_process,osty_utk_netw,osty_x500_subject,osty_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"openstty"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"openstty"}=0;
#Table:password
#delete all rows from the password table
$dbh->do("delete from password");
#Define the column names for the password table to Perl
my $pwd_event_type;
my $pwd_event_qual;
my $pwd_time_written;
my $pwd_date_written;
my $pwd_system_smfid;
my $pwd_violation;
my $pwd_user_ndfnd;
my $pwd_user_warning;
my $pwd_evt_user_id;
my $pwd_evt_grp_id;
my $pwd_auth_normal;
my $pwd_auth_special;
my $pwd_auth_oper;
my $pwd_auth_audit;
my $pwd_auth_exit;
my $pwd_auth_failsft;
my $pwd_auth_bypass;
my $pwd_auth_trusted;
my $pwd_log_class;
my $pwd_log_user;
my $pwd_log_special;
my $pwd_log_access;
my $pwd_log_racinit;
my $pwd_log_always;
my $pwd_log_cmdviol;
my $pwd_log_global;
my $pwd_term_level;
my $pwd_backout_fail;
my $pwd_prof_same;
my $pwd_term;
my $pwd_job_name;
my $pwd_read_time;
my $pwd_read_date;
my $pwd_smf_user_id;
my $pwd_log_level;
my $pwd_log_vmevent;
my $pwd_log_logopt;
my $pwd_log_secl;
my $pwd_log_compatm;
my $pwd_log_applaud;
my $pwd_log_nonomvs;
my $pwd_log_omvsnprv;
my $pwd_auth_omvssu;
my $pwd_auth_omvssys;
my $pwd_usr_secl;
my $pwd_racf_version;
my $pwd_own_id;
my $pwd_user_name;
my $pwd_utk_encr;
my $pwd_utk_pre19;
my $pwd_utk_verprof;
my $pwd_utk_njeunusr;
my $pwd_utk_logusr;
my $pwd_utk_special;
my $pwd_utk_default;
my $pwd_utk_unknusr;
my $pwd_utk_error;
my $pwd_utk_trusted;
my $pwd_utk_sesstype;
my $pwd_utk_surrogat;
my $pwd_utk_remote;
my $pwd_utk_priv;
my $pwd_utk_secl;
my $pwd_utk_execnode;
my $pwd_utk_suser_id;
my $pwd_utk_snode;
my $pwd_utk_sgrp_id;
my $pwd_utk_spoe;
my $pwd_utk_spclass;
my $pwd_utk_user_id;
my $pwd_utk_grp_id;
my $pwd_utk_dft_grp;
my $pwd_utk_dft_secl;
my $pwd_appc_link;
my $pwd_specified;
my $pwd_failed;
my $pwd_ignored;
my $pwd_utk_netw;
my $pwd_x500_subject;
my $pwd_x500_issuer;
#Create and prepare the INSERT statement for password
$statement="INSERT INTO password (pwd_event_type,pwd_event_qual,pwd_time_written,pwd_date_written,pwd_system_smfid,pwd_violation,pwd_user_ndfnd,pwd_user_warning,pwd_evt_user_id,pwd_evt_grp_id,pwd_auth_normal,pwd_auth_special,pwd_auth_oper,pwd_auth_audit,pwd_auth_exit,pwd_auth_failsft,pwd_auth_bypass,pwd_auth_trusted,pwd_log_class,pwd_log_user,pwd_log_special,pwd_log_access,pwd_log_racinit,pwd_log_always,pwd_log_cmdviol,pwd_log_global,pwd_term_level,pwd_backout_fail,pwd_prof_same,pwd_term,pwd_job_name,pwd_read_time,pwd_read_date,pwd_smf_user_id,pwd_log_level,pwd_log_vmevent,pwd_log_logopt,pwd_log_secl,pwd_log_compatm,pwd_log_applaud,pwd_log_nonomvs,pwd_log_omvsnprv,pwd_auth_omvssu,pwd_auth_omvssys,pwd_usr_secl,pwd_racf_version,pwd_own_id,pwd_user_name,pwd_utk_encr,pwd_utk_pre19,pwd_utk_verprof,pwd_utk_njeunusr,pwd_utk_logusr,pwd_utk_special,pwd_utk_default,pwd_utk_unknusr,pwd_utk_error,pwd_utk_trusted,pwd_utk_sesstype,pwd_utk_surrogat,pwd_utk_remote,pwd_utk_priv,pwd_utk_secl,pwd_utk_execnode,pwd_utk_suser_id,pwd_utk_snode,pwd_utk_sgrp_id,pwd_utk_spoe,pwd_utk_spclass,pwd_utk_user_id,pwd_utk_grp_id,pwd_utk_dft_grp,pwd_utk_dft_secl,pwd_appc_link,pwd_specified,pwd_failed,pwd_ignored,pwd_utk_netw,pwd_x500_subject,pwd_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"password"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"password"}=0;
#Table:pdaccess
#delete all rows from the pdaccess table
$dbh->do("delete from pdaccess");
#Define the column names for the pdaccess table to Perl
my $pdac_event_type;
my $pdac_event_qual;
my $pdac_time_written;
my $pdac_date_written;
my $pdac_system_smfid;
my $pdac_violation;
my $pdac_user_ndfnd;
my $pdac_user_warning;
my $pdac_evt_user_id;
my $pdac_evt_grp_id;
my $pdac_auth_normal;
my $pdac_auth_special;
my $pdac_auth_oper;
my $pdac_auth_audit;
my $pdac_auth_exit;
my $pdac_auth_failsft;
my $pdac_auth_bypass;
my $pdac_auth_trusted;
my $pdac_log_class;
my $pdac_log_user;
my $pdac_log_special;
my $pdac_log_access;
my $pdac_log_racinit;
my $pdac_log_always;
my $pdac_log_cmdviol;
my $pdac_log_global;
my $pdac_term_level;
my $pdac_backout_fail;
my $pdac_prof_same;
my $pdac_term;
my $pdac_job_name;
my $pdac_read_time;
my $pdac_read_date;
my $pdac_smf_user_id;
my $pdac_log_level;
my $pdac_log_vmevent;
my $pdac_log_logopt;
my $pdac_log_secl;
my $pdac_log_compatm;
my $pdac_log_applaud;
my $pdac_log_nonomvs;
my $pdac_log_omvsnprv;
my $pdac_auth_omvssu;
my $pdac_auth_omvssys;
my $pdac_usr_secl;
my $pdac_racf_version;
my $pdac_object;
my $pdac_req_perms;
my $pdac_host_userid;
my $pdac_principal;
my $pdac_qop;
my $pdac_cred_type;
#Create and prepare the INSERT statement for pdaccess
$statement="INSERT INTO pdaccess (pdac_event_type,pdac_event_qual,pdac_time_written,pdac_date_written,pdac_system_smfid,pdac_violation,pdac_user_ndfnd,pdac_user_warning,pdac_evt_user_id,pdac_evt_grp_id,pdac_auth_normal,pdac_auth_special,pdac_auth_oper,pdac_auth_audit,pdac_auth_exit,pdac_auth_failsft,pdac_auth_bypass,pdac_auth_trusted,pdac_log_class,pdac_log_user,pdac_log_special,pdac_log_access,pdac_log_racinit,pdac_log_always,pdac_log_cmdviol,pdac_log_global,pdac_term_level,pdac_backout_fail,pdac_prof_same,pdac_term,pdac_job_name,pdac_read_time,pdac_read_date,pdac_smf_user_id,pdac_log_level,pdac_log_vmevent,pdac_log_logopt,pdac_log_secl,pdac_log_compatm,pdac_log_applaud,pdac_log_nonomvs,pdac_log_omvsnprv,pdac_auth_omvssu,pdac_auth_omvssys,pdac_usr_secl,pdac_racf_version,pdac_object,pdac_req_perms,pdac_host_userid,pdac_principal,pdac_qop,pdac_cred_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"pdaccess"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"pdaccess"}=0;
#Table:permit
#delete all rows from the permit table
$dbh->do("delete from permit");
#Define the column names for the permit table to Perl
my $perm_event_type;
my $perm_event_qual;
my $perm_time_written;
my $perm_date_written;
my $perm_system_smfid;
my $perm_violation;
my $perm_user_ndfnd;
my $perm_user_warning;
my $perm_evt_user_id;
my $perm_evt_grp_id;
my $perm_auth_normal;
my $perm_auth_special;
my $perm_auth_oper;
my $perm_auth_audit;
my $perm_auth_exit;
my $perm_auth_failsft;
my $perm_auth_bypass;
my $perm_auth_trusted;
my $perm_log_class;
my $perm_log_user;
my $perm_log_special;
my $perm_log_access;
my $perm_log_racinit;
my $perm_log_always;
my $perm_log_cmdviol;
my $perm_log_global;
my $perm_term_level;
my $perm_backout_fail;
my $perm_prof_same;
my $perm_term;
my $perm_job_name;
my $perm_read_time;
my $perm_read_date;
my $perm_smf_user_id;
my $perm_log_level;
my $perm_log_vmevent;
my $perm_log_logopt;
my $perm_log_secl;
my $perm_log_compatm;
my $perm_log_applaud;
my $perm_log_nonomvs;
my $perm_log_omvsnprv;
my $perm_auth_omvssu;
my $perm_auth_omvssys;
my $perm_usr_secl;
my $perm_racf_version;
my $perm_class;
my $perm_own_id;
my $perm_user_name;
my $perm_utk_encr;
my $perm_utk_pre19;
my $perm_utk_verprof;
my $perm_utk_njeunusr;
my $perm_utk_logusr;
my $perm_utk_special;
my $perm_utk_default;
my $perm_utk_unknusr;
my $perm_utk_error;
my $perm_utk_trusted;
my $perm_utk_sesstype;
my $perm_utk_surrogat;
my $perm_utk_remote;
my $perm_utk_priv;
my $perm_utk_secl;
my $perm_utk_execnode;
my $perm_utk_suser_id;
my $perm_utk_snode;
my $perm_utk_sgrp_id;
my $perm_utk_spoe;
my $perm_utk_spclass;
my $perm_utk_user_id;
my $perm_utk_grp_id;
my $perm_utk_dft_grp;
my $perm_utk_dft_secl;
my $perm_appc_link;
my $perm_res_name;
my $perm_specified;
my $perm_failed;
my $perm_ignored;
my $perm_utk_netw;
my $perm_x500_subject;
my $perm_x500_issuer;
#Create and prepare the INSERT statement for permit
$statement="INSERT INTO permit (perm_event_type,perm_event_qual,perm_time_written,perm_date_written,perm_system_smfid,perm_violation,perm_user_ndfnd,perm_user_warning,perm_evt_user_id,perm_evt_grp_id,perm_auth_normal,perm_auth_special,perm_auth_oper,perm_auth_audit,perm_auth_exit,perm_auth_failsft,perm_auth_bypass,perm_auth_trusted,perm_log_class,perm_log_user,perm_log_special,perm_log_access,perm_log_racinit,perm_log_always,perm_log_cmdviol,perm_log_global,perm_term_level,perm_backout_fail,perm_prof_same,perm_term,perm_job_name,perm_read_time,perm_read_date,perm_smf_user_id,perm_log_level,perm_log_vmevent,perm_log_logopt,perm_log_secl,perm_log_compatm,perm_log_applaud,perm_log_nonomvs,perm_log_omvsnprv,perm_auth_omvssu,perm_auth_omvssys,perm_usr_secl,perm_racf_version,perm_class,perm_own_id,perm_user_name,perm_utk_encr,perm_utk_pre19,perm_utk_verprof,perm_utk_njeunusr,perm_utk_logusr,perm_utk_special,perm_utk_default,perm_utk_unknusr,perm_utk_error,perm_utk_trusted,perm_utk_sesstype,perm_utk_surrogat,perm_utk_remote,perm_utk_priv,perm_utk_secl,perm_utk_execnode,perm_utk_suser_id,perm_utk_snode,perm_utk_sgrp_id,perm_utk_spoe,perm_utk_spclass,perm_utk_user_id,perm_utk_grp_id,perm_utk_dft_grp,perm_utk_dft_secl,perm_appc_link,perm_res_name,perm_specified,perm_failed,perm_ignored,perm_utk_netw,perm_x500_subject,perm_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"permit"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"permit"}=0;
#Table:ptrace
#delete all rows from the ptrace table
$dbh->do("delete from ptrace");
#Define the column names for the ptrace table to Perl
my $ptrc_event_type;
my $ptrc_event_qual;
my $ptrc_time_written;
my $ptrc_date_written;
my $ptrc_system_smfid;
my $ptrc_violation;
my $ptrc_user_ndfnd;
my $ptrc_user_warning;
my $ptrc_evt_user_id;
my $ptrc_evt_grp_id;
my $ptrc_auth_normal;
my $ptrc_auth_special;
my $ptrc_auth_oper;
my $ptrc_auth_audit;
my $ptrc_auth_exit;
my $ptrc_auth_failsft;
my $ptrc_auth_bypass;
my $ptrc_auth_trusted;
my $ptrc_log_class;
my $ptrc_log_user;
my $ptrc_log_special;
my $ptrc_log_access;
my $ptrc_log_racinit;
my $ptrc_log_always;
my $ptrc_log_cmdviol;
my $ptrc_log_global;
my $ptrc_term_level;
my $ptrc_backout_fail;
my $ptrc_prof_same;
my $ptrc_term;
my $ptrc_job_name;
my $ptrc_read_time;
my $ptrc_read_date;
my $ptrc_smf_user_id;
my $ptrc_log_level;
my $ptrc_log_vmevent;
my $ptrc_log_logopt;
my $ptrc_log_secl;
my $ptrc_log_compatm;
my $ptrc_log_applaud;
my $ptrc_log_nonomvs;
my $ptrc_log_omvsnprv;
my $ptrc_auth_omvssu;
my $ptrc_auth_omvssys;
my $ptrc_usr_secl;
my $ptrc_racf_version;
my $ptrc_class;
my $ptrc_user_name;
my $ptrc_utk_encr;
my $ptrc_utk_pre19;
my $ptrc_utk_verprof;
my $ptrc_utk_njeunusr;
my $ptrc_utk_logusr;
my $ptrc_utk_special;
my $ptrc_utk_default;
my $ptrc_utk_unknusr;
my $ptrc_utk_error;
my $ptrc_utk_trusted;
my $ptrc_utk_sesstype;
my $ptrc_utk_surrogat;
my $ptrc_utk_remote;
my $ptrc_utk_priv;
my $ptrc_utk_secl;
my $ptrc_utk_execnode;
my $ptrc_utk_suser_id;
my $ptrc_utk_snode;
my $ptrc_utk_sgrp_id;
my $ptrc_utk_spoe;
my $ptrc_utk_spclass;
my $ptrc_utk_user_id;
my $ptrc_utk_grp_id;
my $ptrc_utk_dft_grp;
my $ptrc_utk_dft_secl;
my $ptrc_appc_link;
my $ptrc_audit_code;
my $ptrc_old_real_uid;
my $ptrc_old_eff_uid;
my $ptrc_old_saved_uid;
my $ptrc_old_real_gid;
my $ptrc_old_eff_gid;
my $ptrc_old_saved_gid;
my $ptrc_tgt_real_uid;
my $ptrc_tgt_eff_uid;
my $ptrc_tgt_saved_uid;
my $ptrc_tgt_real_gid;
my $ptrc_tgt_eff_gid;
my $ptrc_tgt_saved_gid;
my $ptrc_tgt_pid;
my $ptrc_dflt_process;
my $ptrc_utk_netw;
my $ptrc_x500_subject;
my $ptrc_x500_issuer;
#Create and prepare the INSERT statement for ptrace
$statement="INSERT INTO ptrace (ptrc_event_type,ptrc_event_qual,ptrc_time_written,ptrc_date_written,ptrc_system_smfid,ptrc_violation,ptrc_user_ndfnd,ptrc_user_warning,ptrc_evt_user_id,ptrc_evt_grp_id,ptrc_auth_normal,ptrc_auth_special,ptrc_auth_oper,ptrc_auth_audit,ptrc_auth_exit,ptrc_auth_failsft,ptrc_auth_bypass,ptrc_auth_trusted,ptrc_log_class,ptrc_log_user,ptrc_log_special,ptrc_log_access,ptrc_log_racinit,ptrc_log_always,ptrc_log_cmdviol,ptrc_log_global,ptrc_term_level,ptrc_backout_fail,ptrc_prof_same,ptrc_term,ptrc_job_name,ptrc_read_time,ptrc_read_date,ptrc_smf_user_id,ptrc_log_level,ptrc_log_vmevent,ptrc_log_logopt,ptrc_log_secl,ptrc_log_compatm,ptrc_log_applaud,ptrc_log_nonomvs,ptrc_log_omvsnprv,ptrc_auth_omvssu,ptrc_auth_omvssys,ptrc_usr_secl,ptrc_racf_version,ptrc_class,ptrc_user_name,ptrc_utk_encr,ptrc_utk_pre19,ptrc_utk_verprof,ptrc_utk_njeunusr,ptrc_utk_logusr,ptrc_utk_special,ptrc_utk_default,ptrc_utk_unknusr,ptrc_utk_error,ptrc_utk_trusted,ptrc_utk_sesstype,ptrc_utk_surrogat,ptrc_utk_remote,ptrc_utk_priv,ptrc_utk_secl,ptrc_utk_execnode,ptrc_utk_suser_id,ptrc_utk_snode,ptrc_utk_sgrp_id,ptrc_utk_spoe,ptrc_utk_spclass,ptrc_utk_user_id,ptrc_utk_grp_id,ptrc_utk_dft_grp,ptrc_utk_dft_secl,ptrc_appc_link,ptrc_audit_code,ptrc_old_real_uid,ptrc_old_eff_uid,ptrc_old_saved_uid,ptrc_old_real_gid,ptrc_old_eff_gid,ptrc_old_saved_gid,ptrc_tgt_real_uid,ptrc_tgt_eff_uid,ptrc_tgt_saved_uid,ptrc_tgt_real_gid,ptrc_tgt_eff_gid,ptrc_tgt_saved_gid,ptrc_tgt_pid,ptrc_dflt_process,ptrc_utk_netw,ptrc_x500_subject,ptrc_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ptrace"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ptrace"}=0;
#Table:racdcert
#delete all rows from the racdcert table
$dbh->do("delete from racdcert");
#Define the column names for the racdcert table to Perl
my $racd_event_type;
my $racd_event_qual;
my $racd_time_written;
my $racd_date_written;
my $racd_system_smfid;
my $racd_violation;
my $racd_user_ndfnd;
my $racd_user_warning;
my $racd_evt_user_id;
my $racd_evt_grp_id;
my $racd_auth_normal;
my $racd_auth_special;
my $racd_auth_oper;
my $racd_auth_audit;
my $racd_auth_exit;
my $racd_auth_failsft;
my $racd_auth_bypass;
my $racd_auth_trusted;
my $racd_log_class;
my $racd_log_user;
my $racd_log_special;
my $racd_log_access;
my $racd_log_racinit;
my $racd_log_always;
my $racd_log_cmdviol;
my $racd_log_global;
my $racd_term_level;
my $racd_backout_fail;
my $racd_prof_same;
my $racd_term;
my $racd_job_name;
my $racd_read_time;
my $racd_read_date;
my $racd_smf_user_id;
my $racd_log_level;
my $racd_log_vmevent;
my $racd_log_logopt;
my $racd_log_secl;
my $racd_log_compatm;
my $racd_log_applaud;
my $racd_log_nonomvs;
my $racd_log_omvsnprv;
my $racd_auth_omvssu;
my $racd_auth_omvssys;
my $racd_usr_secl;
my $racd_racf_version;
my $racd_user_name;
my $racd_utk_encr;
my $racd_utk_pre19;
my $racd_utk_verprof;
my $racd_utk_njeunusr;
my $racd_utk_logusr;
my $racd_utk_special;
my $racd_utk_default;
my $racd_utk_unknusr;
my $racd_utk_error;
my $racd_utk_trusted;
my $racd_utk_sesstype;
my $racd_utk_surrogat;
my $racd_utk_remote;
my $racd_utk_priv;
my $racd_utk_secl;
my $racd_utk_execnode;
my $racd_utk_suser_id;
my $racd_utk_snode;
my $racd_utk_sgrp_id;
my $racd_utk_spoe;
my $racd_utk_spclass;
my $racd_utk_user_id;
my $racd_utk_grp_id;
my $racd_utk_dft_grp;
my $racd_utk_dft_secl;
my $racd_serial_number;
my $racd_issuers_dn;
my $racd_cert_ds;
my $racd_specified;
my $racd_utk_netw;
my $racd_x500_subject;
my $racd_x500_issuer;
#Create and prepare the INSERT statement for racdcert
$statement="INSERT INTO racdcert (racd_event_type,racd_event_qual,racd_time_written,racd_date_written,racd_system_smfid,racd_violation,racd_user_ndfnd,racd_user_warning,racd_evt_user_id,racd_evt_grp_id,racd_auth_normal,racd_auth_special,racd_auth_oper,racd_auth_audit,racd_auth_exit,racd_auth_failsft,racd_auth_bypass,racd_auth_trusted,racd_log_class,racd_log_user,racd_log_special,racd_log_access,racd_log_racinit,racd_log_always,racd_log_cmdviol,racd_log_global,racd_term_level,racd_backout_fail,racd_prof_same,racd_term,racd_job_name,racd_read_time,racd_read_date,racd_smf_user_id,racd_log_level,racd_log_vmevent,racd_log_logopt,racd_log_secl,racd_log_compatm,racd_log_applaud,racd_log_nonomvs,racd_log_omvsnprv,racd_auth_omvssu,racd_auth_omvssys,racd_usr_secl,racd_racf_version,racd_user_name,racd_utk_encr,racd_utk_pre19,racd_utk_verprof,racd_utk_njeunusr,racd_utk_logusr,racd_utk_special,racd_utk_default,racd_utk_unknusr,racd_utk_error,racd_utk_trusted,racd_utk_sesstype,racd_utk_surrogat,racd_utk_remote,racd_utk_priv,racd_utk_secl,racd_utk_execnode,racd_utk_suser_id,racd_utk_snode,racd_utk_sgrp_id,racd_utk_spoe,racd_utk_spclass,racd_utk_user_id,racd_utk_grp_id,racd_utk_dft_grp,racd_utk_dft_secl,racd_serial_number,racd_issuers_dn,racd_cert_ds,racd_specified,racd_utk_netw,racd_x500_subject,racd_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"racdcert"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"racdcert"}=0;
#Table:racfinit
#delete all rows from the racfinit table
$dbh->do("delete from racfinit");
#Define the column names for the racfinit table to Perl
my $rini_event_type;
my $rini_reserved_01;
my $rini_time_written;
my $rini_date_written;
my $rini_system_smfid;
my $rini_dataset_name;
my $rini_dataset_vol;
my $rini_dataset_unit;
my $rini_uads_name;
my $rini_uads_vol;
my $rini_racinit_stats;
my $rini_dataset_stats;
my $rini_racinit_pre;
my $rini_racheck_pre;
my $rini_racdef_pre;
my $rini_racinit_post;
my $rini_racheck_post;
my $rini_new_pwd_exit;
my $rini_tapevol_stats;
my $rini_dasd_stats;
my $rini_term_stats;
my $rini_cmd_exit;
my $rini_del_cmd_exit;
my $rini_adsp;
my $rini_encrypt_exit;
my $rini_naming_conv;
my $rini_tapevol;
my $rini_dup_dsns;
my $rini_dasd;
my $rini_fracheck_pre;
my $rini_raclist_pre;
my $rini_raclist_sel;
my $rini_racdef_post;
my $rini_audit_user;
my $rini_audit_group;
my $rini_audit_dataset;
my $rini_audit_tapevol;
my $rini_audit_dasdvol;
my $rini_audit_term;
my $rini_audit_cmdviol;
my $rini_audit_special;
my $rini_audit_oper;
my $rini_audit_level;
my $rini_acee_compress;
my $rini_fastauth_pre;
my $rini_fastauth_post;
my $rini_term;
my $rini_term_none;
my $rini_realdsn;
my $rini_xbmallracf;
my $rini_earlyverify;
my $rini_batchallracf;
my $rini_fracheck_post;
my $rini_pwd_int;
my $rini_single_dsn;
my $rini_tapedsn;
my $rini_protectall;
my $rini_protectall_w;
my $rini_erase;
my $rini_erase_level;
my $rini_erase_all;
my $rini_egn;
my $rini_when_program;
my $rini_retention;
my $rini_level_erase;
my $rini_level_audit;
my $rini_secl_ctrl;
my $rini_catdsns;
my $rini_mlquiet;
my $rini_mlstable;
my $rini_mls;
my $rini_mlactive;
my $rini_generic_owner;
my $rini_secl_audit;
my $rini_session_int;
my $rini_nje_name_id;
my $rini_nje_udfnd_id;
my $rini_compatmode;
my $rini_catdsns_fail;
my $rini_mls_fail;
my $rini_mlactive_fail;
my $rini_applaud;
my $rini_dft_pri;
my $rini_dft_sec;
my $rini_reserved_02;
my $rini_all_cmd_exit;
my $rini_addcreator;
my $rini_acee_comp_xm;
my $rini_encrypt_exit2;
my $rini_pwd_hist;
my $rini_pwd_revoke;
my $rini_pwd_warn;
my $rini_pwdrule1_min;
my $rini_pwdrule1_max;
my $rini_pwdrule1;
my $rini_pwdrule2_min;
my $rini_pwdrule2_max;
my $rini_pwdrule2;
my $rini_pwdrule3_min;
my $rini_pwdrule3_max;
my $rini_pwdrule3;
my $rini_pwdrule4_min;
my $rini_pwdrule4_max;
my $rini_pwdrule4;
my $rini_pwdrule5_min;
my $rini_pwdrule5_max;
my $rini_pwdrule5;
my $rini_pwdrule6_min;
my $rini_pwdrule6_max;
my $rini_pwdrule6;
my $rini_pwdrule7_min;
my $rini_pwdrule7_max;
my $rini_pwdrule7;
my $rini_pwdrule8_min;
my $rini_pwdrule8_max;
my $rini_pwdrule8;
my $rini_inactive;
my $rini_grplist;
my $rini_model_gdg;
my $rini_model_user;
my $rini_model_group;
my $rini_rswi_inst_pwd;
my $rini_rsta_inst_pwd;
my $rini_kerblvl;
#Create and prepare the INSERT statement for racfinit
$statement="INSERT INTO racfinit (rini_event_type,rini_reserved_01,rini_time_written,rini_date_written,rini_system_smfid,rini_dataset_name,rini_dataset_vol,rini_dataset_unit,rini_uads_name,rini_uads_vol,rini_racinit_stats,rini_dataset_stats,rini_racinit_pre,rini_racheck_pre,rini_racdef_pre,rini_racinit_post,rini_racheck_post,rini_new_pwd_exit,rini_tapevol_stats,rini_dasd_stats,rini_term_stats,rini_cmd_exit,rini_del_cmd_exit,rini_adsp,rini_encrypt_exit,rini_naming_conv,rini_tapevol,rini_dup_dsns,rini_dasd,rini_fracheck_pre,rini_raclist_pre,rini_raclist_sel,rini_racdef_post,rini_audit_user,rini_audit_group,rini_audit_dataset,rini_audit_tapevol,rini_audit_dasdvol,rini_audit_term,rini_audit_cmdviol,rini_audit_special,rini_audit_oper,rini_audit_level,rini_acee_compress,rini_fastauth_pre,rini_fastauth_post,rini_term,rini_term_none,rini_realdsn,rini_xbmallracf,rini_earlyverify,rini_batchallracf,rini_fracheck_post,rini_pwd_int,rini_single_dsn,rini_tapedsn,rini_protectall,rini_protectall_w,rini_erase,rini_erase_level,rini_erase_all,rini_egn,rini_when_program,rini_retention,rini_level_erase,rini_level_audit,rini_secl_ctrl,rini_catdsns,rini_mlquiet,rini_mlstable,rini_mls,rini_mlactive,rini_generic_owner,rini_secl_audit,rini_session_int,rini_nje_name_id,rini_nje_udfnd_id,rini_compatmode,rini_catdsns_fail,rini_mls_fail,rini_mlactive_fail,rini_applaud,rini_dft_pri,rini_dft_sec,rini_reserved_02,rini_all_cmd_exit,rini_addcreator,rini_acee_comp_xm,rini_encrypt_exit2,rini_pwd_hist,rini_pwd_revoke,rini_pwd_warn,rini_pwdrule1_min,rini_pwdrule1_max,rini_pwdrule1,rini_pwdrule2_min,rini_pwdrule2_max,rini_pwdrule2,rini_pwdrule3_min,rini_pwdrule3_max,rini_pwdrule3,rini_pwdrule4_min,rini_pwdrule4_max,rini_pwdrule4,rini_pwdrule5_min,rini_pwdrule5_max,rini_pwdrule5,rini_pwdrule6_min,rini_pwdrule6_max,rini_pwdrule6,rini_pwdrule7_min,rini_pwdrule7_max,rini_pwdrule7,rini_pwdrule8_min,rini_pwdrule8_max,rini_pwdrule8,rini_inactive,rini_grplist,rini_model_gdg,rini_model_user,rini_model_group,rini_rswi_inst_pwd,rini_rsta_inst_pwd,rini_kerblvl) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"racfinit"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"racfinit"}=0;
#Table:raclink
#delete all rows from the raclink table
$dbh->do("delete from raclink");
#Define the column names for the raclink table to Perl
my $racl_event_type;
my $racl_event_qual;
my $racl_time_written;
my $racl_date_written;
my $racl_system_smfid;
my $racl_violation;
my $racl_user_ndfnd;
my $racl_user_warning;
my $racl_evt_user_id;
my $racl_evt_grp_id;
my $racl_auth_normal;
my $racl_auth_special;
my $racl_auth_oper;
my $racl_auth_audit;
my $racl_auth_exit;
my $racl_auth_failsft;
my $racl_auth_bypass;
my $racl_auth_trusted;
my $racl_log_class;
my $racl_log_user;
my $racl_log_special;
my $racl_log_access;
my $racl_log_racinit;
my $racl_log_always;
my $racl_log_cmdviol;
my $racl_log_global;
my $racl_term_level;
my $racl_backout_fail;
my $racl_prof_same;
my $racl_term;
my $racl_job_name;
my $racl_read_time;
my $racl_read_date;
my $racl_smf_user_id;
my $racl_log_level;
my $racl_log_vmevent;
my $racl_log_logopt;
my $racl_log_secl;
my $racl_log_compatm;
my $racl_log_applaud;
my $racl_log_nonomvs;
my $racl_log_omvsnprv;
my $racl_auth_omvssu;
my $racl_auth_omvssys;
my $racl_usr_secl;
my $racl_racf_version;
my $racl_user_name;
my $racl_utk_encr;
my $racl_utk_pre19;
my $racl_utk_verprof;
my $racl_utk_njeunusr;
my $racl_utk_logusr;
my $racl_utk_special;
my $racl_utk_default;
my $racl_utk_unknusr;
my $racl_utk_error;
my $racl_utk_trusted;
my $racl_utk_sesstype;
my $racl_utk_surrogat;
my $racl_utk_remote;
my $racl_utk_priv;
my $racl_utk_secl;
my $racl_utk_execnode;
my $racl_utk_suser_id;
my $racl_utk_snode;
my $racl_utk_sgrp_id;
my $racl_utk_spoe;
my $racl_utk_spclass;
my $racl_utk_user_id;
my $racl_utk_grp_id;
my $racl_utk_dft_grp;
my $racl_utk_dft_secl;
my $racl_phase;
my $racl_issue_node;
my $racl_issue_id;
my $racl_source_id;
my $racl_tgt_node;
my $racl_tgt_id;
my $racl_tgt_auth_id;
my $racl_source_smfid;
my $racl_source_time;
my $racl_source_date;
my $racl_pwd_status;
my $racl_assoc_status;
my $racl_specified;
my $racl_utk_netw;
my $racl_x500_subject;
my $racl_x500_issuer;
#Create and prepare the INSERT statement for raclink
$statement="INSERT INTO raclink (racl_event_type,racl_event_qual,racl_time_written,racl_date_written,racl_system_smfid,racl_violation,racl_user_ndfnd,racl_user_warning,racl_evt_user_id,racl_evt_grp_id,racl_auth_normal,racl_auth_special,racl_auth_oper,racl_auth_audit,racl_auth_exit,racl_auth_failsft,racl_auth_bypass,racl_auth_trusted,racl_log_class,racl_log_user,racl_log_special,racl_log_access,racl_log_racinit,racl_log_always,racl_log_cmdviol,racl_log_global,racl_term_level,racl_backout_fail,racl_prof_same,racl_term,racl_job_name,racl_read_time,racl_read_date,racl_smf_user_id,racl_log_level,racl_log_vmevent,racl_log_logopt,racl_log_secl,racl_log_compatm,racl_log_applaud,racl_log_nonomvs,racl_log_omvsnprv,racl_auth_omvssu,racl_auth_omvssys,racl_usr_secl,racl_racf_version,racl_user_name,racl_utk_encr,racl_utk_pre19,racl_utk_verprof,racl_utk_njeunusr,racl_utk_logusr,racl_utk_special,racl_utk_default,racl_utk_unknusr,racl_utk_error,racl_utk_trusted,racl_utk_sesstype,racl_utk_surrogat,racl_utk_remote,racl_utk_priv,racl_utk_secl,racl_utk_execnode,racl_utk_suser_id,racl_utk_snode,racl_utk_sgrp_id,racl_utk_spoe,racl_utk_spclass,racl_utk_user_id,racl_utk_grp_id,racl_utk_dft_grp,racl_utk_dft_secl,racl_phase,racl_issue_node,racl_issue_id,racl_source_id,racl_tgt_node,racl_tgt_id,racl_tgt_auth_id,racl_source_smfid,racl_source_time,racl_source_date,racl_pwd_status,racl_assoc_status,racl_specified,racl_utk_netw,racl_x500_subject,racl_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"raclink"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"raclink"}=0;
#Table:ralter
#delete all rows from the ralter table
$dbh->do("delete from ralter");
#Define the column names for the ralter table to Perl
my $ralt_event_type;
my $ralt_event_qual;
my $ralt_time_written;
my $ralt_date_written;
my $ralt_system_smfid;
my $ralt_violation;
my $ralt_user_ndfnd;
my $ralt_user_warning;
my $ralt_evt_user_id;
my $ralt_evt_grp_id;
my $ralt_auth_normal;
my $ralt_auth_special;
my $ralt_auth_oper;
my $ralt_auth_audit;
my $ralt_auth_exit;
my $ralt_auth_failsft;
my $ralt_auth_bypass;
my $ralt_auth_trusted;
my $ralt_log_class;
my $ralt_log_user;
my $ralt_log_special;
my $ralt_log_access;
my $ralt_log_racinit;
my $ralt_log_always;
my $ralt_log_cmdviol;
my $ralt_log_global;
my $ralt_term_level;
my $ralt_backout_fail;
my $ralt_prof_same;
my $ralt_term;
my $ralt_job_name;
my $ralt_read_time;
my $ralt_read_date;
my $ralt_smf_user_id;
my $ralt_log_level;
my $ralt_log_vmevent;
my $ralt_log_logopt;
my $ralt_log_secl;
my $ralt_log_compatm;
my $ralt_log_applaud;
my $ralt_log_nonomvs;
my $ralt_log_omvsnprv;
my $ralt_auth_omvssu;
my $ralt_auth_omvssys;
my $ralt_usr_secl;
my $ralt_racf_version;
my $ralt_class;
my $ralt_own_id;
my $ralt_user_name;
my $ralt_old_secl;
my $ralt_utk_encr;
my $ralt_utk_pre19;
my $ralt_utk_verprof;
my $ralt_utk_njeunusr;
my $ralt_utk_logusr;
my $ralt_utk_special;
my $ralt_utk_default;
my $ralt_utk_unknusr;
my $ralt_utk_error;
my $ralt_utk_trusted;
my $ralt_utk_sesstype;
my $ralt_utk_surrogat;
my $ralt_utk_remote;
my $ralt_utk_priv;
my $ralt_utk_secl;
my $ralt_utk_execnode;
my $ralt_utk_suser_id;
my $ralt_utk_snode;
my $ralt_utk_sgrp_id;
my $ralt_utk_spoe;
my $ralt_utk_spclass;
my $ralt_utk_user_id;
my $ralt_utk_grp_id;
my $ralt_utk_dft_grp;
my $ralt_utk_dft_secl;
my $ralt_appc_link;
my $ralt_res_name;
my $ralt_specified;
my $ralt_failed;
my $ralt_utk_netw;
my $ralt_x500_subject;
my $ralt_x500_issuer;
#Create and prepare the INSERT statement for ralter
$statement="INSERT INTO ralter (ralt_event_type,ralt_event_qual,ralt_time_written,ralt_date_written,ralt_system_smfid,ralt_violation,ralt_user_ndfnd,ralt_user_warning,ralt_evt_user_id,ralt_evt_grp_id,ralt_auth_normal,ralt_auth_special,ralt_auth_oper,ralt_auth_audit,ralt_auth_exit,ralt_auth_failsft,ralt_auth_bypass,ralt_auth_trusted,ralt_log_class,ralt_log_user,ralt_log_special,ralt_log_access,ralt_log_racinit,ralt_log_always,ralt_log_cmdviol,ralt_log_global,ralt_term_level,ralt_backout_fail,ralt_prof_same,ralt_term,ralt_job_name,ralt_read_time,ralt_read_date,ralt_smf_user_id,ralt_log_level,ralt_log_vmevent,ralt_log_logopt,ralt_log_secl,ralt_log_compatm,ralt_log_applaud,ralt_log_nonomvs,ralt_log_omvsnprv,ralt_auth_omvssu,ralt_auth_omvssys,ralt_usr_secl,ralt_racf_version,ralt_class,ralt_own_id,ralt_user_name,ralt_old_secl,ralt_utk_encr,ralt_utk_pre19,ralt_utk_verprof,ralt_utk_njeunusr,ralt_utk_logusr,ralt_utk_special,ralt_utk_default,ralt_utk_unknusr,ralt_utk_error,ralt_utk_trusted,ralt_utk_sesstype,ralt_utk_surrogat,ralt_utk_remote,ralt_utk_priv,ralt_utk_secl,ralt_utk_execnode,ralt_utk_suser_id,ralt_utk_snode,ralt_utk_sgrp_id,ralt_utk_spoe,ralt_utk_spclass,ralt_utk_user_id,ralt_utk_grp_id,ralt_utk_dft_grp,ralt_utk_dft_secl,ralt_appc_link,ralt_res_name,ralt_specified,ralt_failed,ralt_utk_netw,ralt_x500_subject,ralt_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"ralter"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"ralter"}=0;
#Table:rdefine
#delete all rows from the rdefine table
$dbh->do("delete from rdefine");
#Define the column names for the rdefine table to Perl
my $rdef_event_type;
my $rdef_event_qual;
my $rdef_time_written;
my $rdef_date_written;
my $rdef_system_smfid;
my $rdef_violation;
my $rdef_user_ndfnd;
my $rdef_user_warning;
my $rdef_evt_user_id;
my $rdef_evt_grp_id;
my $rdef_auth_normal;
my $rdef_auth_special;
my $rdef_auth_oper;
my $rdef_auth_audit;
my $rdef_auth_exit;
my $rdef_auth_failsft;
my $rdef_auth_bypass;
my $rdef_auth_trusted;
my $rdef_log_class;
my $rdef_log_user;
my $rdef_log_special;
my $rdef_log_access;
my $rdef_log_racinit;
my $rdef_log_always;
my $rdef_log_cmdviol;
my $rdef_log_global;
my $rdef_term_level;
my $rdef_backout_fail;
my $rdef_prof_same;
my $rdef_term;
my $rdef_job_name;
my $rdef_read_time;
my $rdef_read_date;
my $rdef_smf_user_id;
my $rdef_log_level;
my $rdef_log_vmevent;
my $rdef_log_logopt;
my $rdef_log_secl;
my $rdef_log_compatm;
my $rdef_log_applaud;
my $rdef_log_nonomvs;
my $rdef_log_omvsnprv;
my $rdef_auth_omvssu;
my $rdef_auth_omvssys;
my $rdef_usr_secl;
my $rdef_racf_version;
my $rdef_class;
my $rdef_own_id;
my $rdef_user_name;
my $rdef_secl;
my $rdef_utk_encr;
my $rdef_utk_pre19;
my $rdef_utk_verprof;
my $rdef_utk_njeunusr;
my $rdef_utk_logusr;
my $rdef_utk_special;
my $rdef_utk_default;
my $rdef_utk_unknusr;
my $rdef_utk_error;
my $rdef_utk_trusted;
my $rdef_utk_sesstype;
my $rdef_utk_surrogat;
my $rdef_utk_remote;
my $rdef_utk_priv;
my $rdef_utk_secl;
my $rdef_utk_execnode;
my $rdef_utk_suser_id;
my $rdef_utk_snode;
my $rdef_utk_sgrp_id;
my $rdef_utk_spoe;
my $rdef_utk_spclass;
my $rdef_utk_user_id;
my $rdef_utk_grp_id;
my $rdef_utk_dft_grp;
my $rdef_utk_dft_secl;
my $rdef_appc_link;
my $rdef_res_name;
my $rdef_specified;
my $rdef_failed;
my $rdef_utk_netw;
my $rdef_x500_subject;
my $rdef_x500_issuer;
#Create and prepare the INSERT statement for rdefine
$statement="INSERT INTO rdefine (rdef_event_type,rdef_event_qual,rdef_time_written,rdef_date_written,rdef_system_smfid,rdef_violation,rdef_user_ndfnd,rdef_user_warning,rdef_evt_user_id,rdef_evt_grp_id,rdef_auth_normal,rdef_auth_special,rdef_auth_oper,rdef_auth_audit,rdef_auth_exit,rdef_auth_failsft,rdef_auth_bypass,rdef_auth_trusted,rdef_log_class,rdef_log_user,rdef_log_special,rdef_log_access,rdef_log_racinit,rdef_log_always,rdef_log_cmdviol,rdef_log_global,rdef_term_level,rdef_backout_fail,rdef_prof_same,rdef_term,rdef_job_name,rdef_read_time,rdef_read_date,rdef_smf_user_id,rdef_log_level,rdef_log_vmevent,rdef_log_logopt,rdef_log_secl,rdef_log_compatm,rdef_log_applaud,rdef_log_nonomvs,rdef_log_omvsnprv,rdef_auth_omvssu,rdef_auth_omvssys,rdef_usr_secl,rdef_racf_version,rdef_class,rdef_own_id,rdef_user_name,rdef_secl,rdef_utk_encr,rdef_utk_pre19,rdef_utk_verprof,rdef_utk_njeunusr,rdef_utk_logusr,rdef_utk_special,rdef_utk_default,rdef_utk_unknusr,rdef_utk_error,rdef_utk_trusted,rdef_utk_sesstype,rdef_utk_surrogat,rdef_utk_remote,rdef_utk_priv,rdef_utk_secl,rdef_utk_execnode,rdef_utk_suser_id,rdef_utk_snode,rdef_utk_sgrp_id,rdef_utk_spoe,rdef_utk_spclass,rdef_utk_user_id,rdef_utk_grp_id,rdef_utk_dft_grp,rdef_utk_dft_secl,rdef_appc_link,rdef_res_name,rdef_specified,rdef_failed,rdef_utk_netw,rdef_x500_subject,rdef_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rdefine"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rdefine"}=0;
#Table:rdelete
#delete all rows from the rdelete table
$dbh->do("delete from rdelete");
#Define the column names for the rdelete table to Perl
my $rdel_event_type;
my $rdel_event_qual;
my $rdel_time_written;
my $rdel_date_written;
my $rdel_system_smfid;
my $rdel_violation;
my $rdel_user_ndfnd;
my $rdel_user_warning;
my $rdel_evt_user_id;
my $rdel_evt_grp_id;
my $rdel_auth_normal;
my $rdel_auth_special;
my $rdel_auth_oper;
my $rdel_auth_audit;
my $rdel_auth_exit;
my $rdel_auth_failsft;
my $rdel_auth_bypass;
my $rdel_auth_trusted;
my $rdel_log_class;
my $rdel_log_user;
my $rdel_log_special;
my $rdel_log_access;
my $rdel_log_racinit;
my $rdel_log_always;
my $rdel_log_cmdviol;
my $rdel_log_global;
my $rdel_term_level;
my $rdel_backout_fail;
my $rdel_prof_same;
my $rdel_term;
my $rdel_job_name;
my $rdel_read_time;
my $rdel_read_date;
my $rdel_smf_user_id;
my $rdel_log_level;
my $rdel_log_vmevent;
my $rdel_log_logopt;
my $rdel_log_secl;
my $rdel_log_compatm;
my $rdel_log_applaud;
my $rdel_log_nonomvs;
my $rdel_log_omvsnprv;
my $rdel_auth_omvssu;
my $rdel_auth_omvssys;
my $rdel_usr_secl;
my $rdel_racf_version;
my $rdel_class;
my $rdel_own_id;
my $rdel_user_name;
my $rdel_secl;
my $rdel_utk_encr;
my $rdel_utk_pre19;
my $rdel_utk_verprof;
my $rdel_utk_njeunusr;
my $rdel_utk_logusr;
my $rdel_utk_special;
my $rdel_utk_default;
my $rdel_utk_unknusr;
my $rdel_utk_error;
my $rdel_utk_trusted;
my $rdel_utk_sesstype;
my $rdel_utk_surrogat;
my $rdel_utk_remote;
my $rdel_utk_priv;
my $rdel_utk_secl;
my $rdel_utk_execnode;
my $rdel_utk_suser_id;
my $rdel_utk_snode;
my $rdel_utk_sgrp_id;
my $rdel_utk_spoe;
my $rdel_utk_spclass;
my $rdel_utk_user_id;
my $rdel_utk_grp_id;
my $rdel_utk_dft_grp;
my $rdel_utk_dft_secl;
my $rdel_appc_link;
my $rdel_res_name;
my $rdel_specified;
my $rdel_utk_netw;
my $rdel_x500_subject;
my $rdel_x500_issuer;
#Create and prepare the INSERT statement for rdelete
$statement="INSERT INTO rdelete (rdel_event_type,rdel_event_qual,rdel_time_written,rdel_date_written,rdel_system_smfid,rdel_violation,rdel_user_ndfnd,rdel_user_warning,rdel_evt_user_id,rdel_evt_grp_id,rdel_auth_normal,rdel_auth_special,rdel_auth_oper,rdel_auth_audit,rdel_auth_exit,rdel_auth_failsft,rdel_auth_bypass,rdel_auth_trusted,rdel_log_class,rdel_log_user,rdel_log_special,rdel_log_access,rdel_log_racinit,rdel_log_always,rdel_log_cmdviol,rdel_log_global,rdel_term_level,rdel_backout_fail,rdel_prof_same,rdel_term,rdel_job_name,rdel_read_time,rdel_read_date,rdel_smf_user_id,rdel_log_level,rdel_log_vmevent,rdel_log_logopt,rdel_log_secl,rdel_log_compatm,rdel_log_applaud,rdel_log_nonomvs,rdel_log_omvsnprv,rdel_auth_omvssu,rdel_auth_omvssys,rdel_usr_secl,rdel_racf_version,rdel_class,rdel_own_id,rdel_user_name,rdel_secl,rdel_utk_encr,rdel_utk_pre19,rdel_utk_verprof,rdel_utk_njeunusr,rdel_utk_logusr,rdel_utk_special,rdel_utk_default,rdel_utk_unknusr,rdel_utk_error,rdel_utk_trusted,rdel_utk_sesstype,rdel_utk_surrogat,rdel_utk_remote,rdel_utk_priv,rdel_utk_secl,rdel_utk_execnode,rdel_utk_suser_id,rdel_utk_snode,rdel_utk_sgrp_id,rdel_utk_spoe,rdel_utk_spclass,rdel_utk_user_id,rdel_utk_grp_id,rdel_utk_dft_grp,rdel_utk_dft_secl,rdel_appc_link,rdel_res_name,rdel_specified,rdel_utk_netw,rdel_x500_subject,rdel_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rdelete"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rdelete"}=0;
#Table:remove
#delete all rows from the remove table
$dbh->do("delete from remove");
#Define the column names for the remove table to Perl
my $rem_event_type;
my $rem_event_qual;
my $rem_time_written;
my $rem_date_written;
my $rem_system_smfid;
my $rem_violation;
my $rem_user_ndfnd;
my $rem_user_warning;
my $rem_evt_user_id;
my $rem_evt_grp_id;
my $rem_auth_normal;
my $rem_auth_special;
my $rem_auth_oper;
my $rem_auth_audit;
my $rem_auth_exit;
my $rem_auth_failsft;
my $rem_auth_bypass;
my $rem_auth_trusted;
my $rem_log_class;
my $rem_log_user;
my $rem_log_special;
my $rem_log_access;
my $rem_log_racinit;
my $rem_log_always;
my $rem_log_cmdviol;
my $rem_log_global;
my $rem_term_level;
my $rem_backout_fail;
my $rem_prof_same;
my $rem_term;
my $rem_job_name;
my $rem_read_time;
my $rem_read_date;
my $rem_smf_user_id;
my $rem_log_level;
my $rem_log_vmevent;
my $rem_log_logopt;
my $rem_log_secl;
my $rem_log_compatm;
my $rem_log_applaud;
my $rem_log_nonomvs;
my $rem_log_omvsnprv;
my $rem_auth_omvssu;
my $rem_auth_omvssys;
my $rem_usr_secl;
my $rem_racf_version;
my $rem_own_id;
my $rem_user_name;
my $rem_utk_encr;
my $rem_utk_pre19;
my $rem_utk_verprof;
my $rem_utk_njeunusr;
my $rem_utk_logusr;
my $rem_utk_special;
my $rem_utk_default;
my $rem_utk_unknusr;
my $rem_utk_error;
my $rem_utk_trusted;
my $rem_utk_sesstype;
my $rem_utk_surrogat;
my $rem_utk_remote;
my $rem_utk_priv;
my $rem_utk_secl;
my $rem_utk_execnode;
my $rem_utk_suser_id;
my $rem_utk_snode;
my $rem_utk_sgrp_id;
my $rem_utk_spoe;
my $rem_utk_spclass;
my $rem_utk_user_id;
my $rem_utk_grp_id;
my $rem_utk_dft_grp;
my $rem_utk_dft_secl;
my $rem_appc_link;
my $rem_user_id;
my $rem_specified;
my $rem_failed;
my $rem_utk_netw;
my $rem_x500_subject;
my $rem_x500_issuer;
#Create and prepare the INSERT statement for remove
$statement="INSERT INTO remove (rem_event_type,rem_event_qual,rem_time_written,rem_date_written,rem_system_smfid,rem_violation,rem_user_ndfnd,rem_user_warning,rem_evt_user_id,rem_evt_grp_id,rem_auth_normal,rem_auth_special,rem_auth_oper,rem_auth_audit,rem_auth_exit,rem_auth_failsft,rem_auth_bypass,rem_auth_trusted,rem_log_class,rem_log_user,rem_log_special,rem_log_access,rem_log_racinit,rem_log_always,rem_log_cmdviol,rem_log_global,rem_term_level,rem_backout_fail,rem_prof_same,rem_term,rem_job_name,rem_read_time,rem_read_date,rem_smf_user_id,rem_log_level,rem_log_vmevent,rem_log_logopt,rem_log_secl,rem_log_compatm,rem_log_applaud,rem_log_nonomvs,rem_log_omvsnprv,rem_auth_omvssu,rem_auth_omvssys,rem_usr_secl,rem_racf_version,rem_own_id,rem_user_name,rem_utk_encr,rem_utk_pre19,rem_utk_verprof,rem_utk_njeunusr,rem_utk_logusr,rem_utk_special,rem_utk_default,rem_utk_unknusr,rem_utk_error,rem_utk_trusted,rem_utk_sesstype,rem_utk_surrogat,rem_utk_remote,rem_utk_priv,rem_utk_secl,rem_utk_execnode,rem_utk_suser_id,rem_utk_snode,rem_utk_sgrp_id,rem_utk_spoe,rem_utk_spclass,rem_utk_user_id,rem_utk_grp_id,rem_utk_dft_grp,rem_utk_dft_secl,rem_appc_link,rem_user_id,rem_specified,rem_failed,rem_utk_netw,rem_x500_subject,rem_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"remove"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"remove"}=0;
#Table:renameds
#delete all rows from the renameds table
$dbh->do("delete from renameds");
#Define the column names for the renameds table to Perl
my $ren_event_type;
my $ren_event_qual;
my $ren_time_written;
my $ren_date_written;
my $ren_system_smfid;
my $ren_violation;
my $ren_user_ndfnd;
my $ren_user_warning;
my $ren_evt_user_id;
my $ren_evt_grp_id;
my $ren_auth_normal;
my $ren_auth_special;
my $ren_auth_oper;
my $ren_auth_audit;
my $ren_auth_exit;
my $ren_auth_failsft;
my $ren_auth_bypass;
my $ren_auth_trusted;
my $ren_log_class;
my $ren_log_user;
my $ren_log_special;
my $ren_log_access;
my $ren_log_racinit;
my $ren_log_always;
my $ren_log_cmdviol;
my $ren_log_global;
my $ren_term_level;
my $ren_backout_fail;
my $ren_prof_same;
my $ren_term;
my $ren_job_name;
my $ren_read_time;
my $ren_read_date;
my $ren_smf_user_id;
my $ren_log_level;
my $ren_log_vmevent;
my $ren_log_logopt;
my $ren_log_secl;
my $ren_log_compatm;
my $ren_log_applaud;
my $ren_log_nonomvs;
my $ren_log_omvsnprv;
my $ren_auth_omvssu;
my $ren_auth_omvssys;
my $ren_usr_secl;
my $ren_racf_version;
my $ren_res_name;
my $ren_new_res_name;
my $ren_level;
my $ren_vol;
my $ren_class;
my $ren_own_id;
my $ren_logstr;
my $ren_user_name;
my $ren_utk_encr;
my $ren_utk_pre19;
my $ren_utk_verprof;
my $ren_utk_njeunusr;
my $ren_utk_logusr;
my $ren_utk_special;
my $ren_utk_default;
my $ren_utk_unknusr;
my $ren_utk_error;
my $ren_utk_trusted;
my $ren_utk_sesstype;
my $ren_utk_surrogat;
my $ren_utk_remote;
my $ren_utk_priv;
my $ren_utk_secl;
my $ren_utk_execnode;
my $ren_utk_suser_id;
my $ren_utk_snode;
my $ren_utk_sgrp_id;
my $ren_utk_spoe;
my $ren_utk_spclass;
my $ren_utk_user_id;
my $ren_utk_grp_id;
my $ren_utk_dft_grp;
my $ren_utk_dft_secl;
my $ren_appc_link;
my $ren_specified;
my $ren_utk_netw;
my $ren_x500_subject;
my $ren_x500_issuer;
#Create and prepare the INSERT statement for renameds
$statement="INSERT INTO renameds (ren_event_type,ren_event_qual,ren_time_written,ren_date_written,ren_system_smfid,ren_violation,ren_user_ndfnd,ren_user_warning,ren_evt_user_id,ren_evt_grp_id,ren_auth_normal,ren_auth_special,ren_auth_oper,ren_auth_audit,ren_auth_exit,ren_auth_failsft,ren_auth_bypass,ren_auth_trusted,ren_log_class,ren_log_user,ren_log_special,ren_log_access,ren_log_racinit,ren_log_always,ren_log_cmdviol,ren_log_global,ren_term_level,ren_backout_fail,ren_prof_same,ren_term,ren_job_name,ren_read_time,ren_read_date,ren_smf_user_id,ren_log_level,ren_log_vmevent,ren_log_logopt,ren_log_secl,ren_log_compatm,ren_log_applaud,ren_log_nonomvs,ren_log_omvsnprv,ren_auth_omvssu,ren_auth_omvssys,ren_usr_secl,ren_racf_version,ren_res_name,ren_new_res_name,ren_level,ren_vol,ren_class,ren_own_id,ren_logstr,ren_user_name,ren_utk_encr,ren_utk_pre19,ren_utk_verprof,ren_utk_njeunusr,ren_utk_logusr,ren_utk_special,ren_utk_default,ren_utk_unknusr,ren_utk_error,ren_utk_trusted,ren_utk_sesstype,ren_utk_surrogat,ren_utk_remote,ren_utk_priv,ren_utk_secl,ren_utk_execnode,ren_utk_suser_id,ren_utk_snode,ren_utk_sgrp_id,ren_utk_spoe,ren_utk_spclass,ren_utk_user_id,ren_utk_grp_id,ren_utk_dft_grp,ren_utk_dft_secl,ren_appc_link,ren_specified,ren_utk_netw,ren_x500_subject,ren_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"renameds"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"renameds"}=0;
#Table:renamef
#delete all rows from the renamef table
$dbh->do("delete from renamef");
#Define the column names for the renamef table to Perl
my $renf_event_type;
my $renf_event_qual;
my $renf_time_written;
my $renf_date_written;
my $renf_system_smfid;
my $renf_violation;
my $renf_user_ndfnd;
my $renf_user_warning;
my $renf_evt_user_id;
my $renf_evt_grp_id;
my $renf_auth_normal;
my $renf_auth_special;
my $renf_auth_oper;
my $renf_auth_audit;
my $renf_auth_exit;
my $renf_auth_failsft;
my $renf_auth_bypass;
my $renf_auth_trusted;
my $renf_log_class;
my $renf_log_user;
my $renf_log_special;
my $renf_log_access;
my $renf_log_racinit;
my $renf_log_always;
my $renf_log_cmdviol;
my $renf_log_global;
my $renf_term_level;
my $renf_backout_fail;
my $renf_prof_same;
my $renf_term;
my $renf_job_name;
my $renf_read_time;
my $renf_read_date;
my $renf_smf_user_id;
my $renf_log_level;
my $renf_log_vmevent;
my $renf_log_logopt;
my $renf_log_secl;
my $renf_log_compatm;
my $renf_log_applaud;
my $renf_log_nonomvs;
my $renf_log_omvsnprv;
my $renf_auth_omvssu;
my $renf_auth_omvssys;
my $renf_usr_secl;
my $renf_racf_version;
my $renf_class;
my $renf_user_name;
my $renf_utk_encr;
my $renf_utk_pre19;
my $renf_utk_verprof;
my $renf_utk_njeunusr;
my $renf_utk_logusr;
my $renf_utk_special;
my $renf_utk_default;
my $renf_utk_unknusr;
my $renf_utk_error;
my $renf_utk_trusted;
my $renf_utk_sesstype;
my $renf_utk_surrogat;
my $renf_utk_remote;
my $renf_utk_priv;
my $renf_utk_secl;
my $renf_utk_execnode;
my $renf_utk_suser_id;
my $renf_utk_snode;
my $renf_utk_sgrp_id;
my $renf_utk_spoe;
my $renf_utk_spclass;
my $renf_utk_user_id;
my $renf_utk_grp_id;
my $renf_utk_dft_grp;
my $renf_utk_dft_secl;
my $renf_appc_link;
my $renf_audit_code;
my $renf_old_real_uid;
my $renf_old_eff_uid;
my $renf_old_saved_uid;
my $renf_old_real_gid;
my $renf_old_eff_gid;
my $renf_old_saved_gid;
my $renf_path_name;
my $renf_file_id;
my $renf_file_own_uid;
my $renf_file_own_gid;
my $renf_path2;
my $renf_file_id2;
my $renf_owner_uid;
my $renf_owner_gid;
my $renf_path_type;
my $renf_last_deleted;
my $renf_filepool;
my $renf_filespace;
my $renf_inode;
my $renf_scid;
my $renf_filepool2;
my $renf_filespace2;
my $renf_inode2;
my $renf_scid2;
my $renf_dce_link;
my $renf_auth_type;
my $renf_dflt_process;
my $renf_utk_netw;
my $renf_x500_subject;
my $renf_x500_issuer;
#Create and prepare the INSERT statement for renamef
$statement="INSERT INTO renamef (renf_event_type,renf_event_qual,renf_time_written,renf_date_written,renf_system_smfid,renf_violation,renf_user_ndfnd,renf_user_warning,renf_evt_user_id,renf_evt_grp_id,renf_auth_normal,renf_auth_special,renf_auth_oper,renf_auth_audit,renf_auth_exit,renf_auth_failsft,renf_auth_bypass,renf_auth_trusted,renf_log_class,renf_log_user,renf_log_special,renf_log_access,renf_log_racinit,renf_log_always,renf_log_cmdviol,renf_log_global,renf_term_level,renf_backout_fail,renf_prof_same,renf_term,renf_job_name,renf_read_time,renf_read_date,renf_smf_user_id,renf_log_level,renf_log_vmevent,renf_log_logopt,renf_log_secl,renf_log_compatm,renf_log_applaud,renf_log_nonomvs,renf_log_omvsnprv,renf_auth_omvssu,renf_auth_omvssys,renf_usr_secl,renf_racf_version,renf_class,renf_user_name,renf_utk_encr,renf_utk_pre19,renf_utk_verprof,renf_utk_njeunusr,renf_utk_logusr,renf_utk_special,renf_utk_default,renf_utk_unknusr,renf_utk_error,renf_utk_trusted,renf_utk_sesstype,renf_utk_surrogat,renf_utk_remote,renf_utk_priv,renf_utk_secl,renf_utk_execnode,renf_utk_suser_id,renf_utk_snode,renf_utk_sgrp_id,renf_utk_spoe,renf_utk_spclass,renf_utk_user_id,renf_utk_grp_id,renf_utk_dft_grp,renf_utk_dft_secl,renf_appc_link,renf_audit_code,renf_old_real_uid,renf_old_eff_uid,renf_old_saved_uid,renf_old_real_gid,renf_old_eff_gid,renf_old_saved_gid,renf_path_name,renf_file_id,renf_file_own_uid,renf_file_own_gid,renf_path2,renf_file_id2,renf_owner_uid,renf_owner_gid,renf_path_type,renf_last_deleted,renf_filepool,renf_filespace,renf_inode,renf_scid,renf_filepool2,renf_filespace2,renf_inode2,renf_scid2,renf_dce_link,renf_auth_type,renf_dflt_process,renf_utk_netw,renf_x500_subject,renf_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"renamef"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"renamef"}=0;
#Table:rmdir
#delete all rows from the rmdir table
$dbh->do("delete from rmdir");
#Define the column names for the rmdir table to Perl
my $rdir_event_type;
my $rdir_event_qual;
my $rdir_time_written;
my $rdir_date_written;
my $rdir_system_smfid;
my $rdir_violation;
my $rdir_user_ndfnd;
my $rdir_user_warning;
my $rdir_evt_user_id;
my $rdir_evt_grp_id;
my $rdir_auth_normal;
my $rdir_auth_special;
my $rdir_auth_oper;
my $rdir_auth_audit;
my $rdir_auth_exit;
my $rdir_auth_failsft;
my $rdir_auth_bypass;
my $rdir_auth_trusted;
my $rdir_log_class;
my $rdir_log_user;
my $rdir_log_special;
my $rdir_log_access;
my $rdir_log_racinit;
my $rdir_log_always;
my $rdir_log_cmdviol;
my $rdir_log_global;
my $rdir_term_level;
my $rdir_backout_fail;
my $rdir_prof_same;
my $rdir_term;
my $rdir_job_name;
my $rdir_read_time;
my $rdir_read_date;
my $rdir_smf_user_id;
my $rdir_log_level;
my $rdir_log_vmevent;
my $rdir_log_logopt;
my $rdir_log_secl;
my $rdir_log_compatm;
my $rdir_log_applaud;
my $rdir_log_nonomvs;
my $rdir_log_omvsnprv;
my $rdir_auth_omvssu;
my $rdir_auth_omvssys;
my $rdir_usr_secl;
my $rdir_racf_version;
my $rdir_class;
my $rdir_user_name;
my $rdir_utk_encr;
my $rdir_utk_pre19;
my $rdir_utk_verprof;
my $rdir_utk_njeunusr;
my $rdir_utk_logusr;
my $rdir_utk_special;
my $rdir_utk_default;
my $rdir_utk_unknusr;
my $rdir_utk_error;
my $rdir_utk_trusted;
my $rdir_utk_sesstype;
my $rdir_utk_surrogat;
my $rdir_utk_remote;
my $rdir_utk_priv;
my $rdir_utk_secl;
my $rdir_utk_execnode;
my $rdir_utk_suser_id;
my $rdir_utk_snode;
my $rdir_utk_sgrp_id;
my $rdir_utk_spoe;
my $rdir_utk_spclass;
my $rdir_utk_user_id;
my $rdir_utk_grp_id;
my $rdir_utk_dft_grp;
my $rdir_utk_dft_secl;
my $rdir_appc_link;
my $rdir_audit_code;
my $rdir_old_real_uid;
my $rdir_old_eff_uid;
my $rdir_old_saved_uid;
my $rdir_old_real_gid;
my $rdir_old_eff_gid;
my $rdir_old_saved_gid;
my $rdir_path_name;
my $rdir_file_id;
my $rdir_file_own_uid;
my $rdir_file_own_gid;
my $rdir_filepool;
my $rdir_filespace;
my $rdir_inode;
my $rdir_scid;
my $rdir_dce_link;
my $rdir_auth_type;
my $rdir_dflt_process;
my $rdir_utk_netw;
my $rdir_x500_subject;
my $rdir_x500_issuer;
#Create and prepare the INSERT statement for rmdir
$statement="INSERT INTO rmdir (rdir_event_type,rdir_event_qual,rdir_time_written,rdir_date_written,rdir_system_smfid,rdir_violation,rdir_user_ndfnd,rdir_user_warning,rdir_evt_user_id,rdir_evt_grp_id,rdir_auth_normal,rdir_auth_special,rdir_auth_oper,rdir_auth_audit,rdir_auth_exit,rdir_auth_failsft,rdir_auth_bypass,rdir_auth_trusted,rdir_log_class,rdir_log_user,rdir_log_special,rdir_log_access,rdir_log_racinit,rdir_log_always,rdir_log_cmdviol,rdir_log_global,rdir_term_level,rdir_backout_fail,rdir_prof_same,rdir_term,rdir_job_name,rdir_read_time,rdir_read_date,rdir_smf_user_id,rdir_log_level,rdir_log_vmevent,rdir_log_logopt,rdir_log_secl,rdir_log_compatm,rdir_log_applaud,rdir_log_nonomvs,rdir_log_omvsnprv,rdir_auth_omvssu,rdir_auth_omvssys,rdir_usr_secl,rdir_racf_version,rdir_class,rdir_user_name,rdir_utk_encr,rdir_utk_pre19,rdir_utk_verprof,rdir_utk_njeunusr,rdir_utk_logusr,rdir_utk_special,rdir_utk_default,rdir_utk_unknusr,rdir_utk_error,rdir_utk_trusted,rdir_utk_sesstype,rdir_utk_surrogat,rdir_utk_remote,rdir_utk_priv,rdir_utk_secl,rdir_utk_execnode,rdir_utk_suser_id,rdir_utk_snode,rdir_utk_sgrp_id,rdir_utk_spoe,rdir_utk_spclass,rdir_utk_user_id,rdir_utk_grp_id,rdir_utk_dft_grp,rdir_utk_dft_secl,rdir_appc_link,rdir_audit_code,rdir_old_real_uid,rdir_old_eff_uid,rdir_old_saved_uid,rdir_old_real_gid,rdir_old_eff_gid,rdir_old_saved_gid,rdir_path_name,rdir_file_id,rdir_file_own_uid,rdir_file_own_gid,rdir_filepool,rdir_filespace,rdir_inode,rdir_scid,rdir_dce_link,rdir_auth_type,rdir_dflt_process,rdir_utk_netw,rdir_x500_subject,rdir_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rmdir"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rmdir"}=0;
#Table:rpkiexpt
#delete all rows from the rpkiexpt table
$dbh->do("delete from rpkiexpt");
#Define the column names for the rpkiexpt table to Perl
my $rpke_event_type;
my $rpke_event_qual;
my $rpke_time_written;
my $rpke_date_written;
my $rpke_system_smfid;
my $rpke_violation;
my $rpke_user_ndfnd;
my $rpke_user_warning;
my $rpke_evt_user_id;
my $rpke_evt_grp_id;
my $rpke_auth_normal;
my $rpke_auth_special;
my $rpke_auth_oper;
my $rpke_auth_audit;
my $rpke_auth_exit;
my $rpke_auth_failsft;
my $rpke_auth_bypass;
my $rpke_auth_trusted;
my $rpke_log_class;
my $rpke_log_user;
my $rpke_log_special;
my $rpke_log_access;
my $rpke_log_racinit;
my $rpke_log_always;
my $rpke_log_cmdviol;
my $rpke_log_global;
my $rpke_term_level;
my $rpke_backout_fail;
my $rpke_prof_same;
my $rpke_term;
my $rpke_job_name;
my $rpke_read_time;
my $rpke_read_date;
my $rpke_smf_user_id;
my $rpke_log_level;
my $rpke_log_vmevent;
my $rpke_log_logopt;
my $rpke_log_secl;
my $rpke_log_compatm;
my $rpke_log_applaud;
my $rpke_log_nonomvs;
my $rpke_log_omvsnprv;
my $rpke_auth_omvssu;
my $rpke_auth_omvssys;
my $rpke_usr_secl;
my $rpke_racf_version;
my $rpke_logstring;
my $rpke_user_name;
my $rpke_utk_encr;
my $rpke_utk_pre19;
my $rpke_utk_verprof;
my $rpke_utk_njeunusr;
my $rpke_utk_logusr;
my $rpke_utk_special;
my $rpke_utk_default;
my $rpke_utk_unknusr;
my $rpke_utk_error;
my $rpke_utk_trusted;
my $rpke_utk_sesstype;
my $rpke_utk_surrogat;
my $rpke_utk_remote;
my $rpke_utk_priv;
my $rpke_utk_secl;
my $rpke_utk_execnode;
my $rpke_utk_suser_id;
my $rpke_utk_snode;
my $rpke_utk_sgrp_id;
my $rpke_utk_spoe;
my $rpke_utk_spclass;
my $rpke_utk_user_id;
my $rpke_utk_grp_id;
my $rpke_utk_dft_grp;
my $rpke_utk_dft_secl;
my $rpke_utk_netw;
my $rpke_x500_subject;
my $rpke_x500_issuer;
my $rpke_target_userid;
my $rpke_target_label;
my $rpke_cert_id;
my $rpke_pass_phrase;
#Create and prepare the INSERT statement for rpkiexpt
$statement="INSERT INTO rpkiexpt (rpke_event_type,rpke_event_qual,rpke_time_written,rpke_date_written,rpke_system_smfid,rpke_violation,rpke_user_ndfnd,rpke_user_warning,rpke_evt_user_id,rpke_evt_grp_id,rpke_auth_normal,rpke_auth_special,rpke_auth_oper,rpke_auth_audit,rpke_auth_exit,rpke_auth_failsft,rpke_auth_bypass,rpke_auth_trusted,rpke_log_class,rpke_log_user,rpke_log_special,rpke_log_access,rpke_log_racinit,rpke_log_always,rpke_log_cmdviol,rpke_log_global,rpke_term_level,rpke_backout_fail,rpke_prof_same,rpke_term,rpke_job_name,rpke_read_time,rpke_read_date,rpke_smf_user_id,rpke_log_level,rpke_log_vmevent,rpke_log_logopt,rpke_log_secl,rpke_log_compatm,rpke_log_applaud,rpke_log_nonomvs,rpke_log_omvsnprv,rpke_auth_omvssu,rpke_auth_omvssys,rpke_usr_secl,rpke_racf_version,rpke_logstring,rpke_user_name,rpke_utk_encr,rpke_utk_pre19,rpke_utk_verprof,rpke_utk_njeunusr,rpke_utk_logusr,rpke_utk_special,rpke_utk_default,rpke_utk_unknusr,rpke_utk_error,rpke_utk_trusted,rpke_utk_sesstype,rpke_utk_surrogat,rpke_utk_remote,rpke_utk_priv,rpke_utk_secl,rpke_utk_execnode,rpke_utk_suser_id,rpke_utk_snode,rpke_utk_sgrp_id,rpke_utk_spoe,rpke_utk_spclass,rpke_utk_user_id,rpke_utk_grp_id,rpke_utk_dft_grp,rpke_utk_dft_secl,rpke_utk_netw,rpke_x500_subject,rpke_x500_issuer,rpke_target_userid,rpke_target_label,rpke_cert_id,rpke_pass_phrase) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rpkiexpt"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rpkiexpt"}=0;
#Table:rpkigenc
#delete all rows from the rpkigenc table
$dbh->do("delete from rpkigenc");
#Define the column names for the rpkigenc table to Perl
my $rpkg_event_type;
my $rpkg_event_qual;
my $rpkg_time_written;
my $rpkg_date_written;
my $rpkg_system_smfid;
my $rpkg_violation;
my $rpkg_user_ndfnd;
my $rpkg_user_warning;
my $rpkg_evt_user_id;
my $rpkg_evt_grp_id;
my $rpkg_auth_normal;
my $rpkg_auth_special;
my $rpkg_auth_oper;
my $rpkg_auth_audit;
my $rpkg_auth_exit;
my $rpkg_auth_failsft;
my $rpkg_auth_bypass;
my $rpkg_auth_trusted;
my $rpkg_log_class;
my $rpkg_log_user;
my $rpkg_log_special;
my $rpkg_log_access;
my $rpkg_log_racinit;
my $rpkg_log_always;
my $rpkg_log_cmdviol;
my $rpkg_log_global;
my $rpkg_term_level;
my $rpkg_backout_fail;
my $rpkg_prof_same;
my $rpkg_term;
my $rpkg_job_name;
my $rpkg_read_time;
my $rpkg_read_date;
my $rpkg_smf_user_id;
my $rpkg_log_level;
my $rpkg_log_vmevent;
my $rpkg_log_logopt;
my $rpkg_log_secl;
my $rpkg_log_compatm;
my $rpkg_log_applaud;
my $rpkg_log_nonomvs;
my $rpkg_log_omvsnprv;
my $rpkg_auth_omvssu;
my $rpkg_auth_omvssys;
my $rpkg_usr_secl;
my $rpkg_racf_version;
my $rpkg_logstring;
my $rpkg_user_name;
my $rpkg_utk_encr;
my $rpkg_utk_pre19;
my $rpkg_utk_verprof;
my $rpkg_utk_njeunusr;
my $rpkg_utk_logusr;
my $rpkg_utk_special;
my $rpkg_utk_default;
my $rpkg_utk_unknusr;
my $rpkg_utk_error;
my $rpkg_utk_trusted;
my $rpkg_utk_sesstype;
my $rpkg_utk_surrogat;
my $rpkg_utk_remote;
my $rpkg_utk_priv;
my $rpkg_utk_secl;
my $rpkg_utk_execnode;
my $rpkg_utk_suser_id;
my $rpkg_utk_snode;
my $rpkg_utk_sgrp_id;
my $rpkg_utk_spoe;
my $rpkg_utk_spclass;
my $rpkg_utk_user_id;
my $rpkg_utk_grp_id;
my $rpkg_utk_dft_grp;
my $rpkg_utk_dft_secl;
my $rpkg_serial_number;
my $rpkg_issuers_dn;
my $rpkg_utk_netw;
my $rpkg_x500_subject;
my $rpkg_x500_issuer;
my $rpkg_keyusage;
my $rpkg_notbefor_date;
my $rpkg_notafter_date;
my $rpkg_target_userid;
my $rpkg_target_label;
my $rpkg_signwith;
my $rpkg_subjects_dn;
my $rpkg_alt_ip;
my $rpkg_alt_uri;
my $rpkg_alt_email;
my $rpkg_alt_domain;
my $rpkg_cert_id;
my $rpkg_hostid_map;
my $rpkg_requestor;
my $rpkg_pass_phrase;
my $rpkg_notify_email;
#Create and prepare the INSERT statement for rpkigenc
$statement="INSERT INTO rpkigenc (rpkg_event_type,rpkg_event_qual,rpkg_time_written,rpkg_date_written,rpkg_system_smfid,rpkg_violation,rpkg_user_ndfnd,rpkg_user_warning,rpkg_evt_user_id,rpkg_evt_grp_id,rpkg_auth_normal,rpkg_auth_special,rpkg_auth_oper,rpkg_auth_audit,rpkg_auth_exit,rpkg_auth_failsft,rpkg_auth_bypass,rpkg_auth_trusted,rpkg_log_class,rpkg_log_user,rpkg_log_special,rpkg_log_access,rpkg_log_racinit,rpkg_log_always,rpkg_log_cmdviol,rpkg_log_global,rpkg_term_level,rpkg_backout_fail,rpkg_prof_same,rpkg_term,rpkg_job_name,rpkg_read_time,rpkg_read_date,rpkg_smf_user_id,rpkg_log_level,rpkg_log_vmevent,rpkg_log_logopt,rpkg_log_secl,rpkg_log_compatm,rpkg_log_applaud,rpkg_log_nonomvs,rpkg_log_omvsnprv,rpkg_auth_omvssu,rpkg_auth_omvssys,rpkg_usr_secl,rpkg_racf_version,rpkg_logstring,rpkg_user_name,rpkg_utk_encr,rpkg_utk_pre19,rpkg_utk_verprof,rpkg_utk_njeunusr,rpkg_utk_logusr,rpkg_utk_special,rpkg_utk_default,rpkg_utk_unknusr,rpkg_utk_error,rpkg_utk_trusted,rpkg_utk_sesstype,rpkg_utk_surrogat,rpkg_utk_remote,rpkg_utk_priv,rpkg_utk_secl,rpkg_utk_execnode,rpkg_utk_suser_id,rpkg_utk_snode,rpkg_utk_sgrp_id,rpkg_utk_spoe,rpkg_utk_spclass,rpkg_utk_user_id,rpkg_utk_grp_id,rpkg_utk_dft_grp,rpkg_utk_dft_secl,rpkg_serial_number,rpkg_issuers_dn,rpkg_utk_netw,rpkg_x500_subject,rpkg_x500_issuer,rpkg_keyusage,rpkg_notbefor_date,rpkg_notafter_date,rpkg_target_userid,rpkg_target_label,rpkg_signwith,rpkg_subjects_dn,rpkg_alt_ip,rpkg_alt_uri,rpkg_alt_email,rpkg_alt_domain,rpkg_cert_id,rpkg_hostid_map,rpkg_requestor,rpkg_pass_phrase,rpkg_notify_email) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rpkigenc"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rpkigenc"}=0;
#Table:rpkiread
#delete all rows from the rpkiread table
$dbh->do("delete from rpkiread");
#Define the column names for the rpkiread table to Perl
my $rpkr_event_type;
my $rpkr_event_qual;
my $rpkr_time_written;
my $rpkr_date_written;
my $rpkr_system_smfid;
my $rpkr_violation;
my $rpkr_user_ndfnd;
my $rpkr_user_warning;
my $rpkr_evt_user_id;
my $rpkr_evt_grp_id;
my $rpkr_auth_normal;
my $rpkr_auth_special;
my $rpkr_auth_oper;
my $rpkr_auth_audit;
my $rpkr_auth_exit;
my $rpkr_auth_failsft;
my $rpkr_auth_bypass;
my $rpkr_auth_trusted;
my $rpkr_log_class;
my $rpkr_log_user;
my $rpkr_log_special;
my $rpkr_log_access;
my $rpkr_log_racinit;
my $rpkr_log_always;
my $rpkr_log_cmdviol;
my $rpkr_log_global;
my $rpkr_term_level;
my $rpkr_backout_fail;
my $rpkr_prof_same;
my $rpkr_term;
my $rpkr_job_name;
my $rpkr_read_time;
my $rpkr_read_date;
my $rpkr_smf_user_id;
my $rpkr_log_level;
my $rpkr_log_vmevent;
my $rpkr_log_logopt;
my $rpkr_log_secl;
my $rpkr_log_compatm;
my $rpkr_log_applaud;
my $rpkr_log_nonomvs;
my $rpkr_log_omvsnprv;
my $rpkr_auth_omvssu;
my $rpkr_auth_omvssys;
my $rpkr_usr_secl;
my $rpkr_racf_version;
my $rpkr_appl;
my $rpkr_logstring;
my $rpkr_user_name;
my $rpkr_utk_encr;
my $rpkr_utk_pre19;
my $rpkr_utk_verprof;
my $rpkr_utk_njeunusr;
my $rpkr_utk_logusr;
my $rpkr_utk_special;
my $rpkr_utk_default;
my $rpkr_utk_unknusr;
my $rpkr_utk_error;
my $rpkr_utk_trusted;
my $rpkr_utk_sesstype;
my $rpkr_utk_surrogat;
my $rpkr_utk_remote;
my $rpkr_utk_priv;
my $rpkr_utk_secl;
my $rpkr_utk_execnode;
my $rpkr_utk_suser_id;
my $rpkr_utk_snode;
my $rpkr_utk_sgrp_id;
my $rpkr_utk_spoe;
my $rpkr_utk_spclass;
my $rpkr_utk_user_id;
my $rpkr_utk_grp_id;
my $rpkr_utk_dft_grp;
my $rpkr_utk_dft_secl;
my $rpkr_serial_number;
my $rpkr_issuers_dn;
my $rpkr_utk_netw;
my $rpkr_x500_subject;
my $rpkr_x500_issuer;
my $rpkr_keyusage;
my $rpkr_notbefor_date;
my $rpkr_notafter_date;
my $rpkr_subjects_dn;
my $rpkr_cert_id;
my $rpkr_requestor;
my $rpkr_status;
my $rpkr_creation_date;
my $rpkr_last_mod_date;
my $rpkr_prev_serial;
my $rpkr_notify_email;
#Create and prepare the INSERT statement for rpkiread
$statement="INSERT INTO rpkiread (rpkr_event_type,rpkr_event_qual,rpkr_time_written,rpkr_date_written,rpkr_system_smfid,rpkr_violation,rpkr_user_ndfnd,rpkr_user_warning,rpkr_evt_user_id,rpkr_evt_grp_id,rpkr_auth_normal,rpkr_auth_special,rpkr_auth_oper,rpkr_auth_audit,rpkr_auth_exit,rpkr_auth_failsft,rpkr_auth_bypass,rpkr_auth_trusted,rpkr_log_class,rpkr_log_user,rpkr_log_special,rpkr_log_access,rpkr_log_racinit,rpkr_log_always,rpkr_log_cmdviol,rpkr_log_global,rpkr_term_level,rpkr_backout_fail,rpkr_prof_same,rpkr_term,rpkr_job_name,rpkr_read_time,rpkr_read_date,rpkr_smf_user_id,rpkr_log_level,rpkr_log_vmevent,rpkr_log_logopt,rpkr_log_secl,rpkr_log_compatm,rpkr_log_applaud,rpkr_log_nonomvs,rpkr_log_omvsnprv,rpkr_auth_omvssu,rpkr_auth_omvssys,rpkr_usr_secl,rpkr_racf_version,rpkr_appl,rpkr_logstring,rpkr_user_name,rpkr_utk_encr,rpkr_utk_pre19,rpkr_utk_verprof,rpkr_utk_njeunusr,rpkr_utk_logusr,rpkr_utk_special,rpkr_utk_default,rpkr_utk_unknusr,rpkr_utk_error,rpkr_utk_trusted,rpkr_utk_sesstype,rpkr_utk_surrogat,rpkr_utk_remote,rpkr_utk_priv,rpkr_utk_secl,rpkr_utk_execnode,rpkr_utk_suser_id,rpkr_utk_snode,rpkr_utk_sgrp_id,rpkr_utk_spoe,rpkr_utk_spclass,rpkr_utk_user_id,rpkr_utk_grp_id,rpkr_utk_dft_grp,rpkr_utk_dft_secl,rpkr_serial_number,rpkr_issuers_dn,rpkr_utk_netw,rpkr_x500_subject,rpkr_x500_issuer,rpkr_keyusage,rpkr_notbefor_date,rpkr_notafter_date,rpkr_subjects_dn,rpkr_cert_id,rpkr_requestor,rpkr_status,rpkr_creation_date,rpkr_last_mod_date,rpkr_prev_serial,rpkr_notify_email) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rpkiread"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rpkiread"}=0;
#Table:rpkiupdc
#delete all rows from the rpkiupdc table
$dbh->do("delete from rpkiupdc");
#Define the column names for the rpkiupdc table to Perl
my $rpkc_event_type;
my $rpkc_event_qual;
my $rpkc_time_written;
my $rpkc_date_written;
my $rpkc_system_smfid;
my $rpkc_violation;
my $rpkc_user_ndfnd;
my $rpkc_user_warning;
my $rpkc_evt_user_id;
my $rpkc_evt_grp_id;
my $rpkc_auth_normal;
my $rpkc_auth_special;
my $rpkc_auth_oper;
my $rpkc_auth_audit;
my $rpkc_auth_exit;
my $rpkc_auth_failsft;
my $rpkc_auth_bypass;
my $rpkc_auth_trusted;
my $rpkc_log_class;
my $rpkc_log_user;
my $rpkc_log_special;
my $rpkc_log_access;
my $rpkc_log_racinit;
my $rpkc_log_always;
my $rpkc_log_cmdviol;
my $rpkc_log_global;
my $rpkc_term_level;
my $rpkc_backout_fail;
my $rpkc_prof_same;
my $rpkc_term;
my $rpkc_job_name;
my $rpkc_read_time;
my $rpkc_read_date;
my $rpkc_smf_user_id;
my $rpkc_log_level;
my $rpkc_log_vmevent;
my $rpkc_log_logopt;
my $rpkc_log_secl;
my $rpkc_log_compatm;
my $rpkc_log_applaud;
my $rpkc_log_nonomvs;
my $rpkc_log_omvsnprv;
my $rpkc_auth_omvssu;
my $rpkc_auth_omvssys;
my $rpkc_usr_secl;
my $rpkc_racf_version;
my $rpkc_logstring;
my $rpkc_user_name;
my $rpkc_utk_encr;
my $rpkc_utk_pre19;
my $rpkc_utk_verprof;
my $rpkc_utk_njeunusr;
my $rpkc_utk_logusr;
my $rpkc_utk_special;
my $rpkc_utk_default;
my $rpkc_utk_unknusr;
my $rpkc_utk_error;
my $rpkc_utk_trusted;
my $rpkc_utk_sesstype;
my $rpkc_utk_surrogat;
my $rpkc_utk_remote;
my $rpkc_utk_priv;
my $rpkc_utk_secl;
my $rpkc_utk_execnode;
my $rpkc_utk_suser_id;
my $rpkc_utk_snode;
my $rpkc_utk_sgrp_id;
my $rpkc_utk_spoe;
my $rpkc_utk_spclass;
my $rpkc_utk_user_id;
my $rpkc_utk_grp_id;
my $rpkc_utk_dft_grp;
my $rpkc_utk_dft_secl;
my $rpkc_serial_number;
my $rpkc_utk_netw;
my $rpkc_x500_subject;
my $rpkc_x500_issuer;
my $rpkc_action;
my $rpkc_action_com;
my $rpkc_revoke_rsn;
#Create and prepare the INSERT statement for rpkiupdc
$statement="INSERT INTO rpkiupdc (rpkc_event_type,rpkc_event_qual,rpkc_time_written,rpkc_date_written,rpkc_system_smfid,rpkc_violation,rpkc_user_ndfnd,rpkc_user_warning,rpkc_evt_user_id,rpkc_evt_grp_id,rpkc_auth_normal,rpkc_auth_special,rpkc_auth_oper,rpkc_auth_audit,rpkc_auth_exit,rpkc_auth_failsft,rpkc_auth_bypass,rpkc_auth_trusted,rpkc_log_class,rpkc_log_user,rpkc_log_special,rpkc_log_access,rpkc_log_racinit,rpkc_log_always,rpkc_log_cmdviol,rpkc_log_global,rpkc_term_level,rpkc_backout_fail,rpkc_prof_same,rpkc_term,rpkc_job_name,rpkc_read_time,rpkc_read_date,rpkc_smf_user_id,rpkc_log_level,rpkc_log_vmevent,rpkc_log_logopt,rpkc_log_secl,rpkc_log_compatm,rpkc_log_applaud,rpkc_log_nonomvs,rpkc_log_omvsnprv,rpkc_auth_omvssu,rpkc_auth_omvssys,rpkc_usr_secl,rpkc_racf_version,rpkc_logstring,rpkc_user_name,rpkc_utk_encr,rpkc_utk_pre19,rpkc_utk_verprof,rpkc_utk_njeunusr,rpkc_utk_logusr,rpkc_utk_special,rpkc_utk_default,rpkc_utk_unknusr,rpkc_utk_error,rpkc_utk_trusted,rpkc_utk_sesstype,rpkc_utk_surrogat,rpkc_utk_remote,rpkc_utk_priv,rpkc_utk_secl,rpkc_utk_execnode,rpkc_utk_suser_id,rpkc_utk_snode,rpkc_utk_sgrp_id,rpkc_utk_spoe,rpkc_utk_spclass,rpkc_utk_user_id,rpkc_utk_grp_id,rpkc_utk_dft_grp,rpkc_utk_dft_secl,rpkc_serial_number,rpkc_utk_netw,rpkc_x500_subject,rpkc_x500_issuer,rpkc_action,rpkc_action_com,rpkc_revoke_rsn) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rpkiupdc"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rpkiupdc"}=0;
#Table:rpkiupdr
#delete all rows from the rpkiupdr table
$dbh->do("delete from rpkiupdr");
#Define the column names for the rpkiupdr table to Perl
my $rpku_event_type;
my $rpku_event_qual;
my $rpku_time_written;
my $rpku_date_written;
my $rpku_system_smfid;
my $rpku_violation;
my $rpku_user_ndfnd;
my $rpku_user_warning;
my $rpku_evt_user_id;
my $rpku_evt_grp_id;
my $rpku_auth_normal;
my $rpku_auth_special;
my $rpku_auth_oper;
my $rpku_auth_audit;
my $rpku_auth_exit;
my $rpku_auth_failsft;
my $rpku_auth_bypass;
my $rpku_auth_trusted;
my $rpku_log_class;
my $rpku_log_user;
my $rpku_log_special;
my $rpku_log_access;
my $rpku_log_racinit;
my $rpku_log_always;
my $rpku_log_cmdviol;
my $rpku_log_global;
my $rpku_term_level;
my $rpku_backout_fail;
my $rpku_prof_same;
my $rpku_term;
my $rpku_job_name;
my $rpku_read_time;
my $rpku_read_date;
my $rpku_smf_user_id;
my $rpku_log_level;
my $rpku_log_vmevent;
my $rpku_log_logopt;
my $rpku_log_secl;
my $rpku_log_compatm;
my $rpku_log_applaud;
my $rpku_log_nonomvs;
my $rpku_log_omvsnprv;
my $rpku_auth_omvssu;
my $rpku_auth_omvssys;
my $rpku_usr_secl;
my $rpku_racf_version;
my $rpku_logstring;
my $rpku_user_name;
my $rpku_utk_encr;
my $rpku_utk_pre19;
my $rpku_utk_verprof;
my $rpku_utk_njeunusr;
my $rpku_utk_logusr;
my $rpku_utk_special;
my $rpku_utk_default;
my $rpku_utk_unknusr;
my $rpku_utk_error;
my $rpku_utk_trusted;
my $rpku_utk_sesstype;
my $rpku_utk_surrogat;
my $rpku_utk_remote;
my $rpku_utk_priv;
my $rpku_utk_secl;
my $rpku_utk_execnode;
my $rpku_utk_suser_id;
my $rpku_utk_snode;
my $rpku_utk_sgrp_id;
my $rpku_utk_spoe;
my $rpku_utk_spclass;
my $rpku_utk_user_id;
my $rpku_utk_grp_id;
my $rpku_utk_dft_grp;
my $rpku_utk_dft_secl;
my $rpku_utk_netw;
my $rpku_x500_subject;
my $rpku_x500_issuer;
my $rpku_keyusage;
my $rpku_notbefor_date;
my $rpku_notafter_date;
my $rpku_subjects_dn;
my $rpku_alt_ip;
my $rpku_alt_uri;
my $rpku_alt_email;
my $rpku_alt_domain;
my $rpku_cert_id;
my $rpku_hostid_map;
my $rpku_action;
my $rpku_action_com;
#Create and prepare the INSERT statement for rpkiupdr
$statement="INSERT INTO rpkiupdr (rpku_event_type,rpku_event_qual,rpku_time_written,rpku_date_written,rpku_system_smfid,rpku_violation,rpku_user_ndfnd,rpku_user_warning,rpku_evt_user_id,rpku_evt_grp_id,rpku_auth_normal,rpku_auth_special,rpku_auth_oper,rpku_auth_audit,rpku_auth_exit,rpku_auth_failsft,rpku_auth_bypass,rpku_auth_trusted,rpku_log_class,rpku_log_user,rpku_log_special,rpku_log_access,rpku_log_racinit,rpku_log_always,rpku_log_cmdviol,rpku_log_global,rpku_term_level,rpku_backout_fail,rpku_prof_same,rpku_term,rpku_job_name,rpku_read_time,rpku_read_date,rpku_smf_user_id,rpku_log_level,rpku_log_vmevent,rpku_log_logopt,rpku_log_secl,rpku_log_compatm,rpku_log_applaud,rpku_log_nonomvs,rpku_log_omvsnprv,rpku_auth_omvssu,rpku_auth_omvssys,rpku_usr_secl,rpku_racf_version,rpku_logstring,rpku_user_name,rpku_utk_encr,rpku_utk_pre19,rpku_utk_verprof,rpku_utk_njeunusr,rpku_utk_logusr,rpku_utk_special,rpku_utk_default,rpku_utk_unknusr,rpku_utk_error,rpku_utk_trusted,rpku_utk_sesstype,rpku_utk_surrogat,rpku_utk_remote,rpku_utk_priv,rpku_utk_secl,rpku_utk_execnode,rpku_utk_suser_id,rpku_utk_snode,rpku_utk_sgrp_id,rpku_utk_spoe,rpku_utk_spclass,rpku_utk_user_id,rpku_utk_grp_id,rpku_utk_dft_grp,rpku_utk_dft_secl,rpku_utk_netw,rpku_x500_subject,rpku_x500_issuer,rpku_keyusage,rpku_notbefor_date,rpku_notafter_date,rpku_subjects_dn,rpku_alt_ip,rpku_alt_uri,rpku_alt_email,rpku_alt_domain,rpku_cert_id,rpku_hostid_map,rpku_action,rpku_action_com) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rpkiupdr"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rpkiupdr"}=0;
#Table:rvary
#delete all rows from the rvary table
$dbh->do("delete from rvary");
#Define the column names for the rvary table to Perl
my $rvar_event_type;
my $rvar_event_qual;
my $rvar_time_written;
my $rvar_date_written;
my $rvar_system_smfid;
my $rvar_violation;
my $rvar_user_ndfnd;
my $rvar_user_warning;
my $rvar_evt_user_id;
my $rvar_evt_grp_id;
my $rvar_auth_normal;
my $rvar_auth_special;
my $rvar_auth_oper;
my $rvar_auth_audit;
my $rvar_auth_exit;
my $rvar_auth_failsft;
my $rvar_auth_bypass;
my $rvar_auth_trusted;
my $rvar_log_class;
my $rvar_log_user;
my $rvar_log_special;
my $rvar_log_access;
my $rvar_log_racinit;
my $rvar_log_always;
my $rvar_log_cmdviol;
my $rvar_log_global;
my $rvar_term_level;
my $rvar_backout_fail;
my $rvar_prof_same;
my $rvar_term;
my $rvar_job_name;
my $rvar_read_time;
my $rvar_read_date;
my $rvar_smf_user_id;
my $rvar_log_level;
my $rvar_log_vmevent;
my $rvar_log_logopt;
my $rvar_log_secl;
my $rvar_log_compatm;
my $rvar_log_applaud;
my $rvar_log_nonomvs;
my $rvar_log_omvsnprv;
my $rvar_auth_omvssu;
my $rvar_auth_omvssys;
my $rvar_usr_secl;
my $rvar_racf_version;
my $rvar_user_name;
my $rvar_utk_encr;
my $rvar_utk_pre19;
my $rvar_utk_verprof;
my $rvar_utk_njeunusr;
my $rvar_utk_logusr;
my $rvar_utk_special;
my $rvar_utk_default;
my $rvar_utk_unknusr;
my $rvar_utk_error;
my $rvar_utk_trusted;
my $rvar_utk_sesstype;
my $rvar_utk_surrogat;
my $rvar_utk_remove;
my $rvar_utk_priv;
my $rvar_utk_secl;
my $rvar_utk_execnode;
my $rvar_utk_suser_id;
my $rvar_utk_snode;
my $rvar_utk_sgrp_id;
my $rvar_utk_spoe;
my $rvar_utk_spclass;
my $rvar_utk_user_id;
my $rvar_utk_grp_id;
my $rvar_utk_dft_grp;
my $rvar_utk_dft_secl;
my $rvar_appc_link;
my $rvar_specified;
my $rvar_failed;
my $rvar_utk_netw;
my $rvar_x500_subject;
my $rvar_x500_issuer;
#Create and prepare the INSERT statement for rvary
$statement="INSERT INTO rvary (rvar_event_type,rvar_event_qual,rvar_time_written,rvar_date_written,rvar_system_smfid,rvar_violation,rvar_user_ndfnd,rvar_user_warning,rvar_evt_user_id,rvar_evt_grp_id,rvar_auth_normal,rvar_auth_special,rvar_auth_oper,rvar_auth_audit,rvar_auth_exit,rvar_auth_failsft,rvar_auth_bypass,rvar_auth_trusted,rvar_log_class,rvar_log_user,rvar_log_special,rvar_log_access,rvar_log_racinit,rvar_log_always,rvar_log_cmdviol,rvar_log_global,rvar_term_level,rvar_backout_fail,rvar_prof_same,rvar_term,rvar_job_name,rvar_read_time,rvar_read_date,rvar_smf_user_id,rvar_log_level,rvar_log_vmevent,rvar_log_logopt,rvar_log_secl,rvar_log_compatm,rvar_log_applaud,rvar_log_nonomvs,rvar_log_omvsnprv,rvar_auth_omvssu,rvar_auth_omvssys,rvar_usr_secl,rvar_racf_version,rvar_user_name,rvar_utk_encr,rvar_utk_pre19,rvar_utk_verprof,rvar_utk_njeunusr,rvar_utk_logusr,rvar_utk_special,rvar_utk_default,rvar_utk_unknusr,rvar_utk_error,rvar_utk_trusted,rvar_utk_sesstype,rvar_utk_surrogat,rvar_utk_remove,rvar_utk_priv,rvar_utk_secl,rvar_utk_execnode,rvar_utk_suser_id,rvar_utk_snode,rvar_utk_sgrp_id,rvar_utk_spoe,rvar_utk_spclass,rvar_utk_user_id,rvar_utk_grp_id,rvar_utk_dft_grp,rvar_utk_dft_secl,rvar_appc_link,rvar_specified,rvar_failed,rvar_utk_netw,rvar_x500_subject,rvar_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"rvary"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"rvary"}=0;
#Table:setegid
#delete all rows from the setegid table
$dbh->do("delete from setegid");
#Define the column names for the setegid table to Perl
my $segi_event_type;
my $segi_event_qual;
my $segi_time_written;
my $segi_date_written;
my $segi_system_smfid;
my $segi_violation;
my $segi_user_ndfnd;
my $segi_user_warning;
my $segi_evt_user_id;
my $segi_evt_grp_id;
my $segi_auth_normal;
my $segi_auth_special;
my $segi_auth_oper;
my $segi_auth_audit;
my $segi_auth_exit;
my $segi_auth_failsft;
my $segi_auth_bypass;
my $segi_auth_trusted;
my $segi_log_class;
my $segi_log_user;
my $segi_log_special;
my $segi_log_access;
my $segi_log_racinit;
my $segi_log_always;
my $segi_log_cmdviol;
my $segi_log_global;
my $segi_term_level;
my $segi_backout_fail;
my $segi_prof_same;
my $segi_term;
my $segi_job_name;
my $segi_read_time;
my $segi_read_date;
my $segi_smf_user_id;
my $segi_log_level;
my $segi_log_vmevent;
my $segi_log_logopt;
my $segi_log_secl;
my $segi_log_compatm;
my $segi_log_applaud;
my $segi_log_nonomvs;
my $segi_log_omvsnprv;
my $segi_auth_omvssu;
my $segi_auth_omvssys;
my $segi_usr_secl;
my $segi_racf_version;
my $segi_class;
my $segi_user_name;
my $segi_utk_encr;
my $segi_utk_pre19;
my $segi_utk_verprof;
my $segi_utk_njeunusr;
my $segi_utk_logusr;
my $segi_utk_special;
my $segi_utk_default;
my $segi_utk_unknusr;
my $segi_utk_error;
my $segi_utk_trusted;
my $segi_utk_sesstype;
my $segi_utk_surrogat;
my $segi_utk_remote;
my $segi_utk_priv;
my $segi_utk_secl;
my $segi_utk_execnode;
my $segi_utk_suser_id;
my $segi_utk_snode;
my $segi_utk_sgrp_id;
my $segi_utk_spoe;
my $segi_utk_spclass;
my $segi_utk_user_id;
my $segi_utk_grp_id;
my $segi_utk_dft_grp;
my $segi_utk_dft_secl;
my $segi_appc_link;
my $segi_audit_code;
my $segi_old_real_uid;
my $segi_old_eff_uid;
my $segi_old_saved_uid;
my $segi_old_real_gid;
my $segi_old_eff_gid;
my $segi_old_saved_gid;
my $segi_new_real_gid;
my $segi_new_eff_gid;
my $segi_new_saved_gid;
my $segi_gid;
my $segi_dflt_process;
my $segi_utk_netw;
my $segi_x500_subject;
my $segi_x500_issuer;
#Create and prepare the INSERT statement for setegid
$statement="INSERT INTO setegid (segi_event_type,segi_event_qual,segi_time_written,segi_date_written,segi_system_smfid,segi_violation,segi_user_ndfnd,segi_user_warning,segi_evt_user_id,segi_evt_grp_id,segi_auth_normal,segi_auth_special,segi_auth_oper,segi_auth_audit,segi_auth_exit,segi_auth_failsft,segi_auth_bypass,segi_auth_trusted,segi_log_class,segi_log_user,segi_log_special,segi_log_access,segi_log_racinit,segi_log_always,segi_log_cmdviol,segi_log_global,segi_term_level,segi_backout_fail,segi_prof_same,segi_term,segi_job_name,segi_read_time,segi_read_date,segi_smf_user_id,segi_log_level,segi_log_vmevent,segi_log_logopt,segi_log_secl,segi_log_compatm,segi_log_applaud,segi_log_nonomvs,segi_log_omvsnprv,segi_auth_omvssu,segi_auth_omvssys,segi_usr_secl,segi_racf_version,segi_class,segi_user_name,segi_utk_encr,segi_utk_pre19,segi_utk_verprof,segi_utk_njeunusr,segi_utk_logusr,segi_utk_special,segi_utk_default,segi_utk_unknusr,segi_utk_error,segi_utk_trusted,segi_utk_sesstype,segi_utk_surrogat,segi_utk_remote,segi_utk_priv,segi_utk_secl,segi_utk_execnode,segi_utk_suser_id,segi_utk_snode,segi_utk_sgrp_id,segi_utk_spoe,segi_utk_spclass,segi_utk_user_id,segi_utk_grp_id,segi_utk_dft_grp,segi_utk_dft_secl,segi_appc_link,segi_audit_code,segi_old_real_uid,segi_old_eff_uid,segi_old_saved_uid,segi_old_real_gid,segi_old_eff_gid,segi_old_saved_gid,segi_new_real_gid,segi_new_eff_gid,segi_new_saved_gid,segi_gid,segi_dflt_process,segi_utk_netw,segi_x500_subject,segi_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setegid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setegid"}=0;
#Table:seteuid
#delete all rows from the seteuid table
$dbh->do("delete from seteuid");
#Define the column names for the seteuid table to Perl
my $seui_event_type;
my $seui_event_qual;
my $seui_time_written;
my $seui_date_written;
my $seui_system_smfid;
my $seui_violation;
my $seui_user_ndfnd;
my $seui_user_warning;
my $seui_evt_user_id;
my $seui_evt_grp_id;
my $seui_auth_normal;
my $seui_auth_special;
my $seui_auth_oper;
my $seui_auth_audit;
my $seui_auth_exit;
my $seui_auth_failsft;
my $seui_auth_bypass;
my $seui_auth_trusted;
my $seui_log_class;
my $seui_log_user;
my $seui_log_special;
my $seui_log_access;
my $seui_log_racinit;
my $seui_log_always;
my $seui_log_cmdviol;
my $seui_log_global;
my $seui_term_level;
my $seui_backout_fail;
my $seui_prof_same;
my $seui_term;
my $seui_job_name;
my $seui_read_time;
my $seui_read_date;
my $seui_smf_user_id;
my $seui_log_level;
my $seui_log_vmevent;
my $seui_log_logopt;
my $seui_log_secl;
my $seui_log_compatm;
my $seui_log_applaud;
my $seui_log_nonomvs;
my $seui_log_omvsnprv;
my $seui_auth_omvssu;
my $seui_auth_omvssys;
my $seui_usr_secl;
my $seui_racf_version;
my $seui_class;
my $seui_user_name;
my $seui_utk_encr;
my $seui_utk_pre19;
my $seui_utk_verprof;
my $seui_utk_njeunusr;
my $seui_utk_logusr;
my $seui_utk_special;
my $seui_utk_default;
my $seui_utk_unknusr;
my $seui_utk_error;
my $seui_utk_trusted;
my $seui_utk_sesstype;
my $seui_utk_surrogat;
my $seui_utk_remote;
my $seui_utk_priv;
my $seui_utk_secl;
my $seui_utk_execnode;
my $seui_utk_suser_id;
my $seui_utk_snode;
my $seui_utk_sgrp_id;
my $seui_utk_spoe;
my $seui_utk_spclass;
my $seui_utk_user_id;
my $seui_utk_grp_id;
my $seui_utk_dft_grp;
my $seui_utk_dft_secl;
my $seui_appc_link;
my $seui_audit_code;
my $seui_old_real_uid;
my $seui_old_eff_uid;
my $seui_old_saved_uid;
my $seui_old_real_gid;
my $seui_old_eff_gid;
my $seui_old_saved_gid;
my $seui_new_real_uid;
my $seui_new_eff_uid;
my $seui_new_saved_uid;
my $seui_uid;
my $seui_dflt_process;
my $seui_utk_netw;
my $seui_x500_subject;
my $seui_x500_issuer;
#Create and prepare the INSERT statement for seteuid
$statement="INSERT INTO seteuid (seui_event_type,seui_event_qual,seui_time_written,seui_date_written,seui_system_smfid,seui_violation,seui_user_ndfnd,seui_user_warning,seui_evt_user_id,seui_evt_grp_id,seui_auth_normal,seui_auth_special,seui_auth_oper,seui_auth_audit,seui_auth_exit,seui_auth_failsft,seui_auth_bypass,seui_auth_trusted,seui_log_class,seui_log_user,seui_log_special,seui_log_access,seui_log_racinit,seui_log_always,seui_log_cmdviol,seui_log_global,seui_term_level,seui_backout_fail,seui_prof_same,seui_term,seui_job_name,seui_read_time,seui_read_date,seui_smf_user_id,seui_log_level,seui_log_vmevent,seui_log_logopt,seui_log_secl,seui_log_compatm,seui_log_applaud,seui_log_nonomvs,seui_log_omvsnprv,seui_auth_omvssu,seui_auth_omvssys,seui_usr_secl,seui_racf_version,seui_class,seui_user_name,seui_utk_encr,seui_utk_pre19,seui_utk_verprof,seui_utk_njeunusr,seui_utk_logusr,seui_utk_special,seui_utk_default,seui_utk_unknusr,seui_utk_error,seui_utk_trusted,seui_utk_sesstype,seui_utk_surrogat,seui_utk_remote,seui_utk_priv,seui_utk_secl,seui_utk_execnode,seui_utk_suser_id,seui_utk_snode,seui_utk_sgrp_id,seui_utk_spoe,seui_utk_spclass,seui_utk_user_id,seui_utk_grp_id,seui_utk_dft_grp,seui_utk_dft_secl,seui_appc_link,seui_audit_code,seui_old_real_uid,seui_old_eff_uid,seui_old_saved_uid,seui_old_real_gid,seui_old_eff_gid,seui_old_saved_gid,seui_new_real_uid,seui_new_eff_uid,seui_new_saved_uid,seui_uid,seui_dflt_process,seui_utk_netw,seui_x500_subject,seui_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"seteuid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"seteuid"}=0;
#Table:setfacl
#delete all rows from the setfacl table
$dbh->do("delete from setfacl");
#Define the column names for the setfacl table to Perl
my $sacl_event_type;
my $sacl_event_qual;
my $sacl_time_written;
my $sacl_date_written;
my $sacl_system_smfid;
my $sacl_violation;
my $sacl_user_ndfnd;
my $sacl_user_warning;
my $sacl_evt_user_id;
my $sacl_evt_grp_id;
my $sacl_auth_normal;
my $sacl_auth_special;
my $sacl_auth_oper;
my $sacl_auth_audit;
my $sacl_auth_exit;
my $sacl_auth_failsft;
my $sacl_auth_bypass;
my $sacl_auth_trusted;
my $sacl_log_class;
my $sacl_log_user;
my $sacl_log_special;
my $sacl_log_access;
my $sacl_log_racinit;
my $sacl_log_always;
my $sacl_log_cmdviol;
my $sacl_log_global;
my $sacl_term_level;
my $sacl_backout_fail;
my $sacl_prof_same;
my $sacl_term;
my $sacl_job_name;
my $sacl_read_time;
my $sacl_read_date;
my $sacl_smf_user_id;
my $sacl_log_level;
my $sacl_log_vmevent;
my $sacl_log_logopt;
my $sacl_log_secl;
my $sacl_log_compatm;
my $sacl_log_applaud;
my $sacl_log_nonomvs;
my $sacl_log_omvsnprv;
my $sacl_auth_omvssu;
my $sacl_auth_omvssys;
my $sacl_usr_secl;
my $sacl_racf_version;
my $sacl_class;
my $sacl_user_name;
my $sacl_utk_encr;
my $sacl_utk_pre19;
my $sacl_utk_verprof;
my $sacl_utk_njeunusr;
my $sacl_utk_logusr;
my $sacl_utk_special;
my $sacl_utk_default;
my $sacl_utk_unknusr;
my $sacl_utk_error;
my $sacl_utk_trusted;
my $sacl_utk_sesstype;
my $sacl_utk_surrogat;
my $sacl_utk_remote;
my $sacl_utk_priv;
my $sacl_utk_secl;
my $sacl_utk_execnode;
my $sacl_utk_suser_id;
my $sacl_utk_snode;
my $sacl_utk_sgrp_id;
my $sacl_utk_spoe;
my $sacl_utk_spclass;
my $sacl_utk_user_id;
my $sacl_utk_grp_id;
my $sacl_utk_dft_grp;
my $sacl_utk_dft_secl;
my $sacl_appc_link;
my $sacl_audit_code;
my $sacl_old_real_uid;
my $sacl_old_eff_uid;
my $sacl_old_saved_uid;
my $sacl_old_real_gid;
my $sacl_old_eff_gid;
my $sacl_old_saved_gid;
my $sacl_path_name;
my $sacl_file_id;
my $sacl_file_own_uid;
my $sacl_file_own_gid;
my $sacl_filepool;
my $sacl_filespace;
my $sacl_inode;
my $sacl_scid;
my $sacl_dce_link;
my $sacl_auth_type;
my $sacl_dflt_process;
my $sacl_utk_netw;
my $sacl_x500_subject;
my $sacl_x500_issuer;
my $sacl_acl_type;
my $sacl_optype;
my $sacl_entry_type;
my $sacl_entry_id;
my $sacl_old_read;
my $sacl_old_write;
my $sacl_old_execute;
my $sacl_new_read;
my $sacl_new_write;
my $sacl_new_execute;
#Create and prepare the INSERT statement for setfacl
$statement="INSERT INTO setfacl (sacl_event_type,sacl_event_qual,sacl_time_written,sacl_date_written,sacl_system_smfid,sacl_violation,sacl_user_ndfnd,sacl_user_warning,sacl_evt_user_id,sacl_evt_grp_id,sacl_auth_normal,sacl_auth_special,sacl_auth_oper,sacl_auth_audit,sacl_auth_exit,sacl_auth_failsft,sacl_auth_bypass,sacl_auth_trusted,sacl_log_class,sacl_log_user,sacl_log_special,sacl_log_access,sacl_log_racinit,sacl_log_always,sacl_log_cmdviol,sacl_log_global,sacl_term_level,sacl_backout_fail,sacl_prof_same,sacl_term,sacl_job_name,sacl_read_time,sacl_read_date,sacl_smf_user_id,sacl_log_level,sacl_log_vmevent,sacl_log_logopt,sacl_log_secl,sacl_log_compatm,sacl_log_applaud,sacl_log_nonomvs,sacl_log_omvsnprv,sacl_auth_omvssu,sacl_auth_omvssys,sacl_usr_secl,sacl_racf_version,sacl_class,sacl_user_name,sacl_utk_encr,sacl_utk_pre19,sacl_utk_verprof,sacl_utk_njeunusr,sacl_utk_logusr,sacl_utk_special,sacl_utk_default,sacl_utk_unknusr,sacl_utk_error,sacl_utk_trusted,sacl_utk_sesstype,sacl_utk_surrogat,sacl_utk_remote,sacl_utk_priv,sacl_utk_secl,sacl_utk_execnode,sacl_utk_suser_id,sacl_utk_snode,sacl_utk_sgrp_id,sacl_utk_spoe,sacl_utk_spclass,sacl_utk_user_id,sacl_utk_grp_id,sacl_utk_dft_grp,sacl_utk_dft_secl,sacl_appc_link,sacl_audit_code,sacl_old_real_uid,sacl_old_eff_uid,sacl_old_saved_uid,sacl_old_real_gid,sacl_old_eff_gid,sacl_old_saved_gid,sacl_path_name,sacl_file_id,sacl_file_own_uid,sacl_file_own_gid,sacl_filepool,sacl_filespace,sacl_inode,sacl_scid,sacl_dce_link,sacl_auth_type,sacl_dflt_process,sacl_utk_netw,sacl_x500_subject,sacl_x500_issuer,sacl_acl_type,sacl_optype,sacl_entry_type,sacl_entry_id,sacl_old_read,sacl_old_write,sacl_old_execute,sacl_new_read,sacl_new_write,sacl_new_execute) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setfacl"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setfacl"}=0;
#Table:setgid
#delete all rows from the setgid table
$dbh->do("delete from setgid");
#Define the column names for the setgid table to Perl
my $sgi_event_type;
my $sgi_event_qual;
my $sgi_time_written;
my $sgi_date_written;
my $sgi_system_smfid;
my $sgi_violation;
my $sgi_user_ndfnd;
my $sgi_user_warning;
my $sgi_evt_user_id;
my $sgi_evt_grp_id;
my $sgi_auth_normal;
my $sgi_auth_special;
my $sgi_auth_oper;
my $sgi_auth_audit;
my $sgi_auth_exit;
my $sgi_auth_failsft;
my $sgi_auth_bypass;
my $sgi_auth_trusted;
my $sgi_log_class;
my $sgi_log_user;
my $sgi_log_special;
my $sgi_log_access;
my $sgi_log_racinit;
my $sgi_log_always;
my $sgi_log_cmdviol;
my $sgi_log_global;
my $sgi_term_level;
my $sgi_backout_fail;
my $sgi_prof_same;
my $sgi_term;
my $sgi_job_name;
my $sgi_read_time;
my $sgi_read_date;
my $sgi_smf_user_id;
my $sgi_log_level;
my $sgi_log_vmevent;
my $sgi_log_logopt;
my $sgi_log_secl;
my $sgi_log_compatm;
my $sgi_log_applaud;
my $sgi_log_nonomvs;
my $sgi_log_omvsnprv;
my $sgi_auth_omvssu;
my $sgi_auth_omvssys;
my $sgi_usr_secl;
my $sgi_racf_version;
my $sgi_class;
my $sgi_user_name;
my $sgi_utk_encr;
my $sgi_utk_pre19;
my $sgi_utk_verprof;
my $sgi_utk_njeunusr;
my $sgi_utk_logusr;
my $sgi_utk_special;
my $sgi_utk_default;
my $sgi_utk_unknusr;
my $sgi_utk_error;
my $sgi_utk_trusted;
my $sgi_utk_sesstype;
my $sgi_utk_surrogat;
my $sgi_utk_remote;
my $sgi_utk_priv;
my $sgi_utk_secl;
my $sgi_utk_execnode;
my $sgi_utk_suser_id;
my $sgi_utk_snode;
my $sgi_utk_sgrp_id;
my $sgi_utk_spoe;
my $sgi_utk_spclass;
my $sgi_utk_user_id;
my $sgi_utk_grp_id;
my $sgi_utk_dft_grp;
my $sgi_utk_dft_secl;
my $sgi_appc_link;
my $sgi_audit_code;
my $sgi_old_real_uid;
my $sgi_old_eff_uid;
my $sgi_old_saved_uid;
my $sgi_old_real_gid;
my $sgi_old_eff_gid;
my $sgi_old_saved_gid;
my $sgi_new_real_gid;
my $sgi_new_eff_gid;
my $sgi_new_saved_gid;
my $sgi_gid;
my $sgi_dflt_process;
my $sgi_utk_netw;
my $sgi_x500_subject;
my $sgi_x500_issuer;
#Create and prepare the INSERT statement for setgid
$statement="INSERT INTO setgid (sgi_event_type,sgi_event_qual,sgi_time_written,sgi_date_written,sgi_system_smfid,sgi_violation,sgi_user_ndfnd,sgi_user_warning,sgi_evt_user_id,sgi_evt_grp_id,sgi_auth_normal,sgi_auth_special,sgi_auth_oper,sgi_auth_audit,sgi_auth_exit,sgi_auth_failsft,sgi_auth_bypass,sgi_auth_trusted,sgi_log_class,sgi_log_user,sgi_log_special,sgi_log_access,sgi_log_racinit,sgi_log_always,sgi_log_cmdviol,sgi_log_global,sgi_term_level,sgi_backout_fail,sgi_prof_same,sgi_term,sgi_job_name,sgi_read_time,sgi_read_date,sgi_smf_user_id,sgi_log_level,sgi_log_vmevent,sgi_log_logopt,sgi_log_secl,sgi_log_compatm,sgi_log_applaud,sgi_log_nonomvs,sgi_log_omvsnprv,sgi_auth_omvssu,sgi_auth_omvssys,sgi_usr_secl,sgi_racf_version,sgi_class,sgi_user_name,sgi_utk_encr,sgi_utk_pre19,sgi_utk_verprof,sgi_utk_njeunusr,sgi_utk_logusr,sgi_utk_special,sgi_utk_default,sgi_utk_unknusr,sgi_utk_error,sgi_utk_trusted,sgi_utk_sesstype,sgi_utk_surrogat,sgi_utk_remote,sgi_utk_priv,sgi_utk_secl,sgi_utk_execnode,sgi_utk_suser_id,sgi_utk_snode,sgi_utk_sgrp_id,sgi_utk_spoe,sgi_utk_spclass,sgi_utk_user_id,sgi_utk_grp_id,sgi_utk_dft_grp,sgi_utk_dft_secl,sgi_appc_link,sgi_audit_code,sgi_old_real_uid,sgi_old_eff_uid,sgi_old_saved_uid,sgi_old_real_gid,sgi_old_eff_gid,sgi_old_saved_gid,sgi_new_real_gid,sgi_new_eff_gid,sgi_new_saved_gid,sgi_gid,sgi_dflt_process,sgi_utk_netw,sgi_x500_subject,sgi_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setgid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setgid"}=0;
#Table:setgroup
#delete all rows from the setgroup table
$dbh->do("delete from setgroup");
#Define the column names for the setgroup table to Perl
my $setg_event_type;
my $setg_event_qual;
my $setg_time_written;
my $setg_date_written;
my $setg_system_smfid;
my $setg_violation;
my $setg_user_ndfnd;
my $setg_user_warning;
my $setg_evt_user_id;
my $setg_evt_grp_id;
my $setg_auth_normal;
my $setg_auth_special;
my $setg_auth_oper;
my $setg_auth_audit;
my $setg_auth_exit;
my $setg_auth_failsft;
my $setg_auth_bypass;
my $setg_auth_trusted;
my $setg_log_class;
my $setg_log_user;
my $setg_log_special;
my $setg_log_access;
my $setg_log_racinit;
my $setg_log_always;
my $setg_log_cmdviol;
my $setg_log_global;
my $setg_term_level;
my $setg_backout_fail;
my $setg_prof_same;
my $setg_term;
my $setg_job_name;
my $setg_read_time;
my $setg_read_date;
my $setg_smf_user_id;
my $setg_log_level;
my $setg_log_vmevent;
my $setg_log_logopt;
my $setg_log_secl;
my $setg_log_compatm;
my $setg_log_applaud;
my $setg_log_nonomvs;
my $setg_log_omvsnprv;
my $setg_auth_omvssu;
my $setg_auth_omvssys;
my $setg_usr_secl;
my $setg_racf_version;
my $setg_class;
my $setg_user_name;
my $setg_utk_encr;
my $setg_utk_pre19;
my $setg_utk_verprof;
my $setg_utk_njeunusr;
my $setg_utk_logusr;
my $setg_utk_special;
my $setg_utk_default;
my $setg_utk_unknusr;
my $setg_utk_error;
my $setg_utk_trusted;
my $setg_utk_sesstype;
my $setg_utk_surrogat;
my $setg_utk_remote;
my $setg_utk_priv;
my $setg_utk_secl;
my $setg_utk_execnode;
my $setg_utk_suser_id;
my $setg_utk_snode;
my $setg_utk_sgrp_id;
my $setg_utk_spoe;
my $setg_utk_spclass;
my $setg_utk_user_id;
my $setg_utk_grp_id;
my $setg_utk_dft_grp;
my $setg_utk_dft_secl;
my $setg_appc_link;
my $setg_audit_code;
my $setg_old_real_uid;
my $setg_old_eff_uid;
my $setg_old_saved_uid;
my $setg_old_real_gid;
my $setg_old_eff_gid;
my $setg_old_saved_gid;
my $setg_dce_link;
my $setg_auth_type;
my $setg_dflt_process;
my $setg_utk_netw;
my $setg_x500_subject;
my $setg_x500_issuer;
#Create and prepare the INSERT statement for setgroup
$statement="INSERT INTO setgroup (setg_event_type,setg_event_qual,setg_time_written,setg_date_written,setg_system_smfid,setg_violation,setg_user_ndfnd,setg_user_warning,setg_evt_user_id,setg_evt_grp_id,setg_auth_normal,setg_auth_special,setg_auth_oper,setg_auth_audit,setg_auth_exit,setg_auth_failsft,setg_auth_bypass,setg_auth_trusted,setg_log_class,setg_log_user,setg_log_special,setg_log_access,setg_log_racinit,setg_log_always,setg_log_cmdviol,setg_log_global,setg_term_level,setg_backout_fail,setg_prof_same,setg_term,setg_job_name,setg_read_time,setg_read_date,setg_smf_user_id,setg_log_level,setg_log_vmevent,setg_log_logopt,setg_log_secl,setg_log_compatm,setg_log_applaud,setg_log_nonomvs,setg_log_omvsnprv,setg_auth_omvssu,setg_auth_omvssys,setg_usr_secl,setg_racf_version,setg_class,setg_user_name,setg_utk_encr,setg_utk_pre19,setg_utk_verprof,setg_utk_njeunusr,setg_utk_logusr,setg_utk_special,setg_utk_default,setg_utk_unknusr,setg_utk_error,setg_utk_trusted,setg_utk_sesstype,setg_utk_surrogat,setg_utk_remote,setg_utk_priv,setg_utk_secl,setg_utk_execnode,setg_utk_suser_id,setg_utk_snode,setg_utk_sgrp_id,setg_utk_spoe,setg_utk_spclass,setg_utk_user_id,setg_utk_grp_id,setg_utk_dft_grp,setg_utk_dft_secl,setg_appc_link,setg_audit_code,setg_old_real_uid,setg_old_eff_uid,setg_old_saved_uid,setg_old_real_gid,setg_old_eff_gid,setg_old_saved_gid,setg_dce_link,setg_auth_type,setg_dflt_process,setg_utk_netw,setg_x500_subject,setg_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setgroup"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setgroup"}=0;
#Table:setropts
#delete all rows from the setropts table
$dbh->do("delete from setropts");
#Define the column names for the setropts table to Perl
my $setr_event_type;
my $setr_event_qual;
my $setr_time_written;
my $setr_date_written;
my $setr_system_smfid;
my $setr_violation;
my $setr_user_ndfnd;
my $setr_user_warning;
my $setr_evt_user_id;
my $setr_evt_grp_id;
my $setr_auth_normal;
my $setr_auth_special;
my $setr_auth_oper;
my $setr_auth_audit;
my $setr_auth_exit;
my $setr_auth_failsft;
my $setr_auth_bypass;
my $setr_auth_trusted;
my $setr_log_class;
my $setr_log_user;
my $setr_log_special;
my $setr_log_access;
my $setr_log_racinit;
my $setr_log_always;
my $setr_log_cmdviol;
my $setr_log_global;
my $setr_term_level;
my $setr_backout_fail;
my $setr_prof_same;
my $setr_term;
my $setr_job_name;
my $setr_read_time;
my $setr_read_date;
my $setr_smf_user_id;
my $setr_log_level;
my $setr_log_vmevent;
my $setr_log_logopt;
my $setr_log_secl;
my $setr_log_compatm;
my $setr_log_applaud;
my $setr_log_nonomvs;
my $setr_log_omvsnprv;
my $setr_auth_omvssu;
my $setr_auth_omvssys;
my $setr_usr_secl;
my $setr_racf_version;
my $setr_user_name;
my $setr_utk_encr;
my $setr_utk_pre19;
my $setr_utk_verprof;
my $setr_utk_njeunusr;
my $setr_utk_logusr;
my $setr_utk_special;
my $setr_utk_default;
my $setr_utk_unknusr;
my $setr_utk_error;
my $setr_utk_trusted;
my $setr_utk_sesstype;
my $setr_utk_surrogat;
my $setr_utk_remove;
my $setr_utk_priv;
my $setr_utk_secl;
my $setr_utk_execnode;
my $setr_utk_suser_id;
my $setr_utk_snode;
my $setr_utk_sgrp_id;
my $setr_utk_spoe;
my $setr_utk_spclass;
my $setr_utk_user_id;
my $setr_utk_grp_id;
my $setr_utk_dft_grp;
my $setr_utk_dft_secl;
my $setr_appc_link;
my $setr_specified;
my $setr_failed;
my $setr_utk_netw;
my $setr_x500_subject;
my $setr_x500_issuer;
#Create and prepare the INSERT statement for setropts
$statement="INSERT INTO setropts (setr_event_type,setr_event_qual,setr_time_written,setr_date_written,setr_system_smfid,setr_violation,setr_user_ndfnd,setr_user_warning,setr_evt_user_id,setr_evt_grp_id,setr_auth_normal,setr_auth_special,setr_auth_oper,setr_auth_audit,setr_auth_exit,setr_auth_failsft,setr_auth_bypass,setr_auth_trusted,setr_log_class,setr_log_user,setr_log_special,setr_log_access,setr_log_racinit,setr_log_always,setr_log_cmdviol,setr_log_global,setr_term_level,setr_backout_fail,setr_prof_same,setr_term,setr_job_name,setr_read_time,setr_read_date,setr_smf_user_id,setr_log_level,setr_log_vmevent,setr_log_logopt,setr_log_secl,setr_log_compatm,setr_log_applaud,setr_log_nonomvs,setr_log_omvsnprv,setr_auth_omvssu,setr_auth_omvssys,setr_usr_secl,setr_racf_version,setr_user_name,setr_utk_encr,setr_utk_pre19,setr_utk_verprof,setr_utk_njeunusr,setr_utk_logusr,setr_utk_special,setr_utk_default,setr_utk_unknusr,setr_utk_error,setr_utk_trusted,setr_utk_sesstype,setr_utk_surrogat,setr_utk_remove,setr_utk_priv,setr_utk_secl,setr_utk_execnode,setr_utk_suser_id,setr_utk_snode,setr_utk_sgrp_id,setr_utk_spoe,setr_utk_spclass,setr_utk_user_id,setr_utk_grp_id,setr_utk_dft_grp,setr_utk_dft_secl,setr_appc_link,setr_specified,setr_failed,setr_utk_netw,setr_x500_subject,setr_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setropts"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setropts"}=0;
#Table:setuid
#delete all rows from the setuid table
$dbh->do("delete from setuid");
#Define the column names for the setuid table to Perl
my $sui_event_type;
my $sui_event_qual;
my $sui_time_written;
my $sui_date_written;
my $sui_system_smfid;
my $sui_violation;
my $sui_user_ndfnd;
my $sui_user_warning;
my $sui_evt_user_id;
my $sui_evt_grp_id;
my $sui_auth_normal;
my $sui_auth_special;
my $sui_auth_oper;
my $sui_auth_audit;
my $sui_auth_exit;
my $sui_auth_failsft;
my $sui_auth_bypass;
my $sui_auth_trusted;
my $sui_log_class;
my $sui_log_user;
my $sui_log_special;
my $sui_log_access;
my $sui_log_racinit;
my $sui_log_always;
my $sui_log_cmdviol;
my $sui_log_global;
my $sui_term_level;
my $sui_backout_fail;
my $sui_prof_same;
my $sui_term;
my $sui_job_name;
my $sui_read_time;
my $sui_read_date;
my $sui_smf_user_id;
my $sui_log_level;
my $sui_log_vmevent;
my $sui_log_logopt;
my $sui_log_secl;
my $sui_log_compatm;
my $sui_log_applaud;
my $sui_log_nonomvs;
my $sui_log_omvsnprv;
my $sui_auth_omvssu;
my $sui_auth_omvssys;
my $sui_usr_secl;
my $sui_racf_version;
my $sui_class;
my $sui_user_name;
my $sui_utk_encr;
my $sui_utk_pre19;
my $sui_utk_verprof;
my $sui_utk_njeunusr;
my $sui_utk_logusr;
my $sui_utk_special;
my $sui_utk_default;
my $sui_utk_unknusr;
my $sui_utk_error;
my $sui_utk_trusted;
my $sui_utk_sesstype;
my $sui_utk_surrogat;
my $sui_utk_remote;
my $sui_utk_priv;
my $sui_utk_secl;
my $sui_utk_execnode;
my $sui_utk_suser_id;
my $sui_utk_snode;
my $sui_utk_sgrp_id;
my $sui_utk_spoe;
my $sui_utk_spclass;
my $sui_utk_user_id;
my $sui_utk_grp_id;
my $sui_utk_dft_grp;
my $sui_utk_dft_secl;
my $sui_appc_link;
my $sui_audit_code;
my $sui_old_real_uid;
my $sui_old_eff_uid;
my $sui_old_saved_uid;
my $sui_old_real_gid;
my $sui_old_eff_gid;
my $sui_old_saved_gid;
my $sui_new_real_uid;
my $sui_new_eff_uid;
my $sui_new_saved_uid;
my $sui_uid;
my $sui_dflt_process;
my $sui_utk_netw;
my $sui_x500_subject;
my $sui_x500_issuer;
#Create and prepare the INSERT statement for setuid
$statement="INSERT INTO setuid (sui_event_type,sui_event_qual,sui_time_written,sui_date_written,sui_system_smfid,sui_violation,sui_user_ndfnd,sui_user_warning,sui_evt_user_id,sui_evt_grp_id,sui_auth_normal,sui_auth_special,sui_auth_oper,sui_auth_audit,sui_auth_exit,sui_auth_failsft,sui_auth_bypass,sui_auth_trusted,sui_log_class,sui_log_user,sui_log_special,sui_log_access,sui_log_racinit,sui_log_always,sui_log_cmdviol,sui_log_global,sui_term_level,sui_backout_fail,sui_prof_same,sui_term,sui_job_name,sui_read_time,sui_read_date,sui_smf_user_id,sui_log_level,sui_log_vmevent,sui_log_logopt,sui_log_secl,sui_log_compatm,sui_log_applaud,sui_log_nonomvs,sui_log_omvsnprv,sui_auth_omvssu,sui_auth_omvssys,sui_usr_secl,sui_racf_version,sui_class,sui_user_name,sui_utk_encr,sui_utk_pre19,sui_utk_verprof,sui_utk_njeunusr,sui_utk_logusr,sui_utk_special,sui_utk_default,sui_utk_unknusr,sui_utk_error,sui_utk_trusted,sui_utk_sesstype,sui_utk_surrogat,sui_utk_remote,sui_utk_priv,sui_utk_secl,sui_utk_execnode,sui_utk_suser_id,sui_utk_snode,sui_utk_sgrp_id,sui_utk_spoe,sui_utk_spclass,sui_utk_user_id,sui_utk_grp_id,sui_utk_dft_grp,sui_utk_dft_secl,sui_appc_link,sui_audit_code,sui_old_real_uid,sui_old_eff_uid,sui_old_saved_uid,sui_old_real_gid,sui_old_eff_gid,sui_old_saved_gid,sui_new_real_uid,sui_new_eff_uid,sui_new_saved_uid,sui_uid,sui_dflt_process,sui_utk_netw,sui_x500_subject,sui_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"setuid"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"setuid"}=0;
#Table:symlink
#delete all rows from the symlink table
$dbh->do("delete from symlink");
#Define the column names for the symlink table to Perl
my $syml_event_type;
my $syml_event_qual;
my $syml_time_written;
my $syml_date_written;
my $syml_system_smfid;
my $syml_violation;
my $syml_user_ndfnd;
my $syml_user_warning;
my $syml_evt_user_id;
my $syml_evt_grp_id;
my $syml_auth_normal;
my $syml_auth_special;
my $syml_auth_oper;
my $syml_auth_audit;
my $syml_auth_exit;
my $syml_auth_failsft;
my $syml_auth_bypass;
my $syml_auth_trusted;
my $syml_log_class;
my $syml_log_user;
my $syml_log_special;
my $syml_log_access;
my $syml_log_racinit;
my $syml_log_always;
my $syml_log_cmdviol;
my $syml_log_global;
my $syml_term_level;
my $syml_backout_fail;
my $syml_prof_same;
my $syml_term;
my $syml_job_name;
my $syml_read_time;
my $syml_read_date;
my $syml_smf_user_id;
my $syml_log_level;
my $syml_log_vmevent;
my $syml_log_logopt;
my $syml_log_secl;
my $syml_log_compatm;
my $syml_log_applaud;
my $syml_log_nonomvs;
my $syml_log_omvsnprv;
my $syml_auth_omvssu;
my $syml_auth_omvssys;
my $syml_usr_secl;
my $syml_racf_version;
my $syml_class;
my $syml_user_name;
my $syml_utk_encr;
my $syml_utk_pre19;
my $syml_utk_verprof;
my $syml_utk_njeunusr;
my $syml_utk_logusr;
my $syml_utk_special;
my $syml_utk_default;
my $syml_utk_unknusr;
my $syml_utk_error;
my $syml_utk_trusted;
my $syml_utk_sesstype;
my $syml_utk_surrogat;
my $syml_utk_remote;
my $syml_utk_priv;
my $syml_utk_secl;
my $syml_utk_execnode;
my $syml_utk_suser_id;
my $syml_utk_snode;
my $syml_utk_sgrp_id;
my $syml_utk_spoe;
my $syml_utk_spclass;
my $syml_utk_user_id;
my $syml_utk_grp_id;
my $syml_utk_dft_grp;
my $syml_utk_dft_secl;
my $syml_appc_link;
my $syml_audit_code;
my $syml_old_real_uid;
my $syml_old_eff_uid;
my $syml_old_saved_uid;
my $syml_old_real_gid;
my $syml_old_eff_gid;
my $syml_old_saved_gid;
my $syml_path_name;
my $syml_file_id;
my $syml_file_own_uid;
my $syml_file_own_gid;
my $syml_symlink_data;
my $syml_filepool;
my $syml_filespace;
my $syml_inode;
my $syml_scid;
my $syml_dflt_process;
my $syml_utk_netw;
my $syml_x500_subject;
my $syml_x500_issuer;
#Create and prepare the INSERT statement for symlink
$statement="INSERT INTO symlink (syml_event_type,syml_event_qual,syml_time_written,syml_date_written,syml_system_smfid,syml_violation,syml_user_ndfnd,syml_user_warning,syml_evt_user_id,syml_evt_grp_id,syml_auth_normal,syml_auth_special,syml_auth_oper,syml_auth_audit,syml_auth_exit,syml_auth_failsft,syml_auth_bypass,syml_auth_trusted,syml_log_class,syml_log_user,syml_log_special,syml_log_access,syml_log_racinit,syml_log_always,syml_log_cmdviol,syml_log_global,syml_term_level,syml_backout_fail,syml_prof_same,syml_term,syml_job_name,syml_read_time,syml_read_date,syml_smf_user_id,syml_log_level,syml_log_vmevent,syml_log_logopt,syml_log_secl,syml_log_compatm,syml_log_applaud,syml_log_nonomvs,syml_log_omvsnprv,syml_auth_omvssu,syml_auth_omvssys,syml_usr_secl,syml_racf_version,syml_class,syml_user_name,syml_utk_encr,syml_utk_pre19,syml_utk_verprof,syml_utk_njeunusr,syml_utk_logusr,syml_utk_special,syml_utk_default,syml_utk_unknusr,syml_utk_error,syml_utk_trusted,syml_utk_sesstype,syml_utk_surrogat,syml_utk_remote,syml_utk_priv,syml_utk_secl,syml_utk_execnode,syml_utk_suser_id,syml_utk_snode,syml_utk_sgrp_id,syml_utk_spoe,syml_utk_spclass,syml_utk_user_id,syml_utk_grp_id,syml_utk_dft_grp,syml_utk_dft_secl,syml_appc_link,syml_audit_code,syml_old_real_uid,syml_old_eff_uid,syml_old_saved_uid,syml_old_real_gid,syml_old_eff_gid,syml_old_saved_gid,syml_path_name,syml_file_id,syml_file_own_uid,syml_file_own_gid,syml_symlink_data,syml_filepool,syml_filespace,syml_inode,syml_scid,syml_dflt_process,syml_utk_netw,syml_x500_subject,syml_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"symlink"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"symlink"}=0;
#Table:termoedp
#delete all rows from the termoedp table
$dbh->do("delete from termoedp");
#Define the column names for the termoedp table to Perl
my $toep_event_type;
my $toep_event_qual;
my $toep_time_written;
my $toep_date_written;
my $toep_system_smfid;
my $toep_violation;
my $toep_user_ndfnd;
my $toep_user_warning;
my $toep_evt_user_id;
my $toep_evt_grp_id;
my $toep_auth_normal;
my $toep_auth_special;
my $toep_auth_oper;
my $toep_auth_audit;
my $toep_auth_exit;
my $toep_auth_failsft;
my $toep_auth_bypass;
my $toep_auth_trusted;
my $toep_log_class;
my $toep_log_user;
my $toep_log_special;
my $toep_log_access;
my $toep_log_racinit;
my $toep_log_always;
my $toep_log_cmdviol;
my $toep_log_global;
my $toep_term_level;
my $toep_backout_fail;
my $toep_prof_same;
my $toep_term;
my $toep_job_name;
my $toep_read_time;
my $toep_read_date;
my $toep_smf_user_id;
my $toep_log_level;
my $toep_log_vmevent;
my $toep_log_logopt;
my $toep_log_secl;
my $toep_log_compatm;
my $toep_log_applaud;
my $toep_log_nonomvs;
my $toep_log_omvsnprv;
my $toep_auth_omvssu;
my $toep_auth_omvssys;
my $toep_usr_secl;
my $toep_racf_version;
my $toep_class;
my $toep_user_name;
my $toep_utk_encr;
my $toep_utk_pre19;
my $toep_utk_verprof;
my $toep_utk_njeunusr;
my $toep_utk_logusr;
my $toep_utk_special;
my $toep_utk_default;
my $toep_utk_unknusr;
my $toep_utk_error;
my $toep_utk_trusted;
my $toep_utk_sesstype;
my $toep_utk_surrogat;
my $toep_utk_remote;
my $toep_utk_priv;
my $toep_utk_secl;
my $toep_utk_execnode;
my $toep_utk_suser_id;
my $toep_utk_snode;
my $toep_utk_sgrp_id;
my $toep_utk_spoe;
my $toep_utk_spclass;
my $toep_utk_user_id;
my $toep_utk_grp_id;
my $toep_utk_dft_grp;
my $toep_utk_dft_secl;
my $toep_appc_link;
my $toep_audit_code;
my $toep_old_real_uid;
my $toep_old_eff_uid;
my $toep_old_saved_uid;
my $toep_old_real_gid;
my $toep_old_eff_gid;
my $toep_old_saved_gid;
my $toep_dflt_process;
my $toep_utk_netw;
my $toep_x500_subject;
my $toep_x500_issuer;
#Create and prepare the INSERT statement for termoedp
$statement="INSERT INTO termoedp (toep_event_type,toep_event_qual,toep_time_written,toep_date_written,toep_system_smfid,toep_violation,toep_user_ndfnd,toep_user_warning,toep_evt_user_id,toep_evt_grp_id,toep_auth_normal,toep_auth_special,toep_auth_oper,toep_auth_audit,toep_auth_exit,toep_auth_failsft,toep_auth_bypass,toep_auth_trusted,toep_log_class,toep_log_user,toep_log_special,toep_log_access,toep_log_racinit,toep_log_always,toep_log_cmdviol,toep_log_global,toep_term_level,toep_backout_fail,toep_prof_same,toep_term,toep_job_name,toep_read_time,toep_read_date,toep_smf_user_id,toep_log_level,toep_log_vmevent,toep_log_logopt,toep_log_secl,toep_log_compatm,toep_log_applaud,toep_log_nonomvs,toep_log_omvsnprv,toep_auth_omvssu,toep_auth_omvssys,toep_usr_secl,toep_racf_version,toep_class,toep_user_name,toep_utk_encr,toep_utk_pre19,toep_utk_verprof,toep_utk_njeunusr,toep_utk_logusr,toep_utk_special,toep_utk_default,toep_utk_unknusr,toep_utk_error,toep_utk_trusted,toep_utk_sesstype,toep_utk_surrogat,toep_utk_remote,toep_utk_priv,toep_utk_secl,toep_utk_execnode,toep_utk_suser_id,toep_utk_snode,toep_utk_sgrp_id,toep_utk_spoe,toep_utk_spclass,toep_utk_user_id,toep_utk_grp_id,toep_utk_dft_grp,toep_utk_dft_secl,toep_appc_link,toep_audit_code,toep_old_real_uid,toep_old_eff_uid,toep_old_saved_uid,toep_old_real_gid,toep_old_eff_gid,toep_old_saved_gid,toep_dflt_process,toep_utk_netw,toep_x500_subject,toep_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"termoedp"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"termoedp"}=0;
#Table:umntfsys
#delete all rows from the umntfsys table
$dbh->do("delete from umntfsys");
#Define the column names for the umntfsys table to Perl
my $ufs_event_type;
my $ufs_event_qual;
my $ufs_time_written;
my $ufs_date_written;
my $ufs_system_smfid;
my $ufs_violation;
my $ufs_user_ndfnd;
my $ufs_user_warning;
my $ufs_evt_user_id;
my $ufs_evt_grp_id;
my $ufs_auth_normal;
my $ufs_auth_special;
my $ufs_auth_oper;
my $ufs_auth_audit;
my $ufs_auth_exit;
my $ufs_auth_failsft;
my $ufs_auth_bypass;
my $ufs_auth_trusted;
my $ufs_log_class;
my $ufs_log_user;
my $ufs_log_special;
my $ufs_log_access;
my $ufs_log_racinit;
my $ufs_log_always;
my $ufs_log_cmdviol;
my $ufs_log_global;
my $ufs_term_level;
my $ufs_backout_fail;
my $ufs_prof_same;
my $ufs_term;
my $ufs_job_name;
my $ufs_read_time;
my $ufs_read_date;
my $ufs_smf_user_id;
my $ufs_log_level;
my $ufs_log_vmevent;
my $ufs_log_logopt;
my $ufs_log_secl;
my $ufs_log_compatm;
my $ufs_log_applaud;
my $ufs_log_nonomvs;
my $ufs_log_omvsnprv;
my $ufs_auth_omvssu;
my $ufs_auth_omvssys;
my $ufs_usr_secl;
my $ufs_racf_version;
my $ufs_class;
my $ufs_user_name;
my $ufs_utk_encr;
my $ufs_utk_pre19;
my $ufs_utk_verprof;
my $ufs_utk_njeunusr;
my $ufs_utk_logusr;
my $ufs_utk_special;
my $ufs_utk_default;
my $ufs_utk_unknusr;
my $ufs_utk_error;
my $ufs_utk_trusted;
my $ufs_utk_sesstype;
my $ufs_utk_surrogat;
my $ufs_utk_remote;
my $ufs_utk_priv;
my $ufs_utk_secl;
my $ufs_utk_execnode;
my $ufs_utk_suser_id;
my $ufs_utk_snode;
my $ufs_utk_sgrp_id;
my $ufs_utk_spoe;
my $ufs_utk_spclass;
my $ufs_utk_user_id;
my $ufs_utk_grp_id;
my $ufs_utk_dft_grp;
my $ufs_utk_dft_secl;
my $ufs_appc_link;
my $ufs_audit_code;
my $ufs_old_real_uid;
my $ufs_old_eff_uid;
my $ufs_old_saved_uid;
my $ufs_old_real_gid;
my $ufs_old_eff_gid;
my $ufs_old_saved_gid;
my $ufs_path_name;
my $ufs_file_id;
my $ufs_file_own_uid;
my $ufs_file_own_gid;
my $ufs_hfs_ds_name;
my $ufs_dce_link;
my $ufs_auth_type;
my $ufs_dflt_process;
my $ufs_utk_netw;
my $ufs_x500_subject;
my $ufs_x500_issuer;
#Create and prepare the INSERT statement for umntfsys
$statement="INSERT INTO umntfsys (ufs_event_type,ufs_event_qual,ufs_time_written,ufs_date_written,ufs_system_smfid,ufs_violation,ufs_user_ndfnd,ufs_user_warning,ufs_evt_user_id,ufs_evt_grp_id,ufs_auth_normal,ufs_auth_special,ufs_auth_oper,ufs_auth_audit,ufs_auth_exit,ufs_auth_failsft,ufs_auth_bypass,ufs_auth_trusted,ufs_log_class,ufs_log_user,ufs_log_special,ufs_log_access,ufs_log_racinit,ufs_log_always,ufs_log_cmdviol,ufs_log_global,ufs_term_level,ufs_backout_fail,ufs_prof_same,ufs_term,ufs_job_name,ufs_read_time,ufs_read_date,ufs_smf_user_id,ufs_log_level,ufs_log_vmevent,ufs_log_logopt,ufs_log_secl,ufs_log_compatm,ufs_log_applaud,ufs_log_nonomvs,ufs_log_omvsnprv,ufs_auth_omvssu,ufs_auth_omvssys,ufs_usr_secl,ufs_racf_version,ufs_class,ufs_user_name,ufs_utk_encr,ufs_utk_pre19,ufs_utk_verprof,ufs_utk_njeunusr,ufs_utk_logusr,ufs_utk_special,ufs_utk_default,ufs_utk_unknusr,ufs_utk_error,ufs_utk_trusted,ufs_utk_sesstype,ufs_utk_surrogat,ufs_utk_remote,ufs_utk_priv,ufs_utk_secl,ufs_utk_execnode,ufs_utk_suser_id,ufs_utk_snode,ufs_utk_sgrp_id,ufs_utk_spoe,ufs_utk_spclass,ufs_utk_user_id,ufs_utk_grp_id,ufs_utk_dft_grp,ufs_utk_dft_secl,ufs_appc_link,ufs_audit_code,ufs_old_real_uid,ufs_old_eff_uid,ufs_old_saved_uid,ufs_old_real_gid,ufs_old_eff_gid,ufs_old_saved_gid,ufs_path_name,ufs_file_id,ufs_file_own_uid,ufs_file_own_gid,ufs_hfs_ds_name,ufs_dce_link,ufs_auth_type,ufs_dflt_process,ufs_utk_netw,ufs_x500_subject,ufs_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"umntfsys"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"umntfsys"}=0;
#Table:unlink
#delete all rows from the unlink table
$dbh->do("delete from unlink");
#Define the column names for the unlink table to Perl
my $unl_event_type;
my $unl_event_qual;
my $unl_time_written;
my $unl_date_written;
my $unl_system_smfid;
my $unl_violation;
my $unl_user_ndfnd;
my $unl_user_warning;
my $unl_evt_user_id;
my $unl_evt_grp_id;
my $unl_auth_normal;
my $unl_auth_special;
my $unl_auth_oper;
my $unl_auth_audit;
my $unl_auth_exit;
my $unl_auth_failsft;
my $unl_auth_bypass;
my $unl_auth_trusted;
my $unl_log_class;
my $unl_log_user;
my $unl_log_special;
my $unl_log_access;
my $unl_log_racinit;
my $unl_log_always;
my $unl_log_cmdviol;
my $unl_log_global;
my $unl_term_level;
my $unl_backout_fail;
my $unl_prof_same;
my $unl_term;
my $unl_job_name;
my $unl_read_time;
my $unl_read_date;
my $unl_smf_user_id;
my $unl_log_level;
my $unl_log_vmevent;
my $unl_log_logopt;
my $unl_log_secl;
my $unl_log_compatm;
my $unl_log_applaud;
my $unl_log_nonomvs;
my $unl_log_omvsnprv;
my $unl_auth_omvssu;
my $unl_auth_omvssys;
my $unl_usr_secl;
my $unl_racf_version;
my $unl_class;
my $unl_user_name;
my $unl_utk_encr;
my $unl_utk_pre19;
my $unl_utk_verprof;
my $unl_utk_njeunusr;
my $unl_utk_logusr;
my $unl_utk_special;
my $unl_utk_default;
my $unl_utk_unknusr;
my $unl_utk_error;
my $unl_utk_trusted;
my $unl_utk_sesstype;
my $unl_utk_surrogat;
my $unl_utk_remote;
my $unl_utk_priv;
my $unl_utk_secl;
my $unl_utk_execnode;
my $unl_utk_suser_id;
my $unl_utk_snode;
my $unl_utk_sgrp_id;
my $unl_utk_spoe;
my $unl_utk_spclass;
my $unl_utk_user_id;
my $unl_utk_grp_id;
my $unl_utk_dft_grp;
my $unl_utk_dft_secl;
my $unl_appc_link;
my $unl_audit_code;
my $unl_old_real_uid;
my $unl_old_eff_uid;
my $unl_old_saved_uid;
my $unl_old_real_gid;
my $unl_old_eff_gid;
my $unl_old_saved_gid;
my $unl_path_name;
my $unl_file_id;
my $unl_file_own_uid;
my $unl_file_own_gid;
my $unl_last_deleted;
my $unl_filepool;
my $unl_filespace;
my $unl_inode;
my $unl_scid;
my $unl_dce_link;
my $unl_auth_type;
my $unl_dflt_process;
my $unl_utk_netw;
my $unl_x500_subject;
my $unl_x500_issuer;
#Create and prepare the INSERT statement for unlink
$statement="INSERT INTO unlink (unl_event_type,unl_event_qual,unl_time_written,unl_date_written,unl_system_smfid,unl_violation,unl_user_ndfnd,unl_user_warning,unl_evt_user_id,unl_evt_grp_id,unl_auth_normal,unl_auth_special,unl_auth_oper,unl_auth_audit,unl_auth_exit,unl_auth_failsft,unl_auth_bypass,unl_auth_trusted,unl_log_class,unl_log_user,unl_log_special,unl_log_access,unl_log_racinit,unl_log_always,unl_log_cmdviol,unl_log_global,unl_term_level,unl_backout_fail,unl_prof_same,unl_term,unl_job_name,unl_read_time,unl_read_date,unl_smf_user_id,unl_log_level,unl_log_vmevent,unl_log_logopt,unl_log_secl,unl_log_compatm,unl_log_applaud,unl_log_nonomvs,unl_log_omvsnprv,unl_auth_omvssu,unl_auth_omvssys,unl_usr_secl,unl_racf_version,unl_class,unl_user_name,unl_utk_encr,unl_utk_pre19,unl_utk_verprof,unl_utk_njeunusr,unl_utk_logusr,unl_utk_special,unl_utk_default,unl_utk_unknusr,unl_utk_error,unl_utk_trusted,unl_utk_sesstype,unl_utk_surrogat,unl_utk_remote,unl_utk_priv,unl_utk_secl,unl_utk_execnode,unl_utk_suser_id,unl_utk_snode,unl_utk_sgrp_id,unl_utk_spoe,unl_utk_spclass,unl_utk_user_id,unl_utk_grp_id,unl_utk_dft_grp,unl_utk_dft_secl,unl_appc_link,unl_audit_code,unl_old_real_uid,unl_old_eff_uid,unl_old_saved_uid,unl_old_real_gid,unl_old_eff_gid,unl_old_saved_gid,unl_path_name,unl_file_id,unl_file_own_uid,unl_file_own_gid,unl_last_deleted,unl_filepool,unl_filespace,unl_inode,unl_scid,unl_dce_link,unl_auth_type,unl_dflt_process,unl_utk_netw,unl_x500_subject,unl_x500_issuer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if (! defined($insert{"unlink"}=$dbh->prepare($statement)) ) {
	$dbh->rollback;
	$dbh->disconnect;
	die $dbh->errstr;
}

$inserts{"unlink"}=0;
while(<>) {
	s/\x00/ /g; #change nulls to spaces
	if (0 == $. % 1000) { print "Processed $. lines.\n";}
	$rectype=substr($_,0,8);
	if ($rectype eq 'ACCESS  ') {
		$acc_event_type=substr($_,0,8);
		$acc_event_qual=substr($_,9,8);
		$acc_time_written=substr($_,18,8);
		if ($acc_time_written  eq ' ' x length($acc_time_written )) {
			undef $acc_time_written ;
		}
		$acc_date_written=substr($_,27,10);
		if ($acc_date_written  eq ' ' x length($acc_date_written )) {
			undef $acc_date_written ;
		}
		$acc_system_smfid=substr($_,38,4);
		$acc_violation=substr($_,43,1);
		$acc_user_ndfnd=substr($_,48,1);
		$acc_user_warning=substr($_,53,1);
		$acc_evt_user_id=substr($_,58,8);
		$acc_evt_grp_id=substr($_,67,8);
		$acc_auth_normal=substr($_,76,1);
		$acc_auth_special=substr($_,81,1);
		$acc_auth_oper=substr($_,86,1);
		$acc_auth_audit=substr($_,91,1);
		$acc_auth_exit=substr($_,96,1);
		$acc_auth_failsft=substr($_,101,1);
		$acc_auth_bypass=substr($_,106,1);
		$acc_auth_trusted=substr($_,111,1);
		$acc_log_class=substr($_,116,1);
		$acc_log_user=substr($_,121,1);
		$acc_log_special=substr($_,126,1);
		$acc_log_access=substr($_,131,1);
		$acc_log_racinit=substr($_,136,1);
		$acc_log_always=substr($_,141,1);
		$acc_log_cmdviol=substr($_,146,1);
		$acc_log_global=substr($_,151,1);
		$acc_term_level=substr($_,156,3);
		if ($acc_term_level  eq ' ' x length($acc_term_level )) {
			undef $acc_term_level ;
		}
		$acc_backout_fail=substr($_,160,1);
		$acc_prof_same=substr($_,165,1);
		$acc_term=substr($_,170,8);
		$acc_job_name=substr($_,179,8);
		$acc_read_time=substr($_,188,8);
		if ($acc_read_time  eq ' ' x length($acc_read_time )) {
			undef $acc_read_time ;
		}
		$acc_read_date=substr($_,197,10);
		if ($acc_read_date  eq ' ' x length($acc_read_date )) {
			undef $acc_read_date ;
		}
		$acc_smf_user_id=substr($_,208,8);
		$acc_log_level=substr($_,217,1);
		$acc_log_vmevent=substr($_,222,1);
		$acc_log_logopt=substr($_,227,1);
		$acc_log_secl=substr($_,232,1);
		$acc_log_compatm=substr($_,237,1);
		$acc_log_applaud=substr($_,242,1);
		$acc_log_nonomvs=substr($_,247,1);
		$acc_log_omvsnprv=substr($_,252,1);
		$acc_auth_omvssu=substr($_,257,1);
		$acc_auth_omvssys=substr($_,262,1);
		$acc_usr_secl=substr($_,267,8);
		$acc_racf_version=substr($_,276,4);
		$acc_res_name=substr($_,281,255);
		$acc_request=substr($_,537,8);
		$acc_grant=substr($_,546,8);
		$acc_level=substr($_,555,3);
		if ($acc_level  eq ' ' x length($acc_level )) {
			undef $acc_level ;
		}
		$acc_vol=substr($_,559,6);
		$acc_oldvol=substr($_,566,6);
		$acc_class=substr($_,573,8);
		$acc_appl=substr($_,582,8);
		$acc_type=substr($_,591,8);
		$acc_name=substr($_,600,246);
		$acc_own_id=substr($_,847,8);
		$acc_logstr=substr($_,856,255);
		$acc_recvr=substr($_,1112,8);
		$acc_user_name=substr($_,1121,20);
		$acc_secl=substr($_,1142,8);
		$acc_utk_encr=substr($_,1151,1);
		$acc_utk_pre19=substr($_,1156,1);
		$acc_utk_verprof=substr($_,1161,1);
		$acc_utk_njeunusr=substr($_,1166,1);
		$acc_utk_logusr=substr($_,1171,1);
		$acc_utk_special=substr($_,1176,1);
		$acc_utk_default=substr($_,1181,1);
		$acc_utk_unknusr=substr($_,1186,1);
		$acc_utk_error=substr($_,1191,1);
		$acc_utk_trusted=substr($_,1196,1);
		$acc_utk_sesstype=substr($_,1201,8);
		$acc_utk_surrogat=substr($_,1210,1);
		$acc_utk_remote=substr($_,1215,1);
		$acc_utk_priv=substr($_,1220,1);
		$acc_utk_secl=substr($_,1225,8);
		$acc_utk_execnode=substr($_,1234,8);
		$acc_utk_suser_id=substr($_,1243,8);
		$acc_utk_snode=substr($_,1252,8);
		$acc_utk_sgrp_id=substr($_,1261,8);
		$acc_utk_spoe=substr($_,1270,8);
		$acc_utk_spclass=substr($_,1279,8);
		$acc_utk_user_id=substr($_,1288,8);
		$acc_utk_grp_id=substr($_,1297,8);
		$acc_utk_dft_grp=substr($_,1306,1);
		$acc_utk_dft_secl=substr($_,1311,1);
		$acc_rtk_encr=substr($_,1316,1);
		$acc_rtk_pre19=substr($_,1321,1);
		$acc_rtk_verprof=substr($_,1326,1);
		$acc_rtk_njeunusr=substr($_,1331,1);
		$acc_rtk_logusr=substr($_,1336,1);
		$acc_rtk_special=substr($_,1341,1);
		$acc_rtk_default=substr($_,1346,1);
		$acc_rtk_unknusr=substr($_,1351,1);
		$acc_rtk_error=substr($_,1356,1);
		$acc_rtk_trusted=substr($_,1361,1);
		$acc_rtk_sesstype=substr($_,1366,8);
		$acc_rtk_surrogat=substr($_,1375,1);
		$acc_rtk_remote=substr($_,1380,1);
		$acc_rtk_priv=substr($_,1385,1);
		$acc_rtk_secl=substr($_,1390,8);
		$acc_rtk_execnode=substr($_,1399,8);
		$acc_rtk_suser_id=substr($_,1408,8);
		$acc_rtk_snode=substr($_,1417,8);
		$acc_rtk_sgrp_id=substr($_,1426,8);
		$acc_rtk_spoe=substr($_,1435,8);
		$acc_rtk_spclass=substr($_,1444,8);
		$acc_rtk_user_id=substr($_,1453,8);
		$acc_rtk_grp_id=substr($_,1462,8);
		$acc_rtk_dft_grp=substr($_,1471,1);
		$acc_rtk_dft_secl=substr($_,1476,1);
		$acc_appc_link=substr($_,1481,16);
		$acc_dce_link=substr($_,1498,16);
		$acc_auth_type=substr($_,1515,13);
		$acc_pds_dsn=substr($_,1529,44);
		$acc_utk_netw=substr($_,1574,8);
		$acc_rtk_netw=substr($_,1583,8);
		$acc_x500_subject=substr($_,1592,255);
		$acc_x500_issuer=substr($_,1848,255);
		$rv=$insert{access}->execute($acc_event_type,$acc_event_qual,$acc_time_written,$acc_date_written,$acc_system_smfid,$acc_violation,$acc_user_ndfnd,$acc_user_warning,$acc_evt_user_id,$acc_evt_grp_id,$acc_auth_normal,$acc_auth_special,$acc_auth_oper,$acc_auth_audit,$acc_auth_exit,$acc_auth_failsft,$acc_auth_bypass,$acc_auth_trusted,$acc_log_class,$acc_log_user,$acc_log_special,$acc_log_access,$acc_log_racinit,$acc_log_always,$acc_log_cmdviol,$acc_log_global,$acc_term_level,$acc_backout_fail,$acc_prof_same,$acc_term,$acc_job_name,$acc_read_time,$acc_read_date,$acc_smf_user_id,$acc_log_level,$acc_log_vmevent,$acc_log_logopt,$acc_log_secl,$acc_log_compatm,$acc_log_applaud,$acc_log_nonomvs,$acc_log_omvsnprv,$acc_auth_omvssu,$acc_auth_omvssys,$acc_usr_secl,$acc_racf_version,$acc_res_name,$acc_request,$acc_grant,$acc_level,$acc_vol,$acc_oldvol,$acc_class,$acc_appl,$acc_type,$acc_name,$acc_own_id,$acc_logstr,$acc_recvr,$acc_user_name,$acc_secl,$acc_utk_encr,$acc_utk_pre19,$acc_utk_verprof,$acc_utk_njeunusr,$acc_utk_logusr,$acc_utk_special,$acc_utk_default,$acc_utk_unknusr,$acc_utk_error,$acc_utk_trusted,$acc_utk_sesstype,$acc_utk_surrogat,$acc_utk_remote,$acc_utk_priv,$acc_utk_secl,$acc_utk_execnode,$acc_utk_suser_id,$acc_utk_snode,$acc_utk_sgrp_id,$acc_utk_spoe,$acc_utk_spclass,$acc_utk_user_id,$acc_utk_grp_id,$acc_utk_dft_grp,$acc_utk_dft_secl,$acc_rtk_encr,$acc_rtk_pre19,$acc_rtk_verprof,$acc_rtk_njeunusr,$acc_rtk_logusr,$acc_rtk_special,$acc_rtk_default,$acc_rtk_unknusr,$acc_rtk_error,$acc_rtk_trusted,$acc_rtk_sesstype,$acc_rtk_surrogat,$acc_rtk_remote,$acc_rtk_priv,$acc_rtk_secl,$acc_rtk_execnode,$acc_rtk_suser_id,$acc_rtk_snode,$acc_rtk_sgrp_id,$acc_rtk_spoe,$acc_rtk_spclass,$acc_rtk_user_id,$acc_rtk_grp_id,$acc_rtk_dft_grp,$acc_rtk_dft_secl,$acc_appc_link,$acc_dce_link,$acc_auth_type,$acc_pds_dsn,$acc_utk_netw,$acc_rtk_netw,$acc_x500_subject,$acc_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"access"}++;
		next;
	}

	if ($rectype eq 'ACCR    ') {
		$accr_event_type=substr($_,0,8);
		$accr_event_qual=substr($_,9,8);
		$accr_time_written=substr($_,18,8);
		if ($accr_time_written  eq ' ' x length($accr_time_written )) {
			undef $accr_time_written ;
		}
		$accr_date_written=substr($_,27,10);
		if ($accr_date_written  eq ' ' x length($accr_date_written )) {
			undef $accr_date_written ;
		}
		$accr_system_smfid=substr($_,38,4);
		$accr_violation=substr($_,43,1);
		$accr_user_ndfnd=substr($_,48,1);
		$accr_user_warning=substr($_,53,1);
		$accr_evt_user_id=substr($_,58,8);
		$accr_evt_grp_id=substr($_,67,8);
		$accr_auth_normal=substr($_,76,1);
		$accr_auth_special=substr($_,81,1);
		$accr_auth_oper=substr($_,86,1);
		$accr_auth_audit=substr($_,91,1);
		$accr_auth_exit=substr($_,96,1);
		$accr_auth_failsft=substr($_,101,1);
		$accr_auth_bypass=substr($_,106,1);
		$accr_auth_trusted=substr($_,111,1);
		$accr_log_class=substr($_,116,1);
		$accr_log_user=substr($_,121,1);
		$accr_log_special=substr($_,126,1);
		$accr_log_access=substr($_,131,1);
		$accr_log_racinit=substr($_,136,1);
		$accr_log_always=substr($_,141,1);
		$accr_log_cmdviol=substr($_,146,1);
		$accr_log_global=substr($_,151,1);
		$accr_term_level=substr($_,156,3);
		if ($accr_term_level  eq ' ' x length($accr_term_level )) {
			undef $accr_term_level ;
		}
		$accr_backout_fail=substr($_,160,1);
		$accr_prof_same=substr($_,165,1);
		$accr_term=substr($_,170,8);
		$accr_job_name=substr($_,179,8);
		$accr_read_time=substr($_,188,8);
		if ($accr_read_time  eq ' ' x length($accr_read_time )) {
			undef $accr_read_time ;
		}
		$accr_read_date=substr($_,197,10);
		if ($accr_read_date  eq ' ' x length($accr_read_date )) {
			undef $accr_read_date ;
		}
		$accr_smf_user_id=substr($_,208,8);
		$accr_log_level=substr($_,217,1);
		$accr_log_vmevent=substr($_,222,1);
		$accr_log_logopt=substr($_,227,1);
		$accr_log_secl=substr($_,232,1);
		$accr_log_compatm=substr($_,237,1);
		$accr_log_applaud=substr($_,242,1);
		$accr_log_nonomvs=substr($_,247,1);
		$accr_log_omvsnprv=substr($_,252,1);
		$accr_auth_omvssu=substr($_,257,1);
		$accr_auth_omvssys=substr($_,262,1);
		$accr_usr_secl=substr($_,267,8);
		$accr_racf_version=substr($_,276,4);
		$accr_class=substr($_,281,8);
		$accr_user_name=substr($_,290,20);
		$accr_utk_encr=substr($_,311,1);
		$accr_utk_pre19=substr($_,316,1);
		$accr_utk_verprof=substr($_,321,1);
		$accr_utk_njeunusr=substr($_,326,1);
		$accr_utk_logusr=substr($_,331,1);
		$accr_utk_special=substr($_,336,1);
		$accr_utk_default=substr($_,341,1);
		$accr_utk_unknusr=substr($_,346,1);
		$accr_utk_error=substr($_,351,1);
		$accr_utk_trusted=substr($_,356,1);
		$accr_utk_sesstype=substr($_,361,8);
		$accr_utk_surrogat=substr($_,370,1);
		$accr_utk_remote=substr($_,375,1);
		$accr_utk_priv=substr($_,380,1);
		$accr_utk_secl=substr($_,385,8);
		$accr_utk_execnode=substr($_,394,8);
		$accr_utk_suser_id=substr($_,403,8);
		$accr_utk_snode=substr($_,412,8);
		$accr_utk_sgrp_id=substr($_,421,8);
		$accr_utk_spoe=substr($_,430,8);
		$accr_utk_spclass=substr($_,439,8);
		$accr_utk_user_id=substr($_,448,8);
		$accr_utk_grp_id=substr($_,457,8);
		$accr_utk_dft_grp=substr($_,466,1);
		$accr_utk_dft_secl=substr($_,471,1);
		$accr_appc_link=substr($_,476,16);
		$accr_audit_code=substr($_,493,11);
		$accr_old_real_uid=substr($_,505,10);
		if ($accr_old_real_uid  eq ' ' x length($accr_old_real_uid )) {
			undef $accr_old_real_uid ;
		}
		$accr_old_eff_uid=substr($_,516,10);
		if ($accr_old_eff_uid  eq ' ' x length($accr_old_eff_uid )) {
			undef $accr_old_eff_uid ;
		}
		$accr_old_saved_uid=substr($_,527,10);
		if ($accr_old_saved_uid eq ' ' x length($accr_old_saved_uid)) {
			undef $accr_old_saved_uid;
		}
		$accr_old_real_gid=substr($_,538,10);
		if ($accr_old_real_gid  eq ' ' x length($accr_old_real_gid )) {
			undef $accr_old_real_gid ;
		}
		$accr_old_eff_gid=substr($_,549,10);
		if ($accr_old_eff_gid  eq ' ' x length($accr_old_eff_gid )) {
			undef $accr_old_eff_gid ;
		}
		$accr_old_saved_gid=substr($_,560,10);
		if ($accr_old_saved_gid eq ' ' x length($accr_old_saved_gid)) {
			undef $accr_old_saved_gid;
		}
		$accr_path_name=substr($_,571,1023);
		$accr_file1_id=substr($_,1595,32);
		$accr_dflt_process=substr($_,1628,1);
		$accr_utk_netw=substr($_,1633,8);
		$accr_x500_subject=substr($_,1642,255);
		$accr_x500_issuer=substr($_,1898,255);
		$rv=$insert{accr}->execute($accr_event_type,$accr_event_qual,$accr_time_written,$accr_date_written,$accr_system_smfid,$accr_violation,$accr_user_ndfnd,$accr_user_warning,$accr_evt_user_id,$accr_evt_grp_id,$accr_auth_normal,$accr_auth_special,$accr_auth_oper,$accr_auth_audit,$accr_auth_exit,$accr_auth_failsft,$accr_auth_bypass,$accr_auth_trusted,$accr_log_class,$accr_log_user,$accr_log_special,$accr_log_access,$accr_log_racinit,$accr_log_always,$accr_log_cmdviol,$accr_log_global,$accr_term_level,$accr_backout_fail,$accr_prof_same,$accr_term,$accr_job_name,$accr_read_time,$accr_read_date,$accr_smf_user_id,$accr_log_level,$accr_log_vmevent,$accr_log_logopt,$accr_log_secl,$accr_log_compatm,$accr_log_applaud,$accr_log_nonomvs,$accr_log_omvsnprv,$accr_auth_omvssu,$accr_auth_omvssys,$accr_usr_secl,$accr_racf_version,$accr_class,$accr_user_name,$accr_utk_encr,$accr_utk_pre19,$accr_utk_verprof,$accr_utk_njeunusr,$accr_utk_logusr,$accr_utk_special,$accr_utk_default,$accr_utk_unknusr,$accr_utk_error,$accr_utk_trusted,$accr_utk_sesstype,$accr_utk_surrogat,$accr_utk_remote,$accr_utk_priv,$accr_utk_secl,$accr_utk_execnode,$accr_utk_suser_id,$accr_utk_snode,$accr_utk_sgrp_id,$accr_utk_spoe,$accr_utk_spclass,$accr_utk_user_id,$accr_utk_grp_id,$accr_utk_dft_grp,$accr_utk_dft_secl,$accr_appc_link,$accr_audit_code,$accr_old_real_uid,$accr_old_eff_uid,$accr_old_saved_uid,$accr_old_real_gid,$accr_old_eff_gid,$accr_old_saved_gid,$accr_path_name,$accr_file1_id,$accr_dflt_process,$accr_utk_netw,$accr_x500_subject,$accr_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"accr"}++;
		next;
	}

	if ($rectype eq 'ADDGROUP') {
		$ag_event_type=substr($_,0,8);
		$ag_event_qual=substr($_,9,8);
		$ag_time_written=substr($_,18,8);
		if ($ag_time_written  eq ' ' x length($ag_time_written )) {
			undef $ag_time_written ;
		}
		$ag_date_written=substr($_,27,10);
		if ($ag_date_written  eq ' ' x length($ag_date_written )) {
			undef $ag_date_written ;
		}
		$ag_system_smfid=substr($_,38,4);
		$ag_violation=substr($_,43,1);
		$ag_user_ndfnd=substr($_,48,1);
		$ag_user_warning=substr($_,53,1);
		$ag_evt_user_id=substr($_,58,8);
		$ag_evt_grp_id=substr($_,67,8);
		$ag_auth_normal=substr($_,76,1);
		$ag_auth_special=substr($_,81,1);
		$ag_auth_oper=substr($_,86,1);
		$ag_auth_audit=substr($_,91,1);
		$ag_auth_exit=substr($_,96,1);
		$ag_auth_failsft=substr($_,101,1);
		$ag_auth_bypass=substr($_,106,1);
		$ag_auth_trusted=substr($_,111,1);
		$ag_log_class=substr($_,116,1);
		$ag_log_user=substr($_,121,1);
		$ag_log_special=substr($_,126,1);
		$ag_log_access=substr($_,131,1);
		$ag_log_racinit=substr($_,136,1);
		$ag_log_always=substr($_,141,1);
		$ag_log_cmdviol=substr($_,146,1);
		$ag_log_global=substr($_,151,1);
		$ag_term_level=substr($_,156,3);
		if ($ag_term_level  eq ' ' x length($ag_term_level )) {
			undef $ag_term_level ;
		}
		$ag_backout_fail=substr($_,160,1);
		$ag_prof_same=substr($_,165,1);
		$ag_term=substr($_,170,8);
		$ag_job_name=substr($_,179,8);
		$ag_read_time=substr($_,188,8);
		if ($ag_read_time  eq ' ' x length($ag_read_time )) {
			undef $ag_read_time ;
		}
		$ag_read_date=substr($_,197,10);
		if ($ag_read_date  eq ' ' x length($ag_read_date )) {
			undef $ag_read_date ;
		}
		$ag_smf_user_id=substr($_,208,8);
		$ag_log_level=substr($_,217,1);
		$ag_log_vmevent=substr($_,222,1);
		$ag_log_logopt=substr($_,227,1);
		$ag_log_secl=substr($_,232,1);
		$ag_log_compatm=substr($_,237,1);
		$ag_log_applaud=substr($_,242,1);
		$ag_log_nonomvs=substr($_,247,1);
		$ag_log_omvsnprv=substr($_,252,1);
		$ag_auth_omvssu=substr($_,257,1);
		$ag_auth_omvssys=substr($_,262,1);
		$ag_usr_secl=substr($_,267,8);
		$ag_racf_version=substr($_,276,4);
		$ag_own_id=substr($_,281,8);
		$ag_user_name=substr($_,290,20);
		$ag_utk_encr=substr($_,311,1);
		$ag_utk_pre19=substr($_,316,1);
		$ag_utk_verprof=substr($_,321,1);
		$ag_utk_njeunusr=substr($_,326,1);
		$ag_utk_logusr=substr($_,331,1);
		$ag_utk_special=substr($_,336,1);
		$ag_utk_default=substr($_,341,1);
		$ag_utk_unknusr=substr($_,346,1);
		$ag_utk_error=substr($_,351,1);
		$ag_utk_trusted=substr($_,356,1);
		$ag_utk_sesstype=substr($_,361,8);
		$ag_utk_surrogat=substr($_,370,1);
		$ag_utk_remote=substr($_,375,1);
		$ag_utk_priv=substr($_,380,1);
		$ag_utk_secl=substr($_,385,8);
		$ag_utk_execnode=substr($_,394,8);
		$ag_utk_suser_id=substr($_,403,8);
		$ag_utk_snode=substr($_,412,8);
		$ag_utk_sgrp_id=substr($_,421,8);
		$ag_utk_spoe=substr($_,430,8);
		$ag_utk_spclass=substr($_,439,8);
		$ag_utk_user_id=substr($_,448,8);
		$ag_utk_grp_id=substr($_,457,8);
		$ag_utk_dft_grp=substr($_,466,1);
		$ag_utk_dft_secl=substr($_,471,1);
		$ag_appc_link=substr($_,476,16);
		$ag_grp_id=substr($_,493,8);
		$ag_specified=substr($_,502,1024);
		$ag_failed=substr($_,1527,1024);
		$ag_utk_netw=substr($_,2552,8);
		$ag_x500_subject=substr($_,2561,255);
		$ag_x500_issuer=substr($_,2817,255);
		$rv=$insert{addgroup}->execute($ag_event_type,$ag_event_qual,$ag_time_written,$ag_date_written,$ag_system_smfid,$ag_violation,$ag_user_ndfnd,$ag_user_warning,$ag_evt_user_id,$ag_evt_grp_id,$ag_auth_normal,$ag_auth_special,$ag_auth_oper,$ag_auth_audit,$ag_auth_exit,$ag_auth_failsft,$ag_auth_bypass,$ag_auth_trusted,$ag_log_class,$ag_log_user,$ag_log_special,$ag_log_access,$ag_log_racinit,$ag_log_always,$ag_log_cmdviol,$ag_log_global,$ag_term_level,$ag_backout_fail,$ag_prof_same,$ag_term,$ag_job_name,$ag_read_time,$ag_read_date,$ag_smf_user_id,$ag_log_level,$ag_log_vmevent,$ag_log_logopt,$ag_log_secl,$ag_log_compatm,$ag_log_applaud,$ag_log_nonomvs,$ag_log_omvsnprv,$ag_auth_omvssu,$ag_auth_omvssys,$ag_usr_secl,$ag_racf_version,$ag_own_id,$ag_user_name,$ag_utk_encr,$ag_utk_pre19,$ag_utk_verprof,$ag_utk_njeunusr,$ag_utk_logusr,$ag_utk_special,$ag_utk_default,$ag_utk_unknusr,$ag_utk_error,$ag_utk_trusted,$ag_utk_sesstype,$ag_utk_surrogat,$ag_utk_remote,$ag_utk_priv,$ag_utk_secl,$ag_utk_execnode,$ag_utk_suser_id,$ag_utk_snode,$ag_utk_sgrp_id,$ag_utk_spoe,$ag_utk_spclass,$ag_utk_user_id,$ag_utk_grp_id,$ag_utk_dft_grp,$ag_utk_dft_secl,$ag_appc_link,$ag_grp_id,$ag_specified,$ag_failed,$ag_utk_netw,$ag_x500_subject,$ag_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"addgroup"}++;
		next;
	}

	if ($rectype eq 'ADDSD   ') {
		$ad_event_type=substr($_,0,8);
		$ad_event_qual=substr($_,9,8);
		$ad_time_written=substr($_,18,8);
		if ($ad_time_written  eq ' ' x length($ad_time_written )) {
			undef $ad_time_written ;
		}
		$ad_date_written=substr($_,27,10);
		if ($ad_date_written  eq ' ' x length($ad_date_written )) {
			undef $ad_date_written ;
		}
		$ad_system_smfid=substr($_,38,4);
		$ad_violation=substr($_,43,1);
		$ad_user_ndfnd=substr($_,48,1);
		$ad_user_warning=substr($_,53,1);
		$ad_evt_user_id=substr($_,58,8);
		$ad_evt_grp_id=substr($_,67,8);
		$ad_auth_normal=substr($_,76,1);
		$ad_auth_special=substr($_,81,1);
		$ad_auth_oper=substr($_,86,1);
		$ad_auth_audit=substr($_,91,1);
		$ad_auth_exit=substr($_,96,1);
		$ad_auth_failsft=substr($_,101,1);
		$ad_auth_bypass=substr($_,106,1);
		$ad_auth_trusted=substr($_,111,1);
		$ad_log_class=substr($_,116,1);
		$ad_log_user=substr($_,121,1);
		$ad_log_special=substr($_,126,1);
		$ad_log_access=substr($_,131,1);
		$ad_log_racinit=substr($_,136,1);
		$ad_log_always=substr($_,141,1);
		$ad_log_cmdviol=substr($_,146,1);
		$ad_log_global=substr($_,151,1);
		$ad_term_level=substr($_,156,3);
		if ($ad_term_level  eq ' ' x length($ad_term_level )) {
			undef $ad_term_level ;
		}
		$ad_backout_fail=substr($_,160,1);
		$ad_prof_same=substr($_,165,1);
		$ad_term=substr($_,170,8);
		$ad_job_name=substr($_,179,8);
		$ad_read_time=substr($_,188,8);
		if ($ad_read_time  eq ' ' x length($ad_read_time )) {
			undef $ad_read_time ;
		}
		$ad_read_date=substr($_,197,10);
		if ($ad_read_date  eq ' ' x length($ad_read_date )) {
			undef $ad_read_date ;
		}
		$ad_smf_user_id=substr($_,208,8);
		$ad_log_level=substr($_,217,1);
		$ad_log_vmevent=substr($_,222,1);
		$ad_log_logopt=substr($_,227,1);
		$ad_log_secl=substr($_,232,1);
		$ad_log_compatm=substr($_,237,1);
		$ad_log_applaud=substr($_,242,1);
		$ad_log_nonomvs=substr($_,247,1);
		$ad_log_omvsnprv=substr($_,252,1);
		$ad_auth_omvssu=substr($_,257,1);
		$ad_auth_omvssys=substr($_,262,1);
		$ad_usr_secl=substr($_,267,8);
		$ad_racf_version=substr($_,276,4);
		$ad_own_id=substr($_,281,8);
		$ad_user_name=substr($_,290,20);
		$ad_secl=substr($_,311,8);
		$ad_utk_encr=substr($_,320,1);
		$ad_utk_pre19=substr($_,325,1);
		$ad_utk_verprof=substr($_,330,1);
		$ad_utk_njeunusr=substr($_,335,1);
		$ad_utk_logusr=substr($_,340,1);
		$ad_utk_special=substr($_,345,1);
		$ad_utk_default=substr($_,350,1);
		$ad_utk_unknusr=substr($_,355,1);
		$ad_utk_error=substr($_,360,1);
		$ad_utk_trusted=substr($_,365,1);
		$ad_utk_sesstype=substr($_,370,8);
		$ad_utk_surrogat=substr($_,379,1);
		$ad_utk_remote=substr($_,384,1);
		$ad_utk_priv=substr($_,389,1);
		$ad_utk_secl=substr($_,394,8);
		$ad_utk_execnode=substr($_,403,8);
		$ad_utk_suser_id=substr($_,412,8);
		$ad_utk_snode=substr($_,421,8);
		$ad_utk_sgrp_id=substr($_,430,8);
		$ad_utk_spoe=substr($_,439,8);
		$ad_utk_spclass=substr($_,448,8);
		$ad_utk_user_id=substr($_,457,8);
		$ad_utk_grp_id=substr($_,466,8);
		$ad_utk_dft_grp=substr($_,475,1);
		$ad_utk_dft_secl=substr($_,480,1);
		$ad_appc_link=substr($_,485,16);
		$ad_secl_link=substr($_,502,16);
		$ad_ds_name=substr($_,519,44);
		$ad_specified=substr($_,564,1024);
		$ad_failed=substr($_,1589,1024);
		$ad_utk_netw=substr($_,2614,8);
		$ad_x500_subject=substr($_,2623,255);
		$ad_x500_issuer=substr($_,2879,255);
		$rv=$insert{addsd}->execute($ad_event_type,$ad_event_qual,$ad_time_written,$ad_date_written,$ad_system_smfid,$ad_violation,$ad_user_ndfnd,$ad_user_warning,$ad_evt_user_id,$ad_evt_grp_id,$ad_auth_normal,$ad_auth_special,$ad_auth_oper,$ad_auth_audit,$ad_auth_exit,$ad_auth_failsft,$ad_auth_bypass,$ad_auth_trusted,$ad_log_class,$ad_log_user,$ad_log_special,$ad_log_access,$ad_log_racinit,$ad_log_always,$ad_log_cmdviol,$ad_log_global,$ad_term_level,$ad_backout_fail,$ad_prof_same,$ad_term,$ad_job_name,$ad_read_time,$ad_read_date,$ad_smf_user_id,$ad_log_level,$ad_log_vmevent,$ad_log_logopt,$ad_log_secl,$ad_log_compatm,$ad_log_applaud,$ad_log_nonomvs,$ad_log_omvsnprv,$ad_auth_omvssu,$ad_auth_omvssys,$ad_usr_secl,$ad_racf_version,$ad_own_id,$ad_user_name,$ad_secl,$ad_utk_encr,$ad_utk_pre19,$ad_utk_verprof,$ad_utk_njeunusr,$ad_utk_logusr,$ad_utk_special,$ad_utk_default,$ad_utk_unknusr,$ad_utk_error,$ad_utk_trusted,$ad_utk_sesstype,$ad_utk_surrogat,$ad_utk_remote,$ad_utk_priv,$ad_utk_secl,$ad_utk_execnode,$ad_utk_suser_id,$ad_utk_snode,$ad_utk_sgrp_id,$ad_utk_spoe,$ad_utk_spclass,$ad_utk_user_id,$ad_utk_grp_id,$ad_utk_dft_grp,$ad_utk_dft_secl,$ad_appc_link,$ad_secl_link,$ad_ds_name,$ad_specified,$ad_failed,$ad_utk_netw,$ad_x500_subject,$ad_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"addsd"}++;
		next;
	}

	if ($rectype eq 'ADDUSER ') {
		$au_event_type=substr($_,0,8);
		$au_event_qual=substr($_,9,8);
		$au_time_written=substr($_,18,8);
		if ($au_time_written  eq ' ' x length($au_time_written )) {
			undef $au_time_written ;
		}
		$au_date_written=substr($_,27,10);
		if ($au_date_written  eq ' ' x length($au_date_written )) {
			undef $au_date_written ;
		}
		$au_system_smfid=substr($_,38,4);
		$au_violation=substr($_,43,1);
		$au_user_ndfnd=substr($_,48,1);
		$au_user_warning=substr($_,53,1);
		$au_evt_user_id=substr($_,58,8);
		$au_evt_grp_id=substr($_,67,8);
		$au_auth_normal=substr($_,76,1);
		$au_auth_special=substr($_,81,1);
		$au_auth_oper=substr($_,86,1);
		$au_auth_audit=substr($_,91,1);
		$au_auth_exit=substr($_,96,1);
		$au_auth_failsft=substr($_,101,1);
		$au_auth_bypass=substr($_,106,1);
		$au_auth_trusted=substr($_,111,1);
		$au_log_class=substr($_,116,1);
		$au_log_user=substr($_,121,1);
		$au_log_special=substr($_,126,1);
		$au_log_access=substr($_,131,1);
		$au_log_racinit=substr($_,136,1);
		$au_log_always=substr($_,141,1);
		$au_log_cmdviol=substr($_,146,1);
		$au_log_global=substr($_,151,1);
		$au_term_level=substr($_,156,3);
		if ($au_term_level  eq ' ' x length($au_term_level )) {
			undef $au_term_level ;
		}
		$au_backout_fail=substr($_,160,1);
		$au_prof_same=substr($_,165,1);
		$au_term=substr($_,170,8);
		$au_job_name=substr($_,179,8);
		$au_read_time=substr($_,188,8);
		if ($au_read_time  eq ' ' x length($au_read_time )) {
			undef $au_read_time ;
		}
		$au_read_date=substr($_,197,10);
		if ($au_read_date  eq ' ' x length($au_read_date )) {
			undef $au_read_date ;
		}
		$au_smf_user_id=substr($_,208,8);
		$au_log_level=substr($_,217,1);
		$au_log_vmevent=substr($_,222,1);
		$au_log_logopt=substr($_,227,1);
		$au_log_secl=substr($_,232,1);
		$au_log_compatm=substr($_,237,1);
		$au_log_applaud=substr($_,242,1);
		$au_log_nonomvs=substr($_,247,1);
		$au_log_omvsnprv=substr($_,252,1);
		$au_auth_omvssu=substr($_,257,1);
		$au_auth_omvssys=substr($_,262,1);
		$au_usr_secl=substr($_,267,8);
		$au_racf_version=substr($_,276,4);
		$au_own_id=substr($_,281,8);
		$au_user_name=substr($_,290,20);
		$au_utk_encr=substr($_,311,1);
		$au_utk_pre19=substr($_,316,1);
		$au_utk_verprof=substr($_,321,1);
		$au_utk_njeunusr=substr($_,326,1);
		$au_utk_logusr=substr($_,331,1);
		$au_utk_special=substr($_,336,1);
		$au_utk_default=substr($_,341,1);
		$au_utk_unknusr=substr($_,346,1);
		$au_utk_error=substr($_,351,1);
		$au_utk_trusted=substr($_,356,1);
		$au_utk_sesstype=substr($_,361,8);
		$au_utk_surrogat=substr($_,370,1);
		$au_utk_remote=substr($_,375,1);
		$au_utk_priv=substr($_,380,1);
		$au_utk_secl=substr($_,385,8);
		$au_utk_execnode=substr($_,394,8);
		$au_utk_suser_id=substr($_,403,8);
		$au_utk_snode=substr($_,412,8);
		$au_utk_sgrp_id=substr($_,421,8);
		$au_utk_spoe=substr($_,430,8);
		$au_utk_spclass=substr($_,439,8);
		$au_utk_user_id=substr($_,448,8);
		$au_utk_grp_id=substr($_,457,8);
		$au_utk_dft_grp=substr($_,466,1);
		$au_utk_dft_secl=substr($_,471,1);
		$au_appc_link=substr($_,476,16);
		$au_noauth_clauth=substr($_,493,1);
		$au_noauth_group=substr($_,498,1);
		$au_user_id=substr($_,503,8);
		$au_specified=substr($_,512,1024);
		$au_failed=substr($_,1537,1024);
		$au_ignored=substr($_,2562,1024);
		$au_utk_netw=substr($_,3587,8);
		$au_x500_subject=substr($_,3596,255);
		$au_x500_issuer=substr($_,3852,255);
		$rv=$insert{adduser}->execute($au_event_type,$au_event_qual,$au_time_written,$au_date_written,$au_system_smfid,$au_violation,$au_user_ndfnd,$au_user_warning,$au_evt_user_id,$au_evt_grp_id,$au_auth_normal,$au_auth_special,$au_auth_oper,$au_auth_audit,$au_auth_exit,$au_auth_failsft,$au_auth_bypass,$au_auth_trusted,$au_log_class,$au_log_user,$au_log_special,$au_log_access,$au_log_racinit,$au_log_always,$au_log_cmdviol,$au_log_global,$au_term_level,$au_backout_fail,$au_prof_same,$au_term,$au_job_name,$au_read_time,$au_read_date,$au_smf_user_id,$au_log_level,$au_log_vmevent,$au_log_logopt,$au_log_secl,$au_log_compatm,$au_log_applaud,$au_log_nonomvs,$au_log_omvsnprv,$au_auth_omvssu,$au_auth_omvssys,$au_usr_secl,$au_racf_version,$au_own_id,$au_user_name,$au_utk_encr,$au_utk_pre19,$au_utk_verprof,$au_utk_njeunusr,$au_utk_logusr,$au_utk_special,$au_utk_default,$au_utk_unknusr,$au_utk_error,$au_utk_trusted,$au_utk_sesstype,$au_utk_surrogat,$au_utk_remote,$au_utk_priv,$au_utk_secl,$au_utk_execnode,$au_utk_suser_id,$au_utk_snode,$au_utk_sgrp_id,$au_utk_spoe,$au_utk_spclass,$au_utk_user_id,$au_utk_grp_id,$au_utk_dft_grp,$au_utk_dft_secl,$au_appc_link,$au_noauth_clauth,$au_noauth_group,$au_user_id,$au_specified,$au_failed,$au_ignored,$au_utk_netw,$au_x500_subject,$au_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"adduser"}++;
		next;
	}

	if ($rectype eq 'ADDVOL  ') {
		$adv_event_type=substr($_,0,8);
		$adv_event_qual=substr($_,9,8);
		$adv_time_written=substr($_,18,8);
		if ($adv_time_written  eq ' ' x length($adv_time_written )) {
			undef $adv_time_written ;
		}
		$adv_date_written=substr($_,27,10);
		if ($adv_date_written  eq ' ' x length($adv_date_written )) {
			undef $adv_date_written ;
		}
		$adv_system_smfid=substr($_,38,4);
		$adv_violation=substr($_,43,1);
		$adv_user_ndfnd=substr($_,48,1);
		$adv_user_warning=substr($_,53,1);
		$adv_evt_user_id=substr($_,58,8);
		$adv_evt_grp_id=substr($_,67,8);
		$adv_auth_normal=substr($_,76,1);
		$adv_auth_special=substr($_,81,1);
		$adv_auth_oper=substr($_,86,1);
		$adv_auth_audit=substr($_,91,1);
		$adv_auth_exit=substr($_,96,1);
		$adv_auth_failsft=substr($_,101,1);
		$adv_auth_bypass=substr($_,106,1);
		$adv_auth_trusted=substr($_,111,1);
		$adv_log_class=substr($_,116,1);
		$adv_log_user=substr($_,121,1);
		$adv_log_special=substr($_,126,1);
		$adv_log_access=substr($_,131,1);
		$adv_log_racinit=substr($_,136,1);
		$adv_log_always=substr($_,141,1);
		$adv_log_cmdviol=substr($_,146,1);
		$adv_log_global=substr($_,151,1);
		$adv_term_level=substr($_,156,3);
		if ($adv_term_level  eq ' ' x length($adv_term_level )) {
			undef $adv_term_level ;
		}
		$adv_backout_fail=substr($_,160,1);
		$adv_prof_same=substr($_,165,1);
		$adv_term=substr($_,170,8);
		$adv_job_name=substr($_,179,8);
		$adv_read_time=substr($_,188,8);
		if ($adv_read_time  eq ' ' x length($adv_read_time )) {
			undef $adv_read_time ;
		}
		$adv_read_date=substr($_,197,10);
		if ($adv_read_date  eq ' ' x length($adv_read_date )) {
			undef $adv_read_date ;
		}
		$adv_smf_user_id=substr($_,208,8);
		$adv_log_level=substr($_,217,1);
		$adv_log_vmevent=substr($_,222,1);
		$adv_log_logopt=substr($_,227,1);
		$adv_log_secl=substr($_,232,1);
		$adv_log_compatm=substr($_,237,1);
		$adv_log_applaud=substr($_,242,1);
		$adv_log_nonomvs=substr($_,247,1);
		$adv_log_omvsnprv=substr($_,252,1);
		$adv_auth_omvssu=substr($_,257,1);
		$adv_auth_omvssys=substr($_,262,1);
		$adv_usr_secl=substr($_,267,8);
		$adv_racf_version=substr($_,276,4);
		$adv_res_name=substr($_,281,255);
		$adv_grant=substr($_,537,8);
		$adv_level=substr($_,546,3);
		if ($adv_level  eq ' ' x length($adv_level )) {
			undef $adv_level ;
		}
		$adv_vol=substr($_,550,6);
		$adv_oldvol=substr($_,557,6);
		$adv_class=substr($_,564,8);
		$adv_own_id=substr($_,573,8);
		$adv_logstr=substr($_,582,255);
		$adv_user_name=substr($_,838,20);
		$adv_utk_encr=substr($_,859,1);
		$adv_utk_pre19=substr($_,864,1);
		$adv_utk_verprof=substr($_,869,1);
		$adv_utk_njeunusr=substr($_,874,1);
		$adv_utk_logusr=substr($_,879,1);
		$adv_utk_special=substr($_,884,1);
		$adv_utk_default=substr($_,889,1);
		$adv_utk_unknusr=substr($_,894,1);
		$adv_utk_error=substr($_,899,1);
		$adv_utk_trusted=substr($_,904,1);
		$adv_utk_sesstype=substr($_,909,8);
		$adv_utk_surrogat=substr($_,918,1);
		$adv_utk_remote=substr($_,923,1);
		$adv_utk_priv=substr($_,928,1);
		$adv_utk_secl=substr($_,933,8);
		$adv_utk_execnode=substr($_,942,8);
		$adv_utk_suser_id=substr($_,951,8);
		$adv_utk_snode=substr($_,960,8);
		$adv_utk_sgrp_id=substr($_,969,8);
		$adv_utk_spoe=substr($_,978,8);
		$adv_utk_spclass=substr($_,987,8);
		$adv_utk_user_id=substr($_,996,8);
		$adv_utk_grp_id=substr($_,1005,8);
		$adv_utk_dft_grp=substr($_,1014,1);
		$adv_utk_dft_secl=substr($_,1019,1);
		$adv_appc_link=substr($_,1024,16);
		$adv_specified=substr($_,1041,1024);
		$adv_utk_netw=substr($_,2066,8);
		$adv_x500_subject=substr($_,2075,255);
		$adv_x500_issuer=substr($_,2331,255);
		$rv=$insert{addvol}->execute($adv_event_type,$adv_event_qual,$adv_time_written,$adv_date_written,$adv_system_smfid,$adv_violation,$adv_user_ndfnd,$adv_user_warning,$adv_evt_user_id,$adv_evt_grp_id,$adv_auth_normal,$adv_auth_special,$adv_auth_oper,$adv_auth_audit,$adv_auth_exit,$adv_auth_failsft,$adv_auth_bypass,$adv_auth_trusted,$adv_log_class,$adv_log_user,$adv_log_special,$adv_log_access,$adv_log_racinit,$adv_log_always,$adv_log_cmdviol,$adv_log_global,$adv_term_level,$adv_backout_fail,$adv_prof_same,$adv_term,$adv_job_name,$adv_read_time,$adv_read_date,$adv_smf_user_id,$adv_log_level,$adv_log_vmevent,$adv_log_logopt,$adv_log_secl,$adv_log_compatm,$adv_log_applaud,$adv_log_nonomvs,$adv_log_omvsnprv,$adv_auth_omvssu,$adv_auth_omvssys,$adv_usr_secl,$adv_racf_version,$adv_res_name,$adv_grant,$adv_level,$adv_vol,$adv_oldvol,$adv_class,$adv_own_id,$adv_logstr,$adv_user_name,$adv_utk_encr,$adv_utk_pre19,$adv_utk_verprof,$adv_utk_njeunusr,$adv_utk_logusr,$adv_utk_special,$adv_utk_default,$adv_utk_unknusr,$adv_utk_error,$adv_utk_trusted,$adv_utk_sesstype,$adv_utk_surrogat,$adv_utk_remote,$adv_utk_priv,$adv_utk_secl,$adv_utk_execnode,$adv_utk_suser_id,$adv_utk_snode,$adv_utk_sgrp_id,$adv_utk_spoe,$adv_utk_spclass,$adv_utk_user_id,$adv_utk_grp_id,$adv_utk_dft_grp,$adv_utk_dft_secl,$adv_appc_link,$adv_specified,$adv_utk_netw,$adv_x500_subject,$adv_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"addvol"}++;
		next;
	}

	if ($rectype eq 'ALTDSD  ') {
		$ald_event_type=substr($_,0,8);
		$ald_event_qual=substr($_,9,8);
		$ald_time_written=substr($_,18,8);
		if ($ald_time_written  eq ' ' x length($ald_time_written )) {
			undef $ald_time_written ;
		}
		$ald_date_written=substr($_,27,10);
		if ($ald_date_written  eq ' ' x length($ald_date_written )) {
			undef $ald_date_written ;
		}
		$ald_system_smfid=substr($_,38,4);
		$ald_violation=substr($_,43,1);
		$ald_user_ndfnd=substr($_,48,1);
		$ald_user_warning=substr($_,53,1);
		$ald_evt_user_id=substr($_,58,8);
		$ald_evt_grp_id=substr($_,67,8);
		$ald_auth_normal=substr($_,76,1);
		$ald_auth_special=substr($_,81,1);
		$ald_auth_oper=substr($_,86,1);
		$ald_auth_audit=substr($_,91,1);
		$ald_auth_exit=substr($_,96,1);
		$ald_auth_failsft=substr($_,101,1);
		$ald_auth_bypass=substr($_,106,1);
		$ald_auth_trusted=substr($_,111,1);
		$ald_log_class=substr($_,116,1);
		$ald_log_user=substr($_,121,1);
		$ald_log_special=substr($_,126,1);
		$ald_log_access=substr($_,131,1);
		$ald_log_racinit=substr($_,136,1);
		$ald_log_always=substr($_,141,1);
		$ald_log_cmdviol=substr($_,146,1);
		$ald_log_global=substr($_,151,1);
		$ald_term_level=substr($_,156,3);
		if ($ald_term_level  eq ' ' x length($ald_term_level )) {
			undef $ald_term_level ;
		}
		$ald_backout_fail=substr($_,160,1);
		$ald_prof_same=substr($_,165,1);
		$ald_term=substr($_,170,8);
		$ald_job_name=substr($_,179,8);
		$ald_read_time=substr($_,188,8);
		if ($ald_read_time  eq ' ' x length($ald_read_time )) {
			undef $ald_read_time ;
		}
		$ald_read_date=substr($_,197,10);
		if ($ald_read_date  eq ' ' x length($ald_read_date )) {
			undef $ald_read_date ;
		}
		$ald_smf_user_id=substr($_,208,8);
		$ald_log_level=substr($_,217,1);
		$ald_log_vmevent=substr($_,222,1);
		$ald_log_logopt=substr($_,227,1);
		$ald_log_secl=substr($_,232,1);
		$ald_log_compatm=substr($_,237,1);
		$ald_log_applaud=substr($_,242,1);
		$ald_log_nonomvs=substr($_,247,1);
		$ald_log_omvsnprv=substr($_,252,1);
		$ald_auth_omvssu=substr($_,257,1);
		$ald_auth_omvssys=substr($_,262,1);
		$ald_usr_secl=substr($_,267,8);
		$ald_racf_version=substr($_,276,4);
		$ald_own_id=substr($_,281,8);
		$ald_user_name=substr($_,290,20);
		$ald_old_secl=substr($_,311,8);
		$ald_utk_encr=substr($_,320,1);
		$ald_utk_pre19=substr($_,325,1);
		$ald_utk_verprof=substr($_,330,1);
		$ald_utk_njeunusr=substr($_,335,1);
		$ald_utk_logusr=substr($_,340,1);
		$ald_utk_special=substr($_,345,1);
		$ald_utk_default=substr($_,350,1);
		$ald_utk_unknusr=substr($_,355,1);
		$ald_utk_error=substr($_,360,1);
		$ald_utk_trusted=substr($_,365,1);
		$ald_utk_sesstype=substr($_,370,8);
		$ald_utk_surrogat=substr($_,379,1);
		$ald_utk_remote=substr($_,384,1);
		$ald_utk_priv=substr($_,389,1);
		$ald_utk_secl=substr($_,394,8);
		$ald_utk_execnode=substr($_,403,8);
		$ald_utk_suser_id=substr($_,412,8);
		$ald_utk_snode=substr($_,421,8);
		$ald_utk_sgrp_id=substr($_,430,8);
		$ald_utk_spoe=substr($_,439,8);
		$ald_utk_spclass=substr($_,448,8);
		$ald_utk_user_id=substr($_,457,8);
		$ald_utk_grp_id=substr($_,466,8);
		$ald_utk_dft_grp=substr($_,475,1);
		$ald_utk_dft_secl=substr($_,480,1);
		$ald_appc_link=substr($_,485,16);
		$ald_secl_link=substr($_,502,16);
		$ald_ds_name=substr($_,519,44);
		$ald_specified=substr($_,564,1024);
		$ald_failed=substr($_,1589,1024);
		$ald_ignored=substr($_,2614,1024);
		$ald_utk_netw=substr($_,3639,8);
		$ald_x500_subject=substr($_,3648,255);
		$ald_x500_issuer=substr($_,3904,255);
		$rv=$insert{altdsd}->execute($ald_event_type,$ald_event_qual,$ald_time_written,$ald_date_written,$ald_system_smfid,$ald_violation,$ald_user_ndfnd,$ald_user_warning,$ald_evt_user_id,$ald_evt_grp_id,$ald_auth_normal,$ald_auth_special,$ald_auth_oper,$ald_auth_audit,$ald_auth_exit,$ald_auth_failsft,$ald_auth_bypass,$ald_auth_trusted,$ald_log_class,$ald_log_user,$ald_log_special,$ald_log_access,$ald_log_racinit,$ald_log_always,$ald_log_cmdviol,$ald_log_global,$ald_term_level,$ald_backout_fail,$ald_prof_same,$ald_term,$ald_job_name,$ald_read_time,$ald_read_date,$ald_smf_user_id,$ald_log_level,$ald_log_vmevent,$ald_log_logopt,$ald_log_secl,$ald_log_compatm,$ald_log_applaud,$ald_log_nonomvs,$ald_log_omvsnprv,$ald_auth_omvssu,$ald_auth_omvssys,$ald_usr_secl,$ald_racf_version,$ald_own_id,$ald_user_name,$ald_old_secl,$ald_utk_encr,$ald_utk_pre19,$ald_utk_verprof,$ald_utk_njeunusr,$ald_utk_logusr,$ald_utk_special,$ald_utk_default,$ald_utk_unknusr,$ald_utk_error,$ald_utk_trusted,$ald_utk_sesstype,$ald_utk_surrogat,$ald_utk_remote,$ald_utk_priv,$ald_utk_secl,$ald_utk_execnode,$ald_utk_suser_id,$ald_utk_snode,$ald_utk_sgrp_id,$ald_utk_spoe,$ald_utk_spclass,$ald_utk_user_id,$ald_utk_grp_id,$ald_utk_dft_grp,$ald_utk_dft_secl,$ald_appc_link,$ald_secl_link,$ald_ds_name,$ald_specified,$ald_failed,$ald_ignored,$ald_utk_netw,$ald_x500_subject,$ald_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"altdsd"}++;
		next;
	}

	if ($rectype eq 'ALTGROUP') {
		$alg_event_type=substr($_,0,8);
		$alg_event_qual=substr($_,9,8);
		$alg_time_written=substr($_,18,8);
		if ($alg_time_written  eq ' ' x length($alg_time_written )) {
			undef $alg_time_written ;
		}
		$alg_date_written=substr($_,27,10);
		if ($alg_date_written  eq ' ' x length($alg_date_written )) {
			undef $alg_date_written ;
		}
		$alg_system_smfid=substr($_,38,4);
		$alg_violation=substr($_,43,1);
		$alg_user_ndfnd=substr($_,48,1);
		$alg_user_warning=substr($_,53,1);
		$alg_evt_user_id=substr($_,58,8);
		$alg_evt_grp_id=substr($_,67,8);
		$alg_auth_normal=substr($_,76,1);
		$alg_auth_special=substr($_,81,1);
		$alg_auth_oper=substr($_,86,1);
		$alg_auth_audit=substr($_,91,1);
		$alg_auth_exit=substr($_,96,1);
		$alg_auth_failsft=substr($_,101,1);
		$alg_auth_bypass=substr($_,106,1);
		$alg_auth_trusted=substr($_,111,1);
		$alg_log_class=substr($_,116,1);
		$alg_log_user=substr($_,121,1);
		$alg_log_special=substr($_,126,1);
		$alg_log_access=substr($_,131,1);
		$alg_log_racinit=substr($_,136,1);
		$alg_log_always=substr($_,141,1);
		$alg_log_cmdviol=substr($_,146,1);
		$alg_log_global=substr($_,151,1);
		$alg_term_level=substr($_,156,3);
		if ($alg_term_level  eq ' ' x length($alg_term_level )) {
			undef $alg_term_level ;
		}
		$alg_backout_fail=substr($_,160,1);
		$alg_prof_same=substr($_,165,1);
		$alg_term=substr($_,170,8);
		$alg_job_name=substr($_,179,8);
		$alg_read_time=substr($_,188,8);
		if ($alg_read_time  eq ' ' x length($alg_read_time )) {
			undef $alg_read_time ;
		}
		$alg_read_date=substr($_,197,10);
		if ($alg_read_date  eq ' ' x length($alg_read_date )) {
			undef $alg_read_date ;
		}
		$alg_smf_user_id=substr($_,208,8);
		$alg_log_level=substr($_,217,1);
		$alg_log_vmevent=substr($_,222,1);
		$alg_log_logopt=substr($_,227,1);
		$alg_log_secl=substr($_,232,1);
		$alg_log_compatm=substr($_,237,1);
		$alg_log_applaud=substr($_,242,1);
		$alg_log_nonomvs=substr($_,247,1);
		$alg_log_omvsnprv=substr($_,252,1);
		$alg_auth_omvssu=substr($_,257,1);
		$alg_auth_omvssys=substr($_,262,1);
		$alg_usr_secl=substr($_,267,8);
		$alg_racf_version=substr($_,276,4);
		$alg_own_id=substr($_,281,8);
		$alg_user_name=substr($_,290,20);
		$alg_utk_encr=substr($_,311,1);
		$alg_utk_pre19=substr($_,316,1);
		$alg_utk_verprof=substr($_,321,1);
		$alg_utk_njeunusr=substr($_,326,1);
		$alg_utk_logusr=substr($_,331,1);
		$alg_utk_special=substr($_,336,1);
		$alg_utk_default=substr($_,341,1);
		$alg_utk_unknusr=substr($_,346,1);
		$alg_utk_error=substr($_,351,1);
		$alg_utk_trusted=substr($_,356,1);
		$alg_utk_sesstype=substr($_,361,8);
		$alg_utk_surrogat=substr($_,370,1);
		$alg_utk_remote=substr($_,375,1);
		$alg_utk_priv=substr($_,380,1);
		$alg_utk_secl=substr($_,385,8);
		$alg_utk_execnode=substr($_,394,8);
		$alg_utk_suser_id=substr($_,403,8);
		$alg_utk_snode=substr($_,412,8);
		$alg_utk_sgrp_id=substr($_,421,8);
		$alg_utk_spoe=substr($_,430,8);
		$alg_utk_spclass=substr($_,439,8);
		$alg_utk_user_id=substr($_,448,8);
		$alg_utk_grp_id=substr($_,457,8);
		$alg_utk_dft_grp=substr($_,466,1);
		$alg_utk_dft_secl=substr($_,471,1);
		$alg_appc_link=substr($_,476,16);
		$alg_grp_id=substr($_,493,8);
		$alg_specified=substr($_,502,1024);
		$alg_failed=substr($_,1527,1024);
		$alg_ignored=substr($_,2552,1024);
		$alg_utk_netw=substr($_,3577,8);
		$alg_x500_subject=substr($_,3586,255);
		$alg_x500_issuer=substr($_,3842,255);
		$rv=$insert{altgroup}->execute($alg_event_type,$alg_event_qual,$alg_time_written,$alg_date_written,$alg_system_smfid,$alg_violation,$alg_user_ndfnd,$alg_user_warning,$alg_evt_user_id,$alg_evt_grp_id,$alg_auth_normal,$alg_auth_special,$alg_auth_oper,$alg_auth_audit,$alg_auth_exit,$alg_auth_failsft,$alg_auth_bypass,$alg_auth_trusted,$alg_log_class,$alg_log_user,$alg_log_special,$alg_log_access,$alg_log_racinit,$alg_log_always,$alg_log_cmdviol,$alg_log_global,$alg_term_level,$alg_backout_fail,$alg_prof_same,$alg_term,$alg_job_name,$alg_read_time,$alg_read_date,$alg_smf_user_id,$alg_log_level,$alg_log_vmevent,$alg_log_logopt,$alg_log_secl,$alg_log_compatm,$alg_log_applaud,$alg_log_nonomvs,$alg_log_omvsnprv,$alg_auth_omvssu,$alg_auth_omvssys,$alg_usr_secl,$alg_racf_version,$alg_own_id,$alg_user_name,$alg_utk_encr,$alg_utk_pre19,$alg_utk_verprof,$alg_utk_njeunusr,$alg_utk_logusr,$alg_utk_special,$alg_utk_default,$alg_utk_unknusr,$alg_utk_error,$alg_utk_trusted,$alg_utk_sesstype,$alg_utk_surrogat,$alg_utk_remote,$alg_utk_priv,$alg_utk_secl,$alg_utk_execnode,$alg_utk_suser_id,$alg_utk_snode,$alg_utk_sgrp_id,$alg_utk_spoe,$alg_utk_spclass,$alg_utk_user_id,$alg_utk_grp_id,$alg_utk_dft_grp,$alg_utk_dft_secl,$alg_appc_link,$alg_grp_id,$alg_specified,$alg_failed,$alg_ignored,$alg_utk_netw,$alg_x500_subject,$alg_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"altgroup"}++;
		next;
	}

	if ($rectype eq 'ALTUSER ') {
		$alu_event_type=substr($_,0,8);
		$alu_event_qual=substr($_,9,8);
		$alu_time_written=substr($_,18,8);
		if ($alu_time_written  eq ' ' x length($alu_time_written )) {
			undef $alu_time_written ;
		}
		$alu_date_written=substr($_,27,10);
		if ($alu_date_written  eq ' ' x length($alu_date_written )) {
			undef $alu_date_written ;
		}
		$alu_system_smfid=substr($_,38,4);
		$alu_violation=substr($_,43,1);
		$alu_user_ndfnd=substr($_,48,1);
		$alu_user_warning=substr($_,53,1);
		$alu_evt_user_id=substr($_,58,8);
		$alu_evt_grp_id=substr($_,67,8);
		$alu_auth_normal=substr($_,76,1);
		$alu_auth_special=substr($_,81,1);
		$alu_auth_oper=substr($_,86,1);
		$alu_auth_audit=substr($_,91,1);
		$alu_auth_exit=substr($_,96,1);
		$alu_auth_failsft=substr($_,101,1);
		$alu_auth_bypass=substr($_,106,1);
		$alu_auth_trusted=substr($_,111,1);
		$alu_log_class=substr($_,116,1);
		$alu_log_user=substr($_,121,1);
		$alu_log_special=substr($_,126,1);
		$alu_log_access=substr($_,131,1);
		$alu_log_racinit=substr($_,136,1);
		$alu_log_always=substr($_,141,1);
		$alu_log_cmdviol=substr($_,146,1);
		$alu_log_global=substr($_,151,1);
		$alu_term_level=substr($_,156,3);
		if ($alu_term_level  eq ' ' x length($alu_term_level )) {
			undef $alu_term_level ;
		}
		$alu_backout_fail=substr($_,160,1);
		$alu_prof_same=substr($_,165,1);
		$alu_term=substr($_,170,8);
		$alu_job_name=substr($_,179,8);
		$alu_read_time=substr($_,188,8);
		if ($alu_read_time  eq ' ' x length($alu_read_time )) {
			undef $alu_read_time ;
		}
		$alu_read_date=substr($_,197,10);
		if ($alu_read_date  eq ' ' x length($alu_read_date )) {
			undef $alu_read_date ;
		}
		$alu_smf_user_id=substr($_,208,8);
		$alu_log_level=substr($_,217,1);
		$alu_log_vmevent=substr($_,222,1);
		$alu_log_logopt=substr($_,227,1);
		$alu_log_secl=substr($_,232,1);
		$alu_log_compatm=substr($_,237,1);
		$alu_log_applaud=substr($_,242,1);
		$alu_log_nonomvs=substr($_,247,1);
		$alu_log_omvsnprv=substr($_,252,1);
		$alu_auth_omvssu=substr($_,257,1);
		$alu_auth_omvssys=substr($_,262,1);
		$alu_usr_secl=substr($_,267,8);
		$alu_racf_version=substr($_,276,4);
		$alu_own_id=substr($_,281,8);
		$alu_user_name=substr($_,290,20);
		$alu_old_secl=substr($_,311,8);
		$alu_utk_encr=substr($_,320,1);
		$alu_utk_pre19=substr($_,325,1);
		$alu_utk_verprof=substr($_,330,1);
		$alu_utk_njeunusr=substr($_,335,1);
		$alu_utk_logusr=substr($_,340,1);
		$alu_utk_special=substr($_,345,1);
		$alu_utk_default=substr($_,350,1);
		$alu_utk_unknusr=substr($_,355,1);
		$alu_utk_error=substr($_,360,1);
		$alu_utk_trusted=substr($_,365,1);
		$alu_utk_sesstype=substr($_,370,8);
		$alu_utk_surrogat=substr($_,379,1);
		$alu_utk_remote=substr($_,384,1);
		$alu_utk_priv=substr($_,389,1);
		$alu_utk_secl=substr($_,394,8);
		$alu_utk_execnode=substr($_,403,8);
		$alu_utk_suser_id=substr($_,412,8);
		$alu_utk_snode=substr($_,421,8);
		$alu_utk_sgrp_id=substr($_,430,8);
		$alu_utk_spoe=substr($_,439,8);
		$alu_utk_spclass=substr($_,448,8);
		$alu_utk_user_id=substr($_,457,8);
		$alu_utk_grp_id=substr($_,466,8);
		$alu_utk_dft_grp=substr($_,475,1);
		$alu_utk_dft_secl=substr($_,480,1);
		$alu_appc_link=substr($_,485,16);
		$alu_noauth_clauth=substr($_,502,1);
		$alu_noauth_group=substr($_,507,1);
		$alu_noauth_prof=substr($_,512,1);
		$alu_user_id=substr($_,517,8);
		$alu_specified=substr($_,526,1024);
		$alu_failed=substr($_,1551,1024);
		$alu_ignored=substr($_,2576,1024);
		$alu_utk_netw=substr($_,3601,8);
		$alu_x500_subject=substr($_,3610,255);
		$alu_x500_issuer=substr($_,3866,255);
		$rv=$insert{altuser}->execute($alu_event_type,$alu_event_qual,$alu_time_written,$alu_date_written,$alu_system_smfid,$alu_violation,$alu_user_ndfnd,$alu_user_warning,$alu_evt_user_id,$alu_evt_grp_id,$alu_auth_normal,$alu_auth_special,$alu_auth_oper,$alu_auth_audit,$alu_auth_exit,$alu_auth_failsft,$alu_auth_bypass,$alu_auth_trusted,$alu_log_class,$alu_log_user,$alu_log_special,$alu_log_access,$alu_log_racinit,$alu_log_always,$alu_log_cmdviol,$alu_log_global,$alu_term_level,$alu_backout_fail,$alu_prof_same,$alu_term,$alu_job_name,$alu_read_time,$alu_read_date,$alu_smf_user_id,$alu_log_level,$alu_log_vmevent,$alu_log_logopt,$alu_log_secl,$alu_log_compatm,$alu_log_applaud,$alu_log_nonomvs,$alu_log_omvsnprv,$alu_auth_omvssu,$alu_auth_omvssys,$alu_usr_secl,$alu_racf_version,$alu_own_id,$alu_user_name,$alu_old_secl,$alu_utk_encr,$alu_utk_pre19,$alu_utk_verprof,$alu_utk_njeunusr,$alu_utk_logusr,$alu_utk_special,$alu_utk_default,$alu_utk_unknusr,$alu_utk_error,$alu_utk_trusted,$alu_utk_sesstype,$alu_utk_surrogat,$alu_utk_remote,$alu_utk_priv,$alu_utk_secl,$alu_utk_execnode,$alu_utk_suser_id,$alu_utk_snode,$alu_utk_sgrp_id,$alu_utk_spoe,$alu_utk_spclass,$alu_utk_user_id,$alu_utk_grp_id,$alu_utk_dft_grp,$alu_utk_dft_secl,$alu_appc_link,$alu_noauth_clauth,$alu_noauth_group,$alu_noauth_prof,$alu_user_id,$alu_specified,$alu_failed,$alu_ignored,$alu_utk_netw,$alu_x500_subject,$alu_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"altuser"}++;
		next;
	}

	if ($rectype eq 'APPCLU  ') {
		$appc_event_type=substr($_,0,8);
		$appc_event_qual=substr($_,9,8);
		$appc_time_written=substr($_,18,8);
		if ($appc_time_written  eq ' ' x length($appc_time_written )) {
			undef $appc_time_written ;
		}
		$appc_date_written=substr($_,27,10);
		if ($appc_date_written  eq ' ' x length($appc_date_written )) {
			undef $appc_date_written ;
		}
		$appc_system_smfid=substr($_,38,4);
		$appc_violation=substr($_,43,1);
		$appc_user_ndfnd=substr($_,48,1);
		$appc_user_warning=substr($_,53,1);
		$appc_evt_user_id=substr($_,58,8);
		$appc_evt_grp_id=substr($_,67,8);
		$appc_auth_normal=substr($_,76,1);
		$appc_auth_special=substr($_,81,1);
		$appc_auth_oper=substr($_,86,1);
		$appc_auth_audit=substr($_,91,1);
		$appc_auth_exit=substr($_,96,1);
		$appc_auth_failsft=substr($_,101,1);
		$appc_auth_bypass=substr($_,106,1);
		$appc_auth_trusted=substr($_,111,1);
		$appc_log_class=substr($_,116,1);
		$appc_log_user=substr($_,121,1);
		$appc_log_special=substr($_,126,1);
		$appc_log_access=substr($_,131,1);
		$appc_log_racinit=substr($_,136,1);
		$appc_log_always=substr($_,141,1);
		$appc_log_cmdviol=substr($_,146,1);
		$appc_log_global=substr($_,151,1);
		$appc_term_level=substr($_,156,3);
		if ($appc_term_level  eq ' ' x length($appc_term_level )) {
			undef $appc_term_level ;
		}
		$appc_backout_fail=substr($_,160,1);
		$appc_prof_same=substr($_,165,1);
		$appc_term=substr($_,170,8);
		$appc_job_name=substr($_,179,8);
		$appc_read_time=substr($_,188,8);
		if ($appc_read_time  eq ' ' x length($appc_read_time )) {
			undef $appc_read_time ;
		}
		$appc_read_date=substr($_,197,10);
		if ($appc_read_date  eq ' ' x length($appc_read_date )) {
			undef $appc_read_date ;
		}
		$appc_smf_user_id=substr($_,208,8);
		$appc_log_level=substr($_,217,1);
		$appc_log_vmevent=substr($_,222,1);
		$appc_log_logopt=substr($_,227,1);
		$appc_log_secl=substr($_,232,1);
		$appc_log_compatm=substr($_,237,1);
		$appc_log_applaud=substr($_,242,1);
		$appc_log_nonomvs=substr($_,247,1);
		$appc_log_omvsnprv=substr($_,252,1);
		$appc_auth_omvssu=substr($_,257,1);
		$appc_auth_omvssys=substr($_,262,1);
		$appc_usr_secl=substr($_,267,8);
		$appc_racf_version=substr($_,276,4);
		$appc_res_name=substr($_,281,255);
		$appc_class=substr($_,537,8);
		$appc_type=substr($_,546,8);
		$appc_name=substr($_,555,246);
		$appc_own_id=substr($_,802,8);
		$appc_user_name=substr($_,811,20);
		$appc_utk_encr=substr($_,832,1);
		$appc_utk_pre19=substr($_,837,1);
		$appc_utk_verprof=substr($_,842,1);
		$appc_utk_njeunusr=substr($_,847,1);
		$appc_utk_logusr=substr($_,852,1);
		$appc_utk_special=substr($_,857,1);
		$appc_utk_default=substr($_,862,1);
		$appc_utk_unknusr=substr($_,867,1);
		$appc_utk_error=substr($_,872,1);
		$appc_utk_trusted=substr($_,877,1);
		$appc_utk_sesstype=substr($_,882,8);
		$appc_utk_surrogat=substr($_,891,1);
		$appc_utk_remote=substr($_,896,1);
		$appc_utk_priv=substr($_,901,1);
		$appc_utk_secl=substr($_,906,8);
		$appc_utk_execnode=substr($_,915,8);
		$appc_utk_suser_id=substr($_,924,8);
		$appc_utk_snode=substr($_,933,8);
		$appc_utk_sgrp_id=substr($_,942,8);
		$appc_utk_spoe=substr($_,951,8);
		$appc_utk_spclass=substr($_,960,8);
		$appc_utk_user_id=substr($_,969,8);
		$appc_utk_grp_id=substr($_,978,8);
		$appc_utk_dft_grp=substr($_,987,1);
		$appc_utk_dft_secl=substr($_,992,1);
		$appc_appc_link=substr($_,997,16);
		$appc_utk_netw=substr($_,1014,8);
		$appc_x500_subject=substr($_,1023,255);
		$appc_x500_issuer=substr($_,1279,255);
		$rv=$insert{appclu}->execute($appc_event_type,$appc_event_qual,$appc_time_written,$appc_date_written,$appc_system_smfid,$appc_violation,$appc_user_ndfnd,$appc_user_warning,$appc_evt_user_id,$appc_evt_grp_id,$appc_auth_normal,$appc_auth_special,$appc_auth_oper,$appc_auth_audit,$appc_auth_exit,$appc_auth_failsft,$appc_auth_bypass,$appc_auth_trusted,$appc_log_class,$appc_log_user,$appc_log_special,$appc_log_access,$appc_log_racinit,$appc_log_always,$appc_log_cmdviol,$appc_log_global,$appc_term_level,$appc_backout_fail,$appc_prof_same,$appc_term,$appc_job_name,$appc_read_time,$appc_read_date,$appc_smf_user_id,$appc_log_level,$appc_log_vmevent,$appc_log_logopt,$appc_log_secl,$appc_log_compatm,$appc_log_applaud,$appc_log_nonomvs,$appc_log_omvsnprv,$appc_auth_omvssu,$appc_auth_omvssys,$appc_usr_secl,$appc_racf_version,$appc_res_name,$appc_class,$appc_type,$appc_name,$appc_own_id,$appc_user_name,$appc_utk_encr,$appc_utk_pre19,$appc_utk_verprof,$appc_utk_njeunusr,$appc_utk_logusr,$appc_utk_special,$appc_utk_default,$appc_utk_unknusr,$appc_utk_error,$appc_utk_trusted,$appc_utk_sesstype,$appc_utk_surrogat,$appc_utk_remote,$appc_utk_priv,$appc_utk_secl,$appc_utk_execnode,$appc_utk_suser_id,$appc_utk_snode,$appc_utk_sgrp_id,$appc_utk_spoe,$appc_utk_spclass,$appc_utk_user_id,$appc_utk_grp_id,$appc_utk_dft_grp,$appc_utk_dft_secl,$appc_appc_link,$appc_utk_netw,$appc_x500_subject,$appc_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"appclu"}++;
		next;
	}

	if ($rectype eq 'CHAUDIT ') {
		$caud_event_type=substr($_,0,8);
		$caud_event_qual=substr($_,9,8);
		$caud_time_written=substr($_,18,8);
		if ($caud_time_written  eq ' ' x length($caud_time_written )) {
			undef $caud_time_written ;
		}
		$caud_date_written=substr($_,27,10);
		if ($caud_date_written  eq ' ' x length($caud_date_written )) {
			undef $caud_date_written ;
		}
		$caud_system_smfid=substr($_,38,4);
		$caud_violation=substr($_,43,1);
		$caud_user_ndfnd=substr($_,48,1);
		$caud_user_warning=substr($_,53,1);
		$caud_evt_user_id=substr($_,58,8);
		$caud_evt_grp_id=substr($_,67,8);
		$caud_auth_normal=substr($_,76,1);
		$caud_auth_special=substr($_,81,1);
		$caud_auth_oper=substr($_,86,1);
		$caud_auth_audit=substr($_,91,1);
		$caud_auth_exit=substr($_,96,1);
		$caud_auth_failsft=substr($_,101,1);
		$caud_auth_bypass=substr($_,106,1);
		$caud_auth_trusted=substr($_,111,1);
		$caud_log_class=substr($_,116,1);
		$caud_log_user=substr($_,121,1);
		$caud_log_special=substr($_,126,1);
		$caud_log_access=substr($_,131,1);
		$caud_log_racinit=substr($_,136,1);
		$caud_log_always=substr($_,141,1);
		$caud_log_cmdviol=substr($_,146,1);
		$caud_log_global=substr($_,151,1);
		$caud_term_level=substr($_,156,3);
		if ($caud_term_level  eq ' ' x length($caud_term_level )) {
			undef $caud_term_level ;
		}
		$caud_backout_fail=substr($_,160,1);
		$caud_prof_same=substr($_,165,1);
		$caud_term=substr($_,170,8);
		$caud_job_name=substr($_,179,8);
		$caud_read_time=substr($_,188,8);
		if ($caud_read_time  eq ' ' x length($caud_read_time )) {
			undef $caud_read_time ;
		}
		$caud_read_date=substr($_,197,10);
		if ($caud_read_date  eq ' ' x length($caud_read_date )) {
			undef $caud_read_date ;
		}
		$caud_smf_user_id=substr($_,208,8);
		$caud_log_level=substr($_,217,1);
		$caud_log_vmevent=substr($_,222,1);
		$caud_log_logopt=substr($_,227,1);
		$caud_log_secl=substr($_,232,1);
		$caud_log_compatm=substr($_,237,1);
		$caud_log_applaud=substr($_,242,1);
		$caud_log_nonomvs=substr($_,247,1);
		$caud_log_omvsnprv=substr($_,252,1);
		$caud_auth_omvssu=substr($_,257,1);
		$caud_auth_omvssys=substr($_,262,1);
		$caud_usr_secl=substr($_,267,8);
		$caud_racf_version=substr($_,276,4);
		$caud_class=substr($_,281,8);
		$caud_user_name=substr($_,290,20);
		$caud_utk_encr=substr($_,311,1);
		$caud_utk_pre19=substr($_,316,1);
		$caud_utk_verprof=substr($_,321,1);
		$caud_utk_njeunusr=substr($_,326,1);
		$caud_utk_logusr=substr($_,331,1);
		$caud_utk_special=substr($_,336,1);
		$caud_utk_default=substr($_,341,1);
		$caud_utk_unknusr=substr($_,346,1);
		$caud_utk_error=substr($_,351,1);
		$caud_utk_trusted=substr($_,356,1);
		$caud_utk_sesstype=substr($_,361,8);
		$caud_utk_surrogat=substr($_,370,1);
		$caud_utk_remote=substr($_,375,1);
		$caud_utk_priv=substr($_,380,1);
		$caud_utk_secl=substr($_,385,8);
		$caud_utk_execnode=substr($_,394,8);
		$caud_utk_suser_id=substr($_,403,8);
		$caud_utk_snode=substr($_,412,8);
		$caud_utk_sgrp_id=substr($_,421,8);
		$caud_utk_spoe=substr($_,430,8);
		$caud_utk_spclass=substr($_,439,8);
		$caud_utk_user_id=substr($_,448,8);
		$caud_utk_grp_id=substr($_,457,8);
		$caud_utk_dft_grp=substr($_,466,1);
		$caud_utk_dft_secl=substr($_,471,1);
		$caud_appc_link=substr($_,476,16);
		$caud_audit_code=substr($_,493,11);
		$caud_old_real_uid=substr($_,505,10);
		if ($caud_old_real_uid  eq ' ' x length($caud_old_real_uid )) {
			undef $caud_old_real_uid ;
		}
		$caud_old_eff_uid=substr($_,516,10);
		if ($caud_old_eff_uid  eq ' ' x length($caud_old_eff_uid )) {
			undef $caud_old_eff_uid ;
		}
		$caud_old_saved_uid=substr($_,527,10);
		if ($caud_old_saved_uid eq ' ' x length($caud_old_saved_uid)) {
			undef $caud_old_saved_uid;
		}
		$caud_old_real_gid=substr($_,538,10);
		if ($caud_old_real_gid  eq ' ' x length($caud_old_real_gid )) {
			undef $caud_old_real_gid ;
		}
		$caud_old_eff_gid=substr($_,549,10);
		if ($caud_old_eff_gid  eq ' ' x length($caud_old_eff_gid )) {
			undef $caud_old_eff_gid ;
		}
		$caud_old_saved_gid=substr($_,560,10);
		if ($caud_old_saved_gid eq ' ' x length($caud_old_saved_gid)) {
			undef $caud_old_saved_gid;
		}
		$caud_path_name=substr($_,571,1023);
		$caud_file_id=substr($_,1595,32);
		$caud_file_own_uid=substr($_,1628,10);
		if ($caud_file_own_uid  eq ' ' x length($caud_file_own_uid )) {
			undef $caud_file_own_uid ;
		}
		$caud_file_own_gid=substr($_,1639,10);
		if ($caud_file_own_gid  eq ' ' x length($caud_file_own_gid )) {
			undef $caud_file_own_gid ;
		}
		$caud_request_read=substr($_,1650,8);
		$caud_request_write=substr($_,1659,8);
		$caud_request_exec=substr($_,1668,8);
		$caud_uold_read=substr($_,1677,8);
		$caud_uold_write=substr($_,1686,8);
		$caud_uold_exec=substr($_,1695,8);
		$caud_aold_read=substr($_,1704,8);
		$caud_aold_write=substr($_,1713,8);
		$caud_aold_exec=substr($_,1722,8);
		$caud_unew_read=substr($_,1731,8);
		$caud_unew_write=substr($_,1740,8);
		$caud_unew_exec=substr($_,1749,8);
		$caud_anew_read=substr($_,1758,8);
		$caud_anew_write=substr($_,1767,8);
		$caud_anew_exec=substr($_,1776,8);
		$caud_filepool=substr($_,1785,8);
		$caud_filespace=substr($_,1794,8);
		$caud_inode=substr($_,1803,10);
		if ($caud_inode  eq ' ' x length($caud_inode )) {
			undef $caud_inode ;
		}
		$caud_scid=substr($_,1814,10);
		if ($caud_scid  eq ' ' x length($caud_scid )) {
			undef $caud_scid ;
		}
		$caud_dce_link=substr($_,1825,16);
		$caud_auth_type=substr($_,1842,13);
		$caud_dflt_process=substr($_,1856,1);
		$caud_utk_netw=substr($_,1861,8);
		$caud_x500_subject=substr($_,1870,255);
		$caud_x500_issuer=substr($_,2126,255);
		$rv=$insert{chaudit}->execute($caud_event_type,$caud_event_qual,$caud_time_written,$caud_date_written,$caud_system_smfid,$caud_violation,$caud_user_ndfnd,$caud_user_warning,$caud_evt_user_id,$caud_evt_grp_id,$caud_auth_normal,$caud_auth_special,$caud_auth_oper,$caud_auth_audit,$caud_auth_exit,$caud_auth_failsft,$caud_auth_bypass,$caud_auth_trusted,$caud_log_class,$caud_log_user,$caud_log_special,$caud_log_access,$caud_log_racinit,$caud_log_always,$caud_log_cmdviol,$caud_log_global,$caud_term_level,$caud_backout_fail,$caud_prof_same,$caud_term,$caud_job_name,$caud_read_time,$caud_read_date,$caud_smf_user_id,$caud_log_level,$caud_log_vmevent,$caud_log_logopt,$caud_log_secl,$caud_log_compatm,$caud_log_applaud,$caud_log_nonomvs,$caud_log_omvsnprv,$caud_auth_omvssu,$caud_auth_omvssys,$caud_usr_secl,$caud_racf_version,$caud_class,$caud_user_name,$caud_utk_encr,$caud_utk_pre19,$caud_utk_verprof,$caud_utk_njeunusr,$caud_utk_logusr,$caud_utk_special,$caud_utk_default,$caud_utk_unknusr,$caud_utk_error,$caud_utk_trusted,$caud_utk_sesstype,$caud_utk_surrogat,$caud_utk_remote,$caud_utk_priv,$caud_utk_secl,$caud_utk_execnode,$caud_utk_suser_id,$caud_utk_snode,$caud_utk_sgrp_id,$caud_utk_spoe,$caud_utk_spclass,$caud_utk_user_id,$caud_utk_grp_id,$caud_utk_dft_grp,$caud_utk_dft_secl,$caud_appc_link,$caud_audit_code,$caud_old_real_uid,$caud_old_eff_uid,$caud_old_saved_uid,$caud_old_real_gid,$caud_old_eff_gid,$caud_old_saved_gid,$caud_path_name,$caud_file_id,$caud_file_own_uid,$caud_file_own_gid,$caud_request_read,$caud_request_write,$caud_request_exec,$caud_uold_read,$caud_uold_write,$caud_uold_exec,$caud_aold_read,$caud_aold_write,$caud_aold_exec,$caud_unew_read,$caud_unew_write,$caud_unew_exec,$caud_anew_read,$caud_anew_write,$caud_anew_exec,$caud_filepool,$caud_filespace,$caud_inode,$caud_scid,$caud_dce_link,$caud_auth_type,$caud_dflt_process,$caud_utk_netw,$caud_x500_subject,$caud_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chaudit"}++;
		next;
	}

	if ($rectype eq 'CHDIR   ') {
		$cdir_event_type=substr($_,0,8);
		$cdir_event_qual=substr($_,9,8);
		$cdir_time_written=substr($_,18,8);
		if ($cdir_time_written  eq ' ' x length($cdir_time_written )) {
			undef $cdir_time_written ;
		}
		$cdir_date_written=substr($_,27,10);
		if ($cdir_date_written  eq ' ' x length($cdir_date_written )) {
			undef $cdir_date_written ;
		}
		$cdir_system_smfid=substr($_,38,4);
		$cdir_violation=substr($_,43,1);
		$cdir_user_ndfnd=substr($_,48,1);
		$cdir_user_warning=substr($_,53,1);
		$cdir_evt_user_id=substr($_,58,8);
		$cdir_evt_grp_id=substr($_,67,8);
		$cdir_auth_normal=substr($_,76,1);
		$cdir_auth_special=substr($_,81,1);
		$cdir_auth_oper=substr($_,86,1);
		$cdir_auth_audit=substr($_,91,1);
		$cdir_auth_exit=substr($_,96,1);
		$cdir_auth_failsft=substr($_,101,1);
		$cdir_auth_bypass=substr($_,106,1);
		$cdir_auth_trusted=substr($_,111,1);
		$cdir_log_class=substr($_,116,1);
		$cdir_log_user=substr($_,121,1);
		$cdir_log_special=substr($_,126,1);
		$cdir_log_access=substr($_,131,1);
		$cdir_log_racinit=substr($_,136,1);
		$cdir_log_always=substr($_,141,1);
		$cdir_log_cmdviol=substr($_,146,1);
		$cdir_log_global=substr($_,151,1);
		$cdir_term_level=substr($_,156,3);
		if ($cdir_term_level  eq ' ' x length($cdir_term_level )) {
			undef $cdir_term_level ;
		}
		$cdir_backout_fail=substr($_,160,1);
		$cdir_prof_same=substr($_,165,1);
		$cdir_term=substr($_,170,8);
		$cdir_job_name=substr($_,179,8);
		$cdir_read_time=substr($_,188,8);
		if ($cdir_read_time  eq ' ' x length($cdir_read_time )) {
			undef $cdir_read_time ;
		}
		$cdir_read_date=substr($_,197,10);
		if ($cdir_read_date  eq ' ' x length($cdir_read_date )) {
			undef $cdir_read_date ;
		}
		$cdir_smf_user_id=substr($_,208,8);
		$cdir_log_level=substr($_,217,1);
		$cdir_log_vmevent=substr($_,222,1);
		$cdir_log_logopt=substr($_,227,1);
		$cdir_log_secl=substr($_,232,1);
		$cdir_log_compatm=substr($_,237,1);
		$cdir_log_applaud=substr($_,242,1);
		$cdir_log_nonomvs=substr($_,247,1);
		$cdir_log_omvsnprv=substr($_,252,1);
		$cdir_auth_omvssu=substr($_,257,1);
		$cdir_auth_omvssys=substr($_,262,1);
		$cdir_usr_secl=substr($_,267,8);
		$cdir_racf_version=substr($_,276,4);
		$cdir_class=substr($_,281,8);
		$cdir_user_name=substr($_,290,20);
		$cdir_utk_encr=substr($_,311,1);
		$cdir_utk_pre19=substr($_,316,1);
		$cdir_utk_verprof=substr($_,321,1);
		$cdir_utk_njeunusr=substr($_,326,1);
		$cdir_utk_logusr=substr($_,331,1);
		$cdir_utk_special=substr($_,336,1);
		$cdir_utk_default=substr($_,341,1);
		$cdir_utk_unknusr=substr($_,346,1);
		$cdir_utk_error=substr($_,351,1);
		$cdir_utk_trusted=substr($_,356,1);
		$cdir_utk_sesstype=substr($_,361,8);
		$cdir_utk_surrogat=substr($_,370,1);
		$cdir_utk_remote=substr($_,375,1);
		$cdir_utk_priv=substr($_,380,1);
		$cdir_utk_secl=substr($_,385,8);
		$cdir_utk_execnode=substr($_,394,8);
		$cdir_utk_suser_id=substr($_,403,8);
		$cdir_utk_snode=substr($_,412,8);
		$cdir_utk_sgrp_id=substr($_,421,8);
		$cdir_utk_spoe=substr($_,430,8);
		$cdir_utk_spclass=substr($_,439,8);
		$cdir_utk_user_id=substr($_,448,8);
		$cdir_utk_grp_id=substr($_,457,8);
		$cdir_utk_dft_grp=substr($_,466,1);
		$cdir_utk_dft_secl=substr($_,471,1);
		$cdir_appc_link=substr($_,476,16);
		$cdir_audit_code=substr($_,493,11);
		$cdir_old_real_uid=substr($_,505,10);
		if ($cdir_old_real_uid  eq ' ' x length($cdir_old_real_uid )) {
			undef $cdir_old_real_uid ;
		}
		$cdir_old_eff_uid=substr($_,516,10);
		if ($cdir_old_eff_uid  eq ' ' x length($cdir_old_eff_uid )) {
			undef $cdir_old_eff_uid ;
		}
		$cdir_old_saved_uid=substr($_,527,10);
		if ($cdir_old_saved_uid eq ' ' x length($cdir_old_saved_uid)) {
			undef $cdir_old_saved_uid;
		}
		$cdir_old_real_gid=substr($_,538,10);
		if ($cdir_old_real_gid  eq ' ' x length($cdir_old_real_gid )) {
			undef $cdir_old_real_gid ;
		}
		$cdir_old_eff_gid=substr($_,549,10);
		if ($cdir_old_eff_gid  eq ' ' x length($cdir_old_eff_gid )) {
			undef $cdir_old_eff_gid ;
		}
		$cdir_old_saved_gid=substr($_,560,10);
		if ($cdir_old_saved_gid eq ' ' x length($cdir_old_saved_gid)) {
			undef $cdir_old_saved_gid;
		}
		$cdir_path_name=substr($_,571,1023);
		$cdir_file_id=substr($_,1595,32);
		$cdir_file_own_uid=substr($_,1628,10);
		if ($cdir_file_own_uid  eq ' ' x length($cdir_file_own_uid )) {
			undef $cdir_file_own_uid ;
		}
		$cdir_file_own_gid=substr($_,1639,10);
		if ($cdir_file_own_gid  eq ' ' x length($cdir_file_own_gid )) {
			undef $cdir_file_own_gid ;
		}
		$cdir_dce_link=substr($_,1650,16);
		$cdir_auth_type=substr($_,1667,13);
		$cdir_dflt_process=substr($_,1681,1);
		$cdir_utk_netw=substr($_,1686,8);
		$cdir_x500_subject=substr($_,1695,255);
		$cdir_x500_issuer=substr($_,1951,255);
		$rv=$insert{chdir}->execute($cdir_event_type,$cdir_event_qual,$cdir_time_written,$cdir_date_written,$cdir_system_smfid,$cdir_violation,$cdir_user_ndfnd,$cdir_user_warning,$cdir_evt_user_id,$cdir_evt_grp_id,$cdir_auth_normal,$cdir_auth_special,$cdir_auth_oper,$cdir_auth_audit,$cdir_auth_exit,$cdir_auth_failsft,$cdir_auth_bypass,$cdir_auth_trusted,$cdir_log_class,$cdir_log_user,$cdir_log_special,$cdir_log_access,$cdir_log_racinit,$cdir_log_always,$cdir_log_cmdviol,$cdir_log_global,$cdir_term_level,$cdir_backout_fail,$cdir_prof_same,$cdir_term,$cdir_job_name,$cdir_read_time,$cdir_read_date,$cdir_smf_user_id,$cdir_log_level,$cdir_log_vmevent,$cdir_log_logopt,$cdir_log_secl,$cdir_log_compatm,$cdir_log_applaud,$cdir_log_nonomvs,$cdir_log_omvsnprv,$cdir_auth_omvssu,$cdir_auth_omvssys,$cdir_usr_secl,$cdir_racf_version,$cdir_class,$cdir_user_name,$cdir_utk_encr,$cdir_utk_pre19,$cdir_utk_verprof,$cdir_utk_njeunusr,$cdir_utk_logusr,$cdir_utk_special,$cdir_utk_default,$cdir_utk_unknusr,$cdir_utk_error,$cdir_utk_trusted,$cdir_utk_sesstype,$cdir_utk_surrogat,$cdir_utk_remote,$cdir_utk_priv,$cdir_utk_secl,$cdir_utk_execnode,$cdir_utk_suser_id,$cdir_utk_snode,$cdir_utk_sgrp_id,$cdir_utk_spoe,$cdir_utk_spclass,$cdir_utk_user_id,$cdir_utk_grp_id,$cdir_utk_dft_grp,$cdir_utk_dft_secl,$cdir_appc_link,$cdir_audit_code,$cdir_old_real_uid,$cdir_old_eff_uid,$cdir_old_saved_uid,$cdir_old_real_gid,$cdir_old_eff_gid,$cdir_old_saved_gid,$cdir_path_name,$cdir_file_id,$cdir_file_own_uid,$cdir_file_own_gid,$cdir_dce_link,$cdir_auth_type,$cdir_dflt_process,$cdir_utk_netw,$cdir_x500_subject,$cdir_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chdir"}++;
		next;
	}

	if ($rectype eq 'CHKFOWN ') {
		$cfow_event_type=substr($_,0,8);
		$cfow_event_qual=substr($_,9,8);
		$cfow_time_written=substr($_,18,8);
		if ($cfow_time_written  eq ' ' x length($cfow_time_written )) {
			undef $cfow_time_written ;
		}
		$cfow_date_written=substr($_,27,10);
		if ($cfow_date_written  eq ' ' x length($cfow_date_written )) {
			undef $cfow_date_written ;
		}
		$cfow_system_smfid=substr($_,38,4);
		$cfow_violation=substr($_,43,1);
		$cfow_user_ndfnd=substr($_,48,1);
		$cfow_user_warning=substr($_,53,1);
		$cfow_evt_user_id=substr($_,58,8);
		$cfow_evt_grp_id=substr($_,67,8);
		$cfow_auth_normal=substr($_,76,1);
		$cfow_auth_special=substr($_,81,1);
		$cfow_auth_oper=substr($_,86,1);
		$cfow_auth_audit=substr($_,91,1);
		$cfow_auth_exit=substr($_,96,1);
		$cfow_auth_failsft=substr($_,101,1);
		$cfow_auth_bypass=substr($_,106,1);
		$cfow_auth_trusted=substr($_,111,1);
		$cfow_log_class=substr($_,116,1);
		$cfow_log_user=substr($_,121,1);
		$cfow_log_special=substr($_,126,1);
		$cfow_log_access=substr($_,131,1);
		$cfow_log_racinit=substr($_,136,1);
		$cfow_log_always=substr($_,141,1);
		$cfow_log_cmdviol=substr($_,146,1);
		$cfow_log_global=substr($_,151,1);
		$cfow_term_level=substr($_,156,3);
		if ($cfow_term_level  eq ' ' x length($cfow_term_level )) {
			undef $cfow_term_level ;
		}
		$cfow_backout_fail=substr($_,160,1);
		$cfow_prof_same=substr($_,165,1);
		$cfow_term=substr($_,170,8);
		$cfow_job_name=substr($_,179,8);
		$cfow_read_time=substr($_,188,8);
		if ($cfow_read_time  eq ' ' x length($cfow_read_time )) {
			undef $cfow_read_time ;
		}
		$cfow_read_date=substr($_,197,10);
		if ($cfow_read_date  eq ' ' x length($cfow_read_date )) {
			undef $cfow_read_date ;
		}
		$cfow_smf_user_id=substr($_,208,8);
		$cfow_log_level=substr($_,217,1);
		$cfow_log_vmevent=substr($_,222,1);
		$cfow_log_logopt=substr($_,227,1);
		$cfow_log_secl=substr($_,232,1);
		$cfow_log_compatm=substr($_,237,1);
		$cfow_log_applaud=substr($_,242,1);
		$cfow_log_nonomvs=substr($_,247,1);
		$cfow_log_omvsnprv=substr($_,252,1);
		$cfow_auth_omvssu=substr($_,257,1);
		$cfow_auth_omvssys=substr($_,262,1);
		$cfow_usr_secl=substr($_,267,8);
		$cfow_racf_version=substr($_,276,4);
		$cfow_class=substr($_,281,8);
		$cfow_user_name=substr($_,290,20);
		$cfow_utk_encr=substr($_,311,1);
		$cfow_utk_pre19=substr($_,316,1);
		$cfow_utk_verprof=substr($_,321,1);
		$cfow_utk_njeunusr=substr($_,326,1);
		$cfow_utk_logusr=substr($_,331,1);
		$cfow_utk_special=substr($_,336,1);
		$cfow_utk_default=substr($_,341,1);
		$cfow_utk_unknusr=substr($_,346,1);
		$cfow_utk_error=substr($_,351,1);
		$cfow_utk_trusted=substr($_,356,1);
		$cfow_utk_sesstype=substr($_,361,8);
		$cfow_utk_surrogat=substr($_,370,1);
		$cfow_utk_remote=substr($_,375,1);
		$cfow_utk_priv=substr($_,380,1);
		$cfow_utk_secl=substr($_,385,8);
		$cfow_utk_execnode=substr($_,394,8);
		$cfow_utk_suser_id=substr($_,403,8);
		$cfow_utk_snode=substr($_,412,8);
		$cfow_utk_sgrp_id=substr($_,421,8);
		$cfow_utk_spoe=substr($_,430,8);
		$cfow_utk_spclass=substr($_,439,8);
		$cfow_utk_user_id=substr($_,448,8);
		$cfow_utk_grp_id=substr($_,457,8);
		$cfow_utk_dft_grp=substr($_,466,1);
		$cfow_utk_dft_secl=substr($_,471,1);
		$cfow_appc_link=substr($_,476,16);
		$cfow_audit_code=substr($_,493,11);
		$cfow_old_real_uid=substr($_,505,10);
		if ($cfow_old_real_uid  eq ' ' x length($cfow_old_real_uid )) {
			undef $cfow_old_real_uid ;
		}
		$cfow_old_eff_uid=substr($_,516,10);
		if ($cfow_old_eff_uid  eq ' ' x length($cfow_old_eff_uid )) {
			undef $cfow_old_eff_uid ;
		}
		$cfow_old_saved_uid=substr($_,527,10);
		if ($cfow_old_saved_uid eq ' ' x length($cfow_old_saved_uid)) {
			undef $cfow_old_saved_uid;
		}
		$cfow_old_real_gid=substr($_,538,10);
		if ($cfow_old_real_gid  eq ' ' x length($cfow_old_real_gid )) {
			undef $cfow_old_real_gid ;
		}
		$cfow_old_eff_gid=substr($_,549,10);
		if ($cfow_old_eff_gid  eq ' ' x length($cfow_old_eff_gid )) {
			undef $cfow_old_eff_gid ;
		}
		$cfow_old_saved_gid=substr($_,560,10);
		if ($cfow_old_saved_gid eq ' ' x length($cfow_old_saved_gid)) {
			undef $cfow_old_saved_gid;
		}
		$cfow_path_name=substr($_,571,1023);
		$cfow_file_id=substr($_,1595,32);
		$cfow_file_own_uid=substr($_,1628,10);
		if ($cfow_file_own_uid  eq ' ' x length($cfow_file_own_uid )) {
			undef $cfow_file_own_uid ;
		}
		$cfow_file_own_gid=substr($_,1639,10);
		if ($cfow_file_own_gid  eq ' ' x length($cfow_file_own_gid )) {
			undef $cfow_file_own_gid ;
		}
		$cfow_filepool=substr($_,1650,8);
		$cfow_filespace=substr($_,1659,8);
		$cfow_inode=substr($_,1668,10);
		if ($cfow_inode  eq ' ' x length($cfow_inode )) {
			undef $cfow_inode ;
		}
		$cfow_scid=substr($_,1679,10);
		if ($cfow_scid  eq ' ' x length($cfow_scid )) {
			undef $cfow_scid ;
		}
		$cfow_dce_link=substr($_,1690,16);
		$cfow_auth_type=substr($_,1707,13);
		$cfow_dflt_process=substr($_,1721,1);
		$cfow_utk_netw=substr($_,1726,8);
		$cfow_x500_subject=substr($_,1735,255);
		$cfow_x500_issuer=substr($_,1991,255);
		$rv=$insert{chkfown}->execute($cfow_event_type,$cfow_event_qual,$cfow_time_written,$cfow_date_written,$cfow_system_smfid,$cfow_violation,$cfow_user_ndfnd,$cfow_user_warning,$cfow_evt_user_id,$cfow_evt_grp_id,$cfow_auth_normal,$cfow_auth_special,$cfow_auth_oper,$cfow_auth_audit,$cfow_auth_exit,$cfow_auth_failsft,$cfow_auth_bypass,$cfow_auth_trusted,$cfow_log_class,$cfow_log_user,$cfow_log_special,$cfow_log_access,$cfow_log_racinit,$cfow_log_always,$cfow_log_cmdviol,$cfow_log_global,$cfow_term_level,$cfow_backout_fail,$cfow_prof_same,$cfow_term,$cfow_job_name,$cfow_read_time,$cfow_read_date,$cfow_smf_user_id,$cfow_log_level,$cfow_log_vmevent,$cfow_log_logopt,$cfow_log_secl,$cfow_log_compatm,$cfow_log_applaud,$cfow_log_nonomvs,$cfow_log_omvsnprv,$cfow_auth_omvssu,$cfow_auth_omvssys,$cfow_usr_secl,$cfow_racf_version,$cfow_class,$cfow_user_name,$cfow_utk_encr,$cfow_utk_pre19,$cfow_utk_verprof,$cfow_utk_njeunusr,$cfow_utk_logusr,$cfow_utk_special,$cfow_utk_default,$cfow_utk_unknusr,$cfow_utk_error,$cfow_utk_trusted,$cfow_utk_sesstype,$cfow_utk_surrogat,$cfow_utk_remote,$cfow_utk_priv,$cfow_utk_secl,$cfow_utk_execnode,$cfow_utk_suser_id,$cfow_utk_snode,$cfow_utk_sgrp_id,$cfow_utk_spoe,$cfow_utk_spclass,$cfow_utk_user_id,$cfow_utk_grp_id,$cfow_utk_dft_grp,$cfow_utk_dft_secl,$cfow_appc_link,$cfow_audit_code,$cfow_old_real_uid,$cfow_old_eff_uid,$cfow_old_saved_uid,$cfow_old_real_gid,$cfow_old_eff_gid,$cfow_old_saved_gid,$cfow_path_name,$cfow_file_id,$cfow_file_own_uid,$cfow_file_own_gid,$cfow_filepool,$cfow_filespace,$cfow_inode,$cfow_scid,$cfow_dce_link,$cfow_auth_type,$cfow_dflt_process,$cfow_utk_netw,$cfow_x500_subject,$cfow_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chkfown"}++;
		next;
	}

	if ($rectype eq 'CHKPRIV ') {
		$cprv_event_type=substr($_,0,8);
		$cprv_event_qual=substr($_,9,8);
		$cprv_time_written=substr($_,18,8);
		if ($cprv_time_written  eq ' ' x length($cprv_time_written )) {
			undef $cprv_time_written ;
		}
		$cprv_date_written=substr($_,27,10);
		if ($cprv_date_written  eq ' ' x length($cprv_date_written )) {
			undef $cprv_date_written ;
		}
		$cprv_system_smfid=substr($_,38,4);
		$cprv_violation=substr($_,43,1);
		$cprv_user_ndfnd=substr($_,48,1);
		$cprv_user_warning=substr($_,53,1);
		$cprv_evt_user_id=substr($_,58,8);
		$cprv_evt_grp_id=substr($_,67,8);
		$cprv_auth_normal=substr($_,76,1);
		$cprv_auth_special=substr($_,81,1);
		$cprv_auth_oper=substr($_,86,1);
		$cprv_auth_audit=substr($_,91,1);
		$cprv_auth_exit=substr($_,96,1);
		$cprv_auth_failsft=substr($_,101,1);
		$cprv_auth_bypass=substr($_,106,1);
		$cprv_auth_trusted=substr($_,111,1);
		$cprv_log_class=substr($_,116,1);
		$cprv_log_user=substr($_,121,1);
		$cprv_log_special=substr($_,126,1);
		$cprv_log_access=substr($_,131,1);
		$cprv_log_racinit=substr($_,136,1);
		$cprv_log_always=substr($_,141,1);
		$cprv_log_cmdviol=substr($_,146,1);
		$cprv_log_global=substr($_,151,1);
		$cprv_term_level=substr($_,156,3);
		if ($cprv_term_level  eq ' ' x length($cprv_term_level )) {
			undef $cprv_term_level ;
		}
		$cprv_backout_fail=substr($_,160,1);
		$cprv_prof_same=substr($_,165,1);
		$cprv_term=substr($_,170,8);
		$cprv_job_name=substr($_,179,8);
		$cprv_read_time=substr($_,188,8);
		if ($cprv_read_time  eq ' ' x length($cprv_read_time )) {
			undef $cprv_read_time ;
		}
		$cprv_read_date=substr($_,197,10);
		if ($cprv_read_date  eq ' ' x length($cprv_read_date )) {
			undef $cprv_read_date ;
		}
		$cprv_smf_user_id=substr($_,208,8);
		$cprv_log_level=substr($_,217,1);
		$cprv_log_vmevent=substr($_,222,1);
		$cprv_log_logopt=substr($_,227,1);
		$cprv_log_secl=substr($_,232,1);
		$cprv_log_compatm=substr($_,237,1);
		$cprv_log_applaud=substr($_,242,1);
		$cprv_log_nonomvs=substr($_,247,1);
		$cprv_log_omvsnprv=substr($_,252,1);
		$cprv_auth_omvssu=substr($_,257,1);
		$cprv_auth_omvssys=substr($_,262,1);
		$cprv_usr_secl=substr($_,267,8);
		$cprv_racf_version=substr($_,276,4);
		$cprv_class=substr($_,281,8);
		$cprv_user_name=substr($_,290,20);
		$cprv_utk_encr=substr($_,311,1);
		$cprv_utk_pre19=substr($_,316,1);
		$cprv_utk_verprof=substr($_,321,1);
		$cprv_utk_njeunusr=substr($_,326,1);
		$cprv_utk_logusr=substr($_,331,1);
		$cprv_utk_special=substr($_,336,1);
		$cprv_utk_default=substr($_,341,1);
		$cprv_utk_unknusr=substr($_,346,1);
		$cprv_utk_error=substr($_,351,1);
		$cprv_utk_trusted=substr($_,356,1);
		$cprv_utk_sesstype=substr($_,361,8);
		$cprv_utk_surrogat=substr($_,370,1);
		$cprv_utk_remote=substr($_,375,1);
		$cprv_utk_priv=substr($_,380,1);
		$cprv_utk_secl=substr($_,385,8);
		$cprv_utk_execnode=substr($_,394,8);
		$cprv_utk_suser_id=substr($_,403,8);
		$cprv_utk_snode=substr($_,412,8);
		$cprv_utk_sgrp_id=substr($_,421,8);
		$cprv_utk_spoe=substr($_,430,8);
		$cprv_utk_spclass=substr($_,439,8);
		$cprv_utk_user_id=substr($_,448,8);
		$cprv_utk_grp_id=substr($_,457,8);
		$cprv_utk_dft_grp=substr($_,466,1);
		$cprv_utk_dft_secl=substr($_,471,1);
		$cprv_appc_link=substr($_,476,16);
		$cprv_audit_code=substr($_,493,11);
		$cprv_old_real_uid=substr($_,505,10);
		if ($cprv_old_real_uid  eq ' ' x length($cprv_old_real_uid )) {
			undef $cprv_old_real_uid ;
		}
		$cprv_old_eff_uid=substr($_,516,10);
		if ($cprv_old_eff_uid  eq ' ' x length($cprv_old_eff_uid )) {
			undef $cprv_old_eff_uid ;
		}
		$cprv_old_saved_uid=substr($_,527,10);
		if ($cprv_old_saved_uid eq ' ' x length($cprv_old_saved_uid)) {
			undef $cprv_old_saved_uid;
		}
		$cprv_old_real_gid=substr($_,538,10);
		if ($cprv_old_real_gid  eq ' ' x length($cprv_old_real_gid )) {
			undef $cprv_old_real_gid ;
		}
		$cprv_old_eff_gid=substr($_,549,10);
		if ($cprv_old_eff_gid  eq ' ' x length($cprv_old_eff_gid )) {
			undef $cprv_old_eff_gid ;
		}
		$cprv_old_saved_gid=substr($_,560,10);
		if ($cprv_old_saved_gid eq ' ' x length($cprv_old_saved_gid)) {
			undef $cprv_old_saved_gid;
		}
		$cprv_dce_link=substr($_,571,16);
		$cprv_auth_type=substr($_,588,13);
		$cprv_dflt_process=substr($_,602,1);
		$cprv_utk_netw=substr($_,607,8);
		$cprv_x500_subject=substr($_,616,255);
		$cprv_x500_issuer=substr($_,872,255);
		$rv=$insert{chkpriv}->execute($cprv_event_type,$cprv_event_qual,$cprv_time_written,$cprv_date_written,$cprv_system_smfid,$cprv_violation,$cprv_user_ndfnd,$cprv_user_warning,$cprv_evt_user_id,$cprv_evt_grp_id,$cprv_auth_normal,$cprv_auth_special,$cprv_auth_oper,$cprv_auth_audit,$cprv_auth_exit,$cprv_auth_failsft,$cprv_auth_bypass,$cprv_auth_trusted,$cprv_log_class,$cprv_log_user,$cprv_log_special,$cprv_log_access,$cprv_log_racinit,$cprv_log_always,$cprv_log_cmdviol,$cprv_log_global,$cprv_term_level,$cprv_backout_fail,$cprv_prof_same,$cprv_term,$cprv_job_name,$cprv_read_time,$cprv_read_date,$cprv_smf_user_id,$cprv_log_level,$cprv_log_vmevent,$cprv_log_logopt,$cprv_log_secl,$cprv_log_compatm,$cprv_log_applaud,$cprv_log_nonomvs,$cprv_log_omvsnprv,$cprv_auth_omvssu,$cprv_auth_omvssys,$cprv_usr_secl,$cprv_racf_version,$cprv_class,$cprv_user_name,$cprv_utk_encr,$cprv_utk_pre19,$cprv_utk_verprof,$cprv_utk_njeunusr,$cprv_utk_logusr,$cprv_utk_special,$cprv_utk_default,$cprv_utk_unknusr,$cprv_utk_error,$cprv_utk_trusted,$cprv_utk_sesstype,$cprv_utk_surrogat,$cprv_utk_remote,$cprv_utk_priv,$cprv_utk_secl,$cprv_utk_execnode,$cprv_utk_suser_id,$cprv_utk_snode,$cprv_utk_sgrp_id,$cprv_utk_spoe,$cprv_utk_spclass,$cprv_utk_user_id,$cprv_utk_grp_id,$cprv_utk_dft_grp,$cprv_utk_dft_secl,$cprv_appc_link,$cprv_audit_code,$cprv_old_real_uid,$cprv_old_eff_uid,$cprv_old_saved_uid,$cprv_old_real_gid,$cprv_old_eff_gid,$cprv_old_saved_gid,$cprv_dce_link,$cprv_auth_type,$cprv_dflt_process,$cprv_utk_netw,$cprv_x500_subject,$cprv_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chkpriv"}++;
		next;
	}

	if ($rectype eq 'CHMOD   ') {
		$cmod_event_type=substr($_,0,8);
		$cmod_event_qual=substr($_,9,8);
		$cmod_time_written=substr($_,18,8);
		if ($cmod_time_written  eq ' ' x length($cmod_time_written )) {
			undef $cmod_time_written ;
		}
		$cmod_date_written=substr($_,27,10);
		if ($cmod_date_written  eq ' ' x length($cmod_date_written )) {
			undef $cmod_date_written ;
		}
		$cmod_system_smfid=substr($_,38,4);
		$cmod_violation=substr($_,43,1);
		$cmod_user_ndfnd=substr($_,48,1);
		$cmod_user_warning=substr($_,53,1);
		$cmod_evt_user_id=substr($_,58,8);
		$cmod_evt_grp_id=substr($_,67,8);
		$cmod_auth_normal=substr($_,76,1);
		$cmod_auth_special=substr($_,81,1);
		$cmod_auth_oper=substr($_,86,1);
		$cmod_auth_audit=substr($_,91,1);
		$cmod_auth_exit=substr($_,96,1);
		$cmod_auth_failsft=substr($_,101,1);
		$cmod_auth_bypass=substr($_,106,1);
		$cmod_auth_trusted=substr($_,111,1);
		$cmod_log_class=substr($_,116,1);
		$cmod_log_user=substr($_,121,1);
		$cmod_log_special=substr($_,126,1);
		$cmod_log_access=substr($_,131,1);
		$cmod_log_racinit=substr($_,136,1);
		$cmod_log_always=substr($_,141,1);
		$cmod_log_cmdviol=substr($_,146,1);
		$cmod_log_global=substr($_,151,1);
		$cmod_term_level=substr($_,156,3);
		if ($cmod_term_level  eq ' ' x length($cmod_term_level )) {
			undef $cmod_term_level ;
		}
		$cmod_backout_fail=substr($_,160,1);
		$cmod_prof_same=substr($_,165,1);
		$cmod_term=substr($_,170,8);
		$cmod_job_name=substr($_,179,8);
		$cmod_read_time=substr($_,188,8);
		if ($cmod_read_time  eq ' ' x length($cmod_read_time )) {
			undef $cmod_read_time ;
		}
		$cmod_read_date=substr($_,197,10);
		if ($cmod_read_date  eq ' ' x length($cmod_read_date )) {
			undef $cmod_read_date ;
		}
		$cmod_smf_user_id=substr($_,208,8);
		$cmod_log_level=substr($_,217,1);
		$cmod_log_vmevent=substr($_,222,1);
		$cmod_log_logopt=substr($_,227,1);
		$cmod_log_secl=substr($_,232,1);
		$cmod_log_compatm=substr($_,237,1);
		$cmod_log_applaud=substr($_,242,1);
		$cmod_log_nonomvs=substr($_,247,1);
		$cmod_log_omvsnprv=substr($_,252,1);
		$cmod_auth_omvssu=substr($_,257,1);
		$cmod_auth_omvssys=substr($_,262,1);
		$cmod_usr_secl=substr($_,267,8);
		$cmod_racf_version=substr($_,276,4);
		$cmod_class=substr($_,281,8);
		$cmod_user_name=substr($_,290,20);
		$cmod_utk_encr=substr($_,311,1);
		$cmod_utk_pre19=substr($_,316,1);
		$cmod_utk_verprof=substr($_,321,1);
		$cmod_utk_njeunusr=substr($_,326,1);
		$cmod_utk_logusr=substr($_,331,1);
		$cmod_utk_special=substr($_,336,1);
		$cmod_utk_default=substr($_,341,1);
		$cmod_utk_unknusr=substr($_,346,1);
		$cmod_utk_error=substr($_,351,1);
		$cmod_utk_trusted=substr($_,356,1);
		$cmod_utk_sesstype=substr($_,361,8);
		$cmod_utk_surrogat=substr($_,370,1);
		$cmod_utk_remote=substr($_,375,1);
		$cmod_utk_priv=substr($_,380,1);
		$cmod_utk_secl=substr($_,385,8);
		$cmod_utk_execnode=substr($_,394,8);
		$cmod_utk_suser_id=substr($_,403,8);
		$cmod_utk_snode=substr($_,412,8);
		$cmod_utk_sgrp_id=substr($_,421,8);
		$cmod_utk_spoe=substr($_,430,8);
		$cmod_utk_spclass=substr($_,439,8);
		$cmod_utk_user_id=substr($_,448,8);
		$cmod_utk_grp_id=substr($_,457,8);
		$cmod_utk_dft_grp=substr($_,466,1);
		$cmod_utk_dft_secl=substr($_,471,1);
		$cmod_appc_link=substr($_,476,16);
		$cmod_audit_code=substr($_,493,11);
		$cmod_old_real_uid=substr($_,505,10);
		if ($cmod_old_real_uid  eq ' ' x length($cmod_old_real_uid )) {
			undef $cmod_old_real_uid ;
		}
		$cmod_old_eff_uid=substr($_,516,10);
		if ($cmod_old_eff_uid  eq ' ' x length($cmod_old_eff_uid )) {
			undef $cmod_old_eff_uid ;
		}
		$cmod_old_saved_uid=substr($_,527,10);
		if ($cmod_old_saved_uid eq ' ' x length($cmod_old_saved_uid)) {
			undef $cmod_old_saved_uid;
		}
		$cmod_old_real_gid=substr($_,538,10);
		if ($cmod_old_real_gid  eq ' ' x length($cmod_old_real_gid )) {
			undef $cmod_old_real_gid ;
		}
		$cmod_old_eff_gid=substr($_,549,10);
		if ($cmod_old_eff_gid  eq ' ' x length($cmod_old_eff_gid )) {
			undef $cmod_old_eff_gid ;
		}
		$cmod_old_saved_gid=substr($_,560,10);
		if ($cmod_old_saved_gid eq ' ' x length($cmod_old_saved_gid)) {
			undef $cmod_old_saved_gid;
		}
		$cmod_path_name=substr($_,571,1023);
		$cmod_file_id=substr($_,1595,32);
		$cmod_file_own_uid=substr($_,1628,10);
		if ($cmod_file_own_uid  eq ' ' x length($cmod_file_own_uid )) {
			undef $cmod_file_own_uid ;
		}
		$cmod_file_own_gid=substr($_,1639,10);
		if ($cmod_file_own_gid  eq ' ' x length($cmod_file_own_gid )) {
			undef $cmod_file_own_gid ;
		}
		$cmod_old_s_isgid=substr($_,1650,1);
		$cmod_old_s_isuid=substr($_,1655,1);
		$cmod_old_s_isvtx=substr($_,1660,1);
		$cmod_old_own_read=substr($_,1665,1);
		$cmod_old_own_write=substr($_,1670,1);
		$cmod_old_own_exec=substr($_,1675,1);
		$cmod_old_grp_read=substr($_,1680,1);
		$cmod_old_grp_write=substr($_,1685,1);
		$cmod_old_grp_exec=substr($_,1690,1);
		$cmod_old_oth_read=substr($_,1695,1);
		$cmod_old_oth_write=substr($_,1700,1);
		$cmod_old_oth_exec=substr($_,1705,1);
		$cmod_new_s_isgid=substr($_,1710,1);
		$cmod_new_s_isuid=substr($_,1715,1);
		$cmod_new_s_isvtx=substr($_,1720,1);
		$cmod_new_own_read=substr($_,1725,1);
		$cmod_new_own_write=substr($_,1730,1);
		$cmod_new_own_exec=substr($_,1735,1);
		$cmod_new_grp_read=substr($_,1740,1);
		$cmod_new_grp_write=substr($_,1745,1);
		$cmod_new_grp_exec=substr($_,1750,1);
		$cmod_new_oth_read=substr($_,1755,1);
		$cmod_new_oth_write=substr($_,1760,1);
		$cmod_new_oth_exec=substr($_,1765,1);
		$cmod_req_s_isgid=substr($_,1770,1);
		$cmod_req_s_isuid=substr($_,1775,1);
		$cmod_req_s_isvtx=substr($_,1780,1);
		$cmod_req_own_read=substr($_,1785,1);
		$cmod_req_own_write=substr($_,1790,1);
		$cmod_req_own_exec=substr($_,1795,1);
		$cmod_req_grp_read=substr($_,1800,1);
		$cmod_req_grp_write=substr($_,1805,1);
		$cmod_req_grp_exec=substr($_,1810,1);
		$cmod_req_oth_read=substr($_,1815,1);
		$cmod_req_oth_write=substr($_,1820,1);
		$cmod_req_oth_exec=substr($_,1825,1);
		$cmod_filepool=substr($_,1830,8);
		$cmod_filespace=substr($_,1839,8);
		$cmod_inode=substr($_,1848,10);
		if ($cmod_inode  eq ' ' x length($cmod_inode )) {
			undef $cmod_inode ;
		}
		$cmod_scid=substr($_,1859,10);
		if ($cmod_scid  eq ' ' x length($cmod_scid )) {
			undef $cmod_scid ;
		}
		$cmod_dce_link=substr($_,1870,16);
		$cmod_auth_type=substr($_,1887,13);
		$cmod_dflt_process=substr($_,1901,1);
		$cmod_utk_netw=substr($_,1906,8);
		$cmod_x500_subject=substr($_,1915,255);
		$cmod_x500_issuer=substr($_,2171,255);
		$rv=$insert{chmod}->execute($cmod_event_type,$cmod_event_qual,$cmod_time_written,$cmod_date_written,$cmod_system_smfid,$cmod_violation,$cmod_user_ndfnd,$cmod_user_warning,$cmod_evt_user_id,$cmod_evt_grp_id,$cmod_auth_normal,$cmod_auth_special,$cmod_auth_oper,$cmod_auth_audit,$cmod_auth_exit,$cmod_auth_failsft,$cmod_auth_bypass,$cmod_auth_trusted,$cmod_log_class,$cmod_log_user,$cmod_log_special,$cmod_log_access,$cmod_log_racinit,$cmod_log_always,$cmod_log_cmdviol,$cmod_log_global,$cmod_term_level,$cmod_backout_fail,$cmod_prof_same,$cmod_term,$cmod_job_name,$cmod_read_time,$cmod_read_date,$cmod_smf_user_id,$cmod_log_level,$cmod_log_vmevent,$cmod_log_logopt,$cmod_log_secl,$cmod_log_compatm,$cmod_log_applaud,$cmod_log_nonomvs,$cmod_log_omvsnprv,$cmod_auth_omvssu,$cmod_auth_omvssys,$cmod_usr_secl,$cmod_racf_version,$cmod_class,$cmod_user_name,$cmod_utk_encr,$cmod_utk_pre19,$cmod_utk_verprof,$cmod_utk_njeunusr,$cmod_utk_logusr,$cmod_utk_special,$cmod_utk_default,$cmod_utk_unknusr,$cmod_utk_error,$cmod_utk_trusted,$cmod_utk_sesstype,$cmod_utk_surrogat,$cmod_utk_remote,$cmod_utk_priv,$cmod_utk_secl,$cmod_utk_execnode,$cmod_utk_suser_id,$cmod_utk_snode,$cmod_utk_sgrp_id,$cmod_utk_spoe,$cmod_utk_spclass,$cmod_utk_user_id,$cmod_utk_grp_id,$cmod_utk_dft_grp,$cmod_utk_dft_secl,$cmod_appc_link,$cmod_audit_code,$cmod_old_real_uid,$cmod_old_eff_uid,$cmod_old_saved_uid,$cmod_old_real_gid,$cmod_old_eff_gid,$cmod_old_saved_gid,$cmod_path_name,$cmod_file_id,$cmod_file_own_uid,$cmod_file_own_gid,$cmod_old_s_isgid,$cmod_old_s_isuid,$cmod_old_s_isvtx,$cmod_old_own_read,$cmod_old_own_write,$cmod_old_own_exec,$cmod_old_grp_read,$cmod_old_grp_write,$cmod_old_grp_exec,$cmod_old_oth_read,$cmod_old_oth_write,$cmod_old_oth_exec,$cmod_new_s_isgid,$cmod_new_s_isuid,$cmod_new_s_isvtx,$cmod_new_own_read,$cmod_new_own_write,$cmod_new_own_exec,$cmod_new_grp_read,$cmod_new_grp_write,$cmod_new_grp_exec,$cmod_new_oth_read,$cmod_new_oth_write,$cmod_new_oth_exec,$cmod_req_s_isgid,$cmod_req_s_isuid,$cmod_req_s_isvtx,$cmod_req_own_read,$cmod_req_own_write,$cmod_req_own_exec,$cmod_req_grp_read,$cmod_req_grp_write,$cmod_req_grp_exec,$cmod_req_oth_read,$cmod_req_oth_write,$cmod_req_oth_exec,$cmod_filepool,$cmod_filespace,$cmod_inode,$cmod_scid,$cmod_dce_link,$cmod_auth_type,$cmod_dflt_process,$cmod_utk_netw,$cmod_x500_subject,$cmod_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chmod"}++;
		next;
	}

	if ($rectype eq 'CHOWN   ') {
		$cown_event_type=substr($_,0,8);
		$cown_event_qual=substr($_,9,8);
		$cown_time_written=substr($_,18,8);
		if ($cown_time_written  eq ' ' x length($cown_time_written )) {
			undef $cown_time_written ;
		}
		$cown_date_written=substr($_,27,10);
		if ($cown_date_written  eq ' ' x length($cown_date_written )) {
			undef $cown_date_written ;
		}
		$cown_system_smfid=substr($_,38,4);
		$cown_violation=substr($_,43,1);
		$cown_user_ndfnd=substr($_,48,1);
		$cown_user_warning=substr($_,53,1);
		$cown_evt_user_id=substr($_,58,8);
		$cown_evt_grp_id=substr($_,67,8);
		$cown_auth_normal=substr($_,76,1);
		$cown_auth_special=substr($_,81,1);
		$cown_auth_oper=substr($_,86,1);
		$cown_auth_audit=substr($_,91,1);
		$cown_auth_exit=substr($_,96,1);
		$cown_auth_failsft=substr($_,101,1);
		$cown_auth_bypass=substr($_,106,1);
		$cown_auth_trusted=substr($_,111,1);
		$cown_log_class=substr($_,116,1);
		$cown_log_user=substr($_,121,1);
		$cown_log_special=substr($_,126,1);
		$cown_log_access=substr($_,131,1);
		$cown_log_racinit=substr($_,136,1);
		$cown_log_always=substr($_,141,1);
		$cown_log_cmdviol=substr($_,146,1);
		$cown_log_global=substr($_,151,1);
		$cown_term_level=substr($_,156,3);
		if ($cown_term_level  eq ' ' x length($cown_term_level )) {
			undef $cown_term_level ;
		}
		$cown_backout_fail=substr($_,160,1);
		$cown_prof_same=substr($_,165,1);
		$cown_term=substr($_,170,8);
		$cown_job_name=substr($_,179,8);
		$cown_read_time=substr($_,188,8);
		if ($cown_read_time  eq ' ' x length($cown_read_time )) {
			undef $cown_read_time ;
		}
		$cown_read_date=substr($_,197,10);
		if ($cown_read_date  eq ' ' x length($cown_read_date )) {
			undef $cown_read_date ;
		}
		$cown_smf_user_id=substr($_,208,8);
		$cown_log_level=substr($_,217,1);
		$cown_log_vmevent=substr($_,222,1);
		$cown_log_logopt=substr($_,227,1);
		$cown_log_secl=substr($_,232,1);
		$cown_log_compatm=substr($_,237,1);
		$cown_log_applaud=substr($_,242,1);
		$cown_log_nonomvs=substr($_,247,1);
		$cown_log_omvsnprv=substr($_,252,1);
		$cown_auth_omvssu=substr($_,257,1);
		$cown_auth_omvssys=substr($_,262,1);
		$cown_usr_secl=substr($_,267,8);
		$cown_racf_version=substr($_,276,4);
		$cown_class=substr($_,281,8);
		$cown_user_name=substr($_,290,20);
		$cown_utk_encr=substr($_,311,1);
		$cown_utk_pre19=substr($_,316,1);
		$cown_utk_verprof=substr($_,321,1);
		$cown_utk_njeunusr=substr($_,326,1);
		$cown_utk_logusr=substr($_,331,1);
		$cown_utk_special=substr($_,336,1);
		$cown_utk_default=substr($_,341,1);
		$cown_utk_unknusr=substr($_,346,1);
		$cown_utk_error=substr($_,351,1);
		$cown_utk_trusted=substr($_,356,1);
		$cown_utk_sesstype=substr($_,361,8);
		$cown_utk_surrogat=substr($_,370,1);
		$cown_utk_remote=substr($_,375,1);
		$cown_utk_priv=substr($_,380,1);
		$cown_utk_secl=substr($_,385,8);
		$cown_utk_execnode=substr($_,394,8);
		$cown_utk_suser_id=substr($_,403,8);
		$cown_utk_snode=substr($_,412,8);
		$cown_utk_sgrp_id=substr($_,421,8);
		$cown_utk_spoe=substr($_,430,8);
		$cown_utk_spclass=substr($_,439,8);
		$cown_utk_user_id=substr($_,448,8);
		$cown_utk_grp_id=substr($_,457,8);
		$cown_utk_dft_grp=substr($_,466,1);
		$cown_utk_dft_secl=substr($_,471,1);
		$cown_appc_link=substr($_,476,16);
		$cown_audit_code=substr($_,493,11);
		$cown_old_real_uid=substr($_,505,10);
		if ($cown_old_real_uid  eq ' ' x length($cown_old_real_uid )) {
			undef $cown_old_real_uid ;
		}
		$cown_old_eff_uid=substr($_,516,10);
		if ($cown_old_eff_uid  eq ' ' x length($cown_old_eff_uid )) {
			undef $cown_old_eff_uid ;
		}
		$cown_old_saved_uid=substr($_,527,10);
		if ($cown_old_saved_uid eq ' ' x length($cown_old_saved_uid)) {
			undef $cown_old_saved_uid;
		}
		$cown_old_real_gid=substr($_,538,10);
		if ($cown_old_real_gid  eq ' ' x length($cown_old_real_gid )) {
			undef $cown_old_real_gid ;
		}
		$cown_old_eff_gid=substr($_,549,10);
		if ($cown_old_eff_gid  eq ' ' x length($cown_old_eff_gid )) {
			undef $cown_old_eff_gid ;
		}
		$cown_old_saved_gid=substr($_,560,10);
		if ($cown_old_saved_gid eq ' ' x length($cown_old_saved_gid)) {
			undef $cown_old_saved_gid;
		}
		$cown_path_name=substr($_,571,1023);
		$cown_file_id=substr($_,1595,32);
		$cown_file_own_uid=substr($_,1628,10);
		if ($cown_file_own_uid  eq ' ' x length($cown_file_own_uid )) {
			undef $cown_file_own_uid ;
		}
		$cown_file_own_gid=substr($_,1639,10);
		if ($cown_file_own_gid  eq ' ' x length($cown_file_own_gid )) {
			undef $cown_file_own_gid ;
		}
		$cown_uid=substr($_,1650,10);
		if ($cown_uid  eq ' ' x length($cown_uid )) {
			undef $cown_uid ;
		}
		$cown_gid=substr($_,1661,10);
		if ($cown_gid  eq ' ' x length($cown_gid )) {
			undef $cown_gid ;
		}
		$cown_filepool=substr($_,1672,8);
		$cown_filespace=substr($_,1681,8);
		$cown_inode=substr($_,1690,10);
		if ($cown_inode  eq ' ' x length($cown_inode )) {
			undef $cown_inode ;
		}
		$cown_scid=substr($_,1701,10);
		if ($cown_scid  eq ' ' x length($cown_scid )) {
			undef $cown_scid ;
		}
		$cown_dce_link=substr($_,1712,16);
		$cown_auth_type=substr($_,1729,13);
		$cown_dflt_process=substr($_,1743,1);
		$cown_utk_netw=substr($_,1748,8);
		$cown_x500_subject=substr($_,1757,255);
		$cown_x500_issuer=substr($_,2013,255);
		$rv=$insert{chown}->execute($cown_event_type,$cown_event_qual,$cown_time_written,$cown_date_written,$cown_system_smfid,$cown_violation,$cown_user_ndfnd,$cown_user_warning,$cown_evt_user_id,$cown_evt_grp_id,$cown_auth_normal,$cown_auth_special,$cown_auth_oper,$cown_auth_audit,$cown_auth_exit,$cown_auth_failsft,$cown_auth_bypass,$cown_auth_trusted,$cown_log_class,$cown_log_user,$cown_log_special,$cown_log_access,$cown_log_racinit,$cown_log_always,$cown_log_cmdviol,$cown_log_global,$cown_term_level,$cown_backout_fail,$cown_prof_same,$cown_term,$cown_job_name,$cown_read_time,$cown_read_date,$cown_smf_user_id,$cown_log_level,$cown_log_vmevent,$cown_log_logopt,$cown_log_secl,$cown_log_compatm,$cown_log_applaud,$cown_log_nonomvs,$cown_log_omvsnprv,$cown_auth_omvssu,$cown_auth_omvssys,$cown_usr_secl,$cown_racf_version,$cown_class,$cown_user_name,$cown_utk_encr,$cown_utk_pre19,$cown_utk_verprof,$cown_utk_njeunusr,$cown_utk_logusr,$cown_utk_special,$cown_utk_default,$cown_utk_unknusr,$cown_utk_error,$cown_utk_trusted,$cown_utk_sesstype,$cown_utk_surrogat,$cown_utk_remote,$cown_utk_priv,$cown_utk_secl,$cown_utk_execnode,$cown_utk_suser_id,$cown_utk_snode,$cown_utk_sgrp_id,$cown_utk_spoe,$cown_utk_spclass,$cown_utk_user_id,$cown_utk_grp_id,$cown_utk_dft_grp,$cown_utk_dft_secl,$cown_appc_link,$cown_audit_code,$cown_old_real_uid,$cown_old_eff_uid,$cown_old_saved_uid,$cown_old_real_gid,$cown_old_eff_gid,$cown_old_saved_gid,$cown_path_name,$cown_file_id,$cown_file_own_uid,$cown_file_own_gid,$cown_uid,$cown_gid,$cown_filepool,$cown_filespace,$cown_inode,$cown_scid,$cown_dce_link,$cown_auth_type,$cown_dflt_process,$cown_utk_netw,$cown_x500_subject,$cown_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"chown"}++;
		next;
	}

	if ($rectype eq 'CKOWN2  ') {
		$cko2_event_type=substr($_,0,8);
		$cko2_event_qual=substr($_,9,8);
		$cko2_time_written=substr($_,18,8);
		if ($cko2_time_written  eq ' ' x length($cko2_time_written )) {
			undef $cko2_time_written ;
		}
		$cko2_date_written=substr($_,27,10);
		if ($cko2_date_written  eq ' ' x length($cko2_date_written )) {
			undef $cko2_date_written ;
		}
		$cko2_system_smfid=substr($_,38,4);
		$cko2_violation=substr($_,43,1);
		$cko2_user_ndfnd=substr($_,48,1);
		$cko2_user_warning=substr($_,53,1);
		$cko2_evt_user_id=substr($_,58,8);
		$cko2_evt_grp_id=substr($_,67,8);
		$cko2_auth_normal=substr($_,76,1);
		$cko2_auth_special=substr($_,81,1);
		$cko2_auth_oper=substr($_,86,1);
		$cko2_auth_audit=substr($_,91,1);
		$cko2_auth_exit=substr($_,96,1);
		$cko2_auth_failsft=substr($_,101,1);
		$cko2_auth_bypass=substr($_,106,1);
		$cko2_auth_trusted=substr($_,111,1);
		$cko2_log_class=substr($_,116,1);
		$cko2_log_user=substr($_,121,1);
		$cko2_log_special=substr($_,126,1);
		$cko2_log_access=substr($_,131,1);
		$cko2_log_racinit=substr($_,136,1);
		$cko2_log_always=substr($_,141,1);
		$cko2_log_cmdviol=substr($_,146,1);
		$cko2_log_global=substr($_,151,1);
		$cko2_term_level=substr($_,156,3);
		if ($cko2_term_level  eq ' ' x length($cko2_term_level )) {
			undef $cko2_term_level ;
		}
		$cko2_backout_fail=substr($_,160,1);
		$cko2_prof_same=substr($_,165,1);
		$cko2_term=substr($_,170,8);
		$cko2_job_name=substr($_,179,8);
		$cko2_read_time=substr($_,188,8);
		if ($cko2_read_time  eq ' ' x length($cko2_read_time )) {
			undef $cko2_read_time ;
		}
		$cko2_read_date=substr($_,197,10);
		if ($cko2_read_date  eq ' ' x length($cko2_read_date )) {
			undef $cko2_read_date ;
		}
		$cko2_smf_user_id=substr($_,208,8);
		$cko2_log_level=substr($_,217,1);
		$cko2_log_vmevent=substr($_,222,1);
		$cko2_log_logopt=substr($_,227,1);
		$cko2_log_secl=substr($_,232,1);
		$cko2_log_compatm=substr($_,237,1);
		$cko2_log_applaud=substr($_,242,1);
		$cko2_log_nonomvs=substr($_,247,1);
		$cko2_log_omvsnprv=substr($_,252,1);
		$cko2_auth_omvssu=substr($_,257,1);
		$cko2_auth_omvssys=substr($_,262,1);
		$cko2_usr_secl=substr($_,267,8);
		$cko2_racf_version=substr($_,276,4);
		$cko2_class=substr($_,281,8);
		$cko2_user_name=substr($_,290,20);
		$cko2_utk_encr=substr($_,311,1);
		$cko2_utk_pre19=substr($_,316,1);
		$cko2_utk_verprof=substr($_,321,1);
		$cko2_utk_njeunusr=substr($_,326,1);
		$cko2_utk_logusr=substr($_,331,1);
		$cko2_utk_special=substr($_,336,1);
		$cko2_utk_default=substr($_,341,1);
		$cko2_utk_unknusr=substr($_,346,1);
		$cko2_utk_error=substr($_,351,1);
		$cko2_utk_trusted=substr($_,356,1);
		$cko2_utk_sesstype=substr($_,361,8);
		$cko2_utk_surrogat=substr($_,370,1);
		$cko2_utk_remote=substr($_,375,1);
		$cko2_utk_priv=substr($_,380,1);
		$cko2_utk_secl=substr($_,385,8);
		$cko2_utk_execnode=substr($_,394,8);
		$cko2_utk_suser_id=substr($_,403,8);
		$cko2_utk_snode=substr($_,412,8);
		$cko2_utk_sgrp_id=substr($_,421,8);
		$cko2_utk_spoe=substr($_,430,8);
		$cko2_utk_spclass=substr($_,439,8);
		$cko2_utk_user_id=substr($_,448,8);
		$cko2_utk_grp_id=substr($_,457,8);
		$cko2_utk_dft_grp=substr($_,466,1);
		$cko2_utk_dft_secl=substr($_,471,1);
		$cko2_appc_link=substr($_,476,16);
		$cko2_audit_code=substr($_,493,11);
		$cko2_old_real_uid=substr($_,505,10);
		if ($cko2_old_real_uid  eq ' ' x length($cko2_old_real_uid )) {
			undef $cko2_old_real_uid ;
		}
		$cko2_old_eff_uid=substr($_,516,10);
		if ($cko2_old_eff_uid  eq ' ' x length($cko2_old_eff_uid )) {
			undef $cko2_old_eff_uid ;
		}
		$cko2_old_saved_uid=substr($_,527,10);
		if ($cko2_old_saved_uid eq ' ' x length($cko2_old_saved_uid)) {
			undef $cko2_old_saved_uid;
		}
		$cko2_old_real_gid=substr($_,538,10);
		if ($cko2_old_real_gid  eq ' ' x length($cko2_old_real_gid )) {
			undef $cko2_old_real_gid ;
		}
		$cko2_old_eff_gid=substr($_,549,10);
		if ($cko2_old_eff_gid  eq ' ' x length($cko2_old_eff_gid )) {
			undef $cko2_old_eff_gid ;
		}
		$cko2_old_saved_gid=substr($_,560,10);
		if ($cko2_old_saved_gid eq ' ' x length($cko2_old_saved_gid)) {
			undef $cko2_old_saved_gid;
		}
		$cko2_path_name=substr($_,571,1023);
		$cko2_file1_id=substr($_,1595,32);
		$cko2_file1_own_uid=substr($_,1628,10);
		if ($cko2_file1_own_uid eq ' ' x length($cko2_file1_own_uid)) {
			undef $cko2_file1_own_uid;
		}
		$cko2_file1_own_gid=substr($_,1639,10);
		if ($cko2_file1_own_gid eq ' ' x length($cko2_file1_own_gid)) {
			undef $cko2_file1_own_gid;
		}
		$cko2_file2_id=substr($_,1650,32);
		$cko2_file2_own_uid=substr($_,1683,10);
		if ($cko2_file2_own_uid eq ' ' x length($cko2_file2_own_uid)) {
			undef $cko2_file2_own_uid;
		}
		$cko2_file2_own_gid=substr($_,1694,10);
		if ($cko2_file2_own_gid eq ' ' x length($cko2_file2_own_gid)) {
			undef $cko2_file2_own_gid;
		}
		$cko2_dce_link=substr($_,1705,16);
		$cko2_auth_type=substr($_,1722,13);
		$cko2_dflt_process=substr($_,1736,1);
		$cko2_utk_netw=substr($_,1741,8);
		$cko2_x500_subject=substr($_,1750,255);
		$cko2_x500_issuer=substr($_,2006,255);
		$rv=$insert{ckown2}->execute($cko2_event_type,$cko2_event_qual,$cko2_time_written,$cko2_date_written,$cko2_system_smfid,$cko2_violation,$cko2_user_ndfnd,$cko2_user_warning,$cko2_evt_user_id,$cko2_evt_grp_id,$cko2_auth_normal,$cko2_auth_special,$cko2_auth_oper,$cko2_auth_audit,$cko2_auth_exit,$cko2_auth_failsft,$cko2_auth_bypass,$cko2_auth_trusted,$cko2_log_class,$cko2_log_user,$cko2_log_special,$cko2_log_access,$cko2_log_racinit,$cko2_log_always,$cko2_log_cmdviol,$cko2_log_global,$cko2_term_level,$cko2_backout_fail,$cko2_prof_same,$cko2_term,$cko2_job_name,$cko2_read_time,$cko2_read_date,$cko2_smf_user_id,$cko2_log_level,$cko2_log_vmevent,$cko2_log_logopt,$cko2_log_secl,$cko2_log_compatm,$cko2_log_applaud,$cko2_log_nonomvs,$cko2_log_omvsnprv,$cko2_auth_omvssu,$cko2_auth_omvssys,$cko2_usr_secl,$cko2_racf_version,$cko2_class,$cko2_user_name,$cko2_utk_encr,$cko2_utk_pre19,$cko2_utk_verprof,$cko2_utk_njeunusr,$cko2_utk_logusr,$cko2_utk_special,$cko2_utk_default,$cko2_utk_unknusr,$cko2_utk_error,$cko2_utk_trusted,$cko2_utk_sesstype,$cko2_utk_surrogat,$cko2_utk_remote,$cko2_utk_priv,$cko2_utk_secl,$cko2_utk_execnode,$cko2_utk_suser_id,$cko2_utk_snode,$cko2_utk_sgrp_id,$cko2_utk_spoe,$cko2_utk_spclass,$cko2_utk_user_id,$cko2_utk_grp_id,$cko2_utk_dft_grp,$cko2_utk_dft_secl,$cko2_appc_link,$cko2_audit_code,$cko2_old_real_uid,$cko2_old_eff_uid,$cko2_old_saved_uid,$cko2_old_real_gid,$cko2_old_eff_gid,$cko2_old_saved_gid,$cko2_path_name,$cko2_file1_id,$cko2_file1_own_uid,$cko2_file1_own_gid,$cko2_file2_id,$cko2_file2_own_uid,$cko2_file2_own_gid,$cko2_dce_link,$cko2_auth_type,$cko2_dflt_process,$cko2_utk_netw,$cko2_x500_subject,$cko2_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ckown2"}++;
		next;
	}

	if ($rectype eq 'CLASNAME') {
		$rinc_event_type=substr($_,0,8);
		$rinc_reserved_01=substr($_,9,8);
		$rinc_time_written=substr($_,18,8);
		if ($rinc_time_written  eq ' ' x length($rinc_time_written )) {
			undef $rinc_time_written ;
		}
		$rinc_date_written=substr($_,27,10);
		if ($rinc_date_written  eq ' ' x length($rinc_date_written )) {
			undef $rinc_date_written ;
		}
		$rinc_system_smfid=substr($_,38,4);
		$rinc_class_name=substr($_,43,8);
		$rinc_stats=substr($_,52,1);
		$rinc_audit=substr($_,57,1);
		$rinc_active=substr($_,62,1);
		$rinc_generic=substr($_,67,1);
		$rinc_gencmd=substr($_,72,1);
		$rinc_global=substr($_,77,1);
		$rinc_raclist=substr($_,82,1);
		$rinc_genlist=substr($_,87,1);
		$rinc_log_options=substr($_,92,8);
		$rv=$insert{clasname}->execute($rinc_event_type,$rinc_reserved_01,$rinc_time_written,$rinc_date_written,$rinc_system_smfid,$rinc_class_name,$rinc_stats,$rinc_audit,$rinc_active,$rinc_generic,$rinc_gencmd,$rinc_global,$rinc_raclist,$rinc_genlist,$rinc_log_options);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"clasname"}++;
		next;
	}

	if ($rectype eq 'CLRSETID') {
		$csid_event_type=substr($_,0,8);
		$csid_event_qual=substr($_,9,8);
		$csid_time_written=substr($_,18,8);
		if ($csid_time_written  eq ' ' x length($csid_time_written )) {
			undef $csid_time_written ;
		}
		$csid_date_written=substr($_,27,10);
		if ($csid_date_written  eq ' ' x length($csid_date_written )) {
			undef $csid_date_written ;
		}
		$csid_system_smfid=substr($_,38,4);
		$csid_violation=substr($_,43,1);
		$csid_user_ndfnd=substr($_,48,1);
		$csid_user_warning=substr($_,53,1);
		$csid_evt_user_id=substr($_,58,8);
		$csid_evt_grp_id=substr($_,67,8);
		$csid_auth_normal=substr($_,76,1);
		$csid_auth_special=substr($_,81,1);
		$csid_auth_oper=substr($_,86,1);
		$csid_auth_audit=substr($_,91,1);
		$csid_auth_exit=substr($_,96,1);
		$csid_auth_failsft=substr($_,101,1);
		$csid_auth_bypass=substr($_,106,1);
		$csid_auth_trusted=substr($_,111,1);
		$csid_log_class=substr($_,116,1);
		$csid_log_user=substr($_,121,1);
		$csid_log_special=substr($_,126,1);
		$csid_log_access=substr($_,131,1);
		$csid_log_racinit=substr($_,136,1);
		$csid_log_always=substr($_,141,1);
		$csid_log_cmdviol=substr($_,146,1);
		$csid_log_global=substr($_,151,1);
		$csid_term_level=substr($_,156,3);
		if ($csid_term_level  eq ' ' x length($csid_term_level )) {
			undef $csid_term_level ;
		}
		$csid_backout_fail=substr($_,160,1);
		$csid_prof_same=substr($_,165,1);
		$csid_term=substr($_,170,8);
		$csid_job_name=substr($_,179,8);
		$csid_read_time=substr($_,188,8);
		if ($csid_read_time  eq ' ' x length($csid_read_time )) {
			undef $csid_read_time ;
		}
		$csid_read_date=substr($_,197,10);
		if ($csid_read_date  eq ' ' x length($csid_read_date )) {
			undef $csid_read_date ;
		}
		$csid_smf_user_id=substr($_,208,8);
		$csid_log_level=substr($_,217,1);
		$csid_log_vmevent=substr($_,222,1);
		$csid_log_logopt=substr($_,227,1);
		$csid_log_secl=substr($_,232,1);
		$csid_log_compatm=substr($_,237,1);
		$csid_log_applaud=substr($_,242,1);
		$csid_log_nonomvs=substr($_,247,1);
		$csid_log_omvsnprv=substr($_,252,1);
		$csid_auth_omvssu=substr($_,257,1);
		$csid_auth_omvssys=substr($_,262,1);
		$csid_usr_secl=substr($_,267,8);
		$csid_racf_version=substr($_,276,4);
		$csid_class=substr($_,281,8);
		$csid_user_name=substr($_,290,20);
		$csid_utk_encr=substr($_,311,1);
		$csid_utk_pre19=substr($_,316,1);
		$csid_utk_verprof=substr($_,321,1);
		$csid_utk_njeunusr=substr($_,326,1);
		$csid_utk_logusr=substr($_,331,1);
		$csid_utk_special=substr($_,336,1);
		$csid_utk_default=substr($_,341,1);
		$csid_utk_unknusr=substr($_,346,1);
		$csid_utk_error=substr($_,351,1);
		$csid_utk_trusted=substr($_,356,1);
		$csid_utk_sesstype=substr($_,361,8);
		$csid_utk_surrogat=substr($_,370,1);
		$csid_utk_remote=substr($_,375,1);
		$csid_utk_priv=substr($_,380,1);
		$csid_utk_secl=substr($_,385,8);
		$csid_utk_execnode=substr($_,394,8);
		$csid_utk_suser_id=substr($_,403,8);
		$csid_utk_snode=substr($_,412,8);
		$csid_utk_sgrp_id=substr($_,421,8);
		$csid_utk_spoe=substr($_,430,8);
		$csid_utk_spclass=substr($_,439,8);
		$csid_utk_user_id=substr($_,448,8);
		$csid_utk_grp_id=substr($_,457,8);
		$csid_utk_dft_grp=substr($_,466,1);
		$csid_utk_dft_secl=substr($_,471,1);
		$csid_appc_link=substr($_,476,16);
		$csid_audit_code=substr($_,493,11);
		$csid_old_real_uid=substr($_,505,10);
		if ($csid_old_real_uid  eq ' ' x length($csid_old_real_uid )) {
			undef $csid_old_real_uid ;
		}
		$csid_old_eff_uid=substr($_,516,10);
		if ($csid_old_eff_uid  eq ' ' x length($csid_old_eff_uid )) {
			undef $csid_old_eff_uid ;
		}
		$csid_old_saved_uid=substr($_,527,10);
		if ($csid_old_saved_uid eq ' ' x length($csid_old_saved_uid)) {
			undef $csid_old_saved_uid;
		}
		$csid_old_real_gid=substr($_,538,10);
		if ($csid_old_real_gid  eq ' ' x length($csid_old_real_gid )) {
			undef $csid_old_real_gid ;
		}
		$csid_old_eff_gid=substr($_,549,10);
		if ($csid_old_eff_gid  eq ' ' x length($csid_old_eff_gid )) {
			undef $csid_old_eff_gid ;
		}
		$csid_old_saved_gid=substr($_,560,10);
		if ($csid_old_saved_gid eq ' ' x length($csid_old_saved_gid)) {
			undef $csid_old_saved_gid;
		}
		$csid_path_name=substr($_,571,1023);
		$csid_file_id=substr($_,1595,32);
		$csid_file_own_uid=substr($_,1628,10);
		if ($csid_file_own_uid  eq ' ' x length($csid_file_own_uid )) {
			undef $csid_file_own_uid ;
		}
		$csid_file_own_gid=substr($_,1639,10);
		if ($csid_file_own_gid  eq ' ' x length($csid_file_own_gid )) {
			undef $csid_file_own_gid ;
		}
		$csid_old_s_isgid=substr($_,1650,1);
		$csid_old_s_isuid=substr($_,1655,1);
		$csid_old_s_isvtx=substr($_,1660,1);
		$csid_old_own_read=substr($_,1665,1);
		$csid_old_own_write=substr($_,1670,1);
		$csid_old_own_exec=substr($_,1675,1);
		$csid_old_grp_read=substr($_,1680,1);
		$csid_old_grp_write=substr($_,1685,1);
		$csid_old_grp_exec=substr($_,1690,1);
		$csid_old_oth_read=substr($_,1695,1);
		$csid_old_oth_write=substr($_,1700,1);
		$csid_old_oth_exec=substr($_,1705,1);
		$csid_new_s_isgid=substr($_,1710,1);
		$csid_new_s_isuid=substr($_,1715,1);
		$csid_new_s_isvtx=substr($_,1720,1);
		$csid_new_own_read=substr($_,1725,1);
		$csid_new_own_write=substr($_,1730,1);
		$csid_new_own_exec=substr($_,1735,1);
		$csid_new_grp_read=substr($_,1740,1);
		$csid_new_grp_write=substr($_,1745,1);
		$csid_new_grp_exec=substr($_,1750,1);
		$csid_new_oth_read=substr($_,1755,1);
		$csid_new_oth_write=substr($_,1760,1);
		$csid_new_oth_exec=substr($_,1765,1);
		$csid_dflt_process=substr($_,1770,1);
		$csid_utk_netw=substr($_,1775,8);
		$csid_x500_subject=substr($_,1784,255);
		$csid_x500_issuer=substr($_,2040,255);
		$rv=$insert{clrsetid}->execute($csid_event_type,$csid_event_qual,$csid_time_written,$csid_date_written,$csid_system_smfid,$csid_violation,$csid_user_ndfnd,$csid_user_warning,$csid_evt_user_id,$csid_evt_grp_id,$csid_auth_normal,$csid_auth_special,$csid_auth_oper,$csid_auth_audit,$csid_auth_exit,$csid_auth_failsft,$csid_auth_bypass,$csid_auth_trusted,$csid_log_class,$csid_log_user,$csid_log_special,$csid_log_access,$csid_log_racinit,$csid_log_always,$csid_log_cmdviol,$csid_log_global,$csid_term_level,$csid_backout_fail,$csid_prof_same,$csid_term,$csid_job_name,$csid_read_time,$csid_read_date,$csid_smf_user_id,$csid_log_level,$csid_log_vmevent,$csid_log_logopt,$csid_log_secl,$csid_log_compatm,$csid_log_applaud,$csid_log_nonomvs,$csid_log_omvsnprv,$csid_auth_omvssu,$csid_auth_omvssys,$csid_usr_secl,$csid_racf_version,$csid_class,$csid_user_name,$csid_utk_encr,$csid_utk_pre19,$csid_utk_verprof,$csid_utk_njeunusr,$csid_utk_logusr,$csid_utk_special,$csid_utk_default,$csid_utk_unknusr,$csid_utk_error,$csid_utk_trusted,$csid_utk_sesstype,$csid_utk_surrogat,$csid_utk_remote,$csid_utk_priv,$csid_utk_secl,$csid_utk_execnode,$csid_utk_suser_id,$csid_utk_snode,$csid_utk_sgrp_id,$csid_utk_spoe,$csid_utk_spclass,$csid_utk_user_id,$csid_utk_grp_id,$csid_utk_dft_grp,$csid_utk_dft_secl,$csid_appc_link,$csid_audit_code,$csid_old_real_uid,$csid_old_eff_uid,$csid_old_saved_uid,$csid_old_real_gid,$csid_old_eff_gid,$csid_old_saved_gid,$csid_path_name,$csid_file_id,$csid_file_own_uid,$csid_file_own_gid,$csid_old_s_isgid,$csid_old_s_isuid,$csid_old_s_isvtx,$csid_old_own_read,$csid_old_own_write,$csid_old_own_exec,$csid_old_grp_read,$csid_old_grp_write,$csid_old_grp_exec,$csid_old_oth_read,$csid_old_oth_write,$csid_old_oth_exec,$csid_new_s_isgid,$csid_new_s_isuid,$csid_new_s_isvtx,$csid_new_own_read,$csid_new_own_write,$csid_new_own_exec,$csid_new_grp_read,$csid_new_grp_write,$csid_new_grp_exec,$csid_new_oth_read,$csid_new_oth_write,$csid_new_oth_exec,$csid_dflt_process,$csid_utk_netw,$csid_x500_subject,$csid_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"clrsetid"}++;
		next;
	}

	if ($rectype eq 'CONNECT ') {
		$con_event_type=substr($_,0,8);
		$con_event_qual=substr($_,9,8);
		$con_time_written=substr($_,18,8);
		if ($con_time_written  eq ' ' x length($con_time_written )) {
			undef $con_time_written ;
		}
		$con_date_written=substr($_,27,10);
		if ($con_date_written  eq ' ' x length($con_date_written )) {
			undef $con_date_written ;
		}
		$con_system_smfid=substr($_,38,4);
		$con_violation=substr($_,43,1);
		$con_user_ndfnd=substr($_,48,1);
		$con_user_warning=substr($_,53,1);
		$con_evt_user_id=substr($_,58,8);
		$con_evt_grp_id=substr($_,67,8);
		$con_auth_normal=substr($_,76,1);
		$con_auth_special=substr($_,81,1);
		$con_auth_oper=substr($_,86,1);
		$con_auth_audit=substr($_,91,1);
		$con_auth_exit=substr($_,96,1);
		$con_auth_failsft=substr($_,101,1);
		$con_auth_bypass=substr($_,106,1);
		$con_auth_trusted=substr($_,111,1);
		$con_log_class=substr($_,116,1);
		$con_log_user=substr($_,121,1);
		$con_log_special=substr($_,126,1);
		$con_log_access=substr($_,131,1);
		$con_log_racinit=substr($_,136,1);
		$con_log_always=substr($_,141,1);
		$con_log_cmdviol=substr($_,146,1);
		$con_log_global=substr($_,151,1);
		$con_term_level=substr($_,156,3);
		if ($con_term_level  eq ' ' x length($con_term_level )) {
			undef $con_term_level ;
		}
		$con_backout_fail=substr($_,160,1);
		$con_prof_same=substr($_,165,1);
		$con_term=substr($_,170,8);
		$con_job_name=substr($_,179,8);
		$con_read_time=substr($_,188,8);
		if ($con_read_time  eq ' ' x length($con_read_time )) {
			undef $con_read_time ;
		}
		$con_read_date=substr($_,197,10);
		if ($con_read_date  eq ' ' x length($con_read_date )) {
			undef $con_read_date ;
		}
		$con_smf_user_id=substr($_,208,8);
		$con_log_level=substr($_,217,1);
		$con_log_vmevent=substr($_,222,1);
		$con_log_logopt=substr($_,227,1);
		$con_log_secl=substr($_,232,1);
		$con_log_compatm=substr($_,237,1);
		$con_log_applaud=substr($_,242,1);
		$con_log_nonomvs=substr($_,247,1);
		$con_log_omvsnprv=substr($_,252,1);
		$con_auth_omvssu=substr($_,257,1);
		$con_auth_omvssys=substr($_,262,1);
		$con_usr_secl=substr($_,267,8);
		$con_racf_version=substr($_,276,4);
		$con_own_id=substr($_,281,8);
		$con_user_name=substr($_,290,20);
		$con_utk_encr=substr($_,311,1);
		$con_utk_pre19=substr($_,316,1);
		$con_utk_verprof=substr($_,321,1);
		$con_utk_njeunusr=substr($_,326,1);
		$con_utk_logusr=substr($_,331,1);
		$con_utk_special=substr($_,336,1);
		$con_utk_default=substr($_,341,1);
		$con_utk_unknusr=substr($_,346,1);
		$con_utk_error=substr($_,351,1);
		$con_utk_trusted=substr($_,356,1);
		$con_utk_sesstype=substr($_,361,8);
		$con_utk_surrogat=substr($_,370,1);
		$con_utk_remote=substr($_,375,1);
		$con_utk_priv=substr($_,380,1);
		$con_utk_secl=substr($_,385,8);
		$con_utk_execnode=substr($_,394,8);
		$con_utk_suser_id=substr($_,403,8);
		$con_utk_snode=substr($_,412,8);
		$con_utk_sgrp_id=substr($_,421,8);
		$con_utk_spoe=substr($_,430,8);
		$con_utk_spclass=substr($_,439,8);
		$con_utk_user_id=substr($_,448,8);
		$con_utk_grp_id=substr($_,457,8);
		$con_utk_dft_grp=substr($_,466,1);
		$con_utk_dft_secl=substr($_,471,1);
		$con_appc_link=substr($_,476,16);
		$con_user_id=substr($_,493,8);
		$con_specified=substr($_,502,1024);
		$con_failed=substr($_,1527,1024);
		$con_utk_netw=substr($_,2552,8);
		$con_x500_subject=substr($_,2561,255);
		$con_x500_issuer=substr($_,2817,255);
		$rv=$insert{connect}->execute($con_event_type,$con_event_qual,$con_time_written,$con_date_written,$con_system_smfid,$con_violation,$con_user_ndfnd,$con_user_warning,$con_evt_user_id,$con_evt_grp_id,$con_auth_normal,$con_auth_special,$con_auth_oper,$con_auth_audit,$con_auth_exit,$con_auth_failsft,$con_auth_bypass,$con_auth_trusted,$con_log_class,$con_log_user,$con_log_special,$con_log_access,$con_log_racinit,$con_log_always,$con_log_cmdviol,$con_log_global,$con_term_level,$con_backout_fail,$con_prof_same,$con_term,$con_job_name,$con_read_time,$con_read_date,$con_smf_user_id,$con_log_level,$con_log_vmevent,$con_log_logopt,$con_log_secl,$con_log_compatm,$con_log_applaud,$con_log_nonomvs,$con_log_omvsnprv,$con_auth_omvssu,$con_auth_omvssys,$con_usr_secl,$con_racf_version,$con_own_id,$con_user_name,$con_utk_encr,$con_utk_pre19,$con_utk_verprof,$con_utk_njeunusr,$con_utk_logusr,$con_utk_special,$con_utk_default,$con_utk_unknusr,$con_utk_error,$con_utk_trusted,$con_utk_sesstype,$con_utk_surrogat,$con_utk_remote,$con_utk_priv,$con_utk_secl,$con_utk_execnode,$con_utk_suser_id,$con_utk_snode,$con_utk_sgrp_id,$con_utk_spoe,$con_utk_spclass,$con_utk_user_id,$con_utk_grp_id,$con_utk_dft_grp,$con_utk_dft_secl,$con_appc_link,$con_user_id,$con_specified,$con_failed,$con_utk_netw,$con_x500_subject,$con_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"connect"}++;
		next;
	}

	if ($rectype eq 'DACCESS ') {
		$dacc_event_type=substr($_,0,8);
		$dacc_event_qual=substr($_,9,8);
		$dacc_time_written=substr($_,18,8);
		if ($dacc_time_written  eq ' ' x length($dacc_time_written )) {
			undef $dacc_time_written ;
		}
		$dacc_date_written=substr($_,27,10);
		if ($dacc_date_written  eq ' ' x length($dacc_date_written )) {
			undef $dacc_date_written ;
		}
		$dacc_system_smfid=substr($_,38,4);
		$dacc_violation=substr($_,43,1);
		$dacc_user_ndfnd=substr($_,48,1);
		$dacc_user_warning=substr($_,53,1);
		$dacc_evt_user_id=substr($_,58,8);
		$dacc_evt_grp_id=substr($_,67,8);
		$dacc_auth_normal=substr($_,76,1);
		$dacc_auth_special=substr($_,81,1);
		$dacc_auth_oper=substr($_,86,1);
		$dacc_auth_audit=substr($_,91,1);
		$dacc_auth_exit=substr($_,96,1);
		$dacc_auth_failsft=substr($_,101,1);
		$dacc_auth_bypass=substr($_,106,1);
		$dacc_auth_trusted=substr($_,111,1);
		$dacc_log_class=substr($_,116,1);
		$dacc_log_user=substr($_,121,1);
		$dacc_log_special=substr($_,126,1);
		$dacc_log_access=substr($_,131,1);
		$dacc_log_racinit=substr($_,136,1);
		$dacc_log_always=substr($_,141,1);
		$dacc_log_cmdviol=substr($_,146,1);
		$dacc_log_global=substr($_,151,1);
		$dacc_term_level=substr($_,156,3);
		if ($dacc_term_level  eq ' ' x length($dacc_term_level )) {
			undef $dacc_term_level ;
		}
		$dacc_backout_fail=substr($_,160,1);
		$dacc_prof_same=substr($_,165,1);
		$dacc_term=substr($_,170,8);
		$dacc_job_name=substr($_,179,8);
		$dacc_read_time=substr($_,188,8);
		if ($dacc_read_time  eq ' ' x length($dacc_read_time )) {
			undef $dacc_read_time ;
		}
		$dacc_read_date=substr($_,197,10);
		if ($dacc_read_date  eq ' ' x length($dacc_read_date )) {
			undef $dacc_read_date ;
		}
		$dacc_smf_user_id=substr($_,208,8);
		$dacc_log_level=substr($_,217,1);
		$dacc_log_vmevent=substr($_,222,1);
		$dacc_log_logopt=substr($_,227,1);
		$dacc_log_secl=substr($_,232,1);
		$dacc_log_compatm=substr($_,237,1);
		$dacc_log_applaud=substr($_,242,1);
		$dacc_log_nonomvs=substr($_,247,1);
		$dacc_log_omvsnprv=substr($_,252,1);
		$dacc_auth_omvssu=substr($_,257,1);
		$dacc_auth_omvssys=substr($_,262,1);
		$dacc_usr_secl=substr($_,267,8);
		$dacc_racf_version=substr($_,276,4);
		$dacc_class=substr($_,281,8);
		$dacc_user_name=substr($_,290,20);
		$dacc_utk_encr=substr($_,311,1);
		$dacc_utk_pre19=substr($_,316,1);
		$dacc_utk_verprof=substr($_,321,1);
		$dacc_utk_njeunusr=substr($_,326,1);
		$dacc_utk_logusr=substr($_,331,1);
		$dacc_utk_special=substr($_,336,1);
		$dacc_utk_default=substr($_,341,1);
		$dacc_utk_unknusr=substr($_,346,1);
		$dacc_utk_error=substr($_,351,1);
		$dacc_utk_trusted=substr($_,356,1);
		$dacc_utk_sesstype=substr($_,361,8);
		$dacc_utk_surrogat=substr($_,370,1);
		$dacc_utk_remote=substr($_,375,1);
		$dacc_utk_priv=substr($_,380,1);
		$dacc_utk_secl=substr($_,385,8);
		$dacc_utk_execnode=substr($_,394,8);
		$dacc_utk_suser_id=substr($_,403,8);
		$dacc_utk_snode=substr($_,412,8);
		$dacc_utk_sgrp_id=substr($_,421,8);
		$dacc_utk_spoe=substr($_,430,8);
		$dacc_utk_spclass=substr($_,439,8);
		$dacc_utk_user_id=substr($_,448,8);
		$dacc_utk_grp_id=substr($_,457,8);
		$dacc_utk_dft_grp=substr($_,466,1);
		$dacc_utk_dft_secl=substr($_,471,1);
		$dacc_appc_link=substr($_,476,16);
		$dacc_audit_code=substr($_,493,11);
		$dacc_old_real_uid=substr($_,505,10);
		if ($dacc_old_real_uid  eq ' ' x length($dacc_old_real_uid )) {
			undef $dacc_old_real_uid ;
		}
		$dacc_old_eff_uid=substr($_,516,10);
		if ($dacc_old_eff_uid  eq ' ' x length($dacc_old_eff_uid )) {
			undef $dacc_old_eff_uid ;
		}
		$dacc_old_saved_uid=substr($_,527,10);
		if ($dacc_old_saved_uid eq ' ' x length($dacc_old_saved_uid)) {
			undef $dacc_old_saved_uid;
		}
		$dacc_old_real_gid=substr($_,538,10);
		if ($dacc_old_real_gid  eq ' ' x length($dacc_old_real_gid )) {
			undef $dacc_old_real_gid ;
		}
		$dacc_old_eff_gid=substr($_,549,10);
		if ($dacc_old_eff_gid  eq ' ' x length($dacc_old_eff_gid )) {
			undef $dacc_old_eff_gid ;
		}
		$dacc_old_saved_gid=substr($_,560,10);
		if ($dacc_old_saved_gid eq ' ' x length($dacc_old_saved_gid)) {
			undef $dacc_old_saved_gid;
		}
		$dacc_path_name=substr($_,571,1023);
		$dacc_file_id=substr($_,1595,32);
		$dacc_file_own_uid=substr($_,1628,10);
		if ($dacc_file_own_uid  eq ' ' x length($dacc_file_own_uid )) {
			undef $dacc_file_own_uid ;
		}
		$dacc_file_own_gid=substr($_,1639,10);
		if ($dacc_file_own_gid  eq ' ' x length($dacc_file_own_gid )) {
			undef $dacc_file_own_gid ;
		}
		$dacc_request_read=substr($_,1650,1);
		$dacc_request_write=substr($_,1655,1);
		$dacc_request_exec=substr($_,1660,1);
		$dacc_request_dsrch=substr($_,1665,1);
		$dacc_access_type=substr($_,1670,8);
		$dacc_allowed_read=substr($_,1679,1);
		$dacc_allowed_write=substr($_,1684,1);
		$dacc_allowed_exec=substr($_,1689,1);
		$dacc_request_path2=substr($_,1694,1023);
		$dacc_symlink=substr($_,2718,1023);
		$dacc_file_name=substr($_,3742,256);
		$dacc_path_type=substr($_,3999,4);
		$dacc_filepool=substr($_,4004,8);
		$dacc_filespace=substr($_,4013,8);
		$dacc_inode=substr($_,4022,10);
		if ($dacc_inode  eq ' ' x length($dacc_inode )) {
			undef $dacc_inode ;
		}
		$dacc_scid=substr($_,4033,10);
		if ($dacc_scid  eq ' ' x length($dacc_scid )) {
			undef $dacc_scid ;
		}
		$dacc_dce_link=substr($_,4044,16);
		$dacc_auth_type=substr($_,4061,13);
		$dacc_dflt_process=substr($_,4075,1);
		$dacc_utk_netw=substr($_,4080,8);
		$dacc_x500_subject=substr($_,4089,255);
		$dacc_x500_issuer=substr($_,4345,255);
		$rv=$insert{daccess}->execute($dacc_event_type,$dacc_event_qual,$dacc_time_written,$dacc_date_written,$dacc_system_smfid,$dacc_violation,$dacc_user_ndfnd,$dacc_user_warning,$dacc_evt_user_id,$dacc_evt_grp_id,$dacc_auth_normal,$dacc_auth_special,$dacc_auth_oper,$dacc_auth_audit,$dacc_auth_exit,$dacc_auth_failsft,$dacc_auth_bypass,$dacc_auth_trusted,$dacc_log_class,$dacc_log_user,$dacc_log_special,$dacc_log_access,$dacc_log_racinit,$dacc_log_always,$dacc_log_cmdviol,$dacc_log_global,$dacc_term_level,$dacc_backout_fail,$dacc_prof_same,$dacc_term,$dacc_job_name,$dacc_read_time,$dacc_read_date,$dacc_smf_user_id,$dacc_log_level,$dacc_log_vmevent,$dacc_log_logopt,$dacc_log_secl,$dacc_log_compatm,$dacc_log_applaud,$dacc_log_nonomvs,$dacc_log_omvsnprv,$dacc_auth_omvssu,$dacc_auth_omvssys,$dacc_usr_secl,$dacc_racf_version,$dacc_class,$dacc_user_name,$dacc_utk_encr,$dacc_utk_pre19,$dacc_utk_verprof,$dacc_utk_njeunusr,$dacc_utk_logusr,$dacc_utk_special,$dacc_utk_default,$dacc_utk_unknusr,$dacc_utk_error,$dacc_utk_trusted,$dacc_utk_sesstype,$dacc_utk_surrogat,$dacc_utk_remote,$dacc_utk_priv,$dacc_utk_secl,$dacc_utk_execnode,$dacc_utk_suser_id,$dacc_utk_snode,$dacc_utk_sgrp_id,$dacc_utk_spoe,$dacc_utk_spclass,$dacc_utk_user_id,$dacc_utk_grp_id,$dacc_utk_dft_grp,$dacc_utk_dft_secl,$dacc_appc_link,$dacc_audit_code,$dacc_old_real_uid,$dacc_old_eff_uid,$dacc_old_saved_uid,$dacc_old_real_gid,$dacc_old_eff_gid,$dacc_old_saved_gid,$dacc_path_name,$dacc_file_id,$dacc_file_own_uid,$dacc_file_own_gid,$dacc_request_read,$dacc_request_write,$dacc_request_exec,$dacc_request_dsrch,$dacc_access_type,$dacc_allowed_read,$dacc_allowed_write,$dacc_allowed_exec,$dacc_request_path2,$dacc_symlink,$dacc_file_name,$dacc_path_type,$dacc_filepool,$dacc_filespace,$dacc_inode,$dacc_scid,$dacc_dce_link,$dacc_auth_type,$dacc_dflt_process,$dacc_utk_netw,$dacc_x500_subject,$dacc_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"daccess"}++;
		next;
	}

	if ($rectype eq 'DEFINE  ') {
		$def_event_type=substr($_,0,8);
		$def_event_qual=substr($_,9,8);
		$def_time_written=substr($_,18,8);
		if ($def_time_written  eq ' ' x length($def_time_written )) {
			undef $def_time_written ;
		}
		$def_date_written=substr($_,27,10);
		if ($def_date_written  eq ' ' x length($def_date_written )) {
			undef $def_date_written ;
		}
		$def_system_smfid=substr($_,38,4);
		$def_violation=substr($_,43,1);
		$def_user_ndfnd=substr($_,48,1);
		$def_user_warning=substr($_,53,1);
		$def_evt_user_id=substr($_,58,8);
		$def_evt_grp_id=substr($_,67,8);
		$def_auth_normal=substr($_,76,1);
		$def_auth_special=substr($_,81,1);
		$def_auth_oper=substr($_,86,1);
		$def_auth_audit=substr($_,91,1);
		$def_auth_exit=substr($_,96,1);
		$def_auth_failsft=substr($_,101,1);
		$def_auth_bypass=substr($_,106,1);
		$def_auth_trusted=substr($_,111,1);
		$def_log_class=substr($_,116,1);
		$def_log_user=substr($_,121,1);
		$def_log_special=substr($_,126,1);
		$def_log_access=substr($_,131,1);
		$def_log_racinit=substr($_,136,1);
		$def_log_always=substr($_,141,1);
		$def_log_cmdviol=substr($_,146,1);
		$def_log_global=substr($_,151,1);
		$def_term_level=substr($_,156,3);
		if ($def_term_level  eq ' ' x length($def_term_level )) {
			undef $def_term_level ;
		}
		$def_backout_fail=substr($_,160,1);
		$def_prof_same=substr($_,165,1);
		$def_term=substr($_,170,8);
		$def_job_name=substr($_,179,8);
		$def_read_time=substr($_,188,8);
		if ($def_read_time  eq ' ' x length($def_read_time )) {
			undef $def_read_time ;
		}
		$def_read_date=substr($_,197,10);
		if ($def_read_date  eq ' ' x length($def_read_date )) {
			undef $def_read_date ;
		}
		$def_smf_user_id=substr($_,208,8);
		$def_log_level=substr($_,217,1);
		$def_log_vmevent=substr($_,222,1);
		$def_log_logopt=substr($_,227,1);
		$def_log_secl=substr($_,232,1);
		$def_log_compatm=substr($_,237,1);
		$def_log_applaud=substr($_,242,1);
		$def_log_nonomvs=substr($_,247,1);
		$def_log_omvsnprv=substr($_,252,1);
		$def_auth_omvssu=substr($_,257,1);
		$def_auth_omvssys=substr($_,262,1);
		$def_usr_secl=substr($_,267,8);
		$def_racf_version=substr($_,276,4);
		$def_res_name=substr($_,281,255);
		$def_level=substr($_,537,3);
		if ($def_level  eq ' ' x length($def_level )) {
			undef $def_level ;
		}
		$def_vol=substr($_,541,6);
		$def_class=substr($_,548,8);
		$def_model_name=substr($_,557,255);
		$def_model_vol=substr($_,813,6);
		$def_own_id=substr($_,820,8);
		$def_logstr=substr($_,829,255);
		$def_user_name=substr($_,1085,20);
		$def_utk_encr=substr($_,1106,1);
		$def_utk_pre19=substr($_,1111,1);
		$def_utk_verprof=substr($_,1116,1);
		$def_utk_njeunusr=substr($_,1121,1);
		$def_utk_logusr=substr($_,1126,1);
		$def_utk_special=substr($_,1131,1);
		$def_utk_default=substr($_,1136,1);
		$def_utk_unknusr=substr($_,1141,1);
		$def_utk_error=substr($_,1146,1);
		$def_utk_trusted=substr($_,1151,1);
		$def_utk_sesstype=substr($_,1156,8);
		$def_utk_surrogat=substr($_,1165,1);
		$def_utk_remote=substr($_,1170,1);
		$def_utk_priv=substr($_,1175,1);
		$def_utk_secl=substr($_,1180,8);
		$def_utk_execnode=substr($_,1189,8);
		$def_utk_suser_id=substr($_,1198,8);
		$def_utk_snode=substr($_,1207,8);
		$def_utk_sgrp_id=substr($_,1216,8);
		$def_utk_spoe=substr($_,1225,8);
		$def_utk_spclass=substr($_,1234,8);
		$def_utk_user_id=substr($_,1243,8);
		$def_utk_grp_id=substr($_,1252,8);
		$def_utk_dft_grp=substr($_,1261,1);
		$def_utk_dft_secl=substr($_,1266,1);
		$def_appc_link=substr($_,1271,16);
		$def_specified=substr($_,1288,1024);
		$def_utk_netw=substr($_,2313,8);
		$def_x500_subject=substr($_,2322,255);
		$def_x500_issuer=substr($_,2578,255);
		$rv=$insert{define}->execute($def_event_type,$def_event_qual,$def_time_written,$def_date_written,$def_system_smfid,$def_violation,$def_user_ndfnd,$def_user_warning,$def_evt_user_id,$def_evt_grp_id,$def_auth_normal,$def_auth_special,$def_auth_oper,$def_auth_audit,$def_auth_exit,$def_auth_failsft,$def_auth_bypass,$def_auth_trusted,$def_log_class,$def_log_user,$def_log_special,$def_log_access,$def_log_racinit,$def_log_always,$def_log_cmdviol,$def_log_global,$def_term_level,$def_backout_fail,$def_prof_same,$def_term,$def_job_name,$def_read_time,$def_read_date,$def_smf_user_id,$def_log_level,$def_log_vmevent,$def_log_logopt,$def_log_secl,$def_log_compatm,$def_log_applaud,$def_log_nonomvs,$def_log_omvsnprv,$def_auth_omvssu,$def_auth_omvssys,$def_usr_secl,$def_racf_version,$def_res_name,$def_level,$def_vol,$def_class,$def_model_name,$def_model_vol,$def_own_id,$def_logstr,$def_user_name,$def_utk_encr,$def_utk_pre19,$def_utk_verprof,$def_utk_njeunusr,$def_utk_logusr,$def_utk_special,$def_utk_default,$def_utk_unknusr,$def_utk_error,$def_utk_trusted,$def_utk_sesstype,$def_utk_surrogat,$def_utk_remote,$def_utk_priv,$def_utk_secl,$def_utk_execnode,$def_utk_suser_id,$def_utk_snode,$def_utk_sgrp_id,$def_utk_spoe,$def_utk_spclass,$def_utk_user_id,$def_utk_grp_id,$def_utk_dft_grp,$def_utk_dft_secl,$def_appc_link,$def_specified,$def_utk_netw,$def_x500_subject,$def_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"define"}++;
		next;
	}

	if ($rectype eq 'DELDSD  ') {
		$deld_event_type=substr($_,0,8);
		$deld_event_qual=substr($_,9,8);
		$deld_time_written=substr($_,18,8);
		if ($deld_time_written  eq ' ' x length($deld_time_written )) {
			undef $deld_time_written ;
		}
		$deld_date_written=substr($_,27,10);
		if ($deld_date_written  eq ' ' x length($deld_date_written )) {
			undef $deld_date_written ;
		}
		$deld_system_smfid=substr($_,38,4);
		$deld_violation=substr($_,43,1);
		$deld_user_ndfnd=substr($_,48,1);
		$deld_user_warning=substr($_,53,1);
		$deld_evt_user_id=substr($_,58,8);
		$deld_evt_grp_id=substr($_,67,8);
		$deld_auth_normal=substr($_,76,1);
		$deld_auth_special=substr($_,81,1);
		$deld_auth_oper=substr($_,86,1);
		$deld_auth_audit=substr($_,91,1);
		$deld_auth_exit=substr($_,96,1);
		$deld_auth_failsft=substr($_,101,1);
		$deld_auth_bypass=substr($_,106,1);
		$deld_auth_trusted=substr($_,111,1);
		$deld_log_class=substr($_,116,1);
		$deld_log_user=substr($_,121,1);
		$deld_log_special=substr($_,126,1);
		$deld_log_access=substr($_,131,1);
		$deld_log_racinit=substr($_,136,1);
		$deld_log_always=substr($_,141,1);
		$deld_log_cmdviol=substr($_,146,1);
		$deld_log_global=substr($_,151,1);
		$deld_term_level=substr($_,156,3);
		if ($deld_term_level  eq ' ' x length($deld_term_level )) {
			undef $deld_term_level ;
		}
		$deld_backout_fail=substr($_,160,1);
		$deld_prof_same=substr($_,165,1);
		$deld_term=substr($_,170,8);
		$deld_job_name=substr($_,179,8);
		$deld_read_time=substr($_,188,8);
		if ($deld_read_time  eq ' ' x length($deld_read_time )) {
			undef $deld_read_time ;
		}
		$deld_read_date=substr($_,197,10);
		if ($deld_read_date  eq ' ' x length($deld_read_date )) {
			undef $deld_read_date ;
		}
		$deld_smf_user_id=substr($_,208,8);
		$deld_log_level=substr($_,217,1);
		$deld_log_vmevent=substr($_,222,1);
		$deld_log_logopt=substr($_,227,1);
		$deld_log_secl=substr($_,232,1);
		$deld_log_compatm=substr($_,237,1);
		$deld_log_applaud=substr($_,242,1);
		$deld_log_nonomvs=substr($_,247,1);
		$deld_log_omvsnprv=substr($_,252,1);
		$deld_auth_omvssu=substr($_,257,1);
		$deld_auth_omvssys=substr($_,262,1);
		$deld_usr_secl=substr($_,267,8);
		$deld_racf_version=substr($_,276,4);
		$deld_own_id=substr($_,281,8);
		$deld_user_name=substr($_,290,20);
		$deld_old_secl=substr($_,311,8);
		$deld_utk_encr=substr($_,320,1);
		$deld_utk_pre19=substr($_,325,1);
		$deld_utk_verprof=substr($_,330,1);
		$deld_utk_njeunusr=substr($_,335,1);
		$deld_utk_logusr=substr($_,340,1);
		$deld_utk_special=substr($_,345,1);
		$deld_utk_default=substr($_,350,1);
		$deld_utk_unknusr=substr($_,355,1);
		$deld_utk_error=substr($_,360,1);
		$deld_utk_trusted=substr($_,365,1);
		$deld_utk_sesstype=substr($_,370,8);
		$deld_utk_surrogat=substr($_,379,1);
		$deld_utk_remote=substr($_,384,1);
		$deld_utk_priv=substr($_,389,1);
		$deld_utk_secl=substr($_,394,8);
		$deld_utk_execnode=substr($_,403,8);
		$deld_utk_suser_id=substr($_,412,8);
		$deld_utk_snode=substr($_,421,8);
		$deld_utk_sgrp_id=substr($_,430,8);
		$deld_utk_spoe=substr($_,439,8);
		$deld_utk_spclass=substr($_,448,8);
		$deld_utk_user_id=substr($_,457,8);
		$deld_utk_grp_id=substr($_,466,8);
		$deld_utk_dft_grp=substr($_,475,1);
		$deld_utk_dft_secl=substr($_,480,1);
		$deld_appc_link=substr($_,485,16);
		$deld_secl_link=substr($_,502,16);
		$deld_ds_name=substr($_,519,44);
		$deld_specified=substr($_,564,1024);
		$deld_failed=substr($_,1589,1024);
		$deld_utk_netw=substr($_,2614,8);
		$deld_x500_subject=substr($_,2623,255);
		$deld_x500_issuer=substr($_,2879,255);
		$rv=$insert{deldsd}->execute($deld_event_type,$deld_event_qual,$deld_time_written,$deld_date_written,$deld_system_smfid,$deld_violation,$deld_user_ndfnd,$deld_user_warning,$deld_evt_user_id,$deld_evt_grp_id,$deld_auth_normal,$deld_auth_special,$deld_auth_oper,$deld_auth_audit,$deld_auth_exit,$deld_auth_failsft,$deld_auth_bypass,$deld_auth_trusted,$deld_log_class,$deld_log_user,$deld_log_special,$deld_log_access,$deld_log_racinit,$deld_log_always,$deld_log_cmdviol,$deld_log_global,$deld_term_level,$deld_backout_fail,$deld_prof_same,$deld_term,$deld_job_name,$deld_read_time,$deld_read_date,$deld_smf_user_id,$deld_log_level,$deld_log_vmevent,$deld_log_logopt,$deld_log_secl,$deld_log_compatm,$deld_log_applaud,$deld_log_nonomvs,$deld_log_omvsnprv,$deld_auth_omvssu,$deld_auth_omvssys,$deld_usr_secl,$deld_racf_version,$deld_own_id,$deld_user_name,$deld_old_secl,$deld_utk_encr,$deld_utk_pre19,$deld_utk_verprof,$deld_utk_njeunusr,$deld_utk_logusr,$deld_utk_special,$deld_utk_default,$deld_utk_unknusr,$deld_utk_error,$deld_utk_trusted,$deld_utk_sesstype,$deld_utk_surrogat,$deld_utk_remote,$deld_utk_priv,$deld_utk_secl,$deld_utk_execnode,$deld_utk_suser_id,$deld_utk_snode,$deld_utk_sgrp_id,$deld_utk_spoe,$deld_utk_spclass,$deld_utk_user_id,$deld_utk_grp_id,$deld_utk_dft_grp,$deld_utk_dft_secl,$deld_appc_link,$deld_secl_link,$deld_ds_name,$deld_specified,$deld_failed,$deld_utk_netw,$deld_x500_subject,$deld_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"deldsd"}++;
		next;
	}

	if ($rectype eq 'DELFACL ') {
		$dacl_event_type=substr($_,0,8);
		$dacl_event_qual=substr($_,9,8);
		$dacl_time_written=substr($_,18,8);
		if ($dacl_time_written  eq ' ' x length($dacl_time_written )) {
			undef $dacl_time_written ;
		}
		$dacl_date_written=substr($_,27,10);
		if ($dacl_date_written  eq ' ' x length($dacl_date_written )) {
			undef $dacl_date_written ;
		}
		$dacl_system_smfid=substr($_,38,4);
		$dacl_violation=substr($_,43,1);
		$dacl_user_ndfnd=substr($_,48,1);
		$dacl_user_warning=substr($_,53,1);
		$dacl_evt_user_id=substr($_,58,8);
		$dacl_evt_grp_id=substr($_,67,8);
		$dacl_auth_normal=substr($_,76,1);
		$dacl_auth_special=substr($_,81,1);
		$dacl_auth_oper=substr($_,86,1);
		$dacl_auth_audit=substr($_,91,1);
		$dacl_auth_exit=substr($_,96,1);
		$dacl_auth_failsft=substr($_,101,1);
		$dacl_auth_bypass=substr($_,106,1);
		$dacl_auth_trusted=substr($_,111,1);
		$dacl_log_class=substr($_,116,1);
		$dacl_log_user=substr($_,121,1);
		$dacl_log_special=substr($_,126,1);
		$dacl_log_access=substr($_,131,1);
		$dacl_log_racinit=substr($_,136,1);
		$dacl_log_always=substr($_,141,1);
		$dacl_log_cmdviol=substr($_,146,1);
		$dacl_log_global=substr($_,151,1);
		$dacl_term_level=substr($_,156,3);
		if ($dacl_term_level  eq ' ' x length($dacl_term_level )) {
			undef $dacl_term_level ;
		}
		$dacl_backout_fail=substr($_,160,1);
		$dacl_prof_same=substr($_,165,1);
		$dacl_term=substr($_,170,8);
		$dacl_job_name=substr($_,179,8);
		$dacl_read_time=substr($_,188,8);
		if ($dacl_read_time  eq ' ' x length($dacl_read_time )) {
			undef $dacl_read_time ;
		}
		$dacl_read_date=substr($_,197,10);
		if ($dacl_read_date  eq ' ' x length($dacl_read_date )) {
			undef $dacl_read_date ;
		}
		$dacl_smf_user_id=substr($_,208,8);
		$dacl_log_level=substr($_,217,1);
		$dacl_log_vmevent=substr($_,222,1);
		$dacl_log_logopt=substr($_,227,1);
		$dacl_log_secl=substr($_,232,1);
		$dacl_log_compatm=substr($_,237,1);
		$dacl_log_applaud=substr($_,242,1);
		$dacl_log_nonomvs=substr($_,247,1);
		$dacl_log_omvsnprv=substr($_,252,1);
		$dacl_auth_omvssu=substr($_,257,1);
		$dacl_auth_omvssys=substr($_,262,1);
		$dacl_usr_secl=substr($_,267,8);
		$dacl_racf_version=substr($_,276,4);
		$dacl_class=substr($_,281,8);
		$dacl_user_name=substr($_,290,20);
		$dacl_utk_encr=substr($_,311,1);
		$dacl_utk_pre19=substr($_,316,1);
		$dacl_utk_verprof=substr($_,321,1);
		$dacl_utk_njeunusr=substr($_,326,1);
		$dacl_utk_logusr=substr($_,331,1);
		$dacl_utk_special=substr($_,336,1);
		$dacl_utk_default=substr($_,341,1);
		$dacl_utk_unknusr=substr($_,346,1);
		$dacl_utk_error=substr($_,351,1);
		$dacl_utk_trusted=substr($_,356,1);
		$dacl_utk_sesstype=substr($_,361,8);
		$dacl_utk_surrogat=substr($_,370,1);
		$dacl_utk_remote=substr($_,375,1);
		$dacl_utk_priv=substr($_,380,1);
		$dacl_utk_secl=substr($_,385,8);
		$dacl_utk_execnode=substr($_,394,8);
		$dacl_utk_suser_id=substr($_,403,8);
		$dacl_utk_snode=substr($_,412,8);
		$dacl_utk_sgrp_id=substr($_,421,8);
		$dacl_utk_spoe=substr($_,430,8);
		$dacl_utk_spclass=substr($_,439,8);
		$dacl_utk_user_id=substr($_,448,8);
		$dacl_utk_grp_id=substr($_,457,8);
		$dacl_utk_dft_grp=substr($_,466,1);
		$dacl_utk_dft_secl=substr($_,471,1);
		$dacl_appc_link=substr($_,476,16);
		$dacl_audit_code=substr($_,493,11);
		$dacl_old_real_uid=substr($_,505,10);
		if ($dacl_old_real_uid  eq ' ' x length($dacl_old_real_uid )) {
			undef $dacl_old_real_uid ;
		}
		$dacl_old_eff_uid=substr($_,516,10);
		if ($dacl_old_eff_uid  eq ' ' x length($dacl_old_eff_uid )) {
			undef $dacl_old_eff_uid ;
		}
		$dacl_old_saved_uid=substr($_,527,10);
		if ($dacl_old_saved_uid eq ' ' x length($dacl_old_saved_uid)) {
			undef $dacl_old_saved_uid;
		}
		$dacl_old_real_gid=substr($_,538,10);
		if ($dacl_old_real_gid  eq ' ' x length($dacl_old_real_gid )) {
			undef $dacl_old_real_gid ;
		}
		$dacl_old_eff_gid=substr($_,549,10);
		if ($dacl_old_eff_gid  eq ' ' x length($dacl_old_eff_gid )) {
			undef $dacl_old_eff_gid ;
		}
		$dacl_old_saved_gid=substr($_,560,10);
		if ($dacl_old_saved_gid eq ' ' x length($dacl_old_saved_gid)) {
			undef $dacl_old_saved_gid;
		}
		$dacl_path_name=substr($_,571,1023);
		$dacl_file_id=substr($_,1595,32);
		$dacl_file_own_uid=substr($_,1628,10);
		if ($dacl_file_own_uid  eq ' ' x length($dacl_file_own_uid )) {
			undef $dacl_file_own_uid ;
		}
		$dacl_file_own_gid=substr($_,1639,10);
		if ($dacl_file_own_gid  eq ' ' x length($dacl_file_own_gid )) {
			undef $dacl_file_own_gid ;
		}
		$dacl_filepool=substr($_,1650,8);
		$dacl_filespace=substr($_,1659,8);
		$dacl_inode=substr($_,1668,10);
		if ($dacl_inode  eq ' ' x length($dacl_inode )) {
			undef $dacl_inode ;
		}
		$dacl_scid=substr($_,1679,10);
		if ($dacl_scid  eq ' ' x length($dacl_scid )) {
			undef $dacl_scid ;
		}
		$dacl_dce_link=substr($_,1690,16);
		$dacl_auth_type=substr($_,1707,13);
		$dacl_dflt_process=substr($_,1721,1);
		$dacl_utk_netw=substr($_,1726,8);
		$dacl_x500_subject=substr($_,1735,255);
		$dacl_x500_issuer=substr($_,1991,255);
		$dacl_acl_type=substr($_,2247,8);
		$rv=$insert{delfacl}->execute($dacl_event_type,$dacl_event_qual,$dacl_time_written,$dacl_date_written,$dacl_system_smfid,$dacl_violation,$dacl_user_ndfnd,$dacl_user_warning,$dacl_evt_user_id,$dacl_evt_grp_id,$dacl_auth_normal,$dacl_auth_special,$dacl_auth_oper,$dacl_auth_audit,$dacl_auth_exit,$dacl_auth_failsft,$dacl_auth_bypass,$dacl_auth_trusted,$dacl_log_class,$dacl_log_user,$dacl_log_special,$dacl_log_access,$dacl_log_racinit,$dacl_log_always,$dacl_log_cmdviol,$dacl_log_global,$dacl_term_level,$dacl_backout_fail,$dacl_prof_same,$dacl_term,$dacl_job_name,$dacl_read_time,$dacl_read_date,$dacl_smf_user_id,$dacl_log_level,$dacl_log_vmevent,$dacl_log_logopt,$dacl_log_secl,$dacl_log_compatm,$dacl_log_applaud,$dacl_log_nonomvs,$dacl_log_omvsnprv,$dacl_auth_omvssu,$dacl_auth_omvssys,$dacl_usr_secl,$dacl_racf_version,$dacl_class,$dacl_user_name,$dacl_utk_encr,$dacl_utk_pre19,$dacl_utk_verprof,$dacl_utk_njeunusr,$dacl_utk_logusr,$dacl_utk_special,$dacl_utk_default,$dacl_utk_unknusr,$dacl_utk_error,$dacl_utk_trusted,$dacl_utk_sesstype,$dacl_utk_surrogat,$dacl_utk_remote,$dacl_utk_priv,$dacl_utk_secl,$dacl_utk_execnode,$dacl_utk_suser_id,$dacl_utk_snode,$dacl_utk_sgrp_id,$dacl_utk_spoe,$dacl_utk_spclass,$dacl_utk_user_id,$dacl_utk_grp_id,$dacl_utk_dft_grp,$dacl_utk_dft_secl,$dacl_appc_link,$dacl_audit_code,$dacl_old_real_uid,$dacl_old_eff_uid,$dacl_old_saved_uid,$dacl_old_real_gid,$dacl_old_eff_gid,$dacl_old_saved_gid,$dacl_path_name,$dacl_file_id,$dacl_file_own_uid,$dacl_file_own_gid,$dacl_filepool,$dacl_filespace,$dacl_inode,$dacl_scid,$dacl_dce_link,$dacl_auth_type,$dacl_dflt_process,$dacl_utk_netw,$dacl_x500_subject,$dacl_x500_issuer,$dacl_acl_type);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"delfacl"}++;
		next;
	}

	if ($rectype eq 'DELGROUP') {
		$delg_event_type=substr($_,0,8);
		$delg_event_qual=substr($_,9,8);
		$delg_time_written=substr($_,18,8);
		if ($delg_time_written  eq ' ' x length($delg_time_written )) {
			undef $delg_time_written ;
		}
		$delg_date_written=substr($_,27,10);
		if ($delg_date_written  eq ' ' x length($delg_date_written )) {
			undef $delg_date_written ;
		}
		$delg_system_smfid=substr($_,38,4);
		$delg_violation=substr($_,43,1);
		$delg_user_ndfnd=substr($_,48,1);
		$delg_user_warning=substr($_,53,1);
		$delg_evt_user_id=substr($_,58,8);
		$delg_evt_grp_id=substr($_,67,8);
		$delg_auth_normal=substr($_,76,1);
		$delg_auth_special=substr($_,81,1);
		$delg_auth_oper=substr($_,86,1);
		$delg_auth_audit=substr($_,91,1);
		$delg_auth_exit=substr($_,96,1);
		$delg_auth_failsft=substr($_,101,1);
		$delg_auth_bypass=substr($_,106,1);
		$delg_auth_trusted=substr($_,111,1);
		$delg_log_class=substr($_,116,1);
		$delg_log_user=substr($_,121,1);
		$delg_log_special=substr($_,126,1);
		$delg_log_access=substr($_,131,1);
		$delg_log_racinit=substr($_,136,1);
		$delg_log_always=substr($_,141,1);
		$delg_log_cmdviol=substr($_,146,1);
		$delg_log_global=substr($_,151,1);
		$delg_term_level=substr($_,156,3);
		if ($delg_term_level  eq ' ' x length($delg_term_level )) {
			undef $delg_term_level ;
		}
		$delg_backout_fail=substr($_,160,1);
		$delg_prof_same=substr($_,165,1);
		$delg_term=substr($_,170,8);
		$delg_job_name=substr($_,179,8);
		$delg_read_time=substr($_,188,8);
		if ($delg_read_time  eq ' ' x length($delg_read_time )) {
			undef $delg_read_time ;
		}
		$delg_read_date=substr($_,197,10);
		if ($delg_read_date  eq ' ' x length($delg_read_date )) {
			undef $delg_read_date ;
		}
		$delg_smf_user_id=substr($_,208,8);
		$delg_log_level=substr($_,217,1);
		$delg_log_vmevent=substr($_,222,1);
		$delg_log_logopt=substr($_,227,1);
		$delg_log_secl=substr($_,232,1);
		$delg_log_compatm=substr($_,237,1);
		$delg_log_applaud=substr($_,242,1);
		$delg_log_nonomvs=substr($_,247,1);
		$delg_log_omvsnprv=substr($_,252,1);
		$delg_auth_omvssu=substr($_,257,1);
		$delg_auth_omvssys=substr($_,262,1);
		$delg_usr_secl=substr($_,267,8);
		$delg_racf_version=substr($_,276,4);
		$delg_own_id=substr($_,281,8);
		$delg_user_name=substr($_,290,20);
		$delg_utk_encr=substr($_,311,1);
		$delg_utk_pre19=substr($_,316,1);
		$delg_utk_verprof=substr($_,321,1);
		$delg_utk_njeunusr=substr($_,326,1);
		$delg_utk_logusr=substr($_,331,1);
		$delg_utk_special=substr($_,336,1);
		$delg_utk_default=substr($_,341,1);
		$delg_utk_unknusr=substr($_,346,1);
		$delg_utk_error=substr($_,351,1);
		$delg_utk_trusted=substr($_,356,1);
		$delg_utk_sesstype=substr($_,361,8);
		$delg_utk_surrogat=substr($_,370,1);
		$delg_utk_remote=substr($_,375,1);
		$delg_utk_priv=substr($_,380,1);
		$delg_utk_secl=substr($_,385,8);
		$delg_utk_execnode=substr($_,394,8);
		$delg_utk_suser_id=substr($_,403,8);
		$delg_utk_snode=substr($_,412,8);
		$delg_utk_sgrp_id=substr($_,421,8);
		$delg_utk_spoe=substr($_,430,8);
		$delg_utk_spclass=substr($_,439,8);
		$delg_utk_user_id=substr($_,448,8);
		$delg_utk_grp_id=substr($_,457,8);
		$delg_utk_dft_grp=substr($_,466,1);
		$delg_utk_dft_secl=substr($_,471,1);
		$delg_appc_link=substr($_,476,16);
		$delg_grp_id=substr($_,493,8);
		$delg_specified=substr($_,502,1024);
		$delg_utk_netw=substr($_,1527,8);
		$delg_x500_subject=substr($_,1536,255);
		$delg_x500_issuer=substr($_,1792,255);
		$rv=$insert{delgroup}->execute($delg_event_type,$delg_event_qual,$delg_time_written,$delg_date_written,$delg_system_smfid,$delg_violation,$delg_user_ndfnd,$delg_user_warning,$delg_evt_user_id,$delg_evt_grp_id,$delg_auth_normal,$delg_auth_special,$delg_auth_oper,$delg_auth_audit,$delg_auth_exit,$delg_auth_failsft,$delg_auth_bypass,$delg_auth_trusted,$delg_log_class,$delg_log_user,$delg_log_special,$delg_log_access,$delg_log_racinit,$delg_log_always,$delg_log_cmdviol,$delg_log_global,$delg_term_level,$delg_backout_fail,$delg_prof_same,$delg_term,$delg_job_name,$delg_read_time,$delg_read_date,$delg_smf_user_id,$delg_log_level,$delg_log_vmevent,$delg_log_logopt,$delg_log_secl,$delg_log_compatm,$delg_log_applaud,$delg_log_nonomvs,$delg_log_omvsnprv,$delg_auth_omvssu,$delg_auth_omvssys,$delg_usr_secl,$delg_racf_version,$delg_own_id,$delg_user_name,$delg_utk_encr,$delg_utk_pre19,$delg_utk_verprof,$delg_utk_njeunusr,$delg_utk_logusr,$delg_utk_special,$delg_utk_default,$delg_utk_unknusr,$delg_utk_error,$delg_utk_trusted,$delg_utk_sesstype,$delg_utk_surrogat,$delg_utk_remote,$delg_utk_priv,$delg_utk_secl,$delg_utk_execnode,$delg_utk_suser_id,$delg_utk_snode,$delg_utk_sgrp_id,$delg_utk_spoe,$delg_utk_spclass,$delg_utk_user_id,$delg_utk_grp_id,$delg_utk_dft_grp,$delg_utk_dft_secl,$delg_appc_link,$delg_grp_id,$delg_specified,$delg_utk_netw,$delg_x500_subject,$delg_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"delgroup"}++;
		next;
	}

	if ($rectype eq 'DELRES  ') {
		$delr_event_type=substr($_,0,8);
		$delr_event_qual=substr($_,9,8);
		$delr_time_written=substr($_,18,8);
		if ($delr_time_written  eq ' ' x length($delr_time_written )) {
			undef $delr_time_written ;
		}
		$delr_date_written=substr($_,27,10);
		if ($delr_date_written  eq ' ' x length($delr_date_written )) {
			undef $delr_date_written ;
		}
		$delr_system_smfid=substr($_,38,4);
		$delr_violation=substr($_,43,1);
		$delr_user_ndfnd=substr($_,48,1);
		$delr_user_warning=substr($_,53,1);
		$delr_evt_user_id=substr($_,58,8);
		$delr_evt_grp_id=substr($_,67,8);
		$delr_auth_normal=substr($_,76,1);
		$delr_auth_special=substr($_,81,1);
		$delr_auth_oper=substr($_,86,1);
		$delr_auth_audit=substr($_,91,1);
		$delr_auth_exit=substr($_,96,1);
		$delr_auth_failsft=substr($_,101,1);
		$delr_auth_bypass=substr($_,106,1);
		$delr_auth_trusted=substr($_,111,1);
		$delr_log_class=substr($_,116,1);
		$delr_log_user=substr($_,121,1);
		$delr_log_special=substr($_,126,1);
		$delr_log_access=substr($_,131,1);
		$delr_log_racinit=substr($_,136,1);
		$delr_log_always=substr($_,141,1);
		$delr_log_cmdviol=substr($_,146,1);
		$delr_log_global=substr($_,151,1);
		$delr_term_level=substr($_,156,3);
		if ($delr_term_level  eq ' ' x length($delr_term_level )) {
			undef $delr_term_level ;
		}
		$delr_backout_fail=substr($_,160,1);
		$delr_prof_same=substr($_,165,1);
		$delr_term=substr($_,170,8);
		$delr_job_name=substr($_,179,8);
		$delr_read_time=substr($_,188,8);
		if ($delr_read_time  eq ' ' x length($delr_read_time )) {
			undef $delr_read_time ;
		}
		$delr_read_date=substr($_,197,10);
		if ($delr_read_date  eq ' ' x length($delr_read_date )) {
			undef $delr_read_date ;
		}
		$delr_smf_user_id=substr($_,208,8);
		$delr_log_level=substr($_,217,1);
		$delr_log_vmevent=substr($_,222,1);
		$delr_log_logopt=substr($_,227,1);
		$delr_log_secl=substr($_,232,1);
		$delr_log_compatm=substr($_,237,1);
		$delr_log_applaud=substr($_,242,1);
		$delr_log_nonomvs=substr($_,247,1);
		$delr_log_omvsnprv=substr($_,252,1);
		$delr_auth_omvssu=substr($_,257,1);
		$delr_auth_omvssys=substr($_,262,1);
		$delr_usr_secl=substr($_,267,8);
		$delr_racf_version=substr($_,276,4);
		$delr_res_name=substr($_,281,255);
		$delr_level=substr($_,537,3);
		if ($delr_level  eq ' ' x length($delr_level )) {
			undef $delr_level ;
		}
		$delr_vol=substr($_,541,6);
		$delr_class=substr($_,548,8);
		$delr_own_id=substr($_,557,8);
		$delr_logstr=substr($_,566,255);
		$delr_user_name=substr($_,822,20);
		$delr_utk_encr=substr($_,843,1);
		$delr_utk_pre19=substr($_,848,1);
		$delr_utk_verprof=substr($_,853,1);
		$delr_utk_njeunusr=substr($_,858,1);
		$delr_utk_logusr=substr($_,863,1);
		$delr_utk_special=substr($_,868,1);
		$delr_utk_default=substr($_,873,1);
		$delr_utk_unknusr=substr($_,878,1);
		$delr_utk_error=substr($_,883,1);
		$delr_utk_trusted=substr($_,888,1);
		$delr_utk_sesstype=substr($_,893,8);
		$delr_utk_surrogat=substr($_,902,1);
		$delr_utk_remote=substr($_,907,1);
		$delr_utk_priv=substr($_,912,1);
		$delr_utk_secl=substr($_,917,8);
		$delr_utk_execnode=substr($_,926,8);
		$delr_utk_suser_id=substr($_,935,8);
		$delr_utk_snode=substr($_,944,8);
		$delr_utk_sgrp_id=substr($_,953,8);
		$delr_utk_spoe=substr($_,962,8);
		$delr_utk_spclass=substr($_,971,8);
		$delr_utk_user_id=substr($_,980,8);
		$delr_utk_grp_id=substr($_,989,8);
		$delr_utk_dft_grp=substr($_,998,1);
		$delr_utk_dft_secl=substr($_,1003,1);
		$delr_appc_link=substr($_,1008,16);
		$delr_specified=substr($_,1025,1024);
		$delr_utk_netw=substr($_,2050,8);
		$delr_x500_subject=substr($_,2059,255);
		$delr_x500_issuer=substr($_,2315,255);
		$rv=$insert{delres}->execute($delr_event_type,$delr_event_qual,$delr_time_written,$delr_date_written,$delr_system_smfid,$delr_violation,$delr_user_ndfnd,$delr_user_warning,$delr_evt_user_id,$delr_evt_grp_id,$delr_auth_normal,$delr_auth_special,$delr_auth_oper,$delr_auth_audit,$delr_auth_exit,$delr_auth_failsft,$delr_auth_bypass,$delr_auth_trusted,$delr_log_class,$delr_log_user,$delr_log_special,$delr_log_access,$delr_log_racinit,$delr_log_always,$delr_log_cmdviol,$delr_log_global,$delr_term_level,$delr_backout_fail,$delr_prof_same,$delr_term,$delr_job_name,$delr_read_time,$delr_read_date,$delr_smf_user_id,$delr_log_level,$delr_log_vmevent,$delr_log_logopt,$delr_log_secl,$delr_log_compatm,$delr_log_applaud,$delr_log_nonomvs,$delr_log_omvsnprv,$delr_auth_omvssu,$delr_auth_omvssys,$delr_usr_secl,$delr_racf_version,$delr_res_name,$delr_level,$delr_vol,$delr_class,$delr_own_id,$delr_logstr,$delr_user_name,$delr_utk_encr,$delr_utk_pre19,$delr_utk_verprof,$delr_utk_njeunusr,$delr_utk_logusr,$delr_utk_special,$delr_utk_default,$delr_utk_unknusr,$delr_utk_error,$delr_utk_trusted,$delr_utk_sesstype,$delr_utk_surrogat,$delr_utk_remote,$delr_utk_priv,$delr_utk_secl,$delr_utk_execnode,$delr_utk_suser_id,$delr_utk_snode,$delr_utk_sgrp_id,$delr_utk_spoe,$delr_utk_spclass,$delr_utk_user_id,$delr_utk_grp_id,$delr_utk_dft_grp,$delr_utk_dft_secl,$delr_appc_link,$delr_specified,$delr_utk_netw,$delr_x500_subject,$delr_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"delres"}++;
		next;
	}

	if ($rectype eq 'DELUSER ') {
		$delu_event_type=substr($_,0,8);
		$delu_event_qual=substr($_,9,8);
		$delu_time_written=substr($_,18,8);
		if ($delu_time_written  eq ' ' x length($delu_time_written )) {
			undef $delu_time_written ;
		}
		$delu_date_written=substr($_,27,10);
		if ($delu_date_written  eq ' ' x length($delu_date_written )) {
			undef $delu_date_written ;
		}
		$delu_system_smfid=substr($_,38,4);
		$delu_violation=substr($_,43,1);
		$delu_user_ndfnd=substr($_,48,1);
		$delu_user_warning=substr($_,53,1);
		$delu_evt_user_id=substr($_,58,8);
		$delu_evt_grp_id=substr($_,67,8);
		$delu_auth_normal=substr($_,76,1);
		$delu_auth_special=substr($_,81,1);
		$delu_auth_oper=substr($_,86,1);
		$delu_auth_audit=substr($_,91,1);
		$delu_auth_exit=substr($_,96,1);
		$delu_auth_failsft=substr($_,101,1);
		$delu_auth_bypass=substr($_,106,1);
		$delu_auth_trusted=substr($_,111,1);
		$delu_log_class=substr($_,116,1);
		$delu_log_user=substr($_,121,1);
		$delu_log_special=substr($_,126,1);
		$delu_log_access=substr($_,131,1);
		$delu_log_racinit=substr($_,136,1);
		$delu_log_always=substr($_,141,1);
		$delu_log_cmdviol=substr($_,146,1);
		$delu_log_global=substr($_,151,1);
		$delu_term_level=substr($_,156,3);
		if ($delu_term_level  eq ' ' x length($delu_term_level )) {
			undef $delu_term_level ;
		}
		$delu_backout_fail=substr($_,160,1);
		$delu_prof_same=substr($_,165,1);
		$delu_term=substr($_,170,8);
		$delu_job_name=substr($_,179,8);
		$delu_read_time=substr($_,188,8);
		if ($delu_read_time  eq ' ' x length($delu_read_time )) {
			undef $delu_read_time ;
		}
		$delu_read_date=substr($_,197,10);
		if ($delu_read_date  eq ' ' x length($delu_read_date )) {
			undef $delu_read_date ;
		}
		$delu_smf_user_id=substr($_,208,8);
		$delu_log_level=substr($_,217,1);
		$delu_log_vmevent=substr($_,222,1);
		$delu_log_logopt=substr($_,227,1);
		$delu_log_secl=substr($_,232,1);
		$delu_log_compatm=substr($_,237,1);
		$delu_log_applaud=substr($_,242,1);
		$delu_log_nonomvs=substr($_,247,1);
		$delu_log_omvsnprv=substr($_,252,1);
		$delu_auth_omvssu=substr($_,257,1);
		$delu_auth_omvssys=substr($_,262,1);
		$delu_usr_secl=substr($_,267,8);
		$delu_racf_version=substr($_,276,4);
		$delu_own_id=substr($_,281,8);
		$delu_user_name=substr($_,290,20);
		$delu_utk_encr=substr($_,311,1);
		$delu_utk_pre19=substr($_,316,1);
		$delu_utk_verprof=substr($_,321,1);
		$delu_utk_njeunusr=substr($_,326,1);
		$delu_utk_logusr=substr($_,331,1);
		$delu_utk_special=substr($_,336,1);
		$delu_utk_default=substr($_,341,1);
		$delu_utk_unknusr=substr($_,346,1);
		$delu_utk_error=substr($_,351,1);
		$delu_utk_trusted=substr($_,356,1);
		$delu_utk_sesstype=substr($_,361,8);
		$delu_utk_surrogat=substr($_,370,1);
		$delu_utk_remote=substr($_,375,1);
		$delu_utk_priv=substr($_,380,1);
		$delu_utk_secl=substr($_,385,8);
		$delu_utk_execnode=substr($_,394,8);
		$delu_utk_suser_id=substr($_,403,8);
		$delu_utk_snode=substr($_,412,8);
		$delu_utk_sgrp_id=substr($_,421,8);
		$delu_utk_spoe=substr($_,430,8);
		$delu_utk_spclass=substr($_,439,8);
		$delu_utk_user_id=substr($_,448,8);
		$delu_utk_grp_id=substr($_,457,8);
		$delu_utk_dft_grp=substr($_,466,1);
		$delu_utk_dft_secl=substr($_,471,1);
		$delu_appc_link=substr($_,476,16);
		$delu_user_id=substr($_,493,8);
		$delu_specified=substr($_,502,1024);
		$delu_utk_netw=substr($_,1527,8);
		$delu_x500_subject=substr($_,1536,255);
		$delu_x500_issuer=substr($_,1792,255);
		$rv=$insert{deluser}->execute($delu_event_type,$delu_event_qual,$delu_time_written,$delu_date_written,$delu_system_smfid,$delu_violation,$delu_user_ndfnd,$delu_user_warning,$delu_evt_user_id,$delu_evt_grp_id,$delu_auth_normal,$delu_auth_special,$delu_auth_oper,$delu_auth_audit,$delu_auth_exit,$delu_auth_failsft,$delu_auth_bypass,$delu_auth_trusted,$delu_log_class,$delu_log_user,$delu_log_special,$delu_log_access,$delu_log_racinit,$delu_log_always,$delu_log_cmdviol,$delu_log_global,$delu_term_level,$delu_backout_fail,$delu_prof_same,$delu_term,$delu_job_name,$delu_read_time,$delu_read_date,$delu_smf_user_id,$delu_log_level,$delu_log_vmevent,$delu_log_logopt,$delu_log_secl,$delu_log_compatm,$delu_log_applaud,$delu_log_nonomvs,$delu_log_omvsnprv,$delu_auth_omvssu,$delu_auth_omvssys,$delu_usr_secl,$delu_racf_version,$delu_own_id,$delu_user_name,$delu_utk_encr,$delu_utk_pre19,$delu_utk_verprof,$delu_utk_njeunusr,$delu_utk_logusr,$delu_utk_special,$delu_utk_default,$delu_utk_unknusr,$delu_utk_error,$delu_utk_trusted,$delu_utk_sesstype,$delu_utk_surrogat,$delu_utk_remote,$delu_utk_priv,$delu_utk_secl,$delu_utk_execnode,$delu_utk_suser_id,$delu_utk_snode,$delu_utk_sgrp_id,$delu_utk_spoe,$delu_utk_spclass,$delu_utk_user_id,$delu_utk_grp_id,$delu_utk_dft_grp,$delu_utk_dft_secl,$delu_appc_link,$delu_user_id,$delu_specified,$delu_utk_netw,$delu_x500_subject,$delu_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"deluser"}++;
		next;
	}

	if ($rectype eq 'DELVOL  ') {
		$delv_event_type=substr($_,0,8);
		$delv_event_qual=substr($_,9,8);
		$delv_time_written=substr($_,18,8);
		if ($delv_time_written  eq ' ' x length($delv_time_written )) {
			undef $delv_time_written ;
		}
		$delv_date_written=substr($_,27,10);
		if ($delv_date_written  eq ' ' x length($delv_date_written )) {
			undef $delv_date_written ;
		}
		$delv_system_smfid=substr($_,38,4);
		$delv_violation=substr($_,43,1);
		$delv_user_ndfnd=substr($_,48,1);
		$delv_user_warning=substr($_,53,1);
		$delv_evt_user_id=substr($_,58,8);
		$delv_evt_grp_id=substr($_,67,8);
		$delv_auth_normal=substr($_,76,1);
		$delv_auth_special=substr($_,81,1);
		$delv_auth_oper=substr($_,86,1);
		$delv_auth_audit=substr($_,91,1);
		$delv_auth_exit=substr($_,96,1);
		$delv_auth_failsft=substr($_,101,1);
		$delv_auth_bypass=substr($_,106,1);
		$delv_auth_trusted=substr($_,111,1);
		$delv_log_class=substr($_,116,1);
		$delv_log_user=substr($_,121,1);
		$delv_log_special=substr($_,126,1);
		$delv_log_access=substr($_,131,1);
		$delv_log_racinit=substr($_,136,1);
		$delv_log_always=substr($_,141,1);
		$delv_log_cmdviol=substr($_,146,1);
		$delv_log_global=substr($_,151,1);
		$delv_term_level=substr($_,156,3);
		if ($delv_term_level  eq ' ' x length($delv_term_level )) {
			undef $delv_term_level ;
		}
		$delv_backout_fail=substr($_,160,1);
		$delv_prof_same=substr($_,165,1);
		$delv_term=substr($_,170,8);
		$delv_job_name=substr($_,179,8);
		$delv_read_time=substr($_,188,8);
		if ($delv_read_time  eq ' ' x length($delv_read_time )) {
			undef $delv_read_time ;
		}
		$delv_read_date=substr($_,197,10);
		if ($delv_read_date  eq ' ' x length($delv_read_date )) {
			undef $delv_read_date ;
		}
		$delv_smf_user_id=substr($_,208,8);
		$delv_log_level=substr($_,217,1);
		$delv_log_vmevent=substr($_,222,1);
		$delv_log_logopt=substr($_,227,1);
		$delv_log_secl=substr($_,232,1);
		$delv_log_compatm=substr($_,237,1);
		$delv_log_applaud=substr($_,242,1);
		$delv_log_nonomvs=substr($_,247,1);
		$delv_log_omvsnprv=substr($_,252,1);
		$delv_auth_omvssu=substr($_,257,1);
		$delv_auth_omvssys=substr($_,262,1);
		$delv_usr_secl=substr($_,267,8);
		$delv_racf_version=substr($_,276,4);
		$delv_res_name=substr($_,281,255);
		$delv_level=substr($_,537,3);
		if ($delv_level  eq ' ' x length($delv_level )) {
			undef $delv_level ;
		}
		$delv_vol=substr($_,541,6);
		$delv_class=substr($_,548,8);
		$delv_own_id=substr($_,557,8);
		$delv_logstr=substr($_,566,255);
		$delv_user_name=substr($_,822,20);
		$delv_utk_encr=substr($_,843,1);
		$delv_utk_pre19=substr($_,848,1);
		$delv_utk_verprof=substr($_,853,1);
		$delv_utk_njeunusr=substr($_,858,1);
		$delv_utk_logusr=substr($_,863,1);
		$delv_utk_special=substr($_,868,1);
		$delv_utk_default=substr($_,873,1);
		$delv_utk_unknusr=substr($_,878,1);
		$delv_utk_error=substr($_,883,1);
		$delv_utk_trusted=substr($_,888,1);
		$delv_utk_sesstype=substr($_,893,8);
		$delv_utk_surrogat=substr($_,902,1);
		$delv_utk_remote=substr($_,907,1);
		$delv_utk_priv=substr($_,912,1);
		$delv_utk_secl=substr($_,917,8);
		$delv_utk_execnode=substr($_,926,8);
		$delv_utk_suser_id=substr($_,935,8);
		$delv_utk_snode=substr($_,944,8);
		$delv_utk_sgrp_id=substr($_,953,8);
		$delv_utk_spoe=substr($_,962,8);
		$delv_utk_spclass=substr($_,971,8);
		$delv_utk_user_id=substr($_,980,8);
		$delv_utk_grp_id=substr($_,989,8);
		$delv_utk_dft_grp=substr($_,998,1);
		$delv_utk_dft_secl=substr($_,1003,1);
		$delv_appc_link=substr($_,1008,16);
		$delv_specified=substr($_,1025,1024);
		$delv_utk_netw=substr($_,2050,8);
		$delv_x500_subject=substr($_,2059,255);
		$delv_x500_issuer=substr($_,2315,255);
		$rv=$insert{delvol}->execute($delv_event_type,$delv_event_qual,$delv_time_written,$delv_date_written,$delv_system_smfid,$delv_violation,$delv_user_ndfnd,$delv_user_warning,$delv_evt_user_id,$delv_evt_grp_id,$delv_auth_normal,$delv_auth_special,$delv_auth_oper,$delv_auth_audit,$delv_auth_exit,$delv_auth_failsft,$delv_auth_bypass,$delv_auth_trusted,$delv_log_class,$delv_log_user,$delv_log_special,$delv_log_access,$delv_log_racinit,$delv_log_always,$delv_log_cmdviol,$delv_log_global,$delv_term_level,$delv_backout_fail,$delv_prof_same,$delv_term,$delv_job_name,$delv_read_time,$delv_read_date,$delv_smf_user_id,$delv_log_level,$delv_log_vmevent,$delv_log_logopt,$delv_log_secl,$delv_log_compatm,$delv_log_applaud,$delv_log_nonomvs,$delv_log_omvsnprv,$delv_auth_omvssu,$delv_auth_omvssys,$delv_usr_secl,$delv_racf_version,$delv_res_name,$delv_level,$delv_vol,$delv_class,$delv_own_id,$delv_logstr,$delv_user_name,$delv_utk_encr,$delv_utk_pre19,$delv_utk_verprof,$delv_utk_njeunusr,$delv_utk_logusr,$delv_utk_special,$delv_utk_default,$delv_utk_unknusr,$delv_utk_error,$delv_utk_trusted,$delv_utk_sesstype,$delv_utk_surrogat,$delv_utk_remote,$delv_utk_priv,$delv_utk_secl,$delv_utk_execnode,$delv_utk_suser_id,$delv_utk_snode,$delv_utk_sgrp_id,$delv_utk_spoe,$delv_utk_spclass,$delv_utk_user_id,$delv_utk_grp_id,$delv_utk_dft_grp,$delv_utk_dft_secl,$delv_appc_link,$delv_specified,$delv_utk_netw,$delv_x500_subject,$delv_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"delvol"}++;
		next;
	}

	if ($rectype eq 'DIRSRCH ') {
		$dsch_event_type=substr($_,0,8);
		$dsch_event_qual=substr($_,9,8);
		$dsch_time_written=substr($_,18,8);
		if ($dsch_time_written  eq ' ' x length($dsch_time_written )) {
			undef $dsch_time_written ;
		}
		$dsch_date_written=substr($_,27,10);
		if ($dsch_date_written  eq ' ' x length($dsch_date_written )) {
			undef $dsch_date_written ;
		}
		$dsch_system_smfid=substr($_,38,4);
		$dsch_violation=substr($_,43,1);
		$dsch_user_ndfnd=substr($_,48,1);
		$dsch_user_warning=substr($_,53,1);
		$dsch_evt_user_id=substr($_,58,8);
		$dsch_evt_grp_id=substr($_,67,8);
		$dsch_auth_normal=substr($_,76,1);
		$dsch_auth_special=substr($_,81,1);
		$dsch_auth_oper=substr($_,86,1);
		$dsch_auth_audit=substr($_,91,1);
		$dsch_auth_exit=substr($_,96,1);
		$dsch_auth_failsft=substr($_,101,1);
		$dsch_auth_bypass=substr($_,106,1);
		$dsch_auth_trusted=substr($_,111,1);
		$dsch_log_class=substr($_,116,1);
		$dsch_log_user=substr($_,121,1);
		$dsch_log_special=substr($_,126,1);
		$dsch_log_access=substr($_,131,1);
		$dsch_log_racinit=substr($_,136,1);
		$dsch_log_always=substr($_,141,1);
		$dsch_log_cmdviol=substr($_,146,1);
		$dsch_log_global=substr($_,151,1);
		$dsch_term_level=substr($_,156,3);
		if ($dsch_term_level  eq ' ' x length($dsch_term_level )) {
			undef $dsch_term_level ;
		}
		$dsch_backout_fail=substr($_,160,1);
		$dsch_prof_same=substr($_,165,1);
		$dsch_term=substr($_,170,8);
		$dsch_job_name=substr($_,179,8);
		$dsch_read_time=substr($_,188,8);
		if ($dsch_read_time  eq ' ' x length($dsch_read_time )) {
			undef $dsch_read_time ;
		}
		$dsch_read_date=substr($_,197,10);
		if ($dsch_read_date  eq ' ' x length($dsch_read_date )) {
			undef $dsch_read_date ;
		}
		$dsch_smf_user_id=substr($_,208,8);
		$dsch_log_level=substr($_,217,1);
		$dsch_log_vmevent=substr($_,222,1);
		$dsch_log_logopt=substr($_,227,1);
		$dsch_log_secl=substr($_,232,1);
		$dsch_log_compatm=substr($_,237,1);
		$dsch_log_applaud=substr($_,242,1);
		$dsch_log_nonomvs=substr($_,247,1);
		$dsch_log_omvsnprv=substr($_,252,1);
		$dsch_auth_omvssu=substr($_,257,1);
		$dsch_auth_omvssys=substr($_,262,1);
		$dsch_usr_secl=substr($_,267,8);
		$dsch_racf_version=substr($_,276,4);
		$dsch_class=substr($_,281,8);
		$dsch_user_name=substr($_,290,20);
		$dsch_utk_encr=substr($_,311,1);
		$dsch_utk_pre19=substr($_,316,1);
		$dsch_utk_verprof=substr($_,321,1);
		$dsch_utk_njeunusr=substr($_,326,1);
		$dsch_utk_logusr=substr($_,331,1);
		$dsch_utk_special=substr($_,336,1);
		$dsch_utk_default=substr($_,341,1);
		$dsch_utk_unknusr=substr($_,346,1);
		$dsch_utk_error=substr($_,351,1);
		$dsch_utk_trusted=substr($_,356,1);
		$dsch_utk_sesstype=substr($_,361,8);
		$dsch_utk_surrogat=substr($_,370,1);
		$dsch_utk_remote=substr($_,375,1);
		$dsch_utk_priv=substr($_,380,1);
		$dsch_utk_secl=substr($_,385,8);
		$dsch_utk_execnode=substr($_,394,8);
		$dsch_utk_suser_id=substr($_,403,8);
		$dsch_utk_snode=substr($_,412,8);
		$dsch_utk_sgrp_id=substr($_,421,8);
		$dsch_utk_spoe=substr($_,430,8);
		$dsch_utk_spclass=substr($_,439,8);
		$dsch_utk_user_id=substr($_,448,8);
		$dsch_utk_grp_id=substr($_,457,8);
		$dsch_utk_dft_grp=substr($_,466,1);
		$dsch_utk_dft_secl=substr($_,471,1);
		$dsch_appc_link=substr($_,476,16);
		$dsch_audit_code=substr($_,493,11);
		$dsch_old_real_uid=substr($_,505,10);
		if ($dsch_old_real_uid  eq ' ' x length($dsch_old_real_uid )) {
			undef $dsch_old_real_uid ;
		}
		$dsch_old_eff_uid=substr($_,516,10);
		if ($dsch_old_eff_uid  eq ' ' x length($dsch_old_eff_uid )) {
			undef $dsch_old_eff_uid ;
		}
		$dsch_old_saved_uid=substr($_,527,10);
		if ($dsch_old_saved_uid eq ' ' x length($dsch_old_saved_uid)) {
			undef $dsch_old_saved_uid;
		}
		$dsch_old_real_gid=substr($_,538,10);
		if ($dsch_old_real_gid  eq ' ' x length($dsch_old_real_gid )) {
			undef $dsch_old_real_gid ;
		}
		$dsch_old_eff_gid=substr($_,549,10);
		if ($dsch_old_eff_gid  eq ' ' x length($dsch_old_eff_gid )) {
			undef $dsch_old_eff_gid ;
		}
		$dsch_old_saved_gid=substr($_,560,10);
		if ($dsch_old_saved_gid eq ' ' x length($dsch_old_saved_gid)) {
			undef $dsch_old_saved_gid;
		}
		$dsch_path_name=substr($_,571,1023);
		$dsch_file_id=substr($_,1595,32);
		$dsch_file_own_uid=substr($_,1628,10);
		if ($dsch_file_own_uid  eq ' ' x length($dsch_file_own_uid )) {
			undef $dsch_file_own_uid ;
		}
		$dsch_file_own_gid=substr($_,1639,10);
		if ($dsch_file_own_gid  eq ' ' x length($dsch_file_own_gid )) {
			undef $dsch_file_own_gid ;
		}
		$dsch_request_read=substr($_,1650,1);
		$dsch_request_write=substr($_,1655,1);
		$dsch_request_exec=substr($_,1660,1);
		$dsch_request_dsrch=substr($_,1665,1);
		$dsch_access_type=substr($_,1670,8);
		$dsch_allowed_read=substr($_,1679,1);
		$dsch_allowed_write=substr($_,1684,1);
		$dsch_allowed_exec=substr($_,1689,1);
		$dsch_request_path2=substr($_,1694,1023);
		$dsch_service_code=substr($_,2718,11);
		$dsch_hfs_ds_name=substr($_,2730,44);
		$dsch_symlink=substr($_,2775,1023);
		$dsch_file_name=substr($_,3799,256);
		$dsch_path_type=substr($_,4056,4);
		$dsch_filepool=substr($_,4061,8);
		$dsch_filespace=substr($_,4070,8);
		$dsch_inode=substr($_,4079,10);
		if ($dsch_inode  eq ' ' x length($dsch_inode )) {
			undef $dsch_inode ;
		}
		$dsch_scid=substr($_,4090,10);
		if ($dsch_scid  eq ' ' x length($dsch_scid )) {
			undef $dsch_scid ;
		}
		$dsch_dce_link=substr($_,4101,16);
		$dsch_auth_type=substr($_,4118,13);
		$dsch_dflt_process=substr($_,4132,1);
		$dsch_utk_netw=substr($_,4137,8);
		$dsch_x500_subject=substr($_,4146,255);
		$dsch_x500_issuer=substr($_,4402,255);
		$rv=$insert{dirsrch}->execute($dsch_event_type,$dsch_event_qual,$dsch_time_written,$dsch_date_written,$dsch_system_smfid,$dsch_violation,$dsch_user_ndfnd,$dsch_user_warning,$dsch_evt_user_id,$dsch_evt_grp_id,$dsch_auth_normal,$dsch_auth_special,$dsch_auth_oper,$dsch_auth_audit,$dsch_auth_exit,$dsch_auth_failsft,$dsch_auth_bypass,$dsch_auth_trusted,$dsch_log_class,$dsch_log_user,$dsch_log_special,$dsch_log_access,$dsch_log_racinit,$dsch_log_always,$dsch_log_cmdviol,$dsch_log_global,$dsch_term_level,$dsch_backout_fail,$dsch_prof_same,$dsch_term,$dsch_job_name,$dsch_read_time,$dsch_read_date,$dsch_smf_user_id,$dsch_log_level,$dsch_log_vmevent,$dsch_log_logopt,$dsch_log_secl,$dsch_log_compatm,$dsch_log_applaud,$dsch_log_nonomvs,$dsch_log_omvsnprv,$dsch_auth_omvssu,$dsch_auth_omvssys,$dsch_usr_secl,$dsch_racf_version,$dsch_class,$dsch_user_name,$dsch_utk_encr,$dsch_utk_pre19,$dsch_utk_verprof,$dsch_utk_njeunusr,$dsch_utk_logusr,$dsch_utk_special,$dsch_utk_default,$dsch_utk_unknusr,$dsch_utk_error,$dsch_utk_trusted,$dsch_utk_sesstype,$dsch_utk_surrogat,$dsch_utk_remote,$dsch_utk_priv,$dsch_utk_secl,$dsch_utk_execnode,$dsch_utk_suser_id,$dsch_utk_snode,$dsch_utk_sgrp_id,$dsch_utk_spoe,$dsch_utk_spclass,$dsch_utk_user_id,$dsch_utk_grp_id,$dsch_utk_dft_grp,$dsch_utk_dft_secl,$dsch_appc_link,$dsch_audit_code,$dsch_old_real_uid,$dsch_old_eff_uid,$dsch_old_saved_uid,$dsch_old_real_gid,$dsch_old_eff_gid,$dsch_old_saved_gid,$dsch_path_name,$dsch_file_id,$dsch_file_own_uid,$dsch_file_own_gid,$dsch_request_read,$dsch_request_write,$dsch_request_exec,$dsch_request_dsrch,$dsch_access_type,$dsch_allowed_read,$dsch_allowed_write,$dsch_allowed_exec,$dsch_request_path2,$dsch_service_code,$dsch_hfs_ds_name,$dsch_symlink,$dsch_file_name,$dsch_path_type,$dsch_filepool,$dsch_filespace,$dsch_inode,$dsch_scid,$dsch_dce_link,$dsch_auth_type,$dsch_dflt_process,$dsch_utk_netw,$dsch_x500_subject,$dsch_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"dirsrch"}++;
		next;
	}

	if ($rectype eq 'DSAF    ') {
		$dsaf_event_type=substr($_,0,8);
		$dsaf_reserved_01=substr($_,9,8);
		$dsaf_time_written=substr($_,18,8);
		if ($dsaf_time_written  eq ' ' x length($dsaf_time_written )) {
			undef $dsaf_time_written ;
		}
		$dsaf_date_written=substr($_,27,10);
		if ($dsaf_date_written  eq ' ' x length($dsaf_date_written )) {
			undef $dsaf_date_written ;
		}
		$dsaf_system_smfid=substr($_,38,4);
		$dsaf_secl_link=substr($_,43,16);
		$dsaf_violation=substr($_,60,1);
		$dsaf_user_ndfnd=substr($_,65,1);
		$dsaf_user_warning=substr($_,70,1);
		$dsaf_evt_user_id=substr($_,75,8);
		$dsaf_evt_grp_id=substr($_,84,8);
		$dsaf_auth_normal=substr($_,93,1);
		$dsaf_auth_special=substr($_,98,1);
		$dsaf_auth_oper=substr($_,103,1);
		$dsaf_auth_audit=substr($_,108,1);
		$dsaf_auth_exit=substr($_,113,1);
		$dsaf_auth_failsft=substr($_,118,1);
		$dsaf_auth_bypass=substr($_,123,1);
		$dsaf_auth_trusted=substr($_,128,1);
		$dsaf_log_class=substr($_,133,1);
		$dsaf_log_user=substr($_,138,1);
		$dsaf_log_special=substr($_,143,1);
		$dsaf_log_access=substr($_,148,1);
		$dsaf_log_racinit=substr($_,153,1);
		$dsaf_log_always=substr($_,158,1);
		$dsaf_log_cmdviol=substr($_,163,1);
		$dsaf_log_global=substr($_,168,1);
		$dsaf_term_level=substr($_,173,3);
		if ($dsaf_term_level  eq ' ' x length($dsaf_term_level )) {
			undef $dsaf_term_level ;
		}
		$dsaf_backout_fail=substr($_,177,1);
		$dsaf_prof_same=substr($_,182,1);
		$dsaf_term=substr($_,187,8);
		$dsaf_job_name=substr($_,196,8);
		$dsaf_read_time=substr($_,205,8);
		if ($dsaf_read_time  eq ' ' x length($dsaf_read_time )) {
			undef $dsaf_read_time ;
		}
		$dsaf_read_date=substr($_,214,10);
		if ($dsaf_read_date  eq ' ' x length($dsaf_read_date )) {
			undef $dsaf_read_date ;
		}
		$dsaf_smf_user_id=substr($_,225,8);
		$dsaf_log_level=substr($_,234,1);
		$dsaf_log_logopt=substr($_,239,1);
		$dsaf_log_secl=substr($_,244,1);
		$dsaf_log_compatm=substr($_,249,1);
		$dsaf_log_applaud=substr($_,254,1);
		$dsaf_usr_secl=substr($_,259,8);
		$dsaf_data_set=substr($_,268,44);
		$rv=$insert{dsaf}->execute($dsaf_event_type,$dsaf_reserved_01,$dsaf_time_written,$dsaf_date_written,$dsaf_system_smfid,$dsaf_secl_link,$dsaf_violation,$dsaf_user_ndfnd,$dsaf_user_warning,$dsaf_evt_user_id,$dsaf_evt_grp_id,$dsaf_auth_normal,$dsaf_auth_special,$dsaf_auth_oper,$dsaf_auth_audit,$dsaf_auth_exit,$dsaf_auth_failsft,$dsaf_auth_bypass,$dsaf_auth_trusted,$dsaf_log_class,$dsaf_log_user,$dsaf_log_special,$dsaf_log_access,$dsaf_log_racinit,$dsaf_log_always,$dsaf_log_cmdviol,$dsaf_log_global,$dsaf_term_level,$dsaf_backout_fail,$dsaf_prof_same,$dsaf_term,$dsaf_job_name,$dsaf_read_time,$dsaf_read_date,$dsaf_smf_user_id,$dsaf_log_level,$dsaf_log_logopt,$dsaf_log_secl,$dsaf_log_compatm,$dsaf_log_applaud,$dsaf_usr_secl,$dsaf_data_set);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"dsaf"}++;
		next;
	}

	if ($rectype eq 'EXESETID') {
		$esid_event_type=substr($_,0,8);
		$esid_event_qual=substr($_,9,8);
		$esid_time_written=substr($_,18,8);
		if ($esid_time_written  eq ' ' x length($esid_time_written )) {
			undef $esid_time_written ;
		}
		$esid_date_written=substr($_,27,10);
		if ($esid_date_written  eq ' ' x length($esid_date_written )) {
			undef $esid_date_written ;
		}
		$esid_system_smfid=substr($_,38,4);
		$esid_violation=substr($_,43,1);
		$esid_user_ndfnd=substr($_,48,1);
		$esid_user_warning=substr($_,53,1);
		$esid_evt_user_id=substr($_,58,8);
		$esid_evt_grp_id=substr($_,67,8);
		$esid_auth_normal=substr($_,76,1);
		$esid_auth_special=substr($_,81,1);
		$esid_auth_oper=substr($_,86,1);
		$esid_auth_audit=substr($_,91,1);
		$esid_auth_exit=substr($_,96,1);
		$esid_auth_failsft=substr($_,101,1);
		$esid_auth_bypass=substr($_,106,1);
		$esid_auth_trusted=substr($_,111,1);
		$esid_log_class=substr($_,116,1);
		$esid_log_user=substr($_,121,1);
		$esid_log_special=substr($_,126,1);
		$esid_log_access=substr($_,131,1);
		$esid_log_racinit=substr($_,136,1);
		$esid_log_always=substr($_,141,1);
		$esid_log_cmdviol=substr($_,146,1);
		$esid_log_global=substr($_,151,1);
		$esid_term_level=substr($_,156,3);
		if ($esid_term_level  eq ' ' x length($esid_term_level )) {
			undef $esid_term_level ;
		}
		$esid_backout_fail=substr($_,160,1);
		$esid_prof_same=substr($_,165,1);
		$esid_term=substr($_,170,8);
		$esid_job_name=substr($_,179,8);
		$esid_read_time=substr($_,188,8);
		if ($esid_read_time  eq ' ' x length($esid_read_time )) {
			undef $esid_read_time ;
		}
		$esid_read_date=substr($_,197,10);
		if ($esid_read_date  eq ' ' x length($esid_read_date )) {
			undef $esid_read_date ;
		}
		$esid_smf_user_id=substr($_,208,8);
		$esid_log_level=substr($_,217,1);
		$esid_log_vmevent=substr($_,222,1);
		$esid_log_logopt=substr($_,227,1);
		$esid_log_secl=substr($_,232,1);
		$esid_log_compatm=substr($_,237,1);
		$esid_log_applaud=substr($_,242,1);
		$esid_log_nonomvs=substr($_,247,1);
		$esid_log_omvsnprv=substr($_,252,1);
		$esid_auth_omvssu=substr($_,257,1);
		$esid_auth_omvssys=substr($_,262,1);
		$esid_usr_secl=substr($_,267,8);
		$esid_racf_version=substr($_,276,4);
		$esid_class=substr($_,281,8);
		$esid_user_name=substr($_,290,20);
		$esid_utk_encr=substr($_,311,1);
		$esid_utk_pre19=substr($_,316,1);
		$esid_utk_verprof=substr($_,321,1);
		$esid_utk_njeunusr=substr($_,326,1);
		$esid_utk_logusr=substr($_,331,1);
		$esid_utk_special=substr($_,336,1);
		$esid_utk_default=substr($_,341,1);
		$esid_utk_unknusr=substr($_,346,1);
		$esid_utk_error=substr($_,351,1);
		$esid_utk_trusted=substr($_,356,1);
		$esid_utk_sesstype=substr($_,361,8);
		$esid_utk_surrogat=substr($_,370,1);
		$esid_utk_remote=substr($_,375,1);
		$esid_utk_priv=substr($_,380,1);
		$esid_utk_secl=substr($_,385,8);
		$esid_utk_execnode=substr($_,394,8);
		$esid_utk_suser_id=substr($_,403,8);
		$esid_utk_snode=substr($_,412,8);
		$esid_utk_sgrp_id=substr($_,421,8);
		$esid_utk_spoe=substr($_,430,8);
		$esid_utk_spclass=substr($_,439,8);
		$esid_utk_user_id=substr($_,448,8);
		$esid_utk_grp_id=substr($_,457,8);
		$esid_utk_dft_grp=substr($_,466,1);
		$esid_utk_dft_secl=substr($_,471,1);
		$esid_appc_link=substr($_,476,16);
		$esid_audit_code=substr($_,493,11);
		$esid_old_real_uid=substr($_,505,10);
		if ($esid_old_real_uid  eq ' ' x length($esid_old_real_uid )) {
			undef $esid_old_real_uid ;
		}
		$esid_old_eff_uid=substr($_,516,10);
		if ($esid_old_eff_uid  eq ' ' x length($esid_old_eff_uid )) {
			undef $esid_old_eff_uid ;
		}
		$esid_old_saved_uid=substr($_,527,10);
		if ($esid_old_saved_uid eq ' ' x length($esid_old_saved_uid)) {
			undef $esid_old_saved_uid;
		}
		$esid_old_real_gid=substr($_,538,10);
		if ($esid_old_real_gid  eq ' ' x length($esid_old_real_gid )) {
			undef $esid_old_real_gid ;
		}
		$esid_old_eff_gid=substr($_,549,10);
		if ($esid_old_eff_gid  eq ' ' x length($esid_old_eff_gid )) {
			undef $esid_old_eff_gid ;
		}
		$esid_old_saved_gid=substr($_,560,10);
		if ($esid_old_saved_gid eq ' ' x length($esid_old_saved_gid)) {
			undef $esid_old_saved_gid;
		}
		$esid_new_real_uid=substr($_,571,10);
		if ($esid_new_real_uid  eq ' ' x length($esid_new_real_uid )) {
			undef $esid_new_real_uid ;
		}
		$esid_new_eff_uid=substr($_,582,10);
		if ($esid_new_eff_uid  eq ' ' x length($esid_new_eff_uid )) {
			undef $esid_new_eff_uid ;
		}
		$esid_new_saved_uid=substr($_,593,10);
		if ($esid_new_saved_uid eq ' ' x length($esid_new_saved_uid)) {
			undef $esid_new_saved_uid;
		}
		$esid_new_real_gid=substr($_,604,10);
		if ($esid_new_real_gid  eq ' ' x length($esid_new_real_gid )) {
			undef $esid_new_real_gid ;
		}
		$esid_new_eff_gid=substr($_,615,10);
		if ($esid_new_eff_gid  eq ' ' x length($esid_new_eff_gid )) {
			undef $esid_new_eff_gid ;
		}
		$esid_new_saved_gid=substr($_,626,10);
		if ($esid_new_saved_gid eq ' ' x length($esid_new_saved_gid)) {
			undef $esid_new_saved_gid;
		}
		$esid_uid=substr($_,637,10);
		if ($esid_uid  eq ' ' x length($esid_uid )) {
			undef $esid_uid ;
		}
		$esid_gid=substr($_,648,10);
		if ($esid_gid  eq ' ' x length($esid_gid )) {
			undef $esid_gid ;
		}
		$esid_dflt_process=substr($_,659,1);
		$esid_utk_netw=substr($_,664,8);
		$esid_x500_subject=substr($_,673,255);
		$esid_x500_issuer=substr($_,929,255);
		$rv=$insert{exesetid}->execute($esid_event_type,$esid_event_qual,$esid_time_written,$esid_date_written,$esid_system_smfid,$esid_violation,$esid_user_ndfnd,$esid_user_warning,$esid_evt_user_id,$esid_evt_grp_id,$esid_auth_normal,$esid_auth_special,$esid_auth_oper,$esid_auth_audit,$esid_auth_exit,$esid_auth_failsft,$esid_auth_bypass,$esid_auth_trusted,$esid_log_class,$esid_log_user,$esid_log_special,$esid_log_access,$esid_log_racinit,$esid_log_always,$esid_log_cmdviol,$esid_log_global,$esid_term_level,$esid_backout_fail,$esid_prof_same,$esid_term,$esid_job_name,$esid_read_time,$esid_read_date,$esid_smf_user_id,$esid_log_level,$esid_log_vmevent,$esid_log_logopt,$esid_log_secl,$esid_log_compatm,$esid_log_applaud,$esid_log_nonomvs,$esid_log_omvsnprv,$esid_auth_omvssu,$esid_auth_omvssys,$esid_usr_secl,$esid_racf_version,$esid_class,$esid_user_name,$esid_utk_encr,$esid_utk_pre19,$esid_utk_verprof,$esid_utk_njeunusr,$esid_utk_logusr,$esid_utk_special,$esid_utk_default,$esid_utk_unknusr,$esid_utk_error,$esid_utk_trusted,$esid_utk_sesstype,$esid_utk_surrogat,$esid_utk_remote,$esid_utk_priv,$esid_utk_secl,$esid_utk_execnode,$esid_utk_suser_id,$esid_utk_snode,$esid_utk_sgrp_id,$esid_utk_spoe,$esid_utk_spclass,$esid_utk_user_id,$esid_utk_grp_id,$esid_utk_dft_grp,$esid_utk_dft_secl,$esid_appc_link,$esid_audit_code,$esid_old_real_uid,$esid_old_eff_uid,$esid_old_saved_uid,$esid_old_real_gid,$esid_old_eff_gid,$esid_old_saved_gid,$esid_new_real_uid,$esid_new_eff_uid,$esid_new_saved_uid,$esid_new_real_gid,$esid_new_eff_gid,$esid_new_saved_gid,$esid_uid,$esid_gid,$esid_dflt_process,$esid_utk_netw,$esid_x500_subject,$esid_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"exesetid"}++;
		next;
	}

	if ($rectype eq 'FACCESS ') {
		$facc_event_type=substr($_,0,8);
		$facc_event_qual=substr($_,9,8);
		$facc_time_written=substr($_,18,8);
		if ($facc_time_written  eq ' ' x length($facc_time_written )) {
			undef $facc_time_written ;
		}
		$facc_date_written=substr($_,27,10);
		if ($facc_date_written  eq ' ' x length($facc_date_written )) {
			undef $facc_date_written ;
		}
		$facc_system_smfid=substr($_,38,4);
		$facc_violation=substr($_,43,1);
		$facc_user_ndfnd=substr($_,48,1);
		$facc_user_warning=substr($_,53,1);
		$facc_evt_user_id=substr($_,58,8);
		$facc_evt_grp_id=substr($_,67,8);
		$facc_auth_normal=substr($_,76,1);
		$facc_auth_special=substr($_,81,1);
		$facc_auth_oper=substr($_,86,1);
		$facc_auth_audit=substr($_,91,1);
		$facc_auth_exit=substr($_,96,1);
		$facc_auth_failsft=substr($_,101,1);
		$facc_auth_bypass=substr($_,106,1);
		$facc_auth_trusted=substr($_,111,1);
		$facc_log_class=substr($_,116,1);
		$facc_log_user=substr($_,121,1);
		$facc_log_special=substr($_,126,1);
		$facc_log_access=substr($_,131,1);
		$facc_log_racinit=substr($_,136,1);
		$facc_log_always=substr($_,141,1);
		$facc_log_cmdviol=substr($_,146,1);
		$facc_log_global=substr($_,151,1);
		$facc_term_level=substr($_,156,3);
		if ($facc_term_level  eq ' ' x length($facc_term_level )) {
			undef $facc_term_level ;
		}
		$facc_backout_fail=substr($_,160,1);
		$facc_prof_same=substr($_,165,1);
		$facc_term=substr($_,170,8);
		$facc_job_name=substr($_,179,8);
		$facc_read_time=substr($_,188,8);
		if ($facc_read_time  eq ' ' x length($facc_read_time )) {
			undef $facc_read_time ;
		}
		$facc_read_date=substr($_,197,10);
		if ($facc_read_date  eq ' ' x length($facc_read_date )) {
			undef $facc_read_date ;
		}
		$facc_smf_user_id=substr($_,208,8);
		$facc_log_level=substr($_,217,1);
		$facc_log_vmevent=substr($_,222,1);
		$facc_log_logopt=substr($_,227,1);
		$facc_log_secl=substr($_,232,1);
		$facc_log_compatm=substr($_,237,1);
		$facc_log_applaud=substr($_,242,1);
		$facc_log_nonomvs=substr($_,247,1);
		$facc_log_omvsnprv=substr($_,252,1);
		$facc_auth_omvssu=substr($_,257,1);
		$facc_auth_omvssys=substr($_,262,1);
		$facc_usr_secl=substr($_,267,8);
		$facc_racf_version=substr($_,276,4);
		$facc_class=substr($_,281,8);
		$facc_user_name=substr($_,290,20);
		$facc_utk_encr=substr($_,311,1);
		$facc_utk_pre19=substr($_,316,1);
		$facc_utk_verprof=substr($_,321,1);
		$facc_utk_njeunusr=substr($_,326,1);
		$facc_utk_logusr=substr($_,331,1);
		$facc_utk_special=substr($_,336,1);
		$facc_utk_default=substr($_,341,1);
		$facc_utk_unknusr=substr($_,346,1);
		$facc_utk_error=substr($_,351,1);
		$facc_utk_trusted=substr($_,356,1);
		$facc_utk_sesstype=substr($_,361,8);
		$facc_utk_surrogat=substr($_,370,1);
		$facc_utk_remote=substr($_,375,1);
		$facc_utk_priv=substr($_,380,1);
		$facc_utk_secl=substr($_,385,8);
		$facc_utk_execnode=substr($_,394,8);
		$facc_utk_suser_id=substr($_,403,8);
		$facc_utk_snode=substr($_,412,8);
		$facc_utk_sgrp_id=substr($_,421,8);
		$facc_utk_spoe=substr($_,430,8);
		$facc_utk_spclass=substr($_,439,8);
		$facc_utk_user_id=substr($_,448,8);
		$facc_utk_grp_id=substr($_,457,8);
		$facc_utk_dft_grp=substr($_,466,1);
		$facc_utk_dft_secl=substr($_,471,1);
		$facc_appc_link=substr($_,476,16);
		$facc_audit_code=substr($_,493,11);
		$facc_old_real_uid=substr($_,505,10);
		if ($facc_old_real_uid  eq ' ' x length($facc_old_real_uid )) {
			undef $facc_old_real_uid ;
		}
		$facc_old_eff_uid=substr($_,516,10);
		if ($facc_old_eff_uid  eq ' ' x length($facc_old_eff_uid )) {
			undef $facc_old_eff_uid ;
		}
		$facc_old_saved_uid=substr($_,527,10);
		if ($facc_old_saved_uid eq ' ' x length($facc_old_saved_uid)) {
			undef $facc_old_saved_uid;
		}
		$facc_old_real_gid=substr($_,538,10);
		if ($facc_old_real_gid  eq ' ' x length($facc_old_real_gid )) {
			undef $facc_old_real_gid ;
		}
		$facc_old_eff_gid=substr($_,549,10);
		if ($facc_old_eff_gid  eq ' ' x length($facc_old_eff_gid )) {
			undef $facc_old_eff_gid ;
		}
		$facc_old_saved_gid=substr($_,560,10);
		if ($facc_old_saved_gid eq ' ' x length($facc_old_saved_gid)) {
			undef $facc_old_saved_gid;
		}
		$facc_path_name=substr($_,571,1023);
		$facc_file_id=substr($_,1595,32);
		$facc_file_own_uid=substr($_,1628,10);
		if ($facc_file_own_uid  eq ' ' x length($facc_file_own_uid )) {
			undef $facc_file_own_uid ;
		}
		$facc_file_own_gid=substr($_,1639,10);
		if ($facc_file_own_gid  eq ' ' x length($facc_file_own_gid )) {
			undef $facc_file_own_gid ;
		}
		$facc_request_read=substr($_,1650,1);
		$facc_request_write=substr($_,1655,1);
		$facc_request_exec=substr($_,1660,1);
		$facc_request_dsrch=substr($_,1665,1);
		$facc_access_type=substr($_,1670,8);
		$facc_allowed_read=substr($_,1679,1);
		$facc_allowed_write=substr($_,1684,1);
		$facc_allowed_exec=substr($_,1689,1);
		$facc_request_path2=substr($_,1694,1023);
		$facc_file_name=substr($_,2718,256);
		$facc_path_type=substr($_,2975,4);
		$facc_filepool=substr($_,2980,8);
		$facc_filespace=substr($_,2989,8);
		$facc_inode=substr($_,2998,10);
		if ($facc_inode  eq ' ' x length($facc_inode )) {
			undef $facc_inode ;
		}
		$facc_scid=substr($_,3009,10);
		if ($facc_scid  eq ' ' x length($facc_scid )) {
			undef $facc_scid ;
		}
		$facc_dce_link=substr($_,3020,16);
		$facc_auth_type=substr($_,3037,13);
		$facc_dflt_process=substr($_,3051,1);
		$facc_utk_netw=substr($_,3056,8);
		$facc_x500_subject=substr($_,3065,255);
		$facc_x500_issuer=substr($_,3321,255);
		$rv=$insert{faccess}->execute($facc_event_type,$facc_event_qual,$facc_time_written,$facc_date_written,$facc_system_smfid,$facc_violation,$facc_user_ndfnd,$facc_user_warning,$facc_evt_user_id,$facc_evt_grp_id,$facc_auth_normal,$facc_auth_special,$facc_auth_oper,$facc_auth_audit,$facc_auth_exit,$facc_auth_failsft,$facc_auth_bypass,$facc_auth_trusted,$facc_log_class,$facc_log_user,$facc_log_special,$facc_log_access,$facc_log_racinit,$facc_log_always,$facc_log_cmdviol,$facc_log_global,$facc_term_level,$facc_backout_fail,$facc_prof_same,$facc_term,$facc_job_name,$facc_read_time,$facc_read_date,$facc_smf_user_id,$facc_log_level,$facc_log_vmevent,$facc_log_logopt,$facc_log_secl,$facc_log_compatm,$facc_log_applaud,$facc_log_nonomvs,$facc_log_omvsnprv,$facc_auth_omvssu,$facc_auth_omvssys,$facc_usr_secl,$facc_racf_version,$facc_class,$facc_user_name,$facc_utk_encr,$facc_utk_pre19,$facc_utk_verprof,$facc_utk_njeunusr,$facc_utk_logusr,$facc_utk_special,$facc_utk_default,$facc_utk_unknusr,$facc_utk_error,$facc_utk_trusted,$facc_utk_sesstype,$facc_utk_surrogat,$facc_utk_remote,$facc_utk_priv,$facc_utk_secl,$facc_utk_execnode,$facc_utk_suser_id,$facc_utk_snode,$facc_utk_sgrp_id,$facc_utk_spoe,$facc_utk_spclass,$facc_utk_user_id,$facc_utk_grp_id,$facc_utk_dft_grp,$facc_utk_dft_secl,$facc_appc_link,$facc_audit_code,$facc_old_real_uid,$facc_old_eff_uid,$facc_old_saved_uid,$facc_old_real_gid,$facc_old_eff_gid,$facc_old_saved_gid,$facc_path_name,$facc_file_id,$facc_file_own_uid,$facc_file_own_gid,$facc_request_read,$facc_request_write,$facc_request_exec,$facc_request_dsrch,$facc_access_type,$facc_allowed_read,$facc_allowed_write,$facc_allowed_exec,$facc_request_path2,$facc_file_name,$facc_path_type,$facc_filepool,$facc_filespace,$facc_inode,$facc_scid,$facc_dce_link,$facc_auth_type,$facc_dflt_process,$facc_utk_netw,$facc_x500_subject,$facc_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"faccess"}++;
		next;
	}

	if ($rectype eq 'GENERAL ') {
		$gen_event_type=substr($_,0,8);
		$gen_event_qual=substr($_,9,8);
		$gen_time_written=substr($_,18,8);
		if ($gen_time_written  eq ' ' x length($gen_time_written )) {
			undef $gen_time_written ;
		}
		$gen_date_written=substr($_,27,10);
		if ($gen_date_written  eq ' ' x length($gen_date_written )) {
			undef $gen_date_written ;
		}
		$gen_system_smfid=substr($_,38,4);
		$gen_violation=substr($_,43,1);
		$gen_user_ndfnd=substr($_,48,1);
		$gen_user_warning=substr($_,53,1);
		$gen_evt_user_id=substr($_,58,8);
		$gen_evt_grp_id=substr($_,67,8);
		$gen_auth_normal=substr($_,76,1);
		$gen_auth_special=substr($_,81,1);
		$gen_auth_oper=substr($_,86,1);
		$gen_auth_audit=substr($_,91,1);
		$gen_auth_exit=substr($_,96,1);
		$gen_auth_failsft=substr($_,101,1);
		$gen_auth_bypass=substr($_,106,1);
		$gen_auth_trusted=substr($_,111,1);
		$gen_log_class=substr($_,116,1);
		$gen_log_user=substr($_,121,1);
		$gen_log_special=substr($_,126,1);
		$gen_log_access=substr($_,131,1);
		$gen_log_racinit=substr($_,136,1);
		$gen_log_always=substr($_,141,1);
		$gen_log_cmdviol=substr($_,146,1);
		$gen_log_global=substr($_,151,1);
		$gen_term_level=substr($_,156,3);
		if ($gen_term_level  eq ' ' x length($gen_term_level )) {
			undef $gen_term_level ;
		}
		$gen_backout_fail=substr($_,160,1);
		$gen_prof_same=substr($_,165,1);
		$gen_term=substr($_,170,8);
		$gen_job_name=substr($_,179,8);
		$gen_read_time=substr($_,188,8);
		if ($gen_read_time  eq ' ' x length($gen_read_time )) {
			undef $gen_read_time ;
		}
		$gen_read_date=substr($_,197,10);
		if ($gen_read_date  eq ' ' x length($gen_read_date )) {
			undef $gen_read_date ;
		}
		$gen_smf_user_id=substr($_,208,8);
		$gen_log_level=substr($_,217,1);
		$gen_log_vmevent=substr($_,222,1);
		$gen_log_logopt=substr($_,227,1);
		$gen_log_secl=substr($_,232,1);
		$gen_log_compatm=substr($_,237,1);
		$gen_log_applaud=substr($_,242,1);
		$gen_log_nonomvs=substr($_,247,1);
		$gen_log_omvsnprv=substr($_,252,1);
		$gen_auth_omvssu=substr($_,257,1);
		$gen_auth_omvssys=substr($_,262,1);
		$gen_usr_secl=substr($_,267,8);
		$gen_racf_version=substr($_,276,4);
		$gen_class=substr($_,281,8);
		$gen_logstr=substr($_,290,255);
		$gen_user_name=substr($_,546,20);
		$gen_utk_encr=substr($_,567,1);
		$gen_utk_pre19=substr($_,572,1);
		$gen_utk_verprof=substr($_,577,1);
		$gen_utk_njeunusr=substr($_,582,1);
		$gen_utk_logusr=substr($_,587,1);
		$gen_utk_special=substr($_,592,1);
		$gen_utk_default=substr($_,597,1);
		$gen_utk_unknusr=substr($_,602,1);
		$gen_utk_error=substr($_,607,1);
		$gen_utk_trusted=substr($_,612,1);
		$gen_utk_sesstype=substr($_,617,8);
		$gen_utk_surrogat=substr($_,626,1);
		$gen_utk_remote=substr($_,631,1);
		$gen_utk_priv=substr($_,636,1);
		$gen_utk_secl=substr($_,641,8);
		$gen_utk_execnode=substr($_,650,8);
		$gen_utk_suser_id=substr($_,659,8);
		$gen_utk_snode=substr($_,668,8);
		$gen_utk_sgrp_id=substr($_,677,8);
		$gen_utk_spoe=substr($_,686,8);
		$gen_utk_spclass=substr($_,695,8);
		$gen_utk_user_id=substr($_,704,8);
		$gen_utk_grp_id=substr($_,713,8);
		$gen_utk_dft_grp=substr($_,722,1);
		$gen_utk_dft_secl=substr($_,727,1);
		$gen_appc_link=substr($_,732,16);
		$gen_utk_netw=substr($_,749,8);
		$gen_x500_subject=substr($_,758,255);
		$gen_x500_issuer=substr($_,1014,255);
		$rv=$insert{general}->execute($gen_event_type,$gen_event_qual,$gen_time_written,$gen_date_written,$gen_system_smfid,$gen_violation,$gen_user_ndfnd,$gen_user_warning,$gen_evt_user_id,$gen_evt_grp_id,$gen_auth_normal,$gen_auth_special,$gen_auth_oper,$gen_auth_audit,$gen_auth_exit,$gen_auth_failsft,$gen_auth_bypass,$gen_auth_trusted,$gen_log_class,$gen_log_user,$gen_log_special,$gen_log_access,$gen_log_racinit,$gen_log_always,$gen_log_cmdviol,$gen_log_global,$gen_term_level,$gen_backout_fail,$gen_prof_same,$gen_term,$gen_job_name,$gen_read_time,$gen_read_date,$gen_smf_user_id,$gen_log_level,$gen_log_vmevent,$gen_log_logopt,$gen_log_secl,$gen_log_compatm,$gen_log_applaud,$gen_log_nonomvs,$gen_log_omvsnprv,$gen_auth_omvssu,$gen_auth_omvssys,$gen_usr_secl,$gen_racf_version,$gen_class,$gen_logstr,$gen_user_name,$gen_utk_encr,$gen_utk_pre19,$gen_utk_verprof,$gen_utk_njeunusr,$gen_utk_logusr,$gen_utk_special,$gen_utk_default,$gen_utk_unknusr,$gen_utk_error,$gen_utk_trusted,$gen_utk_sesstype,$gen_utk_surrogat,$gen_utk_remote,$gen_utk_priv,$gen_utk_secl,$gen_utk_execnode,$gen_utk_suser_id,$gen_utk_snode,$gen_utk_sgrp_id,$gen_utk_spoe,$gen_utk_spclass,$gen_utk_user_id,$gen_utk_grp_id,$gen_utk_dft_grp,$gen_utk_dft_secl,$gen_appc_link,$gen_utk_netw,$gen_x500_subject,$gen_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"general"}++;
		next;
	}

	if ($rectype eq 'GETPSENT') {
		$gpst_event_type=substr($_,0,8);
		$gpst_event_qual=substr($_,9,8);
		$gpst_time_written=substr($_,18,8);
		if ($gpst_time_written  eq ' ' x length($gpst_time_written )) {
			undef $gpst_time_written ;
		}
		$gpst_date_written=substr($_,27,10);
		if ($gpst_date_written  eq ' ' x length($gpst_date_written )) {
			undef $gpst_date_written ;
		}
		$gpst_system_smfid=substr($_,38,4);
		$gpst_violation=substr($_,43,1);
		$gpst_user_ndfnd=substr($_,48,1);
		$gpst_user_warning=substr($_,53,1);
		$gpst_evt_user_id=substr($_,58,8);
		$gpst_evt_grp_id=substr($_,67,8);
		$gpst_auth_normal=substr($_,76,1);
		$gpst_auth_special=substr($_,81,1);
		$gpst_auth_oper=substr($_,86,1);
		$gpst_auth_audit=substr($_,91,1);
		$gpst_auth_exit=substr($_,96,1);
		$gpst_auth_failsft=substr($_,101,1);
		$gpst_auth_bypass=substr($_,106,1);
		$gpst_auth_trusted=substr($_,111,1);
		$gpst_log_class=substr($_,116,1);
		$gpst_log_user=substr($_,121,1);
		$gpst_log_special=substr($_,126,1);
		$gpst_log_access=substr($_,131,1);
		$gpst_log_racinit=substr($_,136,1);
		$gpst_log_always=substr($_,141,1);
		$gpst_log_cmdviol=substr($_,146,1);
		$gpst_log_global=substr($_,151,1);
		$gpst_term_level=substr($_,156,3);
		if ($gpst_term_level  eq ' ' x length($gpst_term_level )) {
			undef $gpst_term_level ;
		}
		$gpst_backout_fail=substr($_,160,1);
		$gpst_prof_same=substr($_,165,1);
		$gpst_term=substr($_,170,8);
		$gpst_job_name=substr($_,179,8);
		$gpst_read_time=substr($_,188,8);
		if ($gpst_read_time  eq ' ' x length($gpst_read_time )) {
			undef $gpst_read_time ;
		}
		$gpst_read_date=substr($_,197,10);
		if ($gpst_read_date  eq ' ' x length($gpst_read_date )) {
			undef $gpst_read_date ;
		}
		$gpst_smf_user_id=substr($_,208,8);
		$gpst_log_level=substr($_,217,1);
		$gpst_log_vmevent=substr($_,222,1);
		$gpst_log_logopt=substr($_,227,1);
		$gpst_log_secl=substr($_,232,1);
		$gpst_log_compatm=substr($_,237,1);
		$gpst_log_applaud=substr($_,242,1);
		$gpst_log_nonomvs=substr($_,247,1);
		$gpst_log_omvsnprv=substr($_,252,1);
		$gpst_auth_omvssu=substr($_,257,1);
		$gpst_auth_omvssys=substr($_,262,1);
		$gpst_usr_secl=substr($_,267,8);
		$gpst_racf_version=substr($_,276,4);
		$gpst_class=substr($_,281,8);
		$gpst_user_name=substr($_,290,20);
		$gpst_utk_encr=substr($_,311,1);
		$gpst_utk_pre19=substr($_,316,1);
		$gpst_utk_verprof=substr($_,321,1);
		$gpst_utk_njeunusr=substr($_,326,1);
		$gpst_utk_logusr=substr($_,331,1);
		$gpst_utk_special=substr($_,336,1);
		$gpst_utk_default=substr($_,341,1);
		$gpst_utk_unknusr=substr($_,346,1);
		$gpst_utk_error=substr($_,351,1);
		$gpst_utk_trusted=substr($_,356,1);
		$gpst_utk_sesstype=substr($_,361,8);
		$gpst_utk_surrogat=substr($_,370,1);
		$gpst_utk_remote=substr($_,375,1);
		$gpst_utk_priv=substr($_,380,1);
		$gpst_utk_secl=substr($_,385,8);
		$gpst_utk_execnode=substr($_,394,8);
		$gpst_utk_suser_id=substr($_,403,8);
		$gpst_utk_snode=substr($_,412,8);
		$gpst_utk_sgrp_id=substr($_,421,8);
		$gpst_utk_spoe=substr($_,430,8);
		$gpst_utk_spclass=substr($_,439,8);
		$gpst_utk_user_id=substr($_,448,8);
		$gpst_utk_grp_id=substr($_,457,8);
		$gpst_utk_dft_grp=substr($_,466,1);
		$gpst_utk_dft_secl=substr($_,471,1);
		$gpst_appc_link=substr($_,476,16);
		$gpst_audit_code=substr($_,493,11);
		$gpst_old_real_uid=substr($_,505,10);
		if ($gpst_old_real_uid  eq ' ' x length($gpst_old_real_uid )) {
			undef $gpst_old_real_uid ;
		}
		$gpst_old_eff_uid=substr($_,516,10);
		if ($gpst_old_eff_uid  eq ' ' x length($gpst_old_eff_uid )) {
			undef $gpst_old_eff_uid ;
		}
		$gpst_old_saved_uid=substr($_,527,10);
		if ($gpst_old_saved_uid eq ' ' x length($gpst_old_saved_uid)) {
			undef $gpst_old_saved_uid;
		}
		$gpst_old_real_gid=substr($_,538,10);
		if ($gpst_old_real_gid  eq ' ' x length($gpst_old_real_gid )) {
			undef $gpst_old_real_gid ;
		}
		$gpst_old_eff_gid=substr($_,549,10);
		if ($gpst_old_eff_gid  eq ' ' x length($gpst_old_eff_gid )) {
			undef $gpst_old_eff_gid ;
		}
		$gpst_old_saved_gid=substr($_,560,10);
		if ($gpst_old_saved_gid eq ' ' x length($gpst_old_saved_gid)) {
			undef $gpst_old_saved_gid;
		}
		$gpst_tgt_real_uid=substr($_,571,10);
		if ($gpst_tgt_real_uid  eq ' ' x length($gpst_tgt_real_uid )) {
			undef $gpst_tgt_real_uid ;
		}
		$gpst_tgt_eff_uid=substr($_,582,10);
		if ($gpst_tgt_eff_uid  eq ' ' x length($gpst_tgt_eff_uid )) {
			undef $gpst_tgt_eff_uid ;
		}
		$gpst_tgt_sav_uid=substr($_,593,10);
		if ($gpst_tgt_sav_uid  eq ' ' x length($gpst_tgt_sav_uid )) {
			undef $gpst_tgt_sav_uid ;
		}
		$gpst_tgt_pid=substr($_,604,10);
		if ($gpst_tgt_pid  eq ' ' x length($gpst_tgt_pid )) {
			undef $gpst_tgt_pid ;
		}
		$gpst_dflt_process=substr($_,615,1);
		$gpst_utk_netw=substr($_,620,8);
		$gpst_x500_subject=substr($_,629,255);
		$gpst_x500_issuer=substr($_,885,255);
		$rv=$insert{getpsent}->execute($gpst_event_type,$gpst_event_qual,$gpst_time_written,$gpst_date_written,$gpst_system_smfid,$gpst_violation,$gpst_user_ndfnd,$gpst_user_warning,$gpst_evt_user_id,$gpst_evt_grp_id,$gpst_auth_normal,$gpst_auth_special,$gpst_auth_oper,$gpst_auth_audit,$gpst_auth_exit,$gpst_auth_failsft,$gpst_auth_bypass,$gpst_auth_trusted,$gpst_log_class,$gpst_log_user,$gpst_log_special,$gpst_log_access,$gpst_log_racinit,$gpst_log_always,$gpst_log_cmdviol,$gpst_log_global,$gpst_term_level,$gpst_backout_fail,$gpst_prof_same,$gpst_term,$gpst_job_name,$gpst_read_time,$gpst_read_date,$gpst_smf_user_id,$gpst_log_level,$gpst_log_vmevent,$gpst_log_logopt,$gpst_log_secl,$gpst_log_compatm,$gpst_log_applaud,$gpst_log_nonomvs,$gpst_log_omvsnprv,$gpst_auth_omvssu,$gpst_auth_omvssys,$gpst_usr_secl,$gpst_racf_version,$gpst_class,$gpst_user_name,$gpst_utk_encr,$gpst_utk_pre19,$gpst_utk_verprof,$gpst_utk_njeunusr,$gpst_utk_logusr,$gpst_utk_special,$gpst_utk_default,$gpst_utk_unknusr,$gpst_utk_error,$gpst_utk_trusted,$gpst_utk_sesstype,$gpst_utk_surrogat,$gpst_utk_remote,$gpst_utk_priv,$gpst_utk_secl,$gpst_utk_execnode,$gpst_utk_suser_id,$gpst_utk_snode,$gpst_utk_sgrp_id,$gpst_utk_spoe,$gpst_utk_spclass,$gpst_utk_user_id,$gpst_utk_grp_id,$gpst_utk_dft_grp,$gpst_utk_dft_secl,$gpst_appc_link,$gpst_audit_code,$gpst_old_real_uid,$gpst_old_eff_uid,$gpst_old_saved_uid,$gpst_old_real_gid,$gpst_old_eff_gid,$gpst_old_saved_gid,$gpst_tgt_real_uid,$gpst_tgt_eff_uid,$gpst_tgt_sav_uid,$gpst_tgt_pid,$gpst_dflt_process,$gpst_utk_netw,$gpst_x500_subject,$gpst_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"getpsent"}++;
		next;
	}

	if ($rectype eq 'INITACEE') {
		$inta_event_type=substr($_,0,8);
		$inta_event_qual=substr($_,9,8);
		$inta_time_written=substr($_,18,8);
		if ($inta_time_written  eq ' ' x length($inta_time_written )) {
			undef $inta_time_written ;
		}
		$inta_date_written=substr($_,27,10);
		if ($inta_date_written  eq ' ' x length($inta_date_written )) {
			undef $inta_date_written ;
		}
		$inta_system_smfid=substr($_,38,4);
		$inta_violation=substr($_,43,1);
		$inta_user_ndfnd=substr($_,48,1);
		$inta_user_warning=substr($_,53,1);
		$inta_evt_user_id=substr($_,58,8);
		$inta_evt_grp_id=substr($_,67,8);
		$inta_auth_normal=substr($_,76,1);
		$inta_auth_special=substr($_,81,1);
		$inta_auth_oper=substr($_,86,1);
		$inta_auth_audit=substr($_,91,1);
		$inta_auth_exit=substr($_,96,1);
		$inta_auth_failsft=substr($_,101,1);
		$inta_auth_bypass=substr($_,106,1);
		$inta_auth_trusted=substr($_,111,1);
		$inta_log_class=substr($_,116,1);
		$inta_log_user=substr($_,121,1);
		$inta_log_special=substr($_,126,1);
		$inta_log_access=substr($_,131,1);
		$inta_log_racinit=substr($_,136,1);
		$inta_log_always=substr($_,141,1);
		$inta_log_cmdviol=substr($_,146,1);
		$inta_log_global=substr($_,151,1);
		$inta_term_level=substr($_,156,3);
		if ($inta_term_level  eq ' ' x length($inta_term_level )) {
			undef $inta_term_level ;
		}
		$inta_backout_fail=substr($_,160,1);
		$inta_prof_same=substr($_,165,1);
		$inta_term=substr($_,170,8);
		$inta_job_name=substr($_,179,8);
		$inta_read_time=substr($_,188,8);
		if ($inta_read_time  eq ' ' x length($inta_read_time )) {
			undef $inta_read_time ;
		}
		$inta_read_date=substr($_,197,10);
		if ($inta_read_date  eq ' ' x length($inta_read_date )) {
			undef $inta_read_date ;
		}
		$inta_smf_user_id=substr($_,208,8);
		$inta_log_level=substr($_,217,1);
		$inta_log_vmevent=substr($_,222,1);
		$inta_log_logopt=substr($_,227,1);
		$inta_log_secl=substr($_,232,1);
		$inta_log_compatm=substr($_,237,1);
		$inta_log_applaud=substr($_,242,1);
		$inta_log_nonomvs=substr($_,247,1);
		$inta_log_omvsnprv=substr($_,252,1);
		$inta_auth_omvssu=substr($_,257,1);
		$inta_auth_omvssys=substr($_,262,1);
		$inta_usr_secl=substr($_,267,8);
		$inta_racf_version=substr($_,276,4);
		$inta_user_name=substr($_,281,20);
		$inta_utk_encr=substr($_,302,1);
		$inta_utk_pre19=substr($_,307,1);
		$inta_utk_verprof=substr($_,312,1);
		$inta_utk_njeunusr=substr($_,317,1);
		$inta_utk_logusr=substr($_,322,1);
		$inta_utk_special=substr($_,327,1);
		$inta_utk_default=substr($_,332,1);
		$inta_utk_unknusr=substr($_,337,1);
		$inta_utk_error=substr($_,342,1);
		$inta_utk_trusted=substr($_,347,1);
		$inta_utk_sesstype=substr($_,352,8);
		$inta_utk_surrogat=substr($_,361,1);
		$inta_utk_remote=substr($_,366,1);
		$inta_utk_priv=substr($_,371,1);
		$inta_utk_secl=substr($_,376,8);
		$inta_utk_execnode=substr($_,385,8);
		$inta_utk_suser_id=substr($_,394,8);
		$inta_utk_snode=substr($_,403,8);
		$inta_utk_sgrp_id=substr($_,412,8);
		$inta_utk_spoe=substr($_,421,8);
		$inta_utk_spclass=substr($_,430,8);
		$inta_utk_user_id=substr($_,439,8);
		$inta_utk_grp_id=substr($_,448,8);
		$inta_utk_dft_grp=substr($_,457,1);
		$inta_utk_dft_secl=substr($_,462,1);
		$inta_serial_number=substr($_,467,255);
		$inta_issuers_dn=substr($_,723,255);
		$inta_utk_netw=substr($_,979,8);
		$inta_x500_subject=substr($_,988,255);
		$inta_x500_issuer=substr($_,1244,255);
		$rv=$insert{initacee}->execute($inta_event_type,$inta_event_qual,$inta_time_written,$inta_date_written,$inta_system_smfid,$inta_violation,$inta_user_ndfnd,$inta_user_warning,$inta_evt_user_id,$inta_evt_grp_id,$inta_auth_normal,$inta_auth_special,$inta_auth_oper,$inta_auth_audit,$inta_auth_exit,$inta_auth_failsft,$inta_auth_bypass,$inta_auth_trusted,$inta_log_class,$inta_log_user,$inta_log_special,$inta_log_access,$inta_log_racinit,$inta_log_always,$inta_log_cmdviol,$inta_log_global,$inta_term_level,$inta_backout_fail,$inta_prof_same,$inta_term,$inta_job_name,$inta_read_time,$inta_read_date,$inta_smf_user_id,$inta_log_level,$inta_log_vmevent,$inta_log_logopt,$inta_log_secl,$inta_log_compatm,$inta_log_applaud,$inta_log_nonomvs,$inta_log_omvsnprv,$inta_auth_omvssu,$inta_auth_omvssys,$inta_usr_secl,$inta_racf_version,$inta_user_name,$inta_utk_encr,$inta_utk_pre19,$inta_utk_verprof,$inta_utk_njeunusr,$inta_utk_logusr,$inta_utk_special,$inta_utk_default,$inta_utk_unknusr,$inta_utk_error,$inta_utk_trusted,$inta_utk_sesstype,$inta_utk_surrogat,$inta_utk_remote,$inta_utk_priv,$inta_utk_secl,$inta_utk_execnode,$inta_utk_suser_id,$inta_utk_snode,$inta_utk_sgrp_id,$inta_utk_spoe,$inta_utk_spclass,$inta_utk_user_id,$inta_utk_grp_id,$inta_utk_dft_grp,$inta_utk_dft_secl,$inta_serial_number,$inta_issuers_dn,$inta_utk_netw,$inta_x500_subject,$inta_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"initacee"}++;
		next;
	}

	if ($rectype eq 'INITOEDP') {
		$ioep_event_type=substr($_,0,8);
		$ioep_event_qual=substr($_,9,8);
		$ioep_time_written=substr($_,18,8);
		if ($ioep_time_written  eq ' ' x length($ioep_time_written )) {
			undef $ioep_time_written ;
		}
		$ioep_date_written=substr($_,27,10);
		if ($ioep_date_written  eq ' ' x length($ioep_date_written )) {
			undef $ioep_date_written ;
		}
		$ioep_system_smfid=substr($_,38,4);
		$ioep_violation=substr($_,43,1);
		$ioep_user_ndfnd=substr($_,48,1);
		$ioep_user_warning=substr($_,53,1);
		$ioep_evt_user_id=substr($_,58,8);
		$ioep_evt_grp_id=substr($_,67,8);
		$ioep_auth_normal=substr($_,76,1);
		$ioep_auth_special=substr($_,81,1);
		$ioep_auth_oper=substr($_,86,1);
		$ioep_auth_audit=substr($_,91,1);
		$ioep_auth_exit=substr($_,96,1);
		$ioep_auth_failsft=substr($_,101,1);
		$ioep_auth_bypass=substr($_,106,1);
		$ioep_auth_trusted=substr($_,111,1);
		$ioep_log_class=substr($_,116,1);
		$ioep_log_user=substr($_,121,1);
		$ioep_log_special=substr($_,126,1);
		$ioep_log_access=substr($_,131,1);
		$ioep_log_racinit=substr($_,136,1);
		$ioep_log_always=substr($_,141,1);
		$ioep_log_cmdviol=substr($_,146,1);
		$ioep_log_global=substr($_,151,1);
		$ioep_term_level=substr($_,156,3);
		if ($ioep_term_level  eq ' ' x length($ioep_term_level )) {
			undef $ioep_term_level ;
		}
		$ioep_backout_fail=substr($_,160,1);
		$ioep_prof_same=substr($_,165,1);
		$ioep_term=substr($_,170,8);
		$ioep_job_name=substr($_,179,8);
		$ioep_read_time=substr($_,188,8);
		if ($ioep_read_time  eq ' ' x length($ioep_read_time )) {
			undef $ioep_read_time ;
		}
		$ioep_read_date=substr($_,197,10);
		if ($ioep_read_date  eq ' ' x length($ioep_read_date )) {
			undef $ioep_read_date ;
		}
		$ioep_smf_user_id=substr($_,208,8);
		$ioep_log_level=substr($_,217,1);
		$ioep_log_vmevent=substr($_,222,1);
		$ioep_log_logopt=substr($_,227,1);
		$ioep_log_secl=substr($_,232,1);
		$ioep_log_compatm=substr($_,237,1);
		$ioep_log_applaud=substr($_,242,1);
		$ioep_log_nonomvs=substr($_,247,1);
		$ioep_log_omvsnprv=substr($_,252,1);
		$ioep_auth_omvssu=substr($_,257,1);
		$ioep_auth_omvssys=substr($_,262,1);
		$ioep_usr_secl=substr($_,267,8);
		$ioep_racf_version=substr($_,276,4);
		$ioep_class=substr($_,281,8);
		$ioep_user_name=substr($_,290,20);
		$ioep_utk_encr=substr($_,311,1);
		$ioep_utk_pre19=substr($_,316,1);
		$ioep_utk_verprof=substr($_,321,1);
		$ioep_utk_njeunusr=substr($_,326,1);
		$ioep_utk_logusr=substr($_,331,1);
		$ioep_utk_special=substr($_,336,1);
		$ioep_utk_default=substr($_,341,1);
		$ioep_utk_unknusr=substr($_,346,1);
		$ioep_utk_error=substr($_,351,1);
		$ioep_utk_trusted=substr($_,356,1);
		$ioep_utk_sesstype=substr($_,361,8);
		$ioep_utk_surrogat=substr($_,370,1);
		$ioep_utk_remote=substr($_,375,1);
		$ioep_utk_priv=substr($_,380,1);
		$ioep_utk_secl=substr($_,385,8);
		$ioep_utk_execnode=substr($_,394,8);
		$ioep_utk_suser_id=substr($_,403,8);
		$ioep_utk_snode=substr($_,412,8);
		$ioep_utk_sgrp_id=substr($_,421,8);
		$ioep_utk_spoe=substr($_,430,8);
		$ioep_utk_spclass=substr($_,439,8);
		$ioep_utk_user_id=substr($_,448,8);
		$ioep_utk_grp_id=substr($_,457,8);
		$ioep_utk_dft_grp=substr($_,466,1);
		$ioep_utk_dft_secl=substr($_,471,1);
		$ioep_appc_link=substr($_,476,16);
		$ioep_audit_code=substr($_,493,11);
		$ioep_old_real_uid=substr($_,505,10);
		if ($ioep_old_real_uid  eq ' ' x length($ioep_old_real_uid )) {
			undef $ioep_old_real_uid ;
		}
		$ioep_old_eff_uid=substr($_,516,10);
		if ($ioep_old_eff_uid  eq ' ' x length($ioep_old_eff_uid )) {
			undef $ioep_old_eff_uid ;
		}
		$ioep_old_saved_uid=substr($_,527,10);
		if ($ioep_old_saved_uid eq ' ' x length($ioep_old_saved_uid)) {
			undef $ioep_old_saved_uid;
		}
		$ioep_old_real_gid=substr($_,538,10);
		if ($ioep_old_real_gid  eq ' ' x length($ioep_old_real_gid )) {
			undef $ioep_old_real_gid ;
		}
		$ioep_old_eff_gid=substr($_,549,10);
		if ($ioep_old_eff_gid  eq ' ' x length($ioep_old_eff_gid )) {
			undef $ioep_old_eff_gid ;
		}
		$ioep_old_saved_gid=substr($_,560,10);
		if ($ioep_old_saved_gid eq ' ' x length($ioep_old_saved_gid)) {
			undef $ioep_old_saved_gid;
		}
		$ioep_dflt_process=substr($_,571,1);
		$ioep_utk_netw=substr($_,576,8);
		$ioep_x500_subject=substr($_,585,255);
		$ioep_x500_issuer=substr($_,841,255);
		$rv=$insert{initoedp}->execute($ioep_event_type,$ioep_event_qual,$ioep_time_written,$ioep_date_written,$ioep_system_smfid,$ioep_violation,$ioep_user_ndfnd,$ioep_user_warning,$ioep_evt_user_id,$ioep_evt_grp_id,$ioep_auth_normal,$ioep_auth_special,$ioep_auth_oper,$ioep_auth_audit,$ioep_auth_exit,$ioep_auth_failsft,$ioep_auth_bypass,$ioep_auth_trusted,$ioep_log_class,$ioep_log_user,$ioep_log_special,$ioep_log_access,$ioep_log_racinit,$ioep_log_always,$ioep_log_cmdviol,$ioep_log_global,$ioep_term_level,$ioep_backout_fail,$ioep_prof_same,$ioep_term,$ioep_job_name,$ioep_read_time,$ioep_read_date,$ioep_smf_user_id,$ioep_log_level,$ioep_log_vmevent,$ioep_log_logopt,$ioep_log_secl,$ioep_log_compatm,$ioep_log_applaud,$ioep_log_nonomvs,$ioep_log_omvsnprv,$ioep_auth_omvssu,$ioep_auth_omvssys,$ioep_usr_secl,$ioep_racf_version,$ioep_class,$ioep_user_name,$ioep_utk_encr,$ioep_utk_pre19,$ioep_utk_verprof,$ioep_utk_njeunusr,$ioep_utk_logusr,$ioep_utk_special,$ioep_utk_default,$ioep_utk_unknusr,$ioep_utk_error,$ioep_utk_trusted,$ioep_utk_sesstype,$ioep_utk_surrogat,$ioep_utk_remote,$ioep_utk_priv,$ioep_utk_secl,$ioep_utk_execnode,$ioep_utk_suser_id,$ioep_utk_snode,$ioep_utk_sgrp_id,$ioep_utk_spoe,$ioep_utk_spclass,$ioep_utk_user_id,$ioep_utk_grp_id,$ioep_utk_dft_grp,$ioep_utk_dft_secl,$ioep_appc_link,$ioep_audit_code,$ioep_old_real_uid,$ioep_old_eff_uid,$ioep_old_saved_uid,$ioep_old_real_gid,$ioep_old_eff_gid,$ioep_old_saved_gid,$ioep_dflt_process,$ioep_utk_netw,$ioep_x500_subject,$ioep_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"initoedp"}++;
		next;
	}

	if ($rectype eq 'IPCCHK  ') {
		$ichk_event_type=substr($_,0,8);
		$ichk_event_qual=substr($_,9,8);
		$ichk_time_written=substr($_,18,8);
		if ($ichk_time_written  eq ' ' x length($ichk_time_written )) {
			undef $ichk_time_written ;
		}
		$ichk_date_written=substr($_,27,10);
		if ($ichk_date_written  eq ' ' x length($ichk_date_written )) {
			undef $ichk_date_written ;
		}
		$ichk_system_smfid=substr($_,38,4);
		$ichk_violation=substr($_,43,1);
		$ichk_user_ndfnd=substr($_,48,1);
		$ichk_user_warning=substr($_,53,1);
		$ichk_evt_user_id=substr($_,58,8);
		$ichk_evt_grp_id=substr($_,67,8);
		$ichk_auth_normal=substr($_,76,1);
		$ichk_auth_special=substr($_,81,1);
		$ichk_auth_oper=substr($_,86,1);
		$ichk_auth_audit=substr($_,91,1);
		$ichk_auth_exit=substr($_,96,1);
		$ichk_auth_failsft=substr($_,101,1);
		$ichk_auth_bypass=substr($_,106,1);
		$ichk_auth_trusted=substr($_,111,1);
		$ichk_log_class=substr($_,116,1);
		$ichk_log_user=substr($_,121,1);
		$ichk_log_special=substr($_,126,1);
		$ichk_log_access=substr($_,131,1);
		$ichk_log_racinit=substr($_,136,1);
		$ichk_log_always=substr($_,141,1);
		$ichk_log_cmdviol=substr($_,146,1);
		$ichk_log_global=substr($_,151,1);
		$ichk_term_level=substr($_,156,3);
		if ($ichk_term_level  eq ' ' x length($ichk_term_level )) {
			undef $ichk_term_level ;
		}
		$ichk_backout_fail=substr($_,160,1);
		$ichk_prof_same=substr($_,165,1);
		$ichk_term=substr($_,170,8);
		$ichk_job_name=substr($_,179,8);
		$ichk_read_time=substr($_,188,8);
		if ($ichk_read_time  eq ' ' x length($ichk_read_time )) {
			undef $ichk_read_time ;
		}
		$ichk_read_date=substr($_,197,10);
		if ($ichk_read_date  eq ' ' x length($ichk_read_date )) {
			undef $ichk_read_date ;
		}
		$ichk_smf_user_id=substr($_,208,8);
		$ichk_log_level=substr($_,217,1);
		$ichk_log_vmevent=substr($_,222,1);
		$ichk_log_logopt=substr($_,227,1);
		$ichk_log_secl=substr($_,232,1);
		$ichk_log_compatm=substr($_,237,1);
		$ichk_log_applaud=substr($_,242,1);
		$ichk_log_nonomvs=substr($_,247,1);
		$ichk_log_omvsnprv=substr($_,252,1);
		$ichk_auth_omvssu=substr($_,257,1);
		$ichk_auth_omvssys=substr($_,262,1);
		$ichk_usr_secl=substr($_,267,8);
		$ichk_racf_version=substr($_,276,4);
		$ichk_class=substr($_,281,8);
		$ichk_user_name=substr($_,290,20);
		$ichk_utk_encr=substr($_,311,1);
		$ichk_utk_pre19=substr($_,316,1);
		$ichk_utk_verprof=substr($_,321,1);
		$ichk_utk_njeunusr=substr($_,326,1);
		$ichk_utk_logusr=substr($_,331,1);
		$ichk_utk_special=substr($_,336,1);
		$ichk_utk_default=substr($_,341,1);
		$ichk_utk_unknusr=substr($_,346,1);
		$ichk_utk_error=substr($_,351,1);
		$ichk_utk_trusted=substr($_,356,1);
		$ichk_utk_sesstype=substr($_,361,8);
		$ichk_utk_surrogat=substr($_,370,1);
		$ichk_utk_remote=substr($_,375,1);
		$ichk_utk_priv=substr($_,380,1);
		$ichk_utk_secl=substr($_,385,8);
		$ichk_utk_execnode=substr($_,394,8);
		$ichk_utk_suser_id=substr($_,403,8);
		$ichk_utk_snode=substr($_,412,8);
		$ichk_utk_sgrp_id=substr($_,421,8);
		$ichk_utk_spoe=substr($_,430,8);
		$ichk_utk_spclass=substr($_,439,8);
		$ichk_utk_user_id=substr($_,448,8);
		$ichk_utk_grp_id=substr($_,457,8);
		$ichk_utk_dft_grp=substr($_,466,1);
		$ichk_utk_dft_secl=substr($_,471,1);
		$ichk_appc_link=substr($_,476,16);
		$ichk_audit_code=substr($_,493,11);
		$ichk_old_real_uid=substr($_,505,10);
		if ($ichk_old_real_uid  eq ' ' x length($ichk_old_real_uid )) {
			undef $ichk_old_real_uid ;
		}
		$ichk_old_eff_uid=substr($_,516,10);
		if ($ichk_old_eff_uid  eq ' ' x length($ichk_old_eff_uid )) {
			undef $ichk_old_eff_uid ;
		}
		$ichk_old_saved_uid=substr($_,527,10);
		if ($ichk_old_saved_uid eq ' ' x length($ichk_old_saved_uid)) {
			undef $ichk_old_saved_uid;
		}
		$ichk_old_real_gid=substr($_,538,10);
		if ($ichk_old_real_gid  eq ' ' x length($ichk_old_real_gid )) {
			undef $ichk_old_real_gid ;
		}
		$ichk_old_eff_gid=substr($_,549,10);
		if ($ichk_old_eff_gid  eq ' ' x length($ichk_old_eff_gid )) {
			undef $ichk_old_eff_gid ;
		}
		$ichk_old_saved_gid=substr($_,560,10);
		if ($ichk_old_saved_gid eq ' ' x length($ichk_old_saved_gid)) {
			undef $ichk_old_saved_gid;
		}
		$ichk_key_own_uid=substr($_,571,10);
		if ($ichk_key_own_uid  eq ' ' x length($ichk_key_own_uid )) {
			undef $ichk_key_own_uid ;
		}
		$ichk_key_own_gid=substr($_,582,10);
		if ($ichk_key_own_gid  eq ' ' x length($ichk_key_own_gid )) {
			undef $ichk_key_own_gid ;
		}
		$ichk_request_read=substr($_,593,1);
		$ichk_request_write=substr($_,598,1);
		$ichk_request_exec=substr($_,603,1);
		$ichk_reserved_01=substr($_,608,1);
		$ichk_access_type=substr($_,613,8);
		$ichk_allowed_read=substr($_,622,1);
		$ichk_allowed_write=substr($_,627,1);
		$ichk_reserved_02=substr($_,632,1);
		$ichk_key=substr($_,637,8);
		$ichk_id=substr($_,646,10);
		if ($ichk_id  eq ' ' x length($ichk_id )) {
			undef $ichk_id ;
		}
		$ichk_creator_uid=substr($_,657,10);
		if ($ichk_creator_uid  eq ' ' x length($ichk_creator_uid )) {
			undef $ichk_creator_uid ;
		}
		$ichk_creator_gid=substr($_,668,10);
		if ($ichk_creator_gid  eq ' ' x length($ichk_creator_gid )) {
			undef $ichk_creator_gid ;
		}
		$ichk_dflt_process=substr($_,679,1);
		$ichk_utk_netw=substr($_,684,8);
		$ichk_x500_subject=substr($_,693,255);
		$ichk_x500_issuer=substr($_,949,255);
		$rv=$insert{ipcchk}->execute($ichk_event_type,$ichk_event_qual,$ichk_time_written,$ichk_date_written,$ichk_system_smfid,$ichk_violation,$ichk_user_ndfnd,$ichk_user_warning,$ichk_evt_user_id,$ichk_evt_grp_id,$ichk_auth_normal,$ichk_auth_special,$ichk_auth_oper,$ichk_auth_audit,$ichk_auth_exit,$ichk_auth_failsft,$ichk_auth_bypass,$ichk_auth_trusted,$ichk_log_class,$ichk_log_user,$ichk_log_special,$ichk_log_access,$ichk_log_racinit,$ichk_log_always,$ichk_log_cmdviol,$ichk_log_global,$ichk_term_level,$ichk_backout_fail,$ichk_prof_same,$ichk_term,$ichk_job_name,$ichk_read_time,$ichk_read_date,$ichk_smf_user_id,$ichk_log_level,$ichk_log_vmevent,$ichk_log_logopt,$ichk_log_secl,$ichk_log_compatm,$ichk_log_applaud,$ichk_log_nonomvs,$ichk_log_omvsnprv,$ichk_auth_omvssu,$ichk_auth_omvssys,$ichk_usr_secl,$ichk_racf_version,$ichk_class,$ichk_user_name,$ichk_utk_encr,$ichk_utk_pre19,$ichk_utk_verprof,$ichk_utk_njeunusr,$ichk_utk_logusr,$ichk_utk_special,$ichk_utk_default,$ichk_utk_unknusr,$ichk_utk_error,$ichk_utk_trusted,$ichk_utk_sesstype,$ichk_utk_surrogat,$ichk_utk_remote,$ichk_utk_priv,$ichk_utk_secl,$ichk_utk_execnode,$ichk_utk_suser_id,$ichk_utk_snode,$ichk_utk_sgrp_id,$ichk_utk_spoe,$ichk_utk_spclass,$ichk_utk_user_id,$ichk_utk_grp_id,$ichk_utk_dft_grp,$ichk_utk_dft_secl,$ichk_appc_link,$ichk_audit_code,$ichk_old_real_uid,$ichk_old_eff_uid,$ichk_old_saved_uid,$ichk_old_real_gid,$ichk_old_eff_gid,$ichk_old_saved_gid,$ichk_key_own_uid,$ichk_key_own_gid,$ichk_request_read,$ichk_request_write,$ichk_request_exec,$ichk_reserved_01,$ichk_access_type,$ichk_allowed_read,$ichk_allowed_write,$ichk_reserved_02,$ichk_key,$ichk_id,$ichk_creator_uid,$ichk_creator_gid,$ichk_dflt_process,$ichk_utk_netw,$ichk_x500_subject,$ichk_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ipcchk"}++;
		next;
	}

	if ($rectype eq 'IPCCTL  ') {
		$ictl_event_type=substr($_,0,8);
		$ictl_event_qual=substr($_,9,8);
		$ictl_time_written=substr($_,18,8);
		if ($ictl_time_written  eq ' ' x length($ictl_time_written )) {
			undef $ictl_time_written ;
		}
		$ictl_date_written=substr($_,27,10);
		if ($ictl_date_written  eq ' ' x length($ictl_date_written )) {
			undef $ictl_date_written ;
		}
		$ictl_system_smfid=substr($_,38,4);
		$ictl_violation=substr($_,43,1);
		$ictl_user_ndfnd=substr($_,48,1);
		$ictl_user_warning=substr($_,53,1);
		$ictl_evt_user_id=substr($_,58,8);
		$ictl_evt_grp_id=substr($_,67,8);
		$ictl_auth_normal=substr($_,76,1);
		$ictl_auth_special=substr($_,81,1);
		$ictl_auth_oper=substr($_,86,1);
		$ictl_auth_audit=substr($_,91,1);
		$ictl_auth_exit=substr($_,96,1);
		$ictl_auth_failsft=substr($_,101,1);
		$ictl_auth_bypass=substr($_,106,1);
		$ictl_auth_trusted=substr($_,111,1);
		$ictl_log_class=substr($_,116,1);
		$ictl_log_user=substr($_,121,1);
		$ictl_log_special=substr($_,126,1);
		$ictl_log_access=substr($_,131,1);
		$ictl_log_racinit=substr($_,136,1);
		$ictl_log_always=substr($_,141,1);
		$ictl_log_cmdviol=substr($_,146,1);
		$ictl_log_global=substr($_,151,1);
		$ictl_term_level=substr($_,156,3);
		if ($ictl_term_level  eq ' ' x length($ictl_term_level )) {
			undef $ictl_term_level ;
		}
		$ictl_backout_fail=substr($_,160,1);
		$ictl_prof_same=substr($_,165,1);
		$ictl_term=substr($_,170,8);
		$ictl_job_name=substr($_,179,8);
		$ictl_read_time=substr($_,188,8);
		if ($ictl_read_time  eq ' ' x length($ictl_read_time )) {
			undef $ictl_read_time ;
		}
		$ictl_read_date=substr($_,197,10);
		if ($ictl_read_date  eq ' ' x length($ictl_read_date )) {
			undef $ictl_read_date ;
		}
		$ictl_smf_user_id=substr($_,208,8);
		$ictl_log_level=substr($_,217,1);
		$ictl_log_vmevent=substr($_,222,1);
		$ictl_log_logopt=substr($_,227,1);
		$ictl_log_secl=substr($_,232,1);
		$ictl_log_compatm=substr($_,237,1);
		$ictl_log_applaud=substr($_,242,1);
		$ictl_log_nonomvs=substr($_,247,1);
		$ictl_log_omvsnprv=substr($_,252,1);
		$ictl_auth_omvssu=substr($_,257,1);
		$ictl_auth_omvssys=substr($_,262,1);
		$ictl_usr_secl=substr($_,267,8);
		$ictl_racf_version=substr($_,276,4);
		$ictl_class=substr($_,281,8);
		$ictl_user_name=substr($_,290,20);
		$ictl_utk_encr=substr($_,311,1);
		$ictl_utk_pre19=substr($_,316,1);
		$ictl_utk_verprof=substr($_,321,1);
		$ictl_utk_njeunusr=substr($_,326,1);
		$ictl_utk_logusr=substr($_,331,1);
		$ictl_utk_special=substr($_,336,1);
		$ictl_utk_default=substr($_,341,1);
		$ictl_utk_unknusr=substr($_,346,1);
		$ictl_utk_error=substr($_,351,1);
		$ictl_utk_trusted=substr($_,356,1);
		$ictl_utk_sesstype=substr($_,361,8);
		$ictl_utk_surrogat=substr($_,370,1);
		$ictl_utk_remote=substr($_,375,1);
		$ictl_utk_priv=substr($_,380,1);
		$ictl_utk_secl=substr($_,385,8);
		$ictl_utk_execnode=substr($_,394,8);
		$ictl_utk_suser_id=substr($_,403,8);
		$ictl_utk_snode=substr($_,412,8);
		$ictl_utk_sgrp_id=substr($_,421,8);
		$ictl_utk_spoe=substr($_,430,8);
		$ictl_utk_spclass=substr($_,439,8);
		$ictl_utk_user_id=substr($_,448,8);
		$ictl_utk_grp_id=substr($_,457,8);
		$ictl_utk_dft_grp=substr($_,466,1);
		$ictl_utk_dft_secl=substr($_,471,1);
		$ictl_appc_link=substr($_,476,16);
		$ictl_audit_code=substr($_,493,11);
		$ictl_old_real_uid=substr($_,505,10);
		if ($ictl_old_real_uid  eq ' ' x length($ictl_old_real_uid )) {
			undef $ictl_old_real_uid ;
		}
		$ictl_old_eff_uid=substr($_,516,10);
		if ($ictl_old_eff_uid  eq ' ' x length($ictl_old_eff_uid )) {
			undef $ictl_old_eff_uid ;
		}
		$ictl_old_saved_uid=substr($_,527,10);
		if ($ictl_old_saved_uid eq ' ' x length($ictl_old_saved_uid)) {
			undef $ictl_old_saved_uid;
		}
		$ictl_old_real_gid=substr($_,538,10);
		if ($ictl_old_real_gid  eq ' ' x length($ictl_old_real_gid )) {
			undef $ictl_old_real_gid ;
		}
		$ictl_old_eff_gid=substr($_,549,10);
		if ($ictl_old_eff_gid  eq ' ' x length($ictl_old_eff_gid )) {
			undef $ictl_old_eff_gid ;
		}
		$ictl_old_saved_gid=substr($_,560,10);
		if ($ictl_old_saved_gid eq ' ' x length($ictl_old_saved_gid)) {
			undef $ictl_old_saved_gid;
		}
		$ictl_key_own_uid=substr($_,571,10);
		if ($ictl_key_own_uid  eq ' ' x length($ictl_key_own_uid )) {
			undef $ictl_key_own_uid ;
		}
		$ictl_key_own_gid=substr($_,582,10);
		if ($ictl_key_own_gid  eq ' ' x length($ictl_key_own_gid )) {
			undef $ictl_key_own_gid ;
		}
		$ictl_uid=substr($_,593,10);
		if ($ictl_uid  eq ' ' x length($ictl_uid )) {
			undef $ictl_uid ;
		}
		$ictl_gid=substr($_,604,10);
		if ($ictl_gid  eq ' ' x length($ictl_gid )) {
			undef $ictl_gid ;
		}
		$ictl_reserved_01=substr($_,615,1);
		$ictl_reserved_02=substr($_,620,1);
		$ictl_reserved_03=substr($_,625,1);
		$ictl_old_own_read=substr($_,630,1);
		$ictl_old_own_write=substr($_,635,1);
		$ictl_old_own_exec=substr($_,640,1);
		$ictl_old_grp_read=substr($_,645,1);
		$ictl_old_grp_write=substr($_,650,1);
		$ictl_old_grp_exec=substr($_,655,1);
		$ictl_old_oth_read=substr($_,660,1);
		$ictl_old_oth_write=substr($_,665,1);
		$ictl_old_oth_exec=substr($_,670,1);
		$ictl_reserved_04=substr($_,675,1);
		$ictl_reserved_05=substr($_,680,1);
		$ictl_reserved_06=substr($_,685,1);
		$ictl_new_own_read=substr($_,690,1);
		$ictl_new_own_write=substr($_,695,1);
		$ictl_new_own_exec=substr($_,700,1);
		$ictl_new_grp_read=substr($_,705,1);
		$ictl_new_grp_write=substr($_,710,1);
		$ictl_new_grp_exec=substr($_,715,1);
		$ictl_new_oth_read=substr($_,720,1);
		$ictl_new_oth_write=substr($_,725,1);
		$ictl_new_oth_exec=substr($_,730,1);
		$ictl_service_code=substr($_,735,11);
		$ictl_reserved_07=substr($_,747,1);
		$ictl_reserved_08=substr($_,752,1);
		$ictl_reserved_09=substr($_,757,1);
		$ictl_req_own_read=substr($_,762,1);
		$ictl_req_own_write=substr($_,767,1);
		$ictl_req_own_exec=substr($_,772,1);
		$ictl_req_grp_read=substr($_,777,1);
		$ictl_req_grp_write=substr($_,782,1);
		$ictl_req_grp_exec=substr($_,787,1);
		$ictl_req_oth_read=substr($_,792,1);
		$ictl_req_oth_write=substr($_,797,1);
		$ictl_req_oth_exec=substr($_,802,1);
		$ictl_key=substr($_,807,8);
		$ictl_id=substr($_,816,10);
		if ($ictl_id  eq ' ' x length($ictl_id )) {
			undef $ictl_id ;
		}
		$ictl_creator_uid=substr($_,827,10);
		if ($ictl_creator_uid  eq ' ' x length($ictl_creator_uid )) {
			undef $ictl_creator_uid ;
		}
		$ictl_creator_gid=substr($_,838,10);
		if ($ictl_creator_gid  eq ' ' x length($ictl_creator_gid )) {
			undef $ictl_creator_gid ;
		}
		$ictl_dflt_process=substr($_,849,1);
		$ictl_utk_netw=substr($_,854,8);
		$ictl_x500_subject=substr($_,863,255);
		$ictl_x500_issuer=substr($_,1119,255);
		$rv=$insert{ipcctl}->execute($ictl_event_type,$ictl_event_qual,$ictl_time_written,$ictl_date_written,$ictl_system_smfid,$ictl_violation,$ictl_user_ndfnd,$ictl_user_warning,$ictl_evt_user_id,$ictl_evt_grp_id,$ictl_auth_normal,$ictl_auth_special,$ictl_auth_oper,$ictl_auth_audit,$ictl_auth_exit,$ictl_auth_failsft,$ictl_auth_bypass,$ictl_auth_trusted,$ictl_log_class,$ictl_log_user,$ictl_log_special,$ictl_log_access,$ictl_log_racinit,$ictl_log_always,$ictl_log_cmdviol,$ictl_log_global,$ictl_term_level,$ictl_backout_fail,$ictl_prof_same,$ictl_term,$ictl_job_name,$ictl_read_time,$ictl_read_date,$ictl_smf_user_id,$ictl_log_level,$ictl_log_vmevent,$ictl_log_logopt,$ictl_log_secl,$ictl_log_compatm,$ictl_log_applaud,$ictl_log_nonomvs,$ictl_log_omvsnprv,$ictl_auth_omvssu,$ictl_auth_omvssys,$ictl_usr_secl,$ictl_racf_version,$ictl_class,$ictl_user_name,$ictl_utk_encr,$ictl_utk_pre19,$ictl_utk_verprof,$ictl_utk_njeunusr,$ictl_utk_logusr,$ictl_utk_special,$ictl_utk_default,$ictl_utk_unknusr,$ictl_utk_error,$ictl_utk_trusted,$ictl_utk_sesstype,$ictl_utk_surrogat,$ictl_utk_remote,$ictl_utk_priv,$ictl_utk_secl,$ictl_utk_execnode,$ictl_utk_suser_id,$ictl_utk_snode,$ictl_utk_sgrp_id,$ictl_utk_spoe,$ictl_utk_spclass,$ictl_utk_user_id,$ictl_utk_grp_id,$ictl_utk_dft_grp,$ictl_utk_dft_secl,$ictl_appc_link,$ictl_audit_code,$ictl_old_real_uid,$ictl_old_eff_uid,$ictl_old_saved_uid,$ictl_old_real_gid,$ictl_old_eff_gid,$ictl_old_saved_gid,$ictl_key_own_uid,$ictl_key_own_gid,$ictl_uid,$ictl_gid,$ictl_reserved_01,$ictl_reserved_02,$ictl_reserved_03,$ictl_old_own_read,$ictl_old_own_write,$ictl_old_own_exec,$ictl_old_grp_read,$ictl_old_grp_write,$ictl_old_grp_exec,$ictl_old_oth_read,$ictl_old_oth_write,$ictl_old_oth_exec,$ictl_reserved_04,$ictl_reserved_05,$ictl_reserved_06,$ictl_new_own_read,$ictl_new_own_write,$ictl_new_own_exec,$ictl_new_grp_read,$ictl_new_grp_write,$ictl_new_grp_exec,$ictl_new_oth_read,$ictl_new_oth_write,$ictl_new_oth_exec,$ictl_service_code,$ictl_reserved_07,$ictl_reserved_08,$ictl_reserved_09,$ictl_req_own_read,$ictl_req_own_write,$ictl_req_own_exec,$ictl_req_grp_read,$ictl_req_grp_write,$ictl_req_grp_exec,$ictl_req_oth_read,$ictl_req_oth_write,$ictl_req_oth_exec,$ictl_key,$ictl_id,$ictl_creator_uid,$ictl_creator_gid,$ictl_dflt_process,$ictl_utk_netw,$ictl_x500_subject,$ictl_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ipcctl"}++;
		next;
	}

	if ($rectype eq 'IPCGET  ') {
		$iget_event_type=substr($_,0,8);
		$iget_event_qual=substr($_,9,8);
		$iget_time_written=substr($_,18,8);
		if ($iget_time_written  eq ' ' x length($iget_time_written )) {
			undef $iget_time_written ;
		}
		$iget_date_written=substr($_,27,10);
		if ($iget_date_written  eq ' ' x length($iget_date_written )) {
			undef $iget_date_written ;
		}
		$iget_system_smfid=substr($_,38,4);
		$iget_violation=substr($_,43,1);
		$iget_user_ndfnd=substr($_,48,1);
		$iget_user_warning=substr($_,53,1);
		$iget_evt_user_id=substr($_,58,8);
		$iget_evt_grp_id=substr($_,67,8);
		$iget_auth_normal=substr($_,76,1);
		$iget_auth_special=substr($_,81,1);
		$iget_auth_oper=substr($_,86,1);
		$iget_auth_audit=substr($_,91,1);
		$iget_auth_exit=substr($_,96,1);
		$iget_auth_failsft=substr($_,101,1);
		$iget_auth_bypass=substr($_,106,1);
		$iget_auth_trusted=substr($_,111,1);
		$iget_log_class=substr($_,116,1);
		$iget_log_user=substr($_,121,1);
		$iget_log_special=substr($_,126,1);
		$iget_log_access=substr($_,131,1);
		$iget_log_racinit=substr($_,136,1);
		$iget_log_always=substr($_,141,1);
		$iget_log_cmdviol=substr($_,146,1);
		$iget_log_global=substr($_,151,1);
		$iget_term_level=substr($_,156,3);
		if ($iget_term_level  eq ' ' x length($iget_term_level )) {
			undef $iget_term_level ;
		}
		$iget_backout_fail=substr($_,160,1);
		$iget_prof_same=substr($_,165,1);
		$iget_term=substr($_,170,8);
		$iget_job_name=substr($_,179,8);
		$iget_read_time=substr($_,188,8);
		if ($iget_read_time  eq ' ' x length($iget_read_time )) {
			undef $iget_read_time ;
		}
		$iget_read_date=substr($_,197,10);
		if ($iget_read_date  eq ' ' x length($iget_read_date )) {
			undef $iget_read_date ;
		}
		$iget_smf_user_id=substr($_,208,8);
		$iget_log_level=substr($_,217,1);
		$iget_log_vmevent=substr($_,222,1);
		$iget_log_logopt=substr($_,227,1);
		$iget_log_secl=substr($_,232,1);
		$iget_log_compatm=substr($_,237,1);
		$iget_log_applaud=substr($_,242,1);
		$iget_log_nonomvs=substr($_,247,1);
		$iget_log_omvsnprv=substr($_,252,1);
		$iget_auth_omvssu=substr($_,257,1);
		$iget_auth_omvssys=substr($_,262,1);
		$iget_usr_secl=substr($_,267,8);
		$iget_racf_version=substr($_,276,4);
		$iget_class=substr($_,281,8);
		$iget_user_name=substr($_,290,20);
		$iget_utk_encr=substr($_,311,1);
		$iget_utk_pre19=substr($_,316,1);
		$iget_utk_verprof=substr($_,321,1);
		$iget_utk_njeunusr=substr($_,326,1);
		$iget_utk_logusr=substr($_,331,1);
		$iget_utk_special=substr($_,336,1);
		$iget_utk_default=substr($_,341,1);
		$iget_utk_unknusr=substr($_,346,1);
		$iget_utk_error=substr($_,351,1);
		$iget_utk_trusted=substr($_,356,1);
		$iget_utk_sesstype=substr($_,361,8);
		$iget_utk_surrogat=substr($_,370,1);
		$iget_utk_remote=substr($_,375,1);
		$iget_utk_priv=substr($_,380,1);
		$iget_utk_secl=substr($_,385,8);
		$iget_utk_execnode=substr($_,394,8);
		$iget_utk_suser_id=substr($_,403,8);
		$iget_utk_snode=substr($_,412,8);
		$iget_utk_sgrp_id=substr($_,421,8);
		$iget_utk_spoe=substr($_,430,8);
		$iget_utk_spclass=substr($_,439,8);
		$iget_utk_user_id=substr($_,448,8);
		$iget_utk_grp_id=substr($_,457,8);
		$iget_utk_dft_grp=substr($_,466,1);
		$iget_utk_dft_secl=substr($_,471,1);
		$iget_appc_link=substr($_,476,16);
		$iget_audit_code=substr($_,493,11);
		$iget_old_real_uid=substr($_,505,10);
		if ($iget_old_real_uid  eq ' ' x length($iget_old_real_uid )) {
			undef $iget_old_real_uid ;
		}
		$iget_old_eff_uid=substr($_,516,10);
		if ($iget_old_eff_uid  eq ' ' x length($iget_old_eff_uid )) {
			undef $iget_old_eff_uid ;
		}
		$iget_old_saved_uid=substr($_,527,10);
		if ($iget_old_saved_uid eq ' ' x length($iget_old_saved_uid)) {
			undef $iget_old_saved_uid;
		}
		$iget_old_real_gid=substr($_,538,10);
		if ($iget_old_real_gid  eq ' ' x length($iget_old_real_gid )) {
			undef $iget_old_real_gid ;
		}
		$iget_old_eff_gid=substr($_,549,10);
		if ($iget_old_eff_gid  eq ' ' x length($iget_old_eff_gid )) {
			undef $iget_old_eff_gid ;
		}
		$iget_old_saved_gid=substr($_,560,10);
		if ($iget_old_saved_gid eq ' ' x length($iget_old_saved_gid)) {
			undef $iget_old_saved_gid;
		}
		$iget_key_own_uid=substr($_,571,10);
		if ($iget_key_own_uid  eq ' ' x length($iget_key_own_uid )) {
			undef $iget_key_own_uid ;
		}
		$iget_key_own_gid=substr($_,582,10);
		if ($iget_key_own_gid  eq ' ' x length($iget_key_own_gid )) {
			undef $iget_key_own_gid ;
		}
		$iget_reserved_01=substr($_,593,1);
		$iget_reserved_02=substr($_,598,1);
		$iget_reserved_03=substr($_,603,1);
		$iget_req_own_read=substr($_,608,1);
		$iget_req_own_write=substr($_,613,1);
		$iget_req_own_exec=substr($_,618,1);
		$iget_req_grp_read=substr($_,623,1);
		$iget_req_grp_write=substr($_,628,1);
		$iget_req_grp_exec=substr($_,633,1);
		$iget_req_oth_read=substr($_,638,1);
		$iget_req_oth_write=substr($_,643,1);
		$iget_req_oth_exec=substr($_,648,1);
		$iget_key=substr($_,653,8);
		$iget_id=substr($_,662,10);
		if ($iget_id  eq ' ' x length($iget_id )) {
			undef $iget_id ;
		}
		$iget_creator_uid=substr($_,673,10);
		if ($iget_creator_uid  eq ' ' x length($iget_creator_uid )) {
			undef $iget_creator_uid ;
		}
		$iget_creator_gid=substr($_,684,10);
		if ($iget_creator_gid  eq ' ' x length($iget_creator_gid )) {
			undef $iget_creator_gid ;
		}
		$iget_dflt_process=substr($_,695,1);
		$iget_utk_netw=substr($_,700,8);
		$iget_x500_subject=substr($_,709,255);
		$iget_x500_issuer=substr($_,965,255);
		$rv=$insert{ipcget}->execute($iget_event_type,$iget_event_qual,$iget_time_written,$iget_date_written,$iget_system_smfid,$iget_violation,$iget_user_ndfnd,$iget_user_warning,$iget_evt_user_id,$iget_evt_grp_id,$iget_auth_normal,$iget_auth_special,$iget_auth_oper,$iget_auth_audit,$iget_auth_exit,$iget_auth_failsft,$iget_auth_bypass,$iget_auth_trusted,$iget_log_class,$iget_log_user,$iget_log_special,$iget_log_access,$iget_log_racinit,$iget_log_always,$iget_log_cmdviol,$iget_log_global,$iget_term_level,$iget_backout_fail,$iget_prof_same,$iget_term,$iget_job_name,$iget_read_time,$iget_read_date,$iget_smf_user_id,$iget_log_level,$iget_log_vmevent,$iget_log_logopt,$iget_log_secl,$iget_log_compatm,$iget_log_applaud,$iget_log_nonomvs,$iget_log_omvsnprv,$iget_auth_omvssu,$iget_auth_omvssys,$iget_usr_secl,$iget_racf_version,$iget_class,$iget_user_name,$iget_utk_encr,$iget_utk_pre19,$iget_utk_verprof,$iget_utk_njeunusr,$iget_utk_logusr,$iget_utk_special,$iget_utk_default,$iget_utk_unknusr,$iget_utk_error,$iget_utk_trusted,$iget_utk_sesstype,$iget_utk_surrogat,$iget_utk_remote,$iget_utk_priv,$iget_utk_secl,$iget_utk_execnode,$iget_utk_suser_id,$iget_utk_snode,$iget_utk_sgrp_id,$iget_utk_spoe,$iget_utk_spclass,$iget_utk_user_id,$iget_utk_grp_id,$iget_utk_dft_grp,$iget_utk_dft_secl,$iget_appc_link,$iget_audit_code,$iget_old_real_uid,$iget_old_eff_uid,$iget_old_saved_uid,$iget_old_real_gid,$iget_old_eff_gid,$iget_old_saved_gid,$iget_key_own_uid,$iget_key_own_gid,$iget_reserved_01,$iget_reserved_02,$iget_reserved_03,$iget_req_own_read,$iget_req_own_write,$iget_req_own_exec,$iget_req_grp_read,$iget_req_grp_write,$iget_req_grp_exec,$iget_req_oth_read,$iget_req_oth_write,$iget_req_oth_exec,$iget_key,$iget_id,$iget_creator_uid,$iget_creator_gid,$iget_dflt_process,$iget_utk_netw,$iget_x500_subject,$iget_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ipcget"}++;
		next;
	}

	if ($rectype eq 'JOBINIT ') {
		$init_event_type=substr($_,0,8);
		$init_event_qual=substr($_,9,8);
		$init_time_written=substr($_,18,8);
		if ($init_time_written  eq ' ' x length($init_time_written )) {
			undef $init_time_written ;
		}
		$init_date_written=substr($_,27,10);
		if ($init_date_written  eq ' ' x length($init_date_written )) {
			undef $init_date_written ;
		}
		$init_system_smfid=substr($_,38,4);
		$init_violation=substr($_,43,1);
		$init_user_ndfnd=substr($_,48,1);
		$init_user_warning=substr($_,53,1);
		$init_evt_user_id=substr($_,58,8);
		$init_evt_grp_id=substr($_,67,8);
		$init_auth_normal=substr($_,76,1);
		$init_auth_special=substr($_,81,1);
		$init_auth_oper=substr($_,86,1);
		$init_auth_audit=substr($_,91,1);
		$init_auth_exit=substr($_,96,1);
		$init_auth_failsft=substr($_,101,1);
		$init_auth_bypass=substr($_,106,1);
		$init_auth_trusted=substr($_,111,1);
		$init_log_class=substr($_,116,1);
		$init_log_user=substr($_,121,1);
		$init_log_special=substr($_,126,1);
		$init_log_access=substr($_,131,1);
		$init_log_racinit=substr($_,136,1);
		$init_log_always=substr($_,141,1);
		$init_log_cmdviol=substr($_,146,1);
		$init_log_global=substr($_,151,1);
		$init_term_level=substr($_,156,3);
		if ($init_term_level  eq ' ' x length($init_term_level )) {
			undef $init_term_level ;
		}
		$init_backout_fail=substr($_,160,1);
		$init_prof_same=substr($_,165,1);
		$init_term=substr($_,170,8);
		$init_job_name=substr($_,179,8);
		$init_read_time=substr($_,188,8);
		if ($init_read_time  eq ' ' x length($init_read_time )) {
			undef $init_read_time ;
		}
		$init_read_date=substr($_,197,10);
		if ($init_read_date  eq ' ' x length($init_read_date )) {
			undef $init_read_date ;
		}
		$init_smf_user_id=substr($_,208,8);
		$init_log_level=substr($_,217,1);
		$init_log_vmevent=substr($_,222,1);
		$init_log_logopt=substr($_,227,1);
		$init_log_secl=substr($_,232,1);
		$init_log_compatm=substr($_,237,1);
		$init_log_applaud=substr($_,242,1);
		$init_log_nonomvs=substr($_,247,1);
		$init_log_omvsnprv=substr($_,252,1);
		$init_auth_omvssu=substr($_,257,1);
		$init_auth_omvssys=substr($_,262,1);
		$init_usr_secl=substr($_,267,8);
		$init_racf_version=substr($_,276,4);
		$init_appl=substr($_,281,8);
		$init_logstr=substr($_,290,255);
		$init_bad_jobname=substr($_,546,8);
		$init_user_name=substr($_,555,20);
		$init_utk_encr=substr($_,576,1);
		$init_utk_pre19=substr($_,581,1);
		$init_utk_verprof=substr($_,586,1);
		$init_utk_njeunusr=substr($_,591,1);
		$init_utk_logusr=substr($_,596,1);
		$init_utk_special=substr($_,601,1);
		$init_utk_default=substr($_,606,1);
		$init_utk_unknusr=substr($_,611,1);
		$init_utk_error=substr($_,616,1);
		$init_utk_trusted=substr($_,621,1);
		$init_utk_sesstype=substr($_,626,8);
		$init_utk_surrogat=substr($_,635,1);
		$init_utk_remote=substr($_,640,1);
		$init_utk_priv=substr($_,645,1);
		$init_utk_secl=substr($_,650,8);
		$init_utk_execnode=substr($_,659,8);
		$init_utk_suser_id=substr($_,668,8);
		$init_utk_snode=substr($_,677,8);
		$init_utk_sgrp_id=substr($_,686,8);
		$init_utk_spoe=substr($_,695,8);
		$init_utk_spclass=substr($_,704,8);
		$init_utk_user_id=substr($_,713,8);
		$init_utk_grp_id=substr($_,722,8);
		$init_utk_dft_grp=substr($_,731,1);
		$init_utk_dft_secl=substr($_,736,1);
		$init_appc_link=substr($_,741,16);
		$init_utk_netw=substr($_,758,8);
		$init_res_name=substr($_,767,255);
		$init_class=substr($_,1023,8);
		$init_x500_subject=substr($_,1032,255);
		$init_x500_issuer=substr($_,1288,255);
		$rv=$insert{jobinit}->execute($init_event_type,$init_event_qual,$init_time_written,$init_date_written,$init_system_smfid,$init_violation,$init_user_ndfnd,$init_user_warning,$init_evt_user_id,$init_evt_grp_id,$init_auth_normal,$init_auth_special,$init_auth_oper,$init_auth_audit,$init_auth_exit,$init_auth_failsft,$init_auth_bypass,$init_auth_trusted,$init_log_class,$init_log_user,$init_log_special,$init_log_access,$init_log_racinit,$init_log_always,$init_log_cmdviol,$init_log_global,$init_term_level,$init_backout_fail,$init_prof_same,$init_term,$init_job_name,$init_read_time,$init_read_date,$init_smf_user_id,$init_log_level,$init_log_vmevent,$init_log_logopt,$init_log_secl,$init_log_compatm,$init_log_applaud,$init_log_nonomvs,$init_log_omvsnprv,$init_auth_omvssu,$init_auth_omvssys,$init_usr_secl,$init_racf_version,$init_appl,$init_logstr,$init_bad_jobname,$init_user_name,$init_utk_encr,$init_utk_pre19,$init_utk_verprof,$init_utk_njeunusr,$init_utk_logusr,$init_utk_special,$init_utk_default,$init_utk_unknusr,$init_utk_error,$init_utk_trusted,$init_utk_sesstype,$init_utk_surrogat,$init_utk_remote,$init_utk_priv,$init_utk_secl,$init_utk_execnode,$init_utk_suser_id,$init_utk_snode,$init_utk_sgrp_id,$init_utk_spoe,$init_utk_spclass,$init_utk_user_id,$init_utk_grp_id,$init_utk_dft_grp,$init_utk_dft_secl,$init_appc_link,$init_utk_netw,$init_res_name,$init_class,$init_x500_subject,$init_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"jobinit"}++;
		next;
	}

	if ($rectype eq 'KILL    ') {
		$kill_event_type=substr($_,0,8);
		$kill_event_qual=substr($_,9,8);
		$kill_time_written=substr($_,18,8);
		if ($kill_time_written  eq ' ' x length($kill_time_written )) {
			undef $kill_time_written ;
		}
		$kill_date_written=substr($_,27,10);
		if ($kill_date_written  eq ' ' x length($kill_date_written )) {
			undef $kill_date_written ;
		}
		$kill_system_smfid=substr($_,38,4);
		$kill_violation=substr($_,43,1);
		$kill_user_ndfnd=substr($_,48,1);
		$kill_user_warning=substr($_,53,1);
		$kill_evt_user_id=substr($_,58,8);
		$kill_evt_grp_id=substr($_,67,8);
		$kill_auth_normal=substr($_,76,1);
		$kill_auth_special=substr($_,81,1);
		$kill_auth_oper=substr($_,86,1);
		$kill_auth_audit=substr($_,91,1);
		$kill_auth_exit=substr($_,96,1);
		$kill_auth_failsft=substr($_,101,1);
		$kill_auth_bypass=substr($_,106,1);
		$kill_auth_trusted=substr($_,111,1);
		$kill_log_class=substr($_,116,1);
		$kill_log_user=substr($_,121,1);
		$kill_log_special=substr($_,126,1);
		$kill_log_access=substr($_,131,1);
		$kill_log_racinit=substr($_,136,1);
		$kill_log_always=substr($_,141,1);
		$kill_log_cmdviol=substr($_,146,1);
		$kill_log_global=substr($_,151,1);
		$kill_term_level=substr($_,156,3);
		if ($kill_term_level  eq ' ' x length($kill_term_level )) {
			undef $kill_term_level ;
		}
		$kill_backout_fail=substr($_,160,1);
		$kill_prof_same=substr($_,165,1);
		$kill_term=substr($_,170,8);
		$kill_job_name=substr($_,179,8);
		$kill_read_time=substr($_,188,8);
		if ($kill_read_time  eq ' ' x length($kill_read_time )) {
			undef $kill_read_time ;
		}
		$kill_read_date=substr($_,197,10);
		if ($kill_read_date  eq ' ' x length($kill_read_date )) {
			undef $kill_read_date ;
		}
		$kill_smf_user_id=substr($_,208,8);
		$kill_log_level=substr($_,217,1);
		$kill_log_vmevent=substr($_,222,1);
		$kill_log_logopt=substr($_,227,1);
		$kill_log_secl=substr($_,232,1);
		$kill_log_compatm=substr($_,237,1);
		$kill_log_applaud=substr($_,242,1);
		$kill_log_nonomvs=substr($_,247,1);
		$kill_log_omvsnprv=substr($_,252,1);
		$kill_auth_omvssu=substr($_,257,1);
		$kill_auth_omvssys=substr($_,262,1);
		$kill_usr_secl=substr($_,267,8);
		$kill_racf_version=substr($_,276,4);
		$kill_class=substr($_,281,8);
		$kill_user_name=substr($_,290,20);
		$kill_utk_encr=substr($_,311,1);
		$kill_utk_pre19=substr($_,316,1);
		$kill_utk_verprof=substr($_,321,1);
		$kill_utk_njeunusr=substr($_,326,1);
		$kill_utk_logusr=substr($_,331,1);
		$kill_utk_special=substr($_,336,1);
		$kill_utk_default=substr($_,341,1);
		$kill_utk_unknusr=substr($_,346,1);
		$kill_utk_error=substr($_,351,1);
		$kill_utk_trusted=substr($_,356,1);
		$kill_utk_sesstype=substr($_,361,8);
		$kill_utk_surrogat=substr($_,370,1);
		$kill_utk_remote=substr($_,375,1);
		$kill_utk_priv=substr($_,380,1);
		$kill_utk_secl=substr($_,385,8);
		$kill_utk_execnode=substr($_,394,8);
		$kill_utk_suser_id=substr($_,403,8);
		$kill_utk_snode=substr($_,412,8);
		$kill_utk_sgrp_id=substr($_,421,8);
		$kill_utk_spoe=substr($_,430,8);
		$kill_utk_spclass=substr($_,439,8);
		$kill_utk_user_id=substr($_,448,8);
		$kill_utk_grp_id=substr($_,457,8);
		$kill_utk_dft_grp=substr($_,466,1);
		$kill_utk_dft_secl=substr($_,471,1);
		$kill_appc_link=substr($_,476,16);
		$kill_audit_code=substr($_,493,11);
		$kill_old_real_uid=substr($_,505,10);
		if ($kill_old_real_uid  eq ' ' x length($kill_old_real_uid )) {
			undef $kill_old_real_uid ;
		}
		$kill_old_eff_uid=substr($_,516,10);
		if ($kill_old_eff_uid  eq ' ' x length($kill_old_eff_uid )) {
			undef $kill_old_eff_uid ;
		}
		$kill_old_saved_uid=substr($_,527,10);
		if ($kill_old_saved_uid eq ' ' x length($kill_old_saved_uid)) {
			undef $kill_old_saved_uid;
		}
		$kill_old_real_gid=substr($_,538,10);
		if ($kill_old_real_gid  eq ' ' x length($kill_old_real_gid )) {
			undef $kill_old_real_gid ;
		}
		$kill_old_eff_gid=substr($_,549,10);
		if ($kill_old_eff_gid  eq ' ' x length($kill_old_eff_gid )) {
			undef $kill_old_eff_gid ;
		}
		$kill_old_saved_gid=substr($_,560,10);
		if ($kill_old_saved_gid eq ' ' x length($kill_old_saved_gid)) {
			undef $kill_old_saved_gid;
		}
		$kill_tgt_real_uid=substr($_,571,10);
		if ($kill_tgt_real_uid  eq ' ' x length($kill_tgt_real_uid )) {
			undef $kill_tgt_real_uid ;
		}
		$kill_tgt_eff_uid=substr($_,582,10);
		if ($kill_tgt_eff_uid  eq ' ' x length($kill_tgt_eff_uid )) {
			undef $kill_tgt_eff_uid ;
		}
		$kill_tgt_sav_uid=substr($_,593,10);
		if ($kill_tgt_sav_uid  eq ' ' x length($kill_tgt_sav_uid )) {
			undef $kill_tgt_sav_uid ;
		}
		$kill_tgt_pid=substr($_,604,10);
		if ($kill_tgt_pid  eq ' ' x length($kill_tgt_pid )) {
			undef $kill_tgt_pid ;
		}
		$kill_signal_code=substr($_,615,10);
		if ($kill_signal_code  eq ' ' x length($kill_signal_code )) {
			undef $kill_signal_code ;
		}
		$kill_dflt_process=substr($_,626,1);
		$kill_utk_netw=substr($_,631,8);
		$kill_x500_subject=substr($_,640,255);
		$kill_x500_issuer=substr($_,896,255);
		$rv=$insert{kill}->execute($kill_event_type,$kill_event_qual,$kill_time_written,$kill_date_written,$kill_system_smfid,$kill_violation,$kill_user_ndfnd,$kill_user_warning,$kill_evt_user_id,$kill_evt_grp_id,$kill_auth_normal,$kill_auth_special,$kill_auth_oper,$kill_auth_audit,$kill_auth_exit,$kill_auth_failsft,$kill_auth_bypass,$kill_auth_trusted,$kill_log_class,$kill_log_user,$kill_log_special,$kill_log_access,$kill_log_racinit,$kill_log_always,$kill_log_cmdviol,$kill_log_global,$kill_term_level,$kill_backout_fail,$kill_prof_same,$kill_term,$kill_job_name,$kill_read_time,$kill_read_date,$kill_smf_user_id,$kill_log_level,$kill_log_vmevent,$kill_log_logopt,$kill_log_secl,$kill_log_compatm,$kill_log_applaud,$kill_log_nonomvs,$kill_log_omvsnprv,$kill_auth_omvssu,$kill_auth_omvssys,$kill_usr_secl,$kill_racf_version,$kill_class,$kill_user_name,$kill_utk_encr,$kill_utk_pre19,$kill_utk_verprof,$kill_utk_njeunusr,$kill_utk_logusr,$kill_utk_special,$kill_utk_default,$kill_utk_unknusr,$kill_utk_error,$kill_utk_trusted,$kill_utk_sesstype,$kill_utk_surrogat,$kill_utk_remote,$kill_utk_priv,$kill_utk_secl,$kill_utk_execnode,$kill_utk_suser_id,$kill_utk_snode,$kill_utk_sgrp_id,$kill_utk_spoe,$kill_utk_spclass,$kill_utk_user_id,$kill_utk_grp_id,$kill_utk_dft_grp,$kill_utk_dft_secl,$kill_appc_link,$kill_audit_code,$kill_old_real_uid,$kill_old_eff_uid,$kill_old_saved_uid,$kill_old_real_gid,$kill_old_eff_gid,$kill_old_saved_gid,$kill_tgt_real_uid,$kill_tgt_eff_uid,$kill_tgt_sav_uid,$kill_tgt_pid,$kill_signal_code,$kill_dflt_process,$kill_utk_netw,$kill_x500_subject,$kill_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"kill"}++;
		next;
	}

	if ($rectype eq 'KTICKET ') {
		$ktkt_event_type=substr($_,0,8);
		$ktkt_event_qual=substr($_,9,8);
		$ktkt_time_written=substr($_,18,8);
		if ($ktkt_time_written  eq ' ' x length($ktkt_time_written )) {
			undef $ktkt_time_written ;
		}
		$ktkt_date_written=substr($_,27,10);
		if ($ktkt_date_written  eq ' ' x length($ktkt_date_written )) {
			undef $ktkt_date_written ;
		}
		$ktkt_system_smfid=substr($_,38,4);
		$ktkt_violation=substr($_,43,1);
		$ktkt_user_ndfnd=substr($_,48,1);
		$ktkt_user_warning=substr($_,53,1);
		$ktkt_evt_user_id=substr($_,58,8);
		$ktkt_evt_grp_id=substr($_,67,8);
		$ktkt_auth_normal=substr($_,76,1);
		$ktkt_auth_special=substr($_,81,1);
		$ktkt_auth_oper=substr($_,86,1);
		$ktkt_auth_audit=substr($_,91,1);
		$ktkt_auth_exit=substr($_,96,1);
		$ktkt_auth_failsft=substr($_,101,1);
		$ktkt_auth_bypass=substr($_,106,1);
		$ktkt_auth_trusted=substr($_,111,1);
		$ktkt_log_class=substr($_,116,1);
		$ktkt_log_user=substr($_,121,1);
		$ktkt_log_special=substr($_,126,1);
		$ktkt_log_access=substr($_,131,1);
		$ktkt_log_racinit=substr($_,136,1);
		$ktkt_log_always=substr($_,141,1);
		$ktkt_log_cmdviol=substr($_,146,1);
		$ktkt_log_global=substr($_,151,1);
		$ktkt_term_level=substr($_,156,3);
		if ($ktkt_term_level  eq ' ' x length($ktkt_term_level )) {
			undef $ktkt_term_level ;
		}
		$ktkt_backout_fail=substr($_,160,1);
		$ktkt_prof_same=substr($_,165,1);
		$ktkt_term=substr($_,170,8);
		$ktkt_job_name=substr($_,179,8);
		$ktkt_read_time=substr($_,188,8);
		if ($ktkt_read_time  eq ' ' x length($ktkt_read_time )) {
			undef $ktkt_read_time ;
		}
		$ktkt_read_date=substr($_,197,10);
		if ($ktkt_read_date  eq ' ' x length($ktkt_read_date )) {
			undef $ktkt_read_date ;
		}
		$ktkt_smf_user_id=substr($_,208,8);
		$ktkt_log_level=substr($_,217,1);
		$ktkt_log_vmevent=substr($_,222,1);
		$ktkt_log_logopt=substr($_,227,1);
		$ktkt_log_secl=substr($_,232,1);
		$ktkt_log_compatm=substr($_,237,1);
		$ktkt_log_applaud=substr($_,242,1);
		$ktkt_log_nonomvs=substr($_,247,1);
		$ktkt_log_omvsnprv=substr($_,252,1);
		$ktkt_auth_omvssu=substr($_,257,1);
		$ktkt_auth_omvssys=substr($_,262,1);
		$ktkt_usr_secl=substr($_,267,8);
		$ktkt_racf_version=substr($_,276,4);
		$ktkt_principal=substr($_,281,240);
		$ktkt_login_source=substr($_,522,22);
		$ktkt_kdc_stat_code=substr($_,545,10);
		$rv=$insert{kticket}->execute($ktkt_event_type,$ktkt_event_qual,$ktkt_time_written,$ktkt_date_written,$ktkt_system_smfid,$ktkt_violation,$ktkt_user_ndfnd,$ktkt_user_warning,$ktkt_evt_user_id,$ktkt_evt_grp_id,$ktkt_auth_normal,$ktkt_auth_special,$ktkt_auth_oper,$ktkt_auth_audit,$ktkt_auth_exit,$ktkt_auth_failsft,$ktkt_auth_bypass,$ktkt_auth_trusted,$ktkt_log_class,$ktkt_log_user,$ktkt_log_special,$ktkt_log_access,$ktkt_log_racinit,$ktkt_log_always,$ktkt_log_cmdviol,$ktkt_log_global,$ktkt_term_level,$ktkt_backout_fail,$ktkt_prof_same,$ktkt_term,$ktkt_job_name,$ktkt_read_time,$ktkt_read_date,$ktkt_smf_user_id,$ktkt_log_level,$ktkt_log_vmevent,$ktkt_log_logopt,$ktkt_log_secl,$ktkt_log_compatm,$ktkt_log_applaud,$ktkt_log_nonomvs,$ktkt_log_omvsnprv,$ktkt_auth_omvssu,$ktkt_auth_omvssys,$ktkt_usr_secl,$ktkt_racf_version,$ktkt_principal,$ktkt_login_source,$ktkt_kdc_stat_code);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"kticket"}++;
		next;
	}

	if ($rectype eq 'LINK    ') {
		$link_event_type=substr($_,0,8);
		$link_event_qual=substr($_,9,8);
		$link_time_written=substr($_,18,8);
		if ($link_time_written  eq ' ' x length($link_time_written )) {
			undef $link_time_written ;
		}
		$link_date_written=substr($_,27,10);
		if ($link_date_written  eq ' ' x length($link_date_written )) {
			undef $link_date_written ;
		}
		$link_system_smfid=substr($_,38,4);
		$link_violation=substr($_,43,1);
		$link_user_ndfnd=substr($_,48,1);
		$link_user_warning=substr($_,53,1);
		$link_evt_user_id=substr($_,58,8);
		$link_evt_grp_id=substr($_,67,8);
		$link_auth_normal=substr($_,76,1);
		$link_auth_special=substr($_,81,1);
		$link_auth_oper=substr($_,86,1);
		$link_auth_audit=substr($_,91,1);
		$link_auth_exit=substr($_,96,1);
		$link_auth_failsft=substr($_,101,1);
		$link_auth_bypass=substr($_,106,1);
		$link_auth_trusted=substr($_,111,1);
		$link_log_class=substr($_,116,1);
		$link_log_user=substr($_,121,1);
		$link_log_special=substr($_,126,1);
		$link_log_access=substr($_,131,1);
		$link_log_racinit=substr($_,136,1);
		$link_log_always=substr($_,141,1);
		$link_log_cmdviol=substr($_,146,1);
		$link_log_global=substr($_,151,1);
		$link_term_level=substr($_,156,3);
		if ($link_term_level  eq ' ' x length($link_term_level )) {
			undef $link_term_level ;
		}
		$link_backout_fail=substr($_,160,1);
		$link_prof_same=substr($_,165,1);
		$link_term=substr($_,170,8);
		$link_job_name=substr($_,179,8);
		$link_read_time=substr($_,188,8);
		if ($link_read_time  eq ' ' x length($link_read_time )) {
			undef $link_read_time ;
		}
		$link_read_date=substr($_,197,10);
		if ($link_read_date  eq ' ' x length($link_read_date )) {
			undef $link_read_date ;
		}
		$link_smf_user_id=substr($_,208,8);
		$link_log_level=substr($_,217,1);
		$link_log_vmevent=substr($_,222,1);
		$link_log_logopt=substr($_,227,1);
		$link_log_secl=substr($_,232,1);
		$link_log_compatm=substr($_,237,1);
		$link_log_applaud=substr($_,242,1);
		$link_log_nonomvs=substr($_,247,1);
		$link_log_omvsnprv=substr($_,252,1);
		$link_auth_omvssu=substr($_,257,1);
		$link_auth_omvssys=substr($_,262,1);
		$link_usr_secl=substr($_,267,8);
		$link_racf_version=substr($_,276,4);
		$link_class=substr($_,281,8);
		$link_user_name=substr($_,290,20);
		$link_utk_encr=substr($_,311,1);
		$link_utk_pre19=substr($_,316,1);
		$link_utk_verprof=substr($_,321,1);
		$link_utk_njeunusr=substr($_,326,1);
		$link_utk_logusr=substr($_,331,1);
		$link_utk_special=substr($_,336,1);
		$link_utk_default=substr($_,341,1);
		$link_utk_unknusr=substr($_,346,1);
		$link_utk_error=substr($_,351,1);
		$link_utk_trusted=substr($_,356,1);
		$link_utk_sesstype=substr($_,361,8);
		$link_utk_surrogat=substr($_,370,1);
		$link_utk_remote=substr($_,375,1);
		$link_utk_priv=substr($_,380,1);
		$link_utk_secl=substr($_,385,8);
		$link_utk_execnode=substr($_,394,8);
		$link_utk_suser_id=substr($_,403,8);
		$link_utk_snode=substr($_,412,8);
		$link_utk_sgrp_id=substr($_,421,8);
		$link_utk_spoe=substr($_,430,8);
		$link_utk_spclass=substr($_,439,8);
		$link_utk_user_id=substr($_,448,8);
		$link_utk_grp_id=substr($_,457,8);
		$link_utk_dft_grp=substr($_,466,1);
		$link_utk_dft_secl=substr($_,471,1);
		$link_appc_link=substr($_,476,16);
		$link_audit_code=substr($_,493,11);
		$link_old_real_uid=substr($_,505,10);
		if ($link_old_real_uid  eq ' ' x length($link_old_real_uid )) {
			undef $link_old_real_uid ;
		}
		$link_old_eff_uid=substr($_,516,10);
		if ($link_old_eff_uid  eq ' ' x length($link_old_eff_uid )) {
			undef $link_old_eff_uid ;
		}
		$link_old_saved_uid=substr($_,527,10);
		if ($link_old_saved_uid eq ' ' x length($link_old_saved_uid)) {
			undef $link_old_saved_uid;
		}
		$link_old_real_gid=substr($_,538,10);
		if ($link_old_real_gid  eq ' ' x length($link_old_real_gid )) {
			undef $link_old_real_gid ;
		}
		$link_old_eff_gid=substr($_,549,10);
		if ($link_old_eff_gid  eq ' ' x length($link_old_eff_gid )) {
			undef $link_old_eff_gid ;
		}
		$link_old_saved_gid=substr($_,560,10);
		if ($link_old_saved_gid eq ' ' x length($link_old_saved_gid)) {
			undef $link_old_saved_gid;
		}
		$link_path_name=substr($_,571,1023);
		$link_file_id=substr($_,1595,32);
		$link_file_own_uid=substr($_,1628,10);
		if ($link_file_own_uid  eq ' ' x length($link_file_own_uid )) {
			undef $link_file_own_uid ;
		}
		$link_file_own_gid=substr($_,1639,10);
		if ($link_file_own_gid  eq ' ' x length($link_file_own_gid )) {
			undef $link_file_own_gid ;
		}
		$link_request_path2=substr($_,1650,1023);
		$link_path_type=substr($_,2674,4);
		$link_filepool=substr($_,2679,8);
		$link_filespace=substr($_,2688,8);
		$link_inode=substr($_,2697,10);
		if ($link_inode  eq ' ' x length($link_inode )) {
			undef $link_inode ;
		}
		$link_scid=substr($_,2708,10);
		if ($link_scid  eq ' ' x length($link_scid )) {
			undef $link_scid ;
		}
		$link_dce_link=substr($_,2719,16);
		$link_auth_type=substr($_,2736,13);
		$link_dflt_process=substr($_,2750,1);
		$link_utk_netw=substr($_,2755,8);
		$link_x500_subject=substr($_,2764,255);
		$link_x500_issuer=substr($_,3020,255);
		$rv=$insert{link}->execute($link_event_type,$link_event_qual,$link_time_written,$link_date_written,$link_system_smfid,$link_violation,$link_user_ndfnd,$link_user_warning,$link_evt_user_id,$link_evt_grp_id,$link_auth_normal,$link_auth_special,$link_auth_oper,$link_auth_audit,$link_auth_exit,$link_auth_failsft,$link_auth_bypass,$link_auth_trusted,$link_log_class,$link_log_user,$link_log_special,$link_log_access,$link_log_racinit,$link_log_always,$link_log_cmdviol,$link_log_global,$link_term_level,$link_backout_fail,$link_prof_same,$link_term,$link_job_name,$link_read_time,$link_read_date,$link_smf_user_id,$link_log_level,$link_log_vmevent,$link_log_logopt,$link_log_secl,$link_log_compatm,$link_log_applaud,$link_log_nonomvs,$link_log_omvsnprv,$link_auth_omvssu,$link_auth_omvssys,$link_usr_secl,$link_racf_version,$link_class,$link_user_name,$link_utk_encr,$link_utk_pre19,$link_utk_verprof,$link_utk_njeunusr,$link_utk_logusr,$link_utk_special,$link_utk_default,$link_utk_unknusr,$link_utk_error,$link_utk_trusted,$link_utk_sesstype,$link_utk_surrogat,$link_utk_remote,$link_utk_priv,$link_utk_secl,$link_utk_execnode,$link_utk_suser_id,$link_utk_snode,$link_utk_sgrp_id,$link_utk_spoe,$link_utk_spclass,$link_utk_user_id,$link_utk_grp_id,$link_utk_dft_grp,$link_utk_dft_secl,$link_appc_link,$link_audit_code,$link_old_real_uid,$link_old_eff_uid,$link_old_saved_uid,$link_old_real_gid,$link_old_eff_gid,$link_old_saved_gid,$link_path_name,$link_file_id,$link_file_own_uid,$link_file_own_gid,$link_request_path2,$link_path_type,$link_filepool,$link_filespace,$link_inode,$link_scid,$link_dce_link,$link_auth_type,$link_dflt_process,$link_utk_netw,$link_x500_subject,$link_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"link"}++;
		next;
	}

	if ($rectype eq 'MKDIR   ') {
		$mdir_event_type=substr($_,0,8);
		$mdir_event_qual=substr($_,9,8);
		$mdir_time_written=substr($_,18,8);
		if ($mdir_time_written  eq ' ' x length($mdir_time_written )) {
			undef $mdir_time_written ;
		}
		$mdir_date_written=substr($_,27,10);
		if ($mdir_date_written  eq ' ' x length($mdir_date_written )) {
			undef $mdir_date_written ;
		}
		$mdir_system_smfid=substr($_,38,4);
		$mdir_violation=substr($_,43,1);
		$mdir_user_ndfnd=substr($_,48,1);
		$mdir_user_warning=substr($_,53,1);
		$mdir_evt_user_id=substr($_,58,8);
		$mdir_evt_grp_id=substr($_,67,8);
		$mdir_auth_normal=substr($_,76,1);
		$mdir_auth_special=substr($_,81,1);
		$mdir_auth_oper=substr($_,86,1);
		$mdir_auth_audit=substr($_,91,1);
		$mdir_auth_exit=substr($_,96,1);
		$mdir_auth_failsft=substr($_,101,1);
		$mdir_auth_bypass=substr($_,106,1);
		$mdir_auth_trusted=substr($_,111,1);
		$mdir_log_class=substr($_,116,1);
		$mdir_log_user=substr($_,121,1);
		$mdir_log_special=substr($_,126,1);
		$mdir_log_access=substr($_,131,1);
		$mdir_log_racinit=substr($_,136,1);
		$mdir_log_always=substr($_,141,1);
		$mdir_log_cmdviol=substr($_,146,1);
		$mdir_log_global=substr($_,151,1);
		$mdir_term_level=substr($_,156,3);
		if ($mdir_term_level  eq ' ' x length($mdir_term_level )) {
			undef $mdir_term_level ;
		}
		$mdir_backout_fail=substr($_,160,1);
		$mdir_prof_same=substr($_,165,1);
		$mdir_term=substr($_,170,8);
		$mdir_job_name=substr($_,179,8);
		$mdir_read_time=substr($_,188,8);
		if ($mdir_read_time  eq ' ' x length($mdir_read_time )) {
			undef $mdir_read_time ;
		}
		$mdir_read_date=substr($_,197,10);
		if ($mdir_read_date  eq ' ' x length($mdir_read_date )) {
			undef $mdir_read_date ;
		}
		$mdir_smf_user_id=substr($_,208,8);
		$mdir_log_level=substr($_,217,1);
		$mdir_log_vmevent=substr($_,222,1);
		$mdir_log_logopt=substr($_,227,1);
		$mdir_log_secl=substr($_,232,1);
		$mdir_log_compatm=substr($_,237,1);
		$mdir_log_applaud=substr($_,242,1);
		$mdir_log_nonomvs=substr($_,247,1);
		$mdir_log_omvsnprv=substr($_,252,1);
		$mdir_auth_omvssu=substr($_,257,1);
		$mdir_auth_omvssys=substr($_,262,1);
		$mdir_usr_secl=substr($_,267,8);
		$mdir_racf_version=substr($_,276,4);
		$mdir_class=substr($_,281,8);
		$mdir_user_name=substr($_,290,20);
		$mdir_utk_encr=substr($_,311,1);
		$mdir_utk_pre19=substr($_,316,1);
		$mdir_utk_verprof=substr($_,321,1);
		$mdir_utk_njeunusr=substr($_,326,1);
		$mdir_utk_logusr=substr($_,331,1);
		$mdir_utk_special=substr($_,336,1);
		$mdir_utk_default=substr($_,341,1);
		$mdir_utk_unknusr=substr($_,346,1);
		$mdir_utk_error=substr($_,351,1);
		$mdir_utk_trusted=substr($_,356,1);
		$mdir_utk_sesstype=substr($_,361,8);
		$mdir_utk_surrogat=substr($_,370,1);
		$mdir_utk_remote=substr($_,375,1);
		$mdir_utk_priv=substr($_,380,1);
		$mdir_utk_secl=substr($_,385,8);
		$mdir_utk_execnode=substr($_,394,8);
		$mdir_utk_suser_id=substr($_,403,8);
		$mdir_utk_snode=substr($_,412,8);
		$mdir_utk_sgrp_id=substr($_,421,8);
		$mdir_utk_spoe=substr($_,430,8);
		$mdir_utk_spclass=substr($_,439,8);
		$mdir_utk_user_id=substr($_,448,8);
		$mdir_utk_grp_id=substr($_,457,8);
		$mdir_utk_dft_grp=substr($_,466,1);
		$mdir_utk_dft_secl=substr($_,471,1);
		$mdir_appc_link=substr($_,476,16);
		$mdir_audit_code=substr($_,493,11);
		$mdir_old_real_uid=substr($_,505,10);
		if ($mdir_old_real_uid  eq ' ' x length($mdir_old_real_uid )) {
			undef $mdir_old_real_uid ;
		}
		$mdir_old_eff_uid=substr($_,516,10);
		if ($mdir_old_eff_uid  eq ' ' x length($mdir_old_eff_uid )) {
			undef $mdir_old_eff_uid ;
		}
		$mdir_old_saved_uid=substr($_,527,10);
		if ($mdir_old_saved_uid eq ' ' x length($mdir_old_saved_uid)) {
			undef $mdir_old_saved_uid;
		}
		$mdir_old_real_gid=substr($_,538,10);
		if ($mdir_old_real_gid  eq ' ' x length($mdir_old_real_gid )) {
			undef $mdir_old_real_gid ;
		}
		$mdir_old_eff_gid=substr($_,549,10);
		if ($mdir_old_eff_gid  eq ' ' x length($mdir_old_eff_gid )) {
			undef $mdir_old_eff_gid ;
		}
		$mdir_old_saved_gid=substr($_,560,10);
		if ($mdir_old_saved_gid eq ' ' x length($mdir_old_saved_gid)) {
			undef $mdir_old_saved_gid;
		}
		$mdir_path_name=substr($_,571,1023);
		$mdir_file_id=substr($_,1595,32);
		$mdir_file_own_uid=substr($_,1628,10);
		if ($mdir_file_own_uid  eq ' ' x length($mdir_file_own_uid )) {
			undef $mdir_file_own_uid ;
		}
		$mdir_file_own_gid=substr($_,1639,10);
		if ($mdir_file_own_gid  eq ' ' x length($mdir_file_own_gid )) {
			undef $mdir_file_own_gid ;
		}
		$mdir_old_s_isgid=substr($_,1650,1);
		$mdir_old_s_isuid=substr($_,1655,1);
		$mdir_old_s_isvtx=substr($_,1660,1);
		$mdir_old_own_read=substr($_,1665,1);
		$mdir_old_own_write=substr($_,1670,1);
		$mdir_old_own_exec=substr($_,1675,1);
		$mdir_old_grp_read=substr($_,1680,1);
		$mdir_old_grp_write=substr($_,1685,1);
		$mdir_old_grp_exec=substr($_,1690,1);
		$mdir_old_oth_read=substr($_,1695,1);
		$mdir_old_oth_write=substr($_,1700,1);
		$mdir_old_oth_exec=substr($_,1705,1);
		$mdir_new_s_isgid=substr($_,1710,1);
		$mdir_new_s_isuid=substr($_,1715,1);
		$mdir_new_s_isvtx=substr($_,1720,1);
		$mdir_new_own_read=substr($_,1725,1);
		$mdir_new_own_write=substr($_,1730,1);
		$mdir_new_own_exec=substr($_,1735,1);
		$mdir_new_grp_read=substr($_,1740,1);
		$mdir_new_grp_write=substr($_,1745,1);
		$mdir_new_grp_exec=substr($_,1750,1);
		$mdir_new_oth_read=substr($_,1755,1);
		$mdir_new_oth_write=substr($_,1760,1);
		$mdir_new_oth_exec=substr($_,1765,1);
		$mdir_unew_read=substr($_,1770,8);
		$mdir_unew_write=substr($_,1779,8);
		$mdir_unew_exec=substr($_,1788,8);
		$mdir_anew_read=substr($_,1797,8);
		$mdir_anew_write=substr($_,1806,8);
		$mdir_anew_exec=substr($_,1815,8);
		$mdir_req_s_isgid=substr($_,1824,1);
		$mdir_req_s_isuid=substr($_,1829,1);
		$mdir_req_s_isvtx=substr($_,1834,1);
		$mdir_req_own_read=substr($_,1839,1);
		$mdir_req_own_write=substr($_,1844,1);
		$mdir_req_own_exec=substr($_,1849,1);
		$mdir_req_grp_read=substr($_,1854,1);
		$mdir_req_grp_write=substr($_,1859,1);
		$mdir_req_grp_exec=substr($_,1864,1);
		$mdir_req_oth_read=substr($_,1869,1);
		$mdir_req_oth_write=substr($_,1874,1);
		$mdir_req_oth_exec=substr($_,1879,1);
		$mdir_filepool=substr($_,1884,8);
		$mdir_filespace=substr($_,1893,8);
		$mdir_inode=substr($_,1902,10);
		if ($mdir_inode  eq ' ' x length($mdir_inode )) {
			undef $mdir_inode ;
		}
		$mdir_scid=substr($_,1913,10);
		if ($mdir_scid  eq ' ' x length($mdir_scid )) {
			undef $mdir_scid ;
		}
		$mdir_dflt_process=substr($_,1924,1);
		$mdir_utk_netw=substr($_,1929,8);
		$mdir_x500_subject=substr($_,1938,255);
		$mdir_x500_issuer=substr($_,2194,255);
		$rv=$insert{mkdir}->execute($mdir_event_type,$mdir_event_qual,$mdir_time_written,$mdir_date_written,$mdir_system_smfid,$mdir_violation,$mdir_user_ndfnd,$mdir_user_warning,$mdir_evt_user_id,$mdir_evt_grp_id,$mdir_auth_normal,$mdir_auth_special,$mdir_auth_oper,$mdir_auth_audit,$mdir_auth_exit,$mdir_auth_failsft,$mdir_auth_bypass,$mdir_auth_trusted,$mdir_log_class,$mdir_log_user,$mdir_log_special,$mdir_log_access,$mdir_log_racinit,$mdir_log_always,$mdir_log_cmdviol,$mdir_log_global,$mdir_term_level,$mdir_backout_fail,$mdir_prof_same,$mdir_term,$mdir_job_name,$mdir_read_time,$mdir_read_date,$mdir_smf_user_id,$mdir_log_level,$mdir_log_vmevent,$mdir_log_logopt,$mdir_log_secl,$mdir_log_compatm,$mdir_log_applaud,$mdir_log_nonomvs,$mdir_log_omvsnprv,$mdir_auth_omvssu,$mdir_auth_omvssys,$mdir_usr_secl,$mdir_racf_version,$mdir_class,$mdir_user_name,$mdir_utk_encr,$mdir_utk_pre19,$mdir_utk_verprof,$mdir_utk_njeunusr,$mdir_utk_logusr,$mdir_utk_special,$mdir_utk_default,$mdir_utk_unknusr,$mdir_utk_error,$mdir_utk_trusted,$mdir_utk_sesstype,$mdir_utk_surrogat,$mdir_utk_remote,$mdir_utk_priv,$mdir_utk_secl,$mdir_utk_execnode,$mdir_utk_suser_id,$mdir_utk_snode,$mdir_utk_sgrp_id,$mdir_utk_spoe,$mdir_utk_spclass,$mdir_utk_user_id,$mdir_utk_grp_id,$mdir_utk_dft_grp,$mdir_utk_dft_secl,$mdir_appc_link,$mdir_audit_code,$mdir_old_real_uid,$mdir_old_eff_uid,$mdir_old_saved_uid,$mdir_old_real_gid,$mdir_old_eff_gid,$mdir_old_saved_gid,$mdir_path_name,$mdir_file_id,$mdir_file_own_uid,$mdir_file_own_gid,$mdir_old_s_isgid,$mdir_old_s_isuid,$mdir_old_s_isvtx,$mdir_old_own_read,$mdir_old_own_write,$mdir_old_own_exec,$mdir_old_grp_read,$mdir_old_grp_write,$mdir_old_grp_exec,$mdir_old_oth_read,$mdir_old_oth_write,$mdir_old_oth_exec,$mdir_new_s_isgid,$mdir_new_s_isuid,$mdir_new_s_isvtx,$mdir_new_own_read,$mdir_new_own_write,$mdir_new_own_exec,$mdir_new_grp_read,$mdir_new_grp_write,$mdir_new_grp_exec,$mdir_new_oth_read,$mdir_new_oth_write,$mdir_new_oth_exec,$mdir_unew_read,$mdir_unew_write,$mdir_unew_exec,$mdir_anew_read,$mdir_anew_write,$mdir_anew_exec,$mdir_req_s_isgid,$mdir_req_s_isuid,$mdir_req_s_isvtx,$mdir_req_own_read,$mdir_req_own_write,$mdir_req_own_exec,$mdir_req_grp_read,$mdir_req_grp_write,$mdir_req_grp_exec,$mdir_req_oth_read,$mdir_req_oth_write,$mdir_req_oth_exec,$mdir_filepool,$mdir_filespace,$mdir_inode,$mdir_scid,$mdir_dflt_process,$mdir_utk_netw,$mdir_x500_subject,$mdir_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"mkdir"}++;
		next;
	}

	if ($rectype eq 'MKNOD   ') {
		$mnod_event_type=substr($_,0,8);
		$mnod_event_qual=substr($_,9,8);
		$mnod_time_written=substr($_,18,8);
		if ($mnod_time_written  eq ' ' x length($mnod_time_written )) {
			undef $mnod_time_written ;
		}
		$mnod_date_written=substr($_,27,10);
		if ($mnod_date_written  eq ' ' x length($mnod_date_written )) {
			undef $mnod_date_written ;
		}
		$mnod_system_smfid=substr($_,38,4);
		$mnod_violation=substr($_,43,1);
		$mnod_user_ndfnd=substr($_,48,1);
		$mnod_user_warning=substr($_,53,1);
		$mnod_evt_user_id=substr($_,58,8);
		$mnod_evt_grp_id=substr($_,67,8);
		$mnod_auth_normal=substr($_,76,1);
		$mnod_auth_special=substr($_,81,1);
		$mnod_auth_oper=substr($_,86,1);
		$mnod_auth_audit=substr($_,91,1);
		$mnod_auth_exit=substr($_,96,1);
		$mnod_auth_failsft=substr($_,101,1);
		$mnod_auth_bypass=substr($_,106,1);
		$mnod_auth_trusted=substr($_,111,1);
		$mnod_log_class=substr($_,116,1);
		$mnod_log_user=substr($_,121,1);
		$mnod_log_special=substr($_,126,1);
		$mnod_log_access=substr($_,131,1);
		$mnod_log_racinit=substr($_,136,1);
		$mnod_log_always=substr($_,141,1);
		$mnod_log_cmdviol=substr($_,146,1);
		$mnod_log_global=substr($_,151,1);
		$mnod_term_level=substr($_,156,3);
		if ($mnod_term_level  eq ' ' x length($mnod_term_level )) {
			undef $mnod_term_level ;
		}
		$mnod_backout_fail=substr($_,160,1);
		$mnod_prof_same=substr($_,165,1);
		$mnod_term=substr($_,170,8);
		$mnod_job_name=substr($_,179,8);
		$mnod_read_time=substr($_,188,8);
		if ($mnod_read_time  eq ' ' x length($mnod_read_time )) {
			undef $mnod_read_time ;
		}
		$mnod_read_date=substr($_,197,10);
		if ($mnod_read_date  eq ' ' x length($mnod_read_date )) {
			undef $mnod_read_date ;
		}
		$mnod_smf_user_id=substr($_,208,8);
		$mnod_log_level=substr($_,217,1);
		$mnod_log_vmevent=substr($_,222,1);
		$mnod_log_logopt=substr($_,227,1);
		$mnod_log_secl=substr($_,232,1);
		$mnod_log_compatm=substr($_,237,1);
		$mnod_log_applaud=substr($_,242,1);
		$mnod_log_nonomvs=substr($_,247,1);
		$mnod_log_omvsnprv=substr($_,252,1);
		$mnod_auth_omvssu=substr($_,257,1);
		$mnod_auth_omvssys=substr($_,262,1);
		$mnod_usr_secl=substr($_,267,8);
		$mnod_racf_version=substr($_,276,4);
		$mnod_class=substr($_,281,8);
		$mnod_user_name=substr($_,290,20);
		$mnod_utk_encr=substr($_,311,1);
		$mnod_utk_pre19=substr($_,316,1);
		$mnod_utk_verprof=substr($_,321,1);
		$mnod_utk_njeunusr=substr($_,326,1);
		$mnod_utk_logusr=substr($_,331,1);
		$mnod_utk_special=substr($_,336,1);
		$mnod_utk_default=substr($_,341,1);
		$mnod_utk_unknusr=substr($_,346,1);
		$mnod_utk_error=substr($_,351,1);
		$mnod_utk_trusted=substr($_,356,1);
		$mnod_utk_sesstype=substr($_,361,8);
		$mnod_utk_surrogat=substr($_,370,1);
		$mnod_utk_remote=substr($_,375,1);
		$mnod_utk_priv=substr($_,380,1);
		$mnod_utk_secl=substr($_,385,8);
		$mnod_utk_execnode=substr($_,394,8);
		$mnod_utk_suser_id=substr($_,403,8);
		$mnod_utk_snode=substr($_,412,8);
		$mnod_utk_sgrp_id=substr($_,421,8);
		$mnod_utk_spoe=substr($_,430,8);
		$mnod_utk_spclass=substr($_,439,8);
		$mnod_utk_user_id=substr($_,448,8);
		$mnod_utk_grp_id=substr($_,457,8);
		$mnod_utk_dft_grp=substr($_,466,1);
		$mnod_utk_dft_secl=substr($_,471,1);
		$mnod_appc_link=substr($_,476,16);
		$mnod_audit_code=substr($_,493,11);
		$mnod_old_real_uid=substr($_,505,10);
		if ($mnod_old_real_uid  eq ' ' x length($mnod_old_real_uid )) {
			undef $mnod_old_real_uid ;
		}
		$mnod_old_eff_uid=substr($_,516,10);
		if ($mnod_old_eff_uid  eq ' ' x length($mnod_old_eff_uid )) {
			undef $mnod_old_eff_uid ;
		}
		$mnod_old_saved_uid=substr($_,527,10);
		if ($mnod_old_saved_uid eq ' ' x length($mnod_old_saved_uid)) {
			undef $mnod_old_saved_uid;
		}
		$mnod_old_real_gid=substr($_,538,10);
		if ($mnod_old_real_gid  eq ' ' x length($mnod_old_real_gid )) {
			undef $mnod_old_real_gid ;
		}
		$mnod_old_eff_gid=substr($_,549,10);
		if ($mnod_old_eff_gid  eq ' ' x length($mnod_old_eff_gid )) {
			undef $mnod_old_eff_gid ;
		}
		$mnod_old_saved_gid=substr($_,560,10);
		if ($mnod_old_saved_gid eq ' ' x length($mnod_old_saved_gid)) {
			undef $mnod_old_saved_gid;
		}
		$mnod_path_name=substr($_,571,1023);
		$mnod_file_id=substr($_,1595,32);
		$mnod_file_own_uid=substr($_,1628,10);
		if ($mnod_file_own_uid  eq ' ' x length($mnod_file_own_uid )) {
			undef $mnod_file_own_uid ;
		}
		$mnod_file_own_gid=substr($_,1639,10);
		if ($mnod_file_own_gid  eq ' ' x length($mnod_file_own_gid )) {
			undef $mnod_file_own_gid ;
		}
		$mnod_old_s_isgid=substr($_,1650,1);
		$mnod_old_s_isuid=substr($_,1655,1);
		$mnod_old_s_isvtx=substr($_,1660,1);
		$mnod_old_own_read=substr($_,1665,1);
		$mnod_old_own_write=substr($_,1670,1);
		$mnod_old_own_exec=substr($_,1675,1);
		$mnod_old_grp_read=substr($_,1680,1);
		$mnod_old_grp_write=substr($_,1685,1);
		$mnod_old_grp_exec=substr($_,1690,1);
		$mnod_old_oth_read=substr($_,1695,1);
		$mnod_old_oth_write=substr($_,1700,1);
		$mnod_old_oth_exec=substr($_,1705,1);
		$mnod_new_s_isgid=substr($_,1710,1);
		$mnod_new_s_isuid=substr($_,1715,1);
		$mnod_new_s_isvtx=substr($_,1720,1);
		$mnod_new_own_read=substr($_,1725,1);
		$mnod_new_own_write=substr($_,1730,1);
		$mnod_new_own_exec=substr($_,1735,1);
		$mnod_new_grp_read=substr($_,1740,1);
		$mnod_new_grp_write=substr($_,1745,1);
		$mnod_new_grp_exec=substr($_,1750,1);
		$mnod_new_oth_read=substr($_,1755,1);
		$mnod_new_oth_write=substr($_,1760,1);
		$mnod_new_oth_exec=substr($_,1765,1);
		$mnod_unew_read=substr($_,1770,8);
		$mnod_unew_write=substr($_,1779,8);
		$mnod_unew_exec=substr($_,1788,8);
		$mnod_anew_read=substr($_,1797,8);
		$mnod_anew_write=substr($_,1806,8);
		$mnod_anew_exec=substr($_,1815,8);
		$mnod_req_s_isgid=substr($_,1824,1);
		$mnod_req_s_isuid=substr($_,1829,1);
		$mnod_req_s_isvtx=substr($_,1834,1);
		$mnod_req_own_read=substr($_,1839,1);
		$mnod_req_own_write=substr($_,1844,1);
		$mnod_req_own_exec=substr($_,1849,1);
		$mnod_req_grp_read=substr($_,1854,1);
		$mnod_req_grp_write=substr($_,1859,1);
		$mnod_req_grp_exec=substr($_,1864,1);
		$mnod_req_oth_read=substr($_,1869,1);
		$mnod_req_oth_write=substr($_,1874,1);
		$mnod_req_oth_exec=substr($_,1879,1);
		$mnod_filepool=substr($_,1884,8);
		$mnod_filespace=substr($_,1893,8);
		$mnod_inode=substr($_,1902,10);
		if ($mnod_inode  eq ' ' x length($mnod_inode )) {
			undef $mnod_inode ;
		}
		$mnod_scid=substr($_,1913,10);
		if ($mnod_scid  eq ' ' x length($mnod_scid )) {
			undef $mnod_scid ;
		}
		$mnod_dflt_process=substr($_,1924,1);
		$mnod_utk_netw=substr($_,1929,8);
		$mnod_x500_subject=substr($_,1938,255);
		$mnod_x500_issuer=substr($_,2194,255);
		$rv=$insert{mknod}->execute($mnod_event_type,$mnod_event_qual,$mnod_time_written,$mnod_date_written,$mnod_system_smfid,$mnod_violation,$mnod_user_ndfnd,$mnod_user_warning,$mnod_evt_user_id,$mnod_evt_grp_id,$mnod_auth_normal,$mnod_auth_special,$mnod_auth_oper,$mnod_auth_audit,$mnod_auth_exit,$mnod_auth_failsft,$mnod_auth_bypass,$mnod_auth_trusted,$mnod_log_class,$mnod_log_user,$mnod_log_special,$mnod_log_access,$mnod_log_racinit,$mnod_log_always,$mnod_log_cmdviol,$mnod_log_global,$mnod_term_level,$mnod_backout_fail,$mnod_prof_same,$mnod_term,$mnod_job_name,$mnod_read_time,$mnod_read_date,$mnod_smf_user_id,$mnod_log_level,$mnod_log_vmevent,$mnod_log_logopt,$mnod_log_secl,$mnod_log_compatm,$mnod_log_applaud,$mnod_log_nonomvs,$mnod_log_omvsnprv,$mnod_auth_omvssu,$mnod_auth_omvssys,$mnod_usr_secl,$mnod_racf_version,$mnod_class,$mnod_user_name,$mnod_utk_encr,$mnod_utk_pre19,$mnod_utk_verprof,$mnod_utk_njeunusr,$mnod_utk_logusr,$mnod_utk_special,$mnod_utk_default,$mnod_utk_unknusr,$mnod_utk_error,$mnod_utk_trusted,$mnod_utk_sesstype,$mnod_utk_surrogat,$mnod_utk_remote,$mnod_utk_priv,$mnod_utk_secl,$mnod_utk_execnode,$mnod_utk_suser_id,$mnod_utk_snode,$mnod_utk_sgrp_id,$mnod_utk_spoe,$mnod_utk_spclass,$mnod_utk_user_id,$mnod_utk_grp_id,$mnod_utk_dft_grp,$mnod_utk_dft_secl,$mnod_appc_link,$mnod_audit_code,$mnod_old_real_uid,$mnod_old_eff_uid,$mnod_old_saved_uid,$mnod_old_real_gid,$mnod_old_eff_gid,$mnod_old_saved_gid,$mnod_path_name,$mnod_file_id,$mnod_file_own_uid,$mnod_file_own_gid,$mnod_old_s_isgid,$mnod_old_s_isuid,$mnod_old_s_isvtx,$mnod_old_own_read,$mnod_old_own_write,$mnod_old_own_exec,$mnod_old_grp_read,$mnod_old_grp_write,$mnod_old_grp_exec,$mnod_old_oth_read,$mnod_old_oth_write,$mnod_old_oth_exec,$mnod_new_s_isgid,$mnod_new_s_isuid,$mnod_new_s_isvtx,$mnod_new_own_read,$mnod_new_own_write,$mnod_new_own_exec,$mnod_new_grp_read,$mnod_new_grp_write,$mnod_new_grp_exec,$mnod_new_oth_read,$mnod_new_oth_write,$mnod_new_oth_exec,$mnod_unew_read,$mnod_unew_write,$mnod_unew_exec,$mnod_anew_read,$mnod_anew_write,$mnod_anew_exec,$mnod_req_s_isgid,$mnod_req_s_isuid,$mnod_req_s_isvtx,$mnod_req_own_read,$mnod_req_own_write,$mnod_req_own_exec,$mnod_req_grp_read,$mnod_req_grp_write,$mnod_req_grp_exec,$mnod_req_oth_read,$mnod_req_oth_write,$mnod_req_oth_exec,$mnod_filepool,$mnod_filespace,$mnod_inode,$mnod_scid,$mnod_dflt_process,$mnod_utk_netw,$mnod_x500_subject,$mnod_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"mknod"}++;
		next;
	}

	if ($rectype eq 'MNTFSYS ') {
		$mfs_event_type=substr($_,0,8);
		$mfs_event_qual=substr($_,9,8);
		$mfs_time_written=substr($_,18,8);
		if ($mfs_time_written  eq ' ' x length($mfs_time_written )) {
			undef $mfs_time_written ;
		}
		$mfs_date_written=substr($_,27,10);
		if ($mfs_date_written  eq ' ' x length($mfs_date_written )) {
			undef $mfs_date_written ;
		}
		$mfs_system_smfid=substr($_,38,4);
		$mfs_violation=substr($_,43,1);
		$mfs_user_ndfnd=substr($_,48,1);
		$mfs_user_warning=substr($_,53,1);
		$mfs_evt_user_id=substr($_,58,8);
		$mfs_evt_grp_id=substr($_,67,8);
		$mfs_auth_normal=substr($_,76,1);
		$mfs_auth_special=substr($_,81,1);
		$mfs_auth_oper=substr($_,86,1);
		$mfs_auth_audit=substr($_,91,1);
		$mfs_auth_exit=substr($_,96,1);
		$mfs_auth_failsft=substr($_,101,1);
		$mfs_auth_bypass=substr($_,106,1);
		$mfs_auth_trusted=substr($_,111,1);
		$mfs_log_class=substr($_,116,1);
		$mfs_log_user=substr($_,121,1);
		$mfs_log_special=substr($_,126,1);
		$mfs_log_access=substr($_,131,1);
		$mfs_log_racinit=substr($_,136,1);
		$mfs_log_always=substr($_,141,1);
		$mfs_log_cmdviol=substr($_,146,1);
		$mfs_log_global=substr($_,151,1);
		$mfs_term_level=substr($_,156,3);
		if ($mfs_term_level  eq ' ' x length($mfs_term_level )) {
			undef $mfs_term_level ;
		}
		$mfs_backout_fail=substr($_,160,1);
		$mfs_prof_same=substr($_,165,1);
		$mfs_term=substr($_,170,8);
		$mfs_job_name=substr($_,179,8);
		$mfs_read_time=substr($_,188,8);
		if ($mfs_read_time  eq ' ' x length($mfs_read_time )) {
			undef $mfs_read_time ;
		}
		$mfs_read_date=substr($_,197,10);
		if ($mfs_read_date  eq ' ' x length($mfs_read_date )) {
			undef $mfs_read_date ;
		}
		$mfs_smf_user_id=substr($_,208,8);
		$mfs_log_level=substr($_,217,1);
		$mfs_log_vmevent=substr($_,222,1);
		$mfs_log_logopt=substr($_,227,1);
		$mfs_log_secl=substr($_,232,1);
		$mfs_log_compatm=substr($_,237,1);
		$mfs_log_applaud=substr($_,242,1);
		$mfs_log_nonomvs=substr($_,247,1);
		$mfs_log_omvsnprv=substr($_,252,1);
		$mfs_auth_omvssu=substr($_,257,1);
		$mfs_auth_omvssys=substr($_,262,1);
		$mfs_usr_secl=substr($_,267,8);
		$mfs_racf_version=substr($_,276,4);
		$mfs_class=substr($_,281,8);
		$mfs_user_name=substr($_,290,20);
		$mfs_utk_encr=substr($_,311,1);
		$mfs_utk_pre19=substr($_,316,1);
		$mfs_utk_verprof=substr($_,321,1);
		$mfs_utk_njeunusr=substr($_,326,1);
		$mfs_utk_logusr=substr($_,331,1);
		$mfs_utk_special=substr($_,336,1);
		$mfs_utk_default=substr($_,341,1);
		$mfs_utk_unknusr=substr($_,346,1);
		$mfs_utk_error=substr($_,351,1);
		$mfs_utk_trusted=substr($_,356,1);
		$mfs_utk_sesstype=substr($_,361,8);
		$mfs_utk_surrogat=substr($_,370,1);
		$mfs_utk_remote=substr($_,375,1);
		$mfs_utk_priv=substr($_,380,1);
		$mfs_utk_secl=substr($_,385,8);
		$mfs_utk_execnode=substr($_,394,8);
		$mfs_utk_suser_id=substr($_,403,8);
		$mfs_utk_snode=substr($_,412,8);
		$mfs_utk_sgrp_id=substr($_,421,8);
		$mfs_utk_spoe=substr($_,430,8);
		$mfs_utk_spclass=substr($_,439,8);
		$mfs_utk_user_id=substr($_,448,8);
		$mfs_utk_grp_id=substr($_,457,8);
		$mfs_utk_dft_grp=substr($_,466,1);
		$mfs_utk_dft_secl=substr($_,471,1);
		$mfs_appc_link=substr($_,476,16);
		$mfs_audit_code=substr($_,493,11);
		$mfs_old_real_uid=substr($_,505,10);
		if ($mfs_old_real_uid  eq ' ' x length($mfs_old_real_uid )) {
			undef $mfs_old_real_uid ;
		}
		$mfs_old_eff_uid=substr($_,516,10);
		if ($mfs_old_eff_uid  eq ' ' x length($mfs_old_eff_uid )) {
			undef $mfs_old_eff_uid ;
		}
		$mfs_old_saved_uid=substr($_,527,10);
		if ($mfs_old_saved_uid  eq ' ' x length($mfs_old_saved_uid )) {
			undef $mfs_old_saved_uid ;
		}
		$mfs_old_real_gid=substr($_,538,10);
		if ($mfs_old_real_gid  eq ' ' x length($mfs_old_real_gid )) {
			undef $mfs_old_real_gid ;
		}
		$mfs_old_eff_gid=substr($_,549,10);
		if ($mfs_old_eff_gid  eq ' ' x length($mfs_old_eff_gid )) {
			undef $mfs_old_eff_gid ;
		}
		$mfs_old_saved_gid=substr($_,560,10);
		if ($mfs_old_saved_gid  eq ' ' x length($mfs_old_saved_gid )) {
			undef $mfs_old_saved_gid ;
		}
		$mfs_path_name=substr($_,571,1023);
		$mfs_file_id=substr($_,1595,32);
		$mfs_file_own_uid=substr($_,1628,10);
		if ($mfs_file_own_uid  eq ' ' x length($mfs_file_own_uid )) {
			undef $mfs_file_own_uid ;
		}
		$mfs_file_own_gid=substr($_,1639,10);
		if ($mfs_file_own_gid  eq ' ' x length($mfs_file_own_gid )) {
			undef $mfs_file_own_gid ;
		}
		$mfs_hfs_ds_name=substr($_,1650,44);
		$mfs_dce_link=substr($_,1695,16);
		$mfs_auth_type=substr($_,1712,13);
		$mfs_dflt_process=substr($_,1726,1);
		$mfs_utk_netw=substr($_,1731,8);
		$mfs_x500_subject=substr($_,1740,255);
		$mfs_x500_issuer=substr($_,1996,255);
		$rv=$insert{mntfsys}->execute($mfs_event_type,$mfs_event_qual,$mfs_time_written,$mfs_date_written,$mfs_system_smfid,$mfs_violation,$mfs_user_ndfnd,$mfs_user_warning,$mfs_evt_user_id,$mfs_evt_grp_id,$mfs_auth_normal,$mfs_auth_special,$mfs_auth_oper,$mfs_auth_audit,$mfs_auth_exit,$mfs_auth_failsft,$mfs_auth_bypass,$mfs_auth_trusted,$mfs_log_class,$mfs_log_user,$mfs_log_special,$mfs_log_access,$mfs_log_racinit,$mfs_log_always,$mfs_log_cmdviol,$mfs_log_global,$mfs_term_level,$mfs_backout_fail,$mfs_prof_same,$mfs_term,$mfs_job_name,$mfs_read_time,$mfs_read_date,$mfs_smf_user_id,$mfs_log_level,$mfs_log_vmevent,$mfs_log_logopt,$mfs_log_secl,$mfs_log_compatm,$mfs_log_applaud,$mfs_log_nonomvs,$mfs_log_omvsnprv,$mfs_auth_omvssu,$mfs_auth_omvssys,$mfs_usr_secl,$mfs_racf_version,$mfs_class,$mfs_user_name,$mfs_utk_encr,$mfs_utk_pre19,$mfs_utk_verprof,$mfs_utk_njeunusr,$mfs_utk_logusr,$mfs_utk_special,$mfs_utk_default,$mfs_utk_unknusr,$mfs_utk_error,$mfs_utk_trusted,$mfs_utk_sesstype,$mfs_utk_surrogat,$mfs_utk_remote,$mfs_utk_priv,$mfs_utk_secl,$mfs_utk_execnode,$mfs_utk_suser_id,$mfs_utk_snode,$mfs_utk_sgrp_id,$mfs_utk_spoe,$mfs_utk_spclass,$mfs_utk_user_id,$mfs_utk_grp_id,$mfs_utk_dft_grp,$mfs_utk_dft_secl,$mfs_appc_link,$mfs_audit_code,$mfs_old_real_uid,$mfs_old_eff_uid,$mfs_old_saved_uid,$mfs_old_real_gid,$mfs_old_eff_gid,$mfs_old_saved_gid,$mfs_path_name,$mfs_file_id,$mfs_file_own_uid,$mfs_file_own_gid,$mfs_hfs_ds_name,$mfs_dce_link,$mfs_auth_type,$mfs_dflt_process,$mfs_utk_netw,$mfs_x500_subject,$mfs_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"mntfsys"}++;
		next;
	}

	if ($rectype eq 'OPENFILE') {
		$open_event_type=substr($_,0,8);
		$open_event_qual=substr($_,9,8);
		$open_time_written=substr($_,18,8);
		if ($open_time_written  eq ' ' x length($open_time_written )) {
			undef $open_time_written ;
		}
		$open_date_written=substr($_,27,10);
		if ($open_date_written  eq ' ' x length($open_date_written )) {
			undef $open_date_written ;
		}
		$open_system_smfid=substr($_,38,4);
		$open_violation=substr($_,43,1);
		$open_user_ndfnd=substr($_,48,1);
		$open_user_warning=substr($_,53,1);
		$open_evt_user_id=substr($_,58,8);
		$open_evt_grp_id=substr($_,67,8);
		$open_auth_normal=substr($_,76,1);
		$open_auth_special=substr($_,81,1);
		$open_auth_oper=substr($_,86,1);
		$open_auth_audit=substr($_,91,1);
		$open_auth_exit=substr($_,96,1);
		$open_auth_failsft=substr($_,101,1);
		$open_auth_bypass=substr($_,106,1);
		$open_auth_trusted=substr($_,111,1);
		$open_log_class=substr($_,116,1);
		$open_log_user=substr($_,121,1);
		$open_log_special=substr($_,126,1);
		$open_log_access=substr($_,131,1);
		$open_log_racinit=substr($_,136,1);
		$open_log_always=substr($_,141,1);
		$open_log_cmdviol=substr($_,146,1);
		$open_log_global=substr($_,151,1);
		$open_term_level=substr($_,156,3);
		if ($open_term_level  eq ' ' x length($open_term_level )) {
			undef $open_term_level ;
		}
		$open_backout_fail=substr($_,160,1);
		$open_prof_same=substr($_,165,1);
		$open_term=substr($_,170,8);
		$open_job_name=substr($_,179,8);
		$open_read_time=substr($_,188,8);
		if ($open_read_time  eq ' ' x length($open_read_time )) {
			undef $open_read_time ;
		}
		$open_read_date=substr($_,197,10);
		if ($open_read_date  eq ' ' x length($open_read_date )) {
			undef $open_read_date ;
		}
		$open_smf_user_id=substr($_,208,8);
		$open_log_level=substr($_,217,1);
		$open_log_vmevent=substr($_,222,1);
		$open_log_logopt=substr($_,227,1);
		$open_log_secl=substr($_,232,1);
		$open_log_compatm=substr($_,237,1);
		$open_log_applaud=substr($_,242,1);
		$open_log_nonomvs=substr($_,247,1);
		$open_log_omvsnprv=substr($_,252,1);
		$open_auth_omvssu=substr($_,257,1);
		$open_auth_omvssys=substr($_,262,1);
		$open_usr_secl=substr($_,267,8);
		$open_racf_version=substr($_,276,4);
		$open_class=substr($_,281,8);
		$open_user_name=substr($_,290,20);
		$open_utk_encr=substr($_,311,1);
		$open_utk_pre19=substr($_,316,1);
		$open_utk_verprof=substr($_,321,1);
		$open_utk_njeunusr=substr($_,326,1);
		$open_utk_logusr=substr($_,331,1);
		$open_utk_special=substr($_,336,1);
		$open_utk_default=substr($_,341,1);
		$open_utk_unknusr=substr($_,346,1);
		$open_utk_error=substr($_,351,1);
		$open_utk_trusted=substr($_,356,1);
		$open_utk_sesstype=substr($_,361,8);
		$open_utk_surrogat=substr($_,370,1);
		$open_utk_remote=substr($_,375,1);
		$open_utk_priv=substr($_,380,1);
		$open_utk_secl=substr($_,385,8);
		$open_utk_execnode=substr($_,394,8);
		$open_utk_suser_id=substr($_,403,8);
		$open_utk_snode=substr($_,412,8);
		$open_utk_sgrp_id=substr($_,421,8);
		$open_utk_spoe=substr($_,430,8);
		$open_utk_spclass=substr($_,439,8);
		$open_utk_user_id=substr($_,448,8);
		$open_utk_grp_id=substr($_,457,8);
		$open_utk_dft_grp=substr($_,466,1);
		$open_utk_dft_secl=substr($_,471,1);
		$open_appc_link=substr($_,476,16);
		$open_audit_code=substr($_,493,11);
		$open_old_real_uid=substr($_,505,10);
		if ($open_old_real_uid  eq ' ' x length($open_old_real_uid )) {
			undef $open_old_real_uid ;
		}
		$open_old_eff_uid=substr($_,516,10);
		if ($open_old_eff_uid  eq ' ' x length($open_old_eff_uid )) {
			undef $open_old_eff_uid ;
		}
		$open_old_saved_uid=substr($_,527,10);
		if ($open_old_saved_uid eq ' ' x length($open_old_saved_uid)) {
			undef $open_old_saved_uid;
		}
		$open_old_real_gid=substr($_,538,10);
		if ($open_old_real_gid  eq ' ' x length($open_old_real_gid )) {
			undef $open_old_real_gid ;
		}
		$open_old_eff_gid=substr($_,549,10);
		if ($open_old_eff_gid  eq ' ' x length($open_old_eff_gid )) {
			undef $open_old_eff_gid ;
		}
		$open_old_saved_gid=substr($_,560,10);
		if ($open_old_saved_gid eq ' ' x length($open_old_saved_gid)) {
			undef $open_old_saved_gid;
		}
		$open_path_name=substr($_,571,1023);
		$open_file_id=substr($_,1595,32);
		$open_file_own_uid=substr($_,1628,10);
		if ($open_file_own_uid  eq ' ' x length($open_file_own_uid )) {
			undef $open_file_own_uid ;
		}
		$open_file_own_gid=substr($_,1639,10);
		if ($open_file_own_gid  eq ' ' x length($open_file_own_gid )) {
			undef $open_file_own_gid ;
		}
		$open_old_s_isgid=substr($_,1650,1);
		$open_old_s_isuid=substr($_,1655,1);
		$open_old_s_isvtx=substr($_,1660,1);
		$open_old_own_read=substr($_,1665,1);
		$open_old_own_write=substr($_,1670,1);
		$open_old_own_exec=substr($_,1675,1);
		$open_old_grp_read=substr($_,1680,1);
		$open_old_grp_write=substr($_,1685,1);
		$open_old_grp_exec=substr($_,1690,1);
		$open_old_oth_read=substr($_,1695,1);
		$open_old_oth_write=substr($_,1700,1);
		$open_old_oth_exec=substr($_,1705,1);
		$open_new_s_isgid=substr($_,1710,1);
		$open_new_s_isuid=substr($_,1715,1);
		$open_new_s_isvtx=substr($_,1720,1);
		$open_new_own_read=substr($_,1725,1);
		$open_new_own_write=substr($_,1730,1);
		$open_new_own_exec=substr($_,1735,1);
		$open_new_grp_read=substr($_,1740,1);
		$open_new_grp_write=substr($_,1745,1);
		$open_new_grp_exec=substr($_,1750,1);
		$open_new_oth_read=substr($_,1755,1);
		$open_new_oth_write=substr($_,1760,1);
		$open_new_oth_exec=substr($_,1765,1);
		$open_unew_read=substr($_,1770,8);
		$open_unew_write=substr($_,1779,8);
		$open_unew_exec=substr($_,1788,8);
		$open_anew_read=substr($_,1797,8);
		$open_anew_write=substr($_,1806,8);
		$open_anew_exec=substr($_,1815,8);
		$open_req_s_isgid=substr($_,1824,1);
		$open_req_s_isuid=substr($_,1829,1);
		$open_req_s_isvtx=substr($_,1834,1);
		$open_req_own_read=substr($_,1839,1);
		$open_req_own_write=substr($_,1844,1);
		$open_req_own_exec=substr($_,1849,1);
		$open_req_grp_read=substr($_,1854,1);
		$open_req_grp_write=substr($_,1859,1);
		$open_req_grp_exec=substr($_,1864,1);
		$open_req_oth_read=substr($_,1869,1);
		$open_req_oth_write=substr($_,1874,1);
		$open_req_oth_exec=substr($_,1879,1);
		$open_filepool=substr($_,1884,8);
		$open_filespace=substr($_,1893,8);
		$open_inode=substr($_,1902,10);
		if ($open_inode  eq ' ' x length($open_inode )) {
			undef $open_inode ;
		}
		$open_scid=substr($_,1913,10);
		if ($open_scid  eq ' ' x length($open_scid )) {
			undef $open_scid ;
		}
		$open_dflt_process=substr($_,1924,1);
		$open_utk_netw=substr($_,1929,8);
		$open_x500_subject=substr($_,1938,255);
		$open_x500_issuer=substr($_,2194,255);
		$rv=$insert{openfile}->execute($open_event_type,$open_event_qual,$open_time_written,$open_date_written,$open_system_smfid,$open_violation,$open_user_ndfnd,$open_user_warning,$open_evt_user_id,$open_evt_grp_id,$open_auth_normal,$open_auth_special,$open_auth_oper,$open_auth_audit,$open_auth_exit,$open_auth_failsft,$open_auth_bypass,$open_auth_trusted,$open_log_class,$open_log_user,$open_log_special,$open_log_access,$open_log_racinit,$open_log_always,$open_log_cmdviol,$open_log_global,$open_term_level,$open_backout_fail,$open_prof_same,$open_term,$open_job_name,$open_read_time,$open_read_date,$open_smf_user_id,$open_log_level,$open_log_vmevent,$open_log_logopt,$open_log_secl,$open_log_compatm,$open_log_applaud,$open_log_nonomvs,$open_log_omvsnprv,$open_auth_omvssu,$open_auth_omvssys,$open_usr_secl,$open_racf_version,$open_class,$open_user_name,$open_utk_encr,$open_utk_pre19,$open_utk_verprof,$open_utk_njeunusr,$open_utk_logusr,$open_utk_special,$open_utk_default,$open_utk_unknusr,$open_utk_error,$open_utk_trusted,$open_utk_sesstype,$open_utk_surrogat,$open_utk_remote,$open_utk_priv,$open_utk_secl,$open_utk_execnode,$open_utk_suser_id,$open_utk_snode,$open_utk_sgrp_id,$open_utk_spoe,$open_utk_spclass,$open_utk_user_id,$open_utk_grp_id,$open_utk_dft_grp,$open_utk_dft_secl,$open_appc_link,$open_audit_code,$open_old_real_uid,$open_old_eff_uid,$open_old_saved_uid,$open_old_real_gid,$open_old_eff_gid,$open_old_saved_gid,$open_path_name,$open_file_id,$open_file_own_uid,$open_file_own_gid,$open_old_s_isgid,$open_old_s_isuid,$open_old_s_isvtx,$open_old_own_read,$open_old_own_write,$open_old_own_exec,$open_old_grp_read,$open_old_grp_write,$open_old_grp_exec,$open_old_oth_read,$open_old_oth_write,$open_old_oth_exec,$open_new_s_isgid,$open_new_s_isuid,$open_new_s_isvtx,$open_new_own_read,$open_new_own_write,$open_new_own_exec,$open_new_grp_read,$open_new_grp_write,$open_new_grp_exec,$open_new_oth_read,$open_new_oth_write,$open_new_oth_exec,$open_unew_read,$open_unew_write,$open_unew_exec,$open_anew_read,$open_anew_write,$open_anew_exec,$open_req_s_isgid,$open_req_s_isuid,$open_req_s_isvtx,$open_req_own_read,$open_req_own_write,$open_req_own_exec,$open_req_grp_read,$open_req_grp_write,$open_req_grp_exec,$open_req_oth_read,$open_req_oth_write,$open_req_oth_exec,$open_filepool,$open_filespace,$open_inode,$open_scid,$open_dflt_process,$open_utk_netw,$open_x500_subject,$open_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"openfile"}++;
		next;
	}

	if ($rectype eq 'OPENSTTY') {
		$osty_event_type=substr($_,0,8);
		$osty_event_qual=substr($_,9,8);
		$osty_time_written=substr($_,18,8);
		if ($osty_time_written  eq ' ' x length($osty_time_written )) {
			undef $osty_time_written ;
		}
		$osty_date_written=substr($_,27,10);
		if ($osty_date_written  eq ' ' x length($osty_date_written )) {
			undef $osty_date_written ;
		}
		$osty_system_smfid=substr($_,38,4);
		$osty_violation=substr($_,43,1);
		$osty_user_ndfnd=substr($_,48,1);
		$osty_user_warning=substr($_,53,1);
		$osty_evt_user_id=substr($_,58,8);
		$osty_evt_grp_id=substr($_,67,8);
		$osty_auth_normal=substr($_,76,1);
		$osty_auth_special=substr($_,81,1);
		$osty_auth_oper=substr($_,86,1);
		$osty_auth_audit=substr($_,91,1);
		$osty_auth_exit=substr($_,96,1);
		$osty_auth_failsft=substr($_,101,1);
		$osty_auth_bypass=substr($_,106,1);
		$osty_auth_trusted=substr($_,111,1);
		$osty_log_class=substr($_,116,1);
		$osty_log_user=substr($_,121,1);
		$osty_log_special=substr($_,126,1);
		$osty_log_access=substr($_,131,1);
		$osty_log_racinit=substr($_,136,1);
		$osty_log_always=substr($_,141,1);
		$osty_log_cmdviol=substr($_,146,1);
		$osty_log_global=substr($_,151,1);
		$osty_term_level=substr($_,156,3);
		if ($osty_term_level  eq ' ' x length($osty_term_level )) {
			undef $osty_term_level ;
		}
		$osty_backout_fail=substr($_,160,1);
		$osty_prof_same=substr($_,165,1);
		$osty_term=substr($_,170,8);
		$osty_job_name=substr($_,179,8);
		$osty_read_time=substr($_,188,8);
		if ($osty_read_time  eq ' ' x length($osty_read_time )) {
			undef $osty_read_time ;
		}
		$osty_read_date=substr($_,197,10);
		if ($osty_read_date  eq ' ' x length($osty_read_date )) {
			undef $osty_read_date ;
		}
		$osty_smf_user_id=substr($_,208,8);
		$osty_log_level=substr($_,217,1);
		$osty_log_vmevent=substr($_,222,1);
		$osty_log_logopt=substr($_,227,1);
		$osty_log_secl=substr($_,232,1);
		$osty_log_compatm=substr($_,237,1);
		$osty_log_applaud=substr($_,242,1);
		$osty_log_nonomvs=substr($_,247,1);
		$osty_log_omvsnprv=substr($_,252,1);
		$osty_auth_omvssu=substr($_,257,1);
		$osty_auth_omvssys=substr($_,262,1);
		$osty_usr_secl=substr($_,267,8);
		$osty_racf_version=substr($_,276,4);
		$osty_class=substr($_,281,8);
		$osty_user_name=substr($_,290,20);
		$osty_utk_encr=substr($_,311,1);
		$osty_utk_pre19=substr($_,316,1);
		$osty_utk_verprof=substr($_,321,1);
		$osty_utk_njeunusr=substr($_,326,1);
		$osty_utk_logusr=substr($_,331,1);
		$osty_utk_special=substr($_,336,1);
		$osty_utk_default=substr($_,341,1);
		$osty_utk_unknusr=substr($_,346,1);
		$osty_utk_error=substr($_,351,1);
		$osty_utk_trusted=substr($_,356,1);
		$osty_utk_sesstype=substr($_,361,8);
		$osty_utk_surrogat=substr($_,370,1);
		$osty_utk_remote=substr($_,375,1);
		$osty_utk_priv=substr($_,380,1);
		$osty_utk_secl=substr($_,385,8);
		$osty_utk_execnode=substr($_,394,8);
		$osty_utk_suser_id=substr($_,403,8);
		$osty_utk_snode=substr($_,412,8);
		$osty_utk_sgrp_id=substr($_,421,8);
		$osty_utk_spoe=substr($_,430,8);
		$osty_utk_spclass=substr($_,439,8);
		$osty_utk_user_id=substr($_,448,8);
		$osty_utk_grp_id=substr($_,457,8);
		$osty_utk_dft_grp=substr($_,466,1);
		$osty_utk_dft_secl=substr($_,471,1);
		$osty_appc_link=substr($_,476,16);
		$osty_audit_code=substr($_,493,11);
		$osty_old_real_uid=substr($_,505,10);
		if ($osty_old_real_uid  eq ' ' x length($osty_old_real_uid )) {
			undef $osty_old_real_uid ;
		}
		$osty_old_eff_uid=substr($_,516,10);
		if ($osty_old_eff_uid  eq ' ' x length($osty_old_eff_uid )) {
			undef $osty_old_eff_uid ;
		}
		$osty_old_saved_uid=substr($_,527,10);
		if ($osty_old_saved_uid eq ' ' x length($osty_old_saved_uid)) {
			undef $osty_old_saved_uid;
		}
		$osty_old_real_gid=substr($_,538,10);
		if ($osty_old_real_gid  eq ' ' x length($osty_old_real_gid )) {
			undef $osty_old_real_gid ;
		}
		$osty_old_eff_gid=substr($_,549,10);
		if ($osty_old_eff_gid  eq ' ' x length($osty_old_eff_gid )) {
			undef $osty_old_eff_gid ;
		}
		$osty_old_saved_gid=substr($_,560,10);
		if ($osty_old_saved_gid eq ' ' x length($osty_old_saved_gid)) {
			undef $osty_old_saved_gid;
		}
		$osty_tgt_real_uid=substr($_,571,10);
		if ($osty_tgt_real_uid  eq ' ' x length($osty_tgt_real_uid )) {
			undef $osty_tgt_real_uid ;
		}
		$osty_tgt_eff_uid=substr($_,582,10);
		if ($osty_tgt_eff_uid  eq ' ' x length($osty_tgt_eff_uid )) {
			undef $osty_tgt_eff_uid ;
		}
		$osty_tgt_sav_uid=substr($_,593,10);
		if ($osty_tgt_sav_uid  eq ' ' x length($osty_tgt_sav_uid )) {
			undef $osty_tgt_sav_uid ;
		}
		$osty_tgt_pid=substr($_,604,10);
		if ($osty_tgt_pid  eq ' ' x length($osty_tgt_pid )) {
			undef $osty_tgt_pid ;
		}
		$osty_dflt_process=substr($_,615,1);
		$osty_utk_netw=substr($_,620,8);
		$osty_x500_subject=substr($_,629,255);
		$osty_x500_issuer=substr($_,885,255);
		$rv=$insert{openstty}->execute($osty_event_type,$osty_event_qual,$osty_time_written,$osty_date_written,$osty_system_smfid,$osty_violation,$osty_user_ndfnd,$osty_user_warning,$osty_evt_user_id,$osty_evt_grp_id,$osty_auth_normal,$osty_auth_special,$osty_auth_oper,$osty_auth_audit,$osty_auth_exit,$osty_auth_failsft,$osty_auth_bypass,$osty_auth_trusted,$osty_log_class,$osty_log_user,$osty_log_special,$osty_log_access,$osty_log_racinit,$osty_log_always,$osty_log_cmdviol,$osty_log_global,$osty_term_level,$osty_backout_fail,$osty_prof_same,$osty_term,$osty_job_name,$osty_read_time,$osty_read_date,$osty_smf_user_id,$osty_log_level,$osty_log_vmevent,$osty_log_logopt,$osty_log_secl,$osty_log_compatm,$osty_log_applaud,$osty_log_nonomvs,$osty_log_omvsnprv,$osty_auth_omvssu,$osty_auth_omvssys,$osty_usr_secl,$osty_racf_version,$osty_class,$osty_user_name,$osty_utk_encr,$osty_utk_pre19,$osty_utk_verprof,$osty_utk_njeunusr,$osty_utk_logusr,$osty_utk_special,$osty_utk_default,$osty_utk_unknusr,$osty_utk_error,$osty_utk_trusted,$osty_utk_sesstype,$osty_utk_surrogat,$osty_utk_remote,$osty_utk_priv,$osty_utk_secl,$osty_utk_execnode,$osty_utk_suser_id,$osty_utk_snode,$osty_utk_sgrp_id,$osty_utk_spoe,$osty_utk_spclass,$osty_utk_user_id,$osty_utk_grp_id,$osty_utk_dft_grp,$osty_utk_dft_secl,$osty_appc_link,$osty_audit_code,$osty_old_real_uid,$osty_old_eff_uid,$osty_old_saved_uid,$osty_old_real_gid,$osty_old_eff_gid,$osty_old_saved_gid,$osty_tgt_real_uid,$osty_tgt_eff_uid,$osty_tgt_sav_uid,$osty_tgt_pid,$osty_dflt_process,$osty_utk_netw,$osty_x500_subject,$osty_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"openstty"}++;
		next;
	}

	if ($rectype eq 'PASSWORD') {
		$pwd_event_type=substr($_,0,8);
		$pwd_event_qual=substr($_,9,8);
		$pwd_time_written=substr($_,18,8);
		if ($pwd_time_written  eq ' ' x length($pwd_time_written )) {
			undef $pwd_time_written ;
		}
		$pwd_date_written=substr($_,27,10);
		if ($pwd_date_written  eq ' ' x length($pwd_date_written )) {
			undef $pwd_date_written ;
		}
		$pwd_system_smfid=substr($_,38,4);
		$pwd_violation=substr($_,43,1);
		$pwd_user_ndfnd=substr($_,48,1);
		$pwd_user_warning=substr($_,53,1);
		$pwd_evt_user_id=substr($_,58,8);
		$pwd_evt_grp_id=substr($_,67,8);
		$pwd_auth_normal=substr($_,76,1);
		$pwd_auth_special=substr($_,81,1);
		$pwd_auth_oper=substr($_,86,1);
		$pwd_auth_audit=substr($_,91,1);
		$pwd_auth_exit=substr($_,96,1);
		$pwd_auth_failsft=substr($_,101,1);
		$pwd_auth_bypass=substr($_,106,1);
		$pwd_auth_trusted=substr($_,111,1);
		$pwd_log_class=substr($_,116,1);
		$pwd_log_user=substr($_,121,1);
		$pwd_log_special=substr($_,126,1);
		$pwd_log_access=substr($_,131,1);
		$pwd_log_racinit=substr($_,136,1);
		$pwd_log_always=substr($_,141,1);
		$pwd_log_cmdviol=substr($_,146,1);
		$pwd_log_global=substr($_,151,1);
		$pwd_term_level=substr($_,156,3);
		if ($pwd_term_level  eq ' ' x length($pwd_term_level )) {
			undef $pwd_term_level ;
		}
		$pwd_backout_fail=substr($_,160,1);
		$pwd_prof_same=substr($_,165,1);
		$pwd_term=substr($_,170,8);
		$pwd_job_name=substr($_,179,8);
		$pwd_read_time=substr($_,188,8);
		if ($pwd_read_time  eq ' ' x length($pwd_read_time )) {
			undef $pwd_read_time ;
		}
		$pwd_read_date=substr($_,197,10);
		if ($pwd_read_date  eq ' ' x length($pwd_read_date )) {
			undef $pwd_read_date ;
		}
		$pwd_smf_user_id=substr($_,208,8);
		$pwd_log_level=substr($_,217,1);
		$pwd_log_vmevent=substr($_,222,1);
		$pwd_log_logopt=substr($_,227,1);
		$pwd_log_secl=substr($_,232,1);
		$pwd_log_compatm=substr($_,237,1);
		$pwd_log_applaud=substr($_,242,1);
		$pwd_log_nonomvs=substr($_,247,1);
		$pwd_log_omvsnprv=substr($_,252,1);
		$pwd_auth_omvssu=substr($_,257,1);
		$pwd_auth_omvssys=substr($_,262,1);
		$pwd_usr_secl=substr($_,267,8);
		$pwd_racf_version=substr($_,276,4);
		$pwd_own_id=substr($_,281,8);
		$pwd_user_name=substr($_,290,20);
		$pwd_utk_encr=substr($_,311,1);
		$pwd_utk_pre19=substr($_,316,1);
		$pwd_utk_verprof=substr($_,321,1);
		$pwd_utk_njeunusr=substr($_,326,1);
		$pwd_utk_logusr=substr($_,331,1);
		$pwd_utk_special=substr($_,336,1);
		$pwd_utk_default=substr($_,341,1);
		$pwd_utk_unknusr=substr($_,346,1);
		$pwd_utk_error=substr($_,351,1);
		$pwd_utk_trusted=substr($_,356,1);
		$pwd_utk_sesstype=substr($_,361,8);
		$pwd_utk_surrogat=substr($_,370,1);
		$pwd_utk_remote=substr($_,375,1);
		$pwd_utk_priv=substr($_,380,1);
		$pwd_utk_secl=substr($_,385,8);
		$pwd_utk_execnode=substr($_,394,8);
		$pwd_utk_suser_id=substr($_,403,8);
		$pwd_utk_snode=substr($_,412,8);
		$pwd_utk_sgrp_id=substr($_,421,8);
		$pwd_utk_spoe=substr($_,430,8);
		$pwd_utk_spclass=substr($_,439,8);
		$pwd_utk_user_id=substr($_,448,8);
		$pwd_utk_grp_id=substr($_,457,8);
		$pwd_utk_dft_grp=substr($_,466,1);
		$pwd_utk_dft_secl=substr($_,471,1);
		$pwd_appc_link=substr($_,476,16);
		$pwd_specified=substr($_,493,1024);
		$pwd_failed=substr($_,1518,1024);
		$pwd_ignored=substr($_,2543,1024);
		$pwd_utk_netw=substr($_,3568,8);
		$pwd_x500_subject=substr($_,3577,255);
		$pwd_x500_issuer=substr($_,3833,255);
		$rv=$insert{password}->execute($pwd_event_type,$pwd_event_qual,$pwd_time_written,$pwd_date_written,$pwd_system_smfid,$pwd_violation,$pwd_user_ndfnd,$pwd_user_warning,$pwd_evt_user_id,$pwd_evt_grp_id,$pwd_auth_normal,$pwd_auth_special,$pwd_auth_oper,$pwd_auth_audit,$pwd_auth_exit,$pwd_auth_failsft,$pwd_auth_bypass,$pwd_auth_trusted,$pwd_log_class,$pwd_log_user,$pwd_log_special,$pwd_log_access,$pwd_log_racinit,$pwd_log_always,$pwd_log_cmdviol,$pwd_log_global,$pwd_term_level,$pwd_backout_fail,$pwd_prof_same,$pwd_term,$pwd_job_name,$pwd_read_time,$pwd_read_date,$pwd_smf_user_id,$pwd_log_level,$pwd_log_vmevent,$pwd_log_logopt,$pwd_log_secl,$pwd_log_compatm,$pwd_log_applaud,$pwd_log_nonomvs,$pwd_log_omvsnprv,$pwd_auth_omvssu,$pwd_auth_omvssys,$pwd_usr_secl,$pwd_racf_version,$pwd_own_id,$pwd_user_name,$pwd_utk_encr,$pwd_utk_pre19,$pwd_utk_verprof,$pwd_utk_njeunusr,$pwd_utk_logusr,$pwd_utk_special,$pwd_utk_default,$pwd_utk_unknusr,$pwd_utk_error,$pwd_utk_trusted,$pwd_utk_sesstype,$pwd_utk_surrogat,$pwd_utk_remote,$pwd_utk_priv,$pwd_utk_secl,$pwd_utk_execnode,$pwd_utk_suser_id,$pwd_utk_snode,$pwd_utk_sgrp_id,$pwd_utk_spoe,$pwd_utk_spclass,$pwd_utk_user_id,$pwd_utk_grp_id,$pwd_utk_dft_grp,$pwd_utk_dft_secl,$pwd_appc_link,$pwd_specified,$pwd_failed,$pwd_ignored,$pwd_utk_netw,$pwd_x500_subject,$pwd_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"password"}++;
		next;
	}

	if ($rectype eq 'PDACCESS') {
		$pdac_event_type=substr($_,0,8);
		$pdac_event_qual=substr($_,9,8);
		$pdac_time_written=substr($_,18,8);
		if ($pdac_time_written  eq ' ' x length($pdac_time_written )) {
			undef $pdac_time_written ;
		}
		$pdac_date_written=substr($_,27,10);
		if ($pdac_date_written  eq ' ' x length($pdac_date_written )) {
			undef $pdac_date_written ;
		}
		$pdac_system_smfid=substr($_,38,4);
		$pdac_violation=substr($_,43,1);
		$pdac_user_ndfnd=substr($_,48,1);
		$pdac_user_warning=substr($_,53,1);
		$pdac_evt_user_id=substr($_,58,8);
		$pdac_evt_grp_id=substr($_,67,8);
		$pdac_auth_normal=substr($_,76,1);
		$pdac_auth_special=substr($_,81,1);
		$pdac_auth_oper=substr($_,86,1);
		$pdac_auth_audit=substr($_,91,1);
		$pdac_auth_exit=substr($_,96,1);
		$pdac_auth_failsft=substr($_,101,1);
		$pdac_auth_bypass=substr($_,106,1);
		$pdac_auth_trusted=substr($_,111,1);
		$pdac_log_class=substr($_,116,1);
		$pdac_log_user=substr($_,121,1);
		$pdac_log_special=substr($_,126,1);
		$pdac_log_access=substr($_,131,1);
		$pdac_log_racinit=substr($_,136,1);
		$pdac_log_always=substr($_,141,1);
		$pdac_log_cmdviol=substr($_,146,1);
		$pdac_log_global=substr($_,151,1);
		$pdac_term_level=substr($_,156,3);
		if ($pdac_term_level  eq ' ' x length($pdac_term_level )) {
			undef $pdac_term_level ;
		}
		$pdac_backout_fail=substr($_,160,1);
		$pdac_prof_same=substr($_,165,1);
		$pdac_term=substr($_,170,8);
		$pdac_job_name=substr($_,179,8);
		$pdac_read_time=substr($_,188,8);
		if ($pdac_read_time  eq ' ' x length($pdac_read_time )) {
			undef $pdac_read_time ;
		}
		$pdac_read_date=substr($_,197,10);
		if ($pdac_read_date  eq ' ' x length($pdac_read_date )) {
			undef $pdac_read_date ;
		}
		$pdac_smf_user_id=substr($_,208,8);
		$pdac_log_level=substr($_,217,1);
		$pdac_log_vmevent=substr($_,222,1);
		$pdac_log_logopt=substr($_,227,1);
		$pdac_log_secl=substr($_,232,1);
		$pdac_log_compatm=substr($_,237,1);
		$pdac_log_applaud=substr($_,242,1);
		$pdac_log_nonomvs=substr($_,247,1);
		$pdac_log_omvsnprv=substr($_,252,1);
		$pdac_auth_omvssu=substr($_,257,1);
		$pdac_auth_omvssys=substr($_,262,1);
		$pdac_usr_secl=substr($_,267,8);
		$pdac_racf_version=substr($_,276,4);
		$pdac_object=substr($_,281,4096);
		$pdac_req_perms=substr($_,4378,1024);
		$pdac_host_userid=substr($_,5403,8);
		$pdac_principal=substr($_,5412,36);
		$pdac_qop=substr($_,5449,10);
		if ($pdac_qop  eq ' ' x length($pdac_qop )) {
			undef $pdac_qop ;
		}
		$pdac_cred_type=substr($_,5460,30);
		$rv=$insert{pdaccess}->execute($pdac_event_type,$pdac_event_qual,$pdac_time_written,$pdac_date_written,$pdac_system_smfid,$pdac_violation,$pdac_user_ndfnd,$pdac_user_warning,$pdac_evt_user_id,$pdac_evt_grp_id,$pdac_auth_normal,$pdac_auth_special,$pdac_auth_oper,$pdac_auth_audit,$pdac_auth_exit,$pdac_auth_failsft,$pdac_auth_bypass,$pdac_auth_trusted,$pdac_log_class,$pdac_log_user,$pdac_log_special,$pdac_log_access,$pdac_log_racinit,$pdac_log_always,$pdac_log_cmdviol,$pdac_log_global,$pdac_term_level,$pdac_backout_fail,$pdac_prof_same,$pdac_term,$pdac_job_name,$pdac_read_time,$pdac_read_date,$pdac_smf_user_id,$pdac_log_level,$pdac_log_vmevent,$pdac_log_logopt,$pdac_log_secl,$pdac_log_compatm,$pdac_log_applaud,$pdac_log_nonomvs,$pdac_log_omvsnprv,$pdac_auth_omvssu,$pdac_auth_omvssys,$pdac_usr_secl,$pdac_racf_version,$pdac_object,$pdac_req_perms,$pdac_host_userid,$pdac_principal,$pdac_qop,$pdac_cred_type);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"pdaccess"}++;
		next;
	}

	if ($rectype eq 'PERMIT  ') {
		$perm_event_type=substr($_,0,8);
		$perm_event_qual=substr($_,9,8);
		$perm_time_written=substr($_,18,8);
		if ($perm_time_written  eq ' ' x length($perm_time_written )) {
			undef $perm_time_written ;
		}
		$perm_date_written=substr($_,27,10);
		if ($perm_date_written  eq ' ' x length($perm_date_written )) {
			undef $perm_date_written ;
		}
		$perm_system_smfid=substr($_,38,4);
		$perm_violation=substr($_,43,1);
		$perm_user_ndfnd=substr($_,48,1);
		$perm_user_warning=substr($_,53,1);
		$perm_evt_user_id=substr($_,58,8);
		$perm_evt_grp_id=substr($_,67,8);
		$perm_auth_normal=substr($_,76,1);
		$perm_auth_special=substr($_,81,1);
		$perm_auth_oper=substr($_,86,1);
		$perm_auth_audit=substr($_,91,1);
		$perm_auth_exit=substr($_,96,1);
		$perm_auth_failsft=substr($_,101,1);
		$perm_auth_bypass=substr($_,106,1);
		$perm_auth_trusted=substr($_,111,1);
		$perm_log_class=substr($_,116,1);
		$perm_log_user=substr($_,121,1);
		$perm_log_special=substr($_,126,1);
		$perm_log_access=substr($_,131,1);
		$perm_log_racinit=substr($_,136,1);
		$perm_log_always=substr($_,141,1);
		$perm_log_cmdviol=substr($_,146,1);
		$perm_log_global=substr($_,151,1);
		$perm_term_level=substr($_,156,3);
		if ($perm_term_level  eq ' ' x length($perm_term_level )) {
			undef $perm_term_level ;
		}
		$perm_backout_fail=substr($_,160,1);
		$perm_prof_same=substr($_,165,1);
		$perm_term=substr($_,170,8);
		$perm_job_name=substr($_,179,8);
		$perm_read_time=substr($_,188,8);
		if ($perm_read_time  eq ' ' x length($perm_read_time )) {
			undef $perm_read_time ;
		}
		$perm_read_date=substr($_,197,10);
		if ($perm_read_date  eq ' ' x length($perm_read_date )) {
			undef $perm_read_date ;
		}
		$perm_smf_user_id=substr($_,208,8);
		$perm_log_level=substr($_,217,1);
		$perm_log_vmevent=substr($_,222,1);
		$perm_log_logopt=substr($_,227,1);
		$perm_log_secl=substr($_,232,1);
		$perm_log_compatm=substr($_,237,1);
		$perm_log_applaud=substr($_,242,1);
		$perm_log_nonomvs=substr($_,247,1);
		$perm_log_omvsnprv=substr($_,252,1);
		$perm_auth_omvssu=substr($_,257,1);
		$perm_auth_omvssys=substr($_,262,1);
		$perm_usr_secl=substr($_,267,8);
		$perm_racf_version=substr($_,276,4);
		$perm_class=substr($_,281,8);
		$perm_own_id=substr($_,290,8);
		$perm_user_name=substr($_,299,20);
		$perm_utk_encr=substr($_,320,1);
		$perm_utk_pre19=substr($_,325,1);
		$perm_utk_verprof=substr($_,330,1);
		$perm_utk_njeunusr=substr($_,335,1);
		$perm_utk_logusr=substr($_,340,1);
		$perm_utk_special=substr($_,345,1);
		$perm_utk_default=substr($_,350,1);
		$perm_utk_unknusr=substr($_,355,1);
		$perm_utk_error=substr($_,360,1);
		$perm_utk_trusted=substr($_,365,1);
		$perm_utk_sesstype=substr($_,370,8);
		$perm_utk_surrogat=substr($_,379,1);
		$perm_utk_remote=substr($_,384,1);
		$perm_utk_priv=substr($_,389,1);
		$perm_utk_secl=substr($_,394,8);
		$perm_utk_execnode=substr($_,403,8);
		$perm_utk_suser_id=substr($_,412,8);
		$perm_utk_snode=substr($_,421,8);
		$perm_utk_sgrp_id=substr($_,430,8);
		$perm_utk_spoe=substr($_,439,8);
		$perm_utk_spclass=substr($_,448,8);
		$perm_utk_user_id=substr($_,457,8);
		$perm_utk_grp_id=substr($_,466,8);
		$perm_utk_dft_grp=substr($_,475,1);
		$perm_utk_dft_secl=substr($_,480,1);
		$perm_appc_link=substr($_,485,16);
		$perm_res_name=substr($_,502,255);
		$perm_specified=substr($_,758,1024);
		$perm_failed=substr($_,1783,1024);
		$perm_ignored=substr($_,2808,1024);
		$perm_utk_netw=substr($_,3833,8);
		$perm_x500_subject=substr($_,3842,255);
		$perm_x500_issuer=substr($_,4098,255);
		$rv=$insert{permit}->execute($perm_event_type,$perm_event_qual,$perm_time_written,$perm_date_written,$perm_system_smfid,$perm_violation,$perm_user_ndfnd,$perm_user_warning,$perm_evt_user_id,$perm_evt_grp_id,$perm_auth_normal,$perm_auth_special,$perm_auth_oper,$perm_auth_audit,$perm_auth_exit,$perm_auth_failsft,$perm_auth_bypass,$perm_auth_trusted,$perm_log_class,$perm_log_user,$perm_log_special,$perm_log_access,$perm_log_racinit,$perm_log_always,$perm_log_cmdviol,$perm_log_global,$perm_term_level,$perm_backout_fail,$perm_prof_same,$perm_term,$perm_job_name,$perm_read_time,$perm_read_date,$perm_smf_user_id,$perm_log_level,$perm_log_vmevent,$perm_log_logopt,$perm_log_secl,$perm_log_compatm,$perm_log_applaud,$perm_log_nonomvs,$perm_log_omvsnprv,$perm_auth_omvssu,$perm_auth_omvssys,$perm_usr_secl,$perm_racf_version,$perm_class,$perm_own_id,$perm_user_name,$perm_utk_encr,$perm_utk_pre19,$perm_utk_verprof,$perm_utk_njeunusr,$perm_utk_logusr,$perm_utk_special,$perm_utk_default,$perm_utk_unknusr,$perm_utk_error,$perm_utk_trusted,$perm_utk_sesstype,$perm_utk_surrogat,$perm_utk_remote,$perm_utk_priv,$perm_utk_secl,$perm_utk_execnode,$perm_utk_suser_id,$perm_utk_snode,$perm_utk_sgrp_id,$perm_utk_spoe,$perm_utk_spclass,$perm_utk_user_id,$perm_utk_grp_id,$perm_utk_dft_grp,$perm_utk_dft_secl,$perm_appc_link,$perm_res_name,$perm_specified,$perm_failed,$perm_ignored,$perm_utk_netw,$perm_x500_subject,$perm_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"permit"}++;
		next;
	}

	if ($rectype eq 'PTRACE  ') {
		$ptrc_event_type=substr($_,0,8);
		$ptrc_event_qual=substr($_,9,8);
		$ptrc_time_written=substr($_,18,8);
		if ($ptrc_time_written  eq ' ' x length($ptrc_time_written )) {
			undef $ptrc_time_written ;
		}
		$ptrc_date_written=substr($_,27,10);
		if ($ptrc_date_written  eq ' ' x length($ptrc_date_written )) {
			undef $ptrc_date_written ;
		}
		$ptrc_system_smfid=substr($_,38,4);
		$ptrc_violation=substr($_,43,1);
		$ptrc_user_ndfnd=substr($_,48,1);
		$ptrc_user_warning=substr($_,53,1);
		$ptrc_evt_user_id=substr($_,58,8);
		$ptrc_evt_grp_id=substr($_,67,8);
		$ptrc_auth_normal=substr($_,76,1);
		$ptrc_auth_special=substr($_,81,1);
		$ptrc_auth_oper=substr($_,86,1);
		$ptrc_auth_audit=substr($_,91,1);
		$ptrc_auth_exit=substr($_,96,1);
		$ptrc_auth_failsft=substr($_,101,1);
		$ptrc_auth_bypass=substr($_,106,1);
		$ptrc_auth_trusted=substr($_,111,1);
		$ptrc_log_class=substr($_,116,1);
		$ptrc_log_user=substr($_,121,1);
		$ptrc_log_special=substr($_,126,1);
		$ptrc_log_access=substr($_,131,1);
		$ptrc_log_racinit=substr($_,136,1);
		$ptrc_log_always=substr($_,141,1);
		$ptrc_log_cmdviol=substr($_,146,1);
		$ptrc_log_global=substr($_,151,1);
		$ptrc_term_level=substr($_,156,3);
		if ($ptrc_term_level  eq ' ' x length($ptrc_term_level )) {
			undef $ptrc_term_level ;
		}
		$ptrc_backout_fail=substr($_,160,1);
		$ptrc_prof_same=substr($_,165,1);
		$ptrc_term=substr($_,170,8);
		$ptrc_job_name=substr($_,179,8);
		$ptrc_read_time=substr($_,188,8);
		if ($ptrc_read_time  eq ' ' x length($ptrc_read_time )) {
			undef $ptrc_read_time ;
		}
		$ptrc_read_date=substr($_,197,10);
		if ($ptrc_read_date  eq ' ' x length($ptrc_read_date )) {
			undef $ptrc_read_date ;
		}
		$ptrc_smf_user_id=substr($_,208,8);
		$ptrc_log_level=substr($_,217,1);
		$ptrc_log_vmevent=substr($_,222,1);
		$ptrc_log_logopt=substr($_,227,1);
		$ptrc_log_secl=substr($_,232,1);
		$ptrc_log_compatm=substr($_,237,1);
		$ptrc_log_applaud=substr($_,242,1);
		$ptrc_log_nonomvs=substr($_,247,1);
		$ptrc_log_omvsnprv=substr($_,252,1);
		$ptrc_auth_omvssu=substr($_,257,1);
		$ptrc_auth_omvssys=substr($_,262,1);
		$ptrc_usr_secl=substr($_,267,8);
		$ptrc_racf_version=substr($_,276,4);
		$ptrc_class=substr($_,281,8);
		$ptrc_user_name=substr($_,290,20);
		$ptrc_utk_encr=substr($_,311,1);
		$ptrc_utk_pre19=substr($_,316,1);
		$ptrc_utk_verprof=substr($_,321,1);
		$ptrc_utk_njeunusr=substr($_,326,1);
		$ptrc_utk_logusr=substr($_,331,1);
		$ptrc_utk_special=substr($_,336,1);
		$ptrc_utk_default=substr($_,341,1);
		$ptrc_utk_unknusr=substr($_,346,1);
		$ptrc_utk_error=substr($_,351,1);
		$ptrc_utk_trusted=substr($_,356,1);
		$ptrc_utk_sesstype=substr($_,361,8);
		$ptrc_utk_surrogat=substr($_,370,1);
		$ptrc_utk_remote=substr($_,375,1);
		$ptrc_utk_priv=substr($_,380,1);
		$ptrc_utk_secl=substr($_,385,8);
		$ptrc_utk_execnode=substr($_,394,8);
		$ptrc_utk_suser_id=substr($_,403,8);
		$ptrc_utk_snode=substr($_,412,8);
		$ptrc_utk_sgrp_id=substr($_,421,8);
		$ptrc_utk_spoe=substr($_,430,8);
		$ptrc_utk_spclass=substr($_,439,8);
		$ptrc_utk_user_id=substr($_,448,8);
		$ptrc_utk_grp_id=substr($_,457,8);
		$ptrc_utk_dft_grp=substr($_,466,1);
		$ptrc_utk_dft_secl=substr($_,471,1);
		$ptrc_appc_link=substr($_,476,16);
		$ptrc_audit_code=substr($_,493,11);
		$ptrc_old_real_uid=substr($_,505,10);
		if ($ptrc_old_real_uid  eq ' ' x length($ptrc_old_real_uid )) {
			undef $ptrc_old_real_uid ;
		}
		$ptrc_old_eff_uid=substr($_,516,10);
		if ($ptrc_old_eff_uid  eq ' ' x length($ptrc_old_eff_uid )) {
			undef $ptrc_old_eff_uid ;
		}
		$ptrc_old_saved_uid=substr($_,527,10);
		if ($ptrc_old_saved_uid eq ' ' x length($ptrc_old_saved_uid)) {
			undef $ptrc_old_saved_uid;
		}
		$ptrc_old_real_gid=substr($_,538,10);
		if ($ptrc_old_real_gid  eq ' ' x length($ptrc_old_real_gid )) {
			undef $ptrc_old_real_gid ;
		}
		$ptrc_old_eff_gid=substr($_,549,10);
		if ($ptrc_old_eff_gid  eq ' ' x length($ptrc_old_eff_gid )) {
			undef $ptrc_old_eff_gid ;
		}
		$ptrc_old_saved_gid=substr($_,560,10);
		if ($ptrc_old_saved_gid eq ' ' x length($ptrc_old_saved_gid)) {
			undef $ptrc_old_saved_gid;
		}
		$ptrc_tgt_real_uid=substr($_,571,10);
		if ($ptrc_tgt_real_uid  eq ' ' x length($ptrc_tgt_real_uid )) {
			undef $ptrc_tgt_real_uid ;
		}
		$ptrc_tgt_eff_uid=substr($_,582,10);
		if ($ptrc_tgt_eff_uid  eq ' ' x length($ptrc_tgt_eff_uid )) {
			undef $ptrc_tgt_eff_uid ;
		}
		$ptrc_tgt_saved_uid=substr($_,593,10);
		if ($ptrc_tgt_saved_uid eq ' ' x length($ptrc_tgt_saved_uid)) {
			undef $ptrc_tgt_saved_uid;
		}
		$ptrc_tgt_real_gid=substr($_,604,10);
		if ($ptrc_tgt_real_gid  eq ' ' x length($ptrc_tgt_real_gid )) {
			undef $ptrc_tgt_real_gid ;
		}
		$ptrc_tgt_eff_gid=substr($_,615,10);
		if ($ptrc_tgt_eff_gid  eq ' ' x length($ptrc_tgt_eff_gid )) {
			undef $ptrc_tgt_eff_gid ;
		}
		$ptrc_tgt_saved_gid=substr($_,626,10);
		if ($ptrc_tgt_saved_gid eq ' ' x length($ptrc_tgt_saved_gid)) {
			undef $ptrc_tgt_saved_gid;
		}
		$ptrc_tgt_pid=substr($_,637,10);
		if ($ptrc_tgt_pid  eq ' ' x length($ptrc_tgt_pid )) {
			undef $ptrc_tgt_pid ;
		}
		$ptrc_dflt_process=substr($_,648,1);
		$ptrc_utk_netw=substr($_,653,8);
		$ptrc_x500_subject=substr($_,662,255);
		$ptrc_x500_issuer=substr($_,918,255);
		$rv=$insert{ptrace}->execute($ptrc_event_type,$ptrc_event_qual,$ptrc_time_written,$ptrc_date_written,$ptrc_system_smfid,$ptrc_violation,$ptrc_user_ndfnd,$ptrc_user_warning,$ptrc_evt_user_id,$ptrc_evt_grp_id,$ptrc_auth_normal,$ptrc_auth_special,$ptrc_auth_oper,$ptrc_auth_audit,$ptrc_auth_exit,$ptrc_auth_failsft,$ptrc_auth_bypass,$ptrc_auth_trusted,$ptrc_log_class,$ptrc_log_user,$ptrc_log_special,$ptrc_log_access,$ptrc_log_racinit,$ptrc_log_always,$ptrc_log_cmdviol,$ptrc_log_global,$ptrc_term_level,$ptrc_backout_fail,$ptrc_prof_same,$ptrc_term,$ptrc_job_name,$ptrc_read_time,$ptrc_read_date,$ptrc_smf_user_id,$ptrc_log_level,$ptrc_log_vmevent,$ptrc_log_logopt,$ptrc_log_secl,$ptrc_log_compatm,$ptrc_log_applaud,$ptrc_log_nonomvs,$ptrc_log_omvsnprv,$ptrc_auth_omvssu,$ptrc_auth_omvssys,$ptrc_usr_secl,$ptrc_racf_version,$ptrc_class,$ptrc_user_name,$ptrc_utk_encr,$ptrc_utk_pre19,$ptrc_utk_verprof,$ptrc_utk_njeunusr,$ptrc_utk_logusr,$ptrc_utk_special,$ptrc_utk_default,$ptrc_utk_unknusr,$ptrc_utk_error,$ptrc_utk_trusted,$ptrc_utk_sesstype,$ptrc_utk_surrogat,$ptrc_utk_remote,$ptrc_utk_priv,$ptrc_utk_secl,$ptrc_utk_execnode,$ptrc_utk_suser_id,$ptrc_utk_snode,$ptrc_utk_sgrp_id,$ptrc_utk_spoe,$ptrc_utk_spclass,$ptrc_utk_user_id,$ptrc_utk_grp_id,$ptrc_utk_dft_grp,$ptrc_utk_dft_secl,$ptrc_appc_link,$ptrc_audit_code,$ptrc_old_real_uid,$ptrc_old_eff_uid,$ptrc_old_saved_uid,$ptrc_old_real_gid,$ptrc_old_eff_gid,$ptrc_old_saved_gid,$ptrc_tgt_real_uid,$ptrc_tgt_eff_uid,$ptrc_tgt_saved_uid,$ptrc_tgt_real_gid,$ptrc_tgt_eff_gid,$ptrc_tgt_saved_gid,$ptrc_tgt_pid,$ptrc_dflt_process,$ptrc_utk_netw,$ptrc_x500_subject,$ptrc_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ptrace"}++;
		next;
	}

	if ($rectype eq 'RACDCERT') {
		$racd_event_type=substr($_,0,8);
		$racd_event_qual=substr($_,9,8);
		$racd_time_written=substr($_,18,8);
		if ($racd_time_written  eq ' ' x length($racd_time_written )) {
			undef $racd_time_written ;
		}
		$racd_date_written=substr($_,27,10);
		if ($racd_date_written  eq ' ' x length($racd_date_written )) {
			undef $racd_date_written ;
		}
		$racd_system_smfid=substr($_,38,4);
		$racd_violation=substr($_,43,1);
		$racd_user_ndfnd=substr($_,48,1);
		$racd_user_warning=substr($_,53,1);
		$racd_evt_user_id=substr($_,58,8);
		$racd_evt_grp_id=substr($_,67,8);
		$racd_auth_normal=substr($_,76,1);
		$racd_auth_special=substr($_,81,1);
		$racd_auth_oper=substr($_,86,1);
		$racd_auth_audit=substr($_,91,1);
		$racd_auth_exit=substr($_,96,1);
		$racd_auth_failsft=substr($_,101,1);
		$racd_auth_bypass=substr($_,106,1);
		$racd_auth_trusted=substr($_,111,1);
		$racd_log_class=substr($_,116,1);
		$racd_log_user=substr($_,121,1);
		$racd_log_special=substr($_,126,1);
		$racd_log_access=substr($_,131,1);
		$racd_log_racinit=substr($_,136,1);
		$racd_log_always=substr($_,141,1);
		$racd_log_cmdviol=substr($_,146,1);
		$racd_log_global=substr($_,151,1);
		$racd_term_level=substr($_,156,3);
		if ($racd_term_level  eq ' ' x length($racd_term_level )) {
			undef $racd_term_level ;
		}
		$racd_backout_fail=substr($_,160,1);
		$racd_prof_same=substr($_,165,1);
		$racd_term=substr($_,170,8);
		$racd_job_name=substr($_,179,8);
		$racd_read_time=substr($_,188,8);
		if ($racd_read_time  eq ' ' x length($racd_read_time )) {
			undef $racd_read_time ;
		}
		$racd_read_date=substr($_,197,10);
		if ($racd_read_date  eq ' ' x length($racd_read_date )) {
			undef $racd_read_date ;
		}
		$racd_smf_user_id=substr($_,208,8);
		$racd_log_level=substr($_,217,1);
		$racd_log_vmevent=substr($_,222,1);
		$racd_log_logopt=substr($_,227,1);
		$racd_log_secl=substr($_,232,1);
		$racd_log_compatm=substr($_,237,1);
		$racd_log_applaud=substr($_,242,1);
		$racd_log_nonomvs=substr($_,247,1);
		$racd_log_omvsnprv=substr($_,252,1);
		$racd_auth_omvssu=substr($_,257,1);
		$racd_auth_omvssys=substr($_,262,1);
		$racd_usr_secl=substr($_,267,8);
		$racd_racf_version=substr($_,276,4);
		$racd_user_name=substr($_,281,20);
		$racd_utk_encr=substr($_,302,1);
		$racd_utk_pre19=substr($_,307,1);
		$racd_utk_verprof=substr($_,312,1);
		$racd_utk_njeunusr=substr($_,317,1);
		$racd_utk_logusr=substr($_,322,1);
		$racd_utk_special=substr($_,327,1);
		$racd_utk_default=substr($_,332,1);
		$racd_utk_unknusr=substr($_,337,1);
		$racd_utk_error=substr($_,342,1);
		$racd_utk_trusted=substr($_,347,1);
		$racd_utk_sesstype=substr($_,352,8);
		$racd_utk_surrogat=substr($_,361,1);
		$racd_utk_remote=substr($_,366,1);
		$racd_utk_priv=substr($_,371,1);
		$racd_utk_secl=substr($_,376,8);
		$racd_utk_execnode=substr($_,385,8);
		$racd_utk_suser_id=substr($_,394,8);
		$racd_utk_snode=substr($_,403,8);
		$racd_utk_sgrp_id=substr($_,412,8);
		$racd_utk_spoe=substr($_,421,8);
		$racd_utk_spclass=substr($_,430,8);
		$racd_utk_user_id=substr($_,439,8);
		$racd_utk_grp_id=substr($_,448,8);
		$racd_utk_dft_grp=substr($_,457,1);
		$racd_utk_dft_secl=substr($_,462,1);
		$racd_serial_number=substr($_,467,255);
		$racd_issuers_dn=substr($_,723,255);
		$racd_cert_ds=substr($_,979,44);
		$racd_specified=substr($_,1024,1024);
		$racd_utk_netw=substr($_,2049,8);
		$racd_x500_subject=substr($_,2058,255);
		$racd_x500_issuer=substr($_,2314,255);
		$rv=$insert{racdcert}->execute($racd_event_type,$racd_event_qual,$racd_time_written,$racd_date_written,$racd_system_smfid,$racd_violation,$racd_user_ndfnd,$racd_user_warning,$racd_evt_user_id,$racd_evt_grp_id,$racd_auth_normal,$racd_auth_special,$racd_auth_oper,$racd_auth_audit,$racd_auth_exit,$racd_auth_failsft,$racd_auth_bypass,$racd_auth_trusted,$racd_log_class,$racd_log_user,$racd_log_special,$racd_log_access,$racd_log_racinit,$racd_log_always,$racd_log_cmdviol,$racd_log_global,$racd_term_level,$racd_backout_fail,$racd_prof_same,$racd_term,$racd_job_name,$racd_read_time,$racd_read_date,$racd_smf_user_id,$racd_log_level,$racd_log_vmevent,$racd_log_logopt,$racd_log_secl,$racd_log_compatm,$racd_log_applaud,$racd_log_nonomvs,$racd_log_omvsnprv,$racd_auth_omvssu,$racd_auth_omvssys,$racd_usr_secl,$racd_racf_version,$racd_user_name,$racd_utk_encr,$racd_utk_pre19,$racd_utk_verprof,$racd_utk_njeunusr,$racd_utk_logusr,$racd_utk_special,$racd_utk_default,$racd_utk_unknusr,$racd_utk_error,$racd_utk_trusted,$racd_utk_sesstype,$racd_utk_surrogat,$racd_utk_remote,$racd_utk_priv,$racd_utk_secl,$racd_utk_execnode,$racd_utk_suser_id,$racd_utk_snode,$racd_utk_sgrp_id,$racd_utk_spoe,$racd_utk_spclass,$racd_utk_user_id,$racd_utk_grp_id,$racd_utk_dft_grp,$racd_utk_dft_secl,$racd_serial_number,$racd_issuers_dn,$racd_cert_ds,$racd_specified,$racd_utk_netw,$racd_x500_subject,$racd_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"racdcert"}++;
		next;
	}

	if ($rectype eq 'RACFINIT') {
		$rini_event_type=substr($_,0,8);
		$rini_reserved_01=substr($_,9,8);
		$rini_time_written=substr($_,18,8);
		if ($rini_time_written  eq ' ' x length($rini_time_written )) {
			undef $rini_time_written ;
		}
		$rini_date_written=substr($_,27,10);
		if ($rini_date_written  eq ' ' x length($rini_date_written )) {
			undef $rini_date_written ;
		}
		$rini_system_smfid=substr($_,38,4);
		$rini_dataset_name=substr($_,43,44);
		$rini_dataset_vol=substr($_,88,6);
		$rini_dataset_unit=substr($_,95,3);
		$rini_uads_name=substr($_,99,44);
		$rini_uads_vol=substr($_,144,6);
		$rini_racinit_stats=substr($_,151,1);
		$rini_dataset_stats=substr($_,156,1);
		$rini_racinit_pre=substr($_,161,1);
		$rini_racheck_pre=substr($_,166,1);
		$rini_racdef_pre=substr($_,171,1);
		$rini_racinit_post=substr($_,176,1);
		$rini_racheck_post=substr($_,181,1);
		$rini_new_pwd_exit=substr($_,186,1);
		$rini_tapevol_stats=substr($_,191,1);
		$rini_dasd_stats=substr($_,196,1);
		$rini_term_stats=substr($_,201,1);
		$rini_cmd_exit=substr($_,206,1);
		$rini_del_cmd_exit=substr($_,211,1);
		$rini_adsp=substr($_,216,1);
		$rini_encrypt_exit=substr($_,221,1);
		$rini_naming_conv=substr($_,226,1);
		$rini_tapevol=substr($_,231,1);
		$rini_dup_dsns=substr($_,236,1);
		$rini_dasd=substr($_,241,1);
		$rini_fracheck_pre=substr($_,246,1);
		$rini_raclist_pre=substr($_,251,1);
		$rini_raclist_sel=substr($_,256,1);
		$rini_racdef_post=substr($_,261,1);
		$rini_audit_user=substr($_,266,1);
		$rini_audit_group=substr($_,271,1);
		$rini_audit_dataset=substr($_,276,1);
		$rini_audit_tapevol=substr($_,281,1);
		$rini_audit_dasdvol=substr($_,286,1);
		$rini_audit_term=substr($_,291,1);
		$rini_audit_cmdviol=substr($_,296,1);
		$rini_audit_special=substr($_,301,1);
		$rini_audit_oper=substr($_,306,1);
		$rini_audit_level=substr($_,311,1);
		$rini_acee_compress=substr($_,316,1);
		$rini_fastauth_pre=substr($_,321,1);
		$rini_fastauth_post=substr($_,326,1);
		$rini_term=substr($_,331,1);
		$rini_term_none=substr($_,336,1);
		$rini_realdsn=substr($_,341,1);
		$rini_xbmallracf=substr($_,346,1);
		$rini_earlyverify=substr($_,351,1);
		$rini_batchallracf=substr($_,356,1);
		$rini_fracheck_post=substr($_,361,1);
		$rini_pwd_int=substr($_,366,3);
		if ($rini_pwd_int  eq ' ' x length($rini_pwd_int )) {
			undef $rini_pwd_int ;
		}
		$rini_single_dsn=substr($_,370,8);
		$rini_tapedsn=substr($_,379,1);
		$rini_protectall=substr($_,384,1);
		$rini_protectall_w=substr($_,389,1);
		$rini_erase=substr($_,394,1);
		$rini_erase_level=substr($_,399,1);
		$rini_erase_all=substr($_,404,1);
		$rini_egn=substr($_,409,1);
		$rini_when_program=substr($_,414,1);
		$rini_retention=substr($_,419,5);
		if ($rini_retention  eq ' ' x length($rini_retention )) {
			undef $rini_retention ;
		}
		$rini_level_erase=substr($_,425,5);
		if ($rini_level_erase  eq ' ' x length($rini_level_erase )) {
			undef $rini_level_erase ;
		}
		$rini_level_audit=substr($_,431,5);
		if ($rini_level_audit  eq ' ' x length($rini_level_audit )) {
			undef $rini_level_audit ;
		}
		$rini_secl_ctrl=substr($_,437,1);
		$rini_catdsns=substr($_,442,1);
		$rini_mlquiet=substr($_,447,1);
		$rini_mlstable=substr($_,452,1);
		$rini_mls=substr($_,457,1);
		$rini_mlactive=substr($_,462,1);
		$rini_generic_owner=substr($_,467,1);
		$rini_secl_audit=substr($_,472,1);
		$rini_session_int=substr($_,477,5);
		if ($rini_session_int  eq ' ' x length($rini_session_int )) {
			undef $rini_session_int ;
		}
		$rini_nje_name_id=substr($_,483,8);
		$rini_nje_udfnd_id=substr($_,492,8);
		$rini_compatmode=substr($_,501,1);
		$rini_catdsns_fail=substr($_,506,1);
		$rini_mls_fail=substr($_,511,1);
		$rini_mlactive_fail=substr($_,516,1);
		$rini_applaud=substr($_,521,1);
		$rini_dft_pri=substr($_,526,3);
		$rini_dft_sec=substr($_,530,3);
		$rini_reserved_02=substr($_,534,4);
		$rini_all_cmd_exit=substr($_,539,1);
		$rini_addcreator=substr($_,544,1);
		$rini_acee_comp_xm=substr($_,549,1);
		$rini_encrypt_exit2=substr($_,554,1);
		$rini_pwd_hist=substr($_,559,3);
		if ($rini_pwd_hist  eq ' ' x length($rini_pwd_hist )) {
			undef $rini_pwd_hist ;
		}
		$rini_pwd_revoke=substr($_,563,3);
		if ($rini_pwd_revoke  eq ' ' x length($rini_pwd_revoke )) {
			undef $rini_pwd_revoke ;
		}
		$rini_pwd_warn=substr($_,567,3);
		if ($rini_pwd_warn  eq ' ' x length($rini_pwd_warn )) {
			undef $rini_pwd_warn ;
		}
		$rini_pwdrule1_min=substr($_,571,1);
		if ($rini_pwdrule1_min  eq ' ' x length($rini_pwdrule1_min )) {
			undef $rini_pwdrule1_min ;
		}
		$rini_pwdrule1_max=substr($_,573,1);
		if ($rini_pwdrule1_max  eq ' ' x length($rini_pwdrule1_max )) {
			undef $rini_pwdrule1_max ;
		}
		$rini_pwdrule1=substr($_,575,8);
		$rini_pwdrule2_min=substr($_,584,1);
		if ($rini_pwdrule2_min  eq ' ' x length($rini_pwdrule2_min )) {
			undef $rini_pwdrule2_min ;
		}
		$rini_pwdrule2_max=substr($_,586,1);
		if ($rini_pwdrule2_max  eq ' ' x length($rini_pwdrule2_max )) {
			undef $rini_pwdrule2_max ;
		}
		$rini_pwdrule2=substr($_,588,8);
		$rini_pwdrule3_min=substr($_,597,1);
		if ($rini_pwdrule3_min  eq ' ' x length($rini_pwdrule3_min )) {
			undef $rini_pwdrule3_min ;
		}
		$rini_pwdrule3_max=substr($_,599,1);
		if ($rini_pwdrule3_max  eq ' ' x length($rini_pwdrule3_max )) {
			undef $rini_pwdrule3_max ;
		}
		$rini_pwdrule3=substr($_,601,8);
		$rini_pwdrule4_min=substr($_,610,1);
		if ($rini_pwdrule4_min  eq ' ' x length($rini_pwdrule4_min )) {
			undef $rini_pwdrule4_min ;
		}
		$rini_pwdrule4_max=substr($_,612,1);
		if ($rini_pwdrule4_max  eq ' ' x length($rini_pwdrule4_max )) {
			undef $rini_pwdrule4_max ;
		}
		$rini_pwdrule4=substr($_,614,8);
		$rini_pwdrule5_min=substr($_,623,1);
		if ($rini_pwdrule5_min  eq ' ' x length($rini_pwdrule5_min )) {
			undef $rini_pwdrule5_min ;
		}
		$rini_pwdrule5_max=substr($_,625,1);
		if ($rini_pwdrule5_max  eq ' ' x length($rini_pwdrule5_max )) {
			undef $rini_pwdrule5_max ;
		}
		$rini_pwdrule5=substr($_,627,8);
		$rini_pwdrule6_min=substr($_,636,1);
		if ($rini_pwdrule6_min  eq ' ' x length($rini_pwdrule6_min )) {
			undef $rini_pwdrule6_min ;
		}
		$rini_pwdrule6_max=substr($_,638,1);
		if ($rini_pwdrule6_max  eq ' ' x length($rini_pwdrule6_max )) {
			undef $rini_pwdrule6_max ;
		}
		$rini_pwdrule6=substr($_,640,8);
		$rini_pwdrule7_min=substr($_,649,1);
		if ($rini_pwdrule7_min  eq ' ' x length($rini_pwdrule7_min )) {
			undef $rini_pwdrule7_min ;
		}
		$rini_pwdrule7_max=substr($_,651,1);
		if ($rini_pwdrule7_max  eq ' ' x length($rini_pwdrule7_max )) {
			undef $rini_pwdrule7_max ;
		}
		$rini_pwdrule7=substr($_,653,8);
		$rini_pwdrule8_min=substr($_,662,1);
		if ($rini_pwdrule8_min  eq ' ' x length($rini_pwdrule8_min )) {
			undef $rini_pwdrule8_min ;
		}
		$rini_pwdrule8_max=substr($_,664,1);
		if ($rini_pwdrule8_max  eq ' ' x length($rini_pwdrule8_max )) {
			undef $rini_pwdrule8_max ;
		}
		$rini_pwdrule8=substr($_,666,8);
		$rini_inactive=substr($_,675,3);
		if ($rini_inactive  eq ' ' x length($rini_inactive )) {
			undef $rini_inactive ;
		}
		$rini_grplist=substr($_,679,1);
		$rini_model_gdg=substr($_,684,1);
		$rini_model_user=substr($_,689,1);
		$rini_model_group=substr($_,694,1);
		$rini_rswi_inst_pwd=substr($_,699,1);
		$rini_rsta_inst_pwd=substr($_,704,1);
		$rini_kerblvl=substr($_,709,4);
		$rv=$insert{racfinit}->execute($rini_event_type,$rini_reserved_01,$rini_time_written,$rini_date_written,$rini_system_smfid,$rini_dataset_name,$rini_dataset_vol,$rini_dataset_unit,$rini_uads_name,$rini_uads_vol,$rini_racinit_stats,$rini_dataset_stats,$rini_racinit_pre,$rini_racheck_pre,$rini_racdef_pre,$rini_racinit_post,$rini_racheck_post,$rini_new_pwd_exit,$rini_tapevol_stats,$rini_dasd_stats,$rini_term_stats,$rini_cmd_exit,$rini_del_cmd_exit,$rini_adsp,$rini_encrypt_exit,$rini_naming_conv,$rini_tapevol,$rini_dup_dsns,$rini_dasd,$rini_fracheck_pre,$rini_raclist_pre,$rini_raclist_sel,$rini_racdef_post,$rini_audit_user,$rini_audit_group,$rini_audit_dataset,$rini_audit_tapevol,$rini_audit_dasdvol,$rini_audit_term,$rini_audit_cmdviol,$rini_audit_special,$rini_audit_oper,$rini_audit_level,$rini_acee_compress,$rini_fastauth_pre,$rini_fastauth_post,$rini_term,$rini_term_none,$rini_realdsn,$rini_xbmallracf,$rini_earlyverify,$rini_batchallracf,$rini_fracheck_post,$rini_pwd_int,$rini_single_dsn,$rini_tapedsn,$rini_protectall,$rini_protectall_w,$rini_erase,$rini_erase_level,$rini_erase_all,$rini_egn,$rini_when_program,$rini_retention,$rini_level_erase,$rini_level_audit,$rini_secl_ctrl,$rini_catdsns,$rini_mlquiet,$rini_mlstable,$rini_mls,$rini_mlactive,$rini_generic_owner,$rini_secl_audit,$rini_session_int,$rini_nje_name_id,$rini_nje_udfnd_id,$rini_compatmode,$rini_catdsns_fail,$rini_mls_fail,$rini_mlactive_fail,$rini_applaud,$rini_dft_pri,$rini_dft_sec,$rini_reserved_02,$rini_all_cmd_exit,$rini_addcreator,$rini_acee_comp_xm,$rini_encrypt_exit2,$rini_pwd_hist,$rini_pwd_revoke,$rini_pwd_warn,$rini_pwdrule1_min,$rini_pwdrule1_max,$rini_pwdrule1,$rini_pwdrule2_min,$rini_pwdrule2_max,$rini_pwdrule2,$rini_pwdrule3_min,$rini_pwdrule3_max,$rini_pwdrule3,$rini_pwdrule4_min,$rini_pwdrule4_max,$rini_pwdrule4,$rini_pwdrule5_min,$rini_pwdrule5_max,$rini_pwdrule5,$rini_pwdrule6_min,$rini_pwdrule6_max,$rini_pwdrule6,$rini_pwdrule7_min,$rini_pwdrule7_max,$rini_pwdrule7,$rini_pwdrule8_min,$rini_pwdrule8_max,$rini_pwdrule8,$rini_inactive,$rini_grplist,$rini_model_gdg,$rini_model_user,$rini_model_group,$rini_rswi_inst_pwd,$rini_rsta_inst_pwd,$rini_kerblvl);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"racfinit"}++;
		next;
	}

	if ($rectype eq 'RACLINK ') {
		$racl_event_type=substr($_,0,8);
		$racl_event_qual=substr($_,9,8);
		$racl_time_written=substr($_,18,8);
		if ($racl_time_written  eq ' ' x length($racl_time_written )) {
			undef $racl_time_written ;
		}
		$racl_date_written=substr($_,27,10);
		if ($racl_date_written  eq ' ' x length($racl_date_written )) {
			undef $racl_date_written ;
		}
		$racl_system_smfid=substr($_,38,4);
		$racl_violation=substr($_,43,1);
		$racl_user_ndfnd=substr($_,48,1);
		$racl_user_warning=substr($_,53,1);
		$racl_evt_user_id=substr($_,58,8);
		$racl_evt_grp_id=substr($_,67,8);
		$racl_auth_normal=substr($_,76,1);
		$racl_auth_special=substr($_,81,1);
		$racl_auth_oper=substr($_,86,1);
		$racl_auth_audit=substr($_,91,1);
		$racl_auth_exit=substr($_,96,1);
		$racl_auth_failsft=substr($_,101,1);
		$racl_auth_bypass=substr($_,106,1);
		$racl_auth_trusted=substr($_,111,1);
		$racl_log_class=substr($_,116,1);
		$racl_log_user=substr($_,121,1);
		$racl_log_special=substr($_,126,1);
		$racl_log_access=substr($_,131,1);
		$racl_log_racinit=substr($_,136,1);
		$racl_log_always=substr($_,141,1);
		$racl_log_cmdviol=substr($_,146,1);
		$racl_log_global=substr($_,151,1);
		$racl_term_level=substr($_,156,3);
		if ($racl_term_level  eq ' ' x length($racl_term_level )) {
			undef $racl_term_level ;
		}
		$racl_backout_fail=substr($_,160,1);
		$racl_prof_same=substr($_,165,1);
		$racl_term=substr($_,170,8);
		$racl_job_name=substr($_,179,8);
		$racl_read_time=substr($_,188,8);
		if ($racl_read_time  eq ' ' x length($racl_read_time )) {
			undef $racl_read_time ;
		}
		$racl_read_date=substr($_,197,10);
		if ($racl_read_date  eq ' ' x length($racl_read_date )) {
			undef $racl_read_date ;
		}
		$racl_smf_user_id=substr($_,208,8);
		$racl_log_level=substr($_,217,1);
		$racl_log_vmevent=substr($_,222,1);
		$racl_log_logopt=substr($_,227,1);
		$racl_log_secl=substr($_,232,1);
		$racl_log_compatm=substr($_,237,1);
		$racl_log_applaud=substr($_,242,1);
		$racl_log_nonomvs=substr($_,247,1);
		$racl_log_omvsnprv=substr($_,252,1);
		$racl_auth_omvssu=substr($_,257,1);
		$racl_auth_omvssys=substr($_,262,1);
		$racl_usr_secl=substr($_,267,8);
		$racl_racf_version=substr($_,276,4);
		$racl_user_name=substr($_,281,20);
		$racl_utk_encr=substr($_,302,1);
		$racl_utk_pre19=substr($_,307,1);
		$racl_utk_verprof=substr($_,312,1);
		$racl_utk_njeunusr=substr($_,317,1);
		$racl_utk_logusr=substr($_,322,1);
		$racl_utk_special=substr($_,327,1);
		$racl_utk_default=substr($_,332,1);
		$racl_utk_unknusr=substr($_,337,1);
		$racl_utk_error=substr($_,342,1);
		$racl_utk_trusted=substr($_,347,1);
		$racl_utk_sesstype=substr($_,352,8);
		$racl_utk_surrogat=substr($_,361,1);
		$racl_utk_remote=substr($_,366,1);
		$racl_utk_priv=substr($_,371,1);
		$racl_utk_secl=substr($_,376,8);
		$racl_utk_execnode=substr($_,385,8);
		$racl_utk_suser_id=substr($_,394,8);
		$racl_utk_snode=substr($_,403,8);
		$racl_utk_sgrp_id=substr($_,412,8);
		$racl_utk_spoe=substr($_,421,8);
		$racl_utk_spclass=substr($_,430,8);
		$racl_utk_user_id=substr($_,439,8);
		$racl_utk_grp_id=substr($_,448,8);
		$racl_utk_dft_grp=substr($_,457,1);
		$racl_utk_dft_secl=substr($_,462,1);
		$racl_phase=substr($_,467,20);
		$racl_issue_node=substr($_,488,8);
		$racl_issue_id=substr($_,497,8);
		$racl_source_id=substr($_,506,8);
		$racl_tgt_node=substr($_,515,8);
		$racl_tgt_id=substr($_,524,8);
		$racl_tgt_auth_id=substr($_,533,8);
		$racl_source_smfid=substr($_,542,4);
		$racl_source_time=substr($_,547,8);
		$racl_source_date=substr($_,556,10);
		$racl_pwd_status=substr($_,567,8);
		$racl_assoc_status=substr($_,576,8);
		$racl_specified=substr($_,585,1024);
		$racl_utk_netw=substr($_,1610,8);
		$racl_x500_subject=substr($_,1619,255);
		$racl_x500_issuer=substr($_,1875,255);
		$rv=$insert{raclink}->execute($racl_event_type,$racl_event_qual,$racl_time_written,$racl_date_written,$racl_system_smfid,$racl_violation,$racl_user_ndfnd,$racl_user_warning,$racl_evt_user_id,$racl_evt_grp_id,$racl_auth_normal,$racl_auth_special,$racl_auth_oper,$racl_auth_audit,$racl_auth_exit,$racl_auth_failsft,$racl_auth_bypass,$racl_auth_trusted,$racl_log_class,$racl_log_user,$racl_log_special,$racl_log_access,$racl_log_racinit,$racl_log_always,$racl_log_cmdviol,$racl_log_global,$racl_term_level,$racl_backout_fail,$racl_prof_same,$racl_term,$racl_job_name,$racl_read_time,$racl_read_date,$racl_smf_user_id,$racl_log_level,$racl_log_vmevent,$racl_log_logopt,$racl_log_secl,$racl_log_compatm,$racl_log_applaud,$racl_log_nonomvs,$racl_log_omvsnprv,$racl_auth_omvssu,$racl_auth_omvssys,$racl_usr_secl,$racl_racf_version,$racl_user_name,$racl_utk_encr,$racl_utk_pre19,$racl_utk_verprof,$racl_utk_njeunusr,$racl_utk_logusr,$racl_utk_special,$racl_utk_default,$racl_utk_unknusr,$racl_utk_error,$racl_utk_trusted,$racl_utk_sesstype,$racl_utk_surrogat,$racl_utk_remote,$racl_utk_priv,$racl_utk_secl,$racl_utk_execnode,$racl_utk_suser_id,$racl_utk_snode,$racl_utk_sgrp_id,$racl_utk_spoe,$racl_utk_spclass,$racl_utk_user_id,$racl_utk_grp_id,$racl_utk_dft_grp,$racl_utk_dft_secl,$racl_phase,$racl_issue_node,$racl_issue_id,$racl_source_id,$racl_tgt_node,$racl_tgt_id,$racl_tgt_auth_id,$racl_source_smfid,$racl_source_time,$racl_source_date,$racl_pwd_status,$racl_assoc_status,$racl_specified,$racl_utk_netw,$racl_x500_subject,$racl_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"raclink"}++;
		next;
	}

	if ($rectype eq 'RALTER  ') {
		$ralt_event_type=substr($_,0,8);
		$ralt_event_qual=substr($_,9,8);
		$ralt_time_written=substr($_,18,8);
		if ($ralt_time_written  eq ' ' x length($ralt_time_written )) {
			undef $ralt_time_written ;
		}
		$ralt_date_written=substr($_,27,10);
		if ($ralt_date_written  eq ' ' x length($ralt_date_written )) {
			undef $ralt_date_written ;
		}
		$ralt_system_smfid=substr($_,38,4);
		$ralt_violation=substr($_,43,1);
		$ralt_user_ndfnd=substr($_,48,1);
		$ralt_user_warning=substr($_,53,1);
		$ralt_evt_user_id=substr($_,58,8);
		$ralt_evt_grp_id=substr($_,67,8);
		$ralt_auth_normal=substr($_,76,1);
		$ralt_auth_special=substr($_,81,1);
		$ralt_auth_oper=substr($_,86,1);
		$ralt_auth_audit=substr($_,91,1);
		$ralt_auth_exit=substr($_,96,1);
		$ralt_auth_failsft=substr($_,101,1);
		$ralt_auth_bypass=substr($_,106,1);
		$ralt_auth_trusted=substr($_,111,1);
		$ralt_log_class=substr($_,116,1);
		$ralt_log_user=substr($_,121,1);
		$ralt_log_special=substr($_,126,1);
		$ralt_log_access=substr($_,131,1);
		$ralt_log_racinit=substr($_,136,1);
		$ralt_log_always=substr($_,141,1);
		$ralt_log_cmdviol=substr($_,146,1);
		$ralt_log_global=substr($_,151,1);
		$ralt_term_level=substr($_,156,3);
		if ($ralt_term_level  eq ' ' x length($ralt_term_level )) {
			undef $ralt_term_level ;
		}
		$ralt_backout_fail=substr($_,160,1);
		$ralt_prof_same=substr($_,165,1);
		$ralt_term=substr($_,170,8);
		$ralt_job_name=substr($_,179,8);
		$ralt_read_time=substr($_,188,8);
		if ($ralt_read_time  eq ' ' x length($ralt_read_time )) {
			undef $ralt_read_time ;
		}
		$ralt_read_date=substr($_,197,10);
		if ($ralt_read_date  eq ' ' x length($ralt_read_date )) {
			undef $ralt_read_date ;
		}
		$ralt_smf_user_id=substr($_,208,8);
		$ralt_log_level=substr($_,217,1);
		$ralt_log_vmevent=substr($_,222,1);
		$ralt_log_logopt=substr($_,227,1);
		$ralt_log_secl=substr($_,232,1);
		$ralt_log_compatm=substr($_,237,1);
		$ralt_log_applaud=substr($_,242,1);
		$ralt_log_nonomvs=substr($_,247,1);
		$ralt_log_omvsnprv=substr($_,252,1);
		$ralt_auth_omvssu=substr($_,257,1);
		$ralt_auth_omvssys=substr($_,262,1);
		$ralt_usr_secl=substr($_,267,8);
		$ralt_racf_version=substr($_,276,4);
		$ralt_class=substr($_,281,8);
		$ralt_own_id=substr($_,290,8);
		$ralt_user_name=substr($_,299,20);
		$ralt_old_secl=substr($_,320,8);
		$ralt_utk_encr=substr($_,329,1);
		$ralt_utk_pre19=substr($_,334,1);
		$ralt_utk_verprof=substr($_,339,1);
		$ralt_utk_njeunusr=substr($_,344,1);
		$ralt_utk_logusr=substr($_,349,1);
		$ralt_utk_special=substr($_,354,1);
		$ralt_utk_default=substr($_,359,1);
		$ralt_utk_unknusr=substr($_,364,1);
		$ralt_utk_error=substr($_,369,1);
		$ralt_utk_trusted=substr($_,374,1);
		$ralt_utk_sesstype=substr($_,379,8);
		$ralt_utk_surrogat=substr($_,388,1);
		$ralt_utk_remote=substr($_,393,1);
		$ralt_utk_priv=substr($_,398,1);
		$ralt_utk_secl=substr($_,403,8);
		$ralt_utk_execnode=substr($_,412,8);
		$ralt_utk_suser_id=substr($_,421,8);
		$ralt_utk_snode=substr($_,430,8);
		$ralt_utk_sgrp_id=substr($_,439,8);
		$ralt_utk_spoe=substr($_,448,8);
		$ralt_utk_spclass=substr($_,457,8);
		$ralt_utk_user_id=substr($_,466,8);
		$ralt_utk_grp_id=substr($_,475,8);
		$ralt_utk_dft_grp=substr($_,484,1);
		$ralt_utk_dft_secl=substr($_,489,1);
		$ralt_appc_link=substr($_,494,16);
		$ralt_res_name=substr($_,511,255);
		$ralt_specified=substr($_,767,1024);
		$ralt_failed=substr($_,1792,1024);
		$ralt_utk_netw=substr($_,2817,8);
		$ralt_x500_subject=substr($_,2826,255);
		$ralt_x500_issuer=substr($_,3082,255);
		$rv=$insert{ralter}->execute($ralt_event_type,$ralt_event_qual,$ralt_time_written,$ralt_date_written,$ralt_system_smfid,$ralt_violation,$ralt_user_ndfnd,$ralt_user_warning,$ralt_evt_user_id,$ralt_evt_grp_id,$ralt_auth_normal,$ralt_auth_special,$ralt_auth_oper,$ralt_auth_audit,$ralt_auth_exit,$ralt_auth_failsft,$ralt_auth_bypass,$ralt_auth_trusted,$ralt_log_class,$ralt_log_user,$ralt_log_special,$ralt_log_access,$ralt_log_racinit,$ralt_log_always,$ralt_log_cmdviol,$ralt_log_global,$ralt_term_level,$ralt_backout_fail,$ralt_prof_same,$ralt_term,$ralt_job_name,$ralt_read_time,$ralt_read_date,$ralt_smf_user_id,$ralt_log_level,$ralt_log_vmevent,$ralt_log_logopt,$ralt_log_secl,$ralt_log_compatm,$ralt_log_applaud,$ralt_log_nonomvs,$ralt_log_omvsnprv,$ralt_auth_omvssu,$ralt_auth_omvssys,$ralt_usr_secl,$ralt_racf_version,$ralt_class,$ralt_own_id,$ralt_user_name,$ralt_old_secl,$ralt_utk_encr,$ralt_utk_pre19,$ralt_utk_verprof,$ralt_utk_njeunusr,$ralt_utk_logusr,$ralt_utk_special,$ralt_utk_default,$ralt_utk_unknusr,$ralt_utk_error,$ralt_utk_trusted,$ralt_utk_sesstype,$ralt_utk_surrogat,$ralt_utk_remote,$ralt_utk_priv,$ralt_utk_secl,$ralt_utk_execnode,$ralt_utk_suser_id,$ralt_utk_snode,$ralt_utk_sgrp_id,$ralt_utk_spoe,$ralt_utk_spclass,$ralt_utk_user_id,$ralt_utk_grp_id,$ralt_utk_dft_grp,$ralt_utk_dft_secl,$ralt_appc_link,$ralt_res_name,$ralt_specified,$ralt_failed,$ralt_utk_netw,$ralt_x500_subject,$ralt_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"ralter"}++;
		next;
	}

	if ($rectype eq 'RDEFINE ') {
		$rdef_event_type=substr($_,0,8);
		$rdef_event_qual=substr($_,9,8);
		$rdef_time_written=substr($_,18,8);
		if ($rdef_time_written  eq ' ' x length($rdef_time_written )) {
			undef $rdef_time_written ;
		}
		$rdef_date_written=substr($_,27,10);
		if ($rdef_date_written  eq ' ' x length($rdef_date_written )) {
			undef $rdef_date_written ;
		}
		$rdef_system_smfid=substr($_,38,4);
		$rdef_violation=substr($_,43,1);
		$rdef_user_ndfnd=substr($_,48,1);
		$rdef_user_warning=substr($_,53,1);
		$rdef_evt_user_id=substr($_,58,8);
		$rdef_evt_grp_id=substr($_,67,8);
		$rdef_auth_normal=substr($_,76,1);
		$rdef_auth_special=substr($_,81,1);
		$rdef_auth_oper=substr($_,86,1);
		$rdef_auth_audit=substr($_,91,1);
		$rdef_auth_exit=substr($_,96,1);
		$rdef_auth_failsft=substr($_,101,1);
		$rdef_auth_bypass=substr($_,106,1);
		$rdef_auth_trusted=substr($_,111,1);
		$rdef_log_class=substr($_,116,1);
		$rdef_log_user=substr($_,121,1);
		$rdef_log_special=substr($_,126,1);
		$rdef_log_access=substr($_,131,1);
		$rdef_log_racinit=substr($_,136,1);
		$rdef_log_always=substr($_,141,1);
		$rdef_log_cmdviol=substr($_,146,1);
		$rdef_log_global=substr($_,151,1);
		$rdef_term_level=substr($_,156,3);
		if ($rdef_term_level  eq ' ' x length($rdef_term_level )) {
			undef $rdef_term_level ;
		}
		$rdef_backout_fail=substr($_,160,1);
		$rdef_prof_same=substr($_,165,1);
		$rdef_term=substr($_,170,8);
		$rdef_job_name=substr($_,179,8);
		$rdef_read_time=substr($_,188,8);
		if ($rdef_read_time  eq ' ' x length($rdef_read_time )) {
			undef $rdef_read_time ;
		}
		$rdef_read_date=substr($_,197,10);
		if ($rdef_read_date  eq ' ' x length($rdef_read_date )) {
			undef $rdef_read_date ;
		}
		$rdef_smf_user_id=substr($_,208,8);
		$rdef_log_level=substr($_,217,1);
		$rdef_log_vmevent=substr($_,222,1);
		$rdef_log_logopt=substr($_,227,1);
		$rdef_log_secl=substr($_,232,1);
		$rdef_log_compatm=substr($_,237,1);
		$rdef_log_applaud=substr($_,242,1);
		$rdef_log_nonomvs=substr($_,247,1);
		$rdef_log_omvsnprv=substr($_,252,1);
		$rdef_auth_omvssu=substr($_,257,1);
		$rdef_auth_omvssys=substr($_,262,1);
		$rdef_usr_secl=substr($_,267,8);
		$rdef_racf_version=substr($_,276,4);
		$rdef_class=substr($_,281,8);
		$rdef_own_id=substr($_,290,8);
		$rdef_user_name=substr($_,299,20);
		$rdef_secl=substr($_,320,8);
		$rdef_utk_encr=substr($_,329,1);
		$rdef_utk_pre19=substr($_,334,1);
		$rdef_utk_verprof=substr($_,339,1);
		$rdef_utk_njeunusr=substr($_,344,1);
		$rdef_utk_logusr=substr($_,349,1);
		$rdef_utk_special=substr($_,354,1);
		$rdef_utk_default=substr($_,359,1);
		$rdef_utk_unknusr=substr($_,364,1);
		$rdef_utk_error=substr($_,369,1);
		$rdef_utk_trusted=substr($_,374,1);
		$rdef_utk_sesstype=substr($_,379,8);
		$rdef_utk_surrogat=substr($_,388,1);
		$rdef_utk_remote=substr($_,393,1);
		$rdef_utk_priv=substr($_,398,1);
		$rdef_utk_secl=substr($_,403,8);
		$rdef_utk_execnode=substr($_,412,8);
		$rdef_utk_suser_id=substr($_,421,8);
		$rdef_utk_snode=substr($_,430,8);
		$rdef_utk_sgrp_id=substr($_,439,8);
		$rdef_utk_spoe=substr($_,448,8);
		$rdef_utk_spclass=substr($_,457,8);
		$rdef_utk_user_id=substr($_,466,8);
		$rdef_utk_grp_id=substr($_,475,8);
		$rdef_utk_dft_grp=substr($_,484,1);
		$rdef_utk_dft_secl=substr($_,489,1);
		$rdef_appc_link=substr($_,494,16);
		$rdef_res_name=substr($_,511,255);
		$rdef_specified=substr($_,767,1024);
		$rdef_failed=substr($_,1792,1024);
		$rdef_utk_netw=substr($_,2817,8);
		$rdef_x500_subject=substr($_,2826,255);
		$rdef_x500_issuer=substr($_,3082,255);
		$rv=$insert{rdefine}->execute($rdef_event_type,$rdef_event_qual,$rdef_time_written,$rdef_date_written,$rdef_system_smfid,$rdef_violation,$rdef_user_ndfnd,$rdef_user_warning,$rdef_evt_user_id,$rdef_evt_grp_id,$rdef_auth_normal,$rdef_auth_special,$rdef_auth_oper,$rdef_auth_audit,$rdef_auth_exit,$rdef_auth_failsft,$rdef_auth_bypass,$rdef_auth_trusted,$rdef_log_class,$rdef_log_user,$rdef_log_special,$rdef_log_access,$rdef_log_racinit,$rdef_log_always,$rdef_log_cmdviol,$rdef_log_global,$rdef_term_level,$rdef_backout_fail,$rdef_prof_same,$rdef_term,$rdef_job_name,$rdef_read_time,$rdef_read_date,$rdef_smf_user_id,$rdef_log_level,$rdef_log_vmevent,$rdef_log_logopt,$rdef_log_secl,$rdef_log_compatm,$rdef_log_applaud,$rdef_log_nonomvs,$rdef_log_omvsnprv,$rdef_auth_omvssu,$rdef_auth_omvssys,$rdef_usr_secl,$rdef_racf_version,$rdef_class,$rdef_own_id,$rdef_user_name,$rdef_secl,$rdef_utk_encr,$rdef_utk_pre19,$rdef_utk_verprof,$rdef_utk_njeunusr,$rdef_utk_logusr,$rdef_utk_special,$rdef_utk_default,$rdef_utk_unknusr,$rdef_utk_error,$rdef_utk_trusted,$rdef_utk_sesstype,$rdef_utk_surrogat,$rdef_utk_remote,$rdef_utk_priv,$rdef_utk_secl,$rdef_utk_execnode,$rdef_utk_suser_id,$rdef_utk_snode,$rdef_utk_sgrp_id,$rdef_utk_spoe,$rdef_utk_spclass,$rdef_utk_user_id,$rdef_utk_grp_id,$rdef_utk_dft_grp,$rdef_utk_dft_secl,$rdef_appc_link,$rdef_res_name,$rdef_specified,$rdef_failed,$rdef_utk_netw,$rdef_x500_subject,$rdef_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rdefine"}++;
		next;
	}

	if ($rectype eq 'RDELETE ') {
		$rdel_event_type=substr($_,0,8);
		$rdel_event_qual=substr($_,9,8);
		$rdel_time_written=substr($_,18,8);
		if ($rdel_time_written  eq ' ' x length($rdel_time_written )) {
			undef $rdel_time_written ;
		}
		$rdel_date_written=substr($_,27,10);
		if ($rdel_date_written  eq ' ' x length($rdel_date_written )) {
			undef $rdel_date_written ;
		}
		$rdel_system_smfid=substr($_,38,4);
		$rdel_violation=substr($_,43,1);
		$rdel_user_ndfnd=substr($_,48,1);
		$rdel_user_warning=substr($_,53,1);
		$rdel_evt_user_id=substr($_,58,8);
		$rdel_evt_grp_id=substr($_,67,8);
		$rdel_auth_normal=substr($_,76,1);
		$rdel_auth_special=substr($_,81,1);
		$rdel_auth_oper=substr($_,86,1);
		$rdel_auth_audit=substr($_,91,1);
		$rdel_auth_exit=substr($_,96,1);
		$rdel_auth_failsft=substr($_,101,1);
		$rdel_auth_bypass=substr($_,106,1);
		$rdel_auth_trusted=substr($_,111,1);
		$rdel_log_class=substr($_,116,1);
		$rdel_log_user=substr($_,121,1);
		$rdel_log_special=substr($_,126,1);
		$rdel_log_access=substr($_,131,1);
		$rdel_log_racinit=substr($_,136,1);
		$rdel_log_always=substr($_,141,1);
		$rdel_log_cmdviol=substr($_,146,1);
		$rdel_log_global=substr($_,151,1);
		$rdel_term_level=substr($_,156,3);
		if ($rdel_term_level  eq ' ' x length($rdel_term_level )) {
			undef $rdel_term_level ;
		}
		$rdel_backout_fail=substr($_,160,1);
		$rdel_prof_same=substr($_,165,1);
		$rdel_term=substr($_,170,8);
		$rdel_job_name=substr($_,179,8);
		$rdel_read_time=substr($_,188,8);
		if ($rdel_read_time  eq ' ' x length($rdel_read_time )) {
			undef $rdel_read_time ;
		}
		$rdel_read_date=substr($_,197,10);
		if ($rdel_read_date  eq ' ' x length($rdel_read_date )) {
			undef $rdel_read_date ;
		}
		$rdel_smf_user_id=substr($_,208,8);
		$rdel_log_level=substr($_,217,1);
		$rdel_log_vmevent=substr($_,222,1);
		$rdel_log_logopt=substr($_,227,1);
		$rdel_log_secl=substr($_,232,1);
		$rdel_log_compatm=substr($_,237,1);
		$rdel_log_applaud=substr($_,242,1);
		$rdel_log_nonomvs=substr($_,247,1);
		$rdel_log_omvsnprv=substr($_,252,1);
		$rdel_auth_omvssu=substr($_,257,1);
		$rdel_auth_omvssys=substr($_,262,1);
		$rdel_usr_secl=substr($_,267,8);
		$rdel_racf_version=substr($_,276,4);
		$rdel_class=substr($_,281,8);
		$rdel_own_id=substr($_,290,8);
		$rdel_user_name=substr($_,299,20);
		$rdel_secl=substr($_,320,8);
		$rdel_utk_encr=substr($_,329,1);
		$rdel_utk_pre19=substr($_,334,1);
		$rdel_utk_verprof=substr($_,339,1);
		$rdel_utk_njeunusr=substr($_,344,1);
		$rdel_utk_logusr=substr($_,349,1);
		$rdel_utk_special=substr($_,354,1);
		$rdel_utk_default=substr($_,359,1);
		$rdel_utk_unknusr=substr($_,364,1);
		$rdel_utk_error=substr($_,369,1);
		$rdel_utk_trusted=substr($_,374,1);
		$rdel_utk_sesstype=substr($_,379,8);
		$rdel_utk_surrogat=substr($_,388,1);
		$rdel_utk_remote=substr($_,393,1);
		$rdel_utk_priv=substr($_,398,1);
		$rdel_utk_secl=substr($_,403,8);
		$rdel_utk_execnode=substr($_,412,8);
		$rdel_utk_suser_id=substr($_,421,8);
		$rdel_utk_snode=substr($_,430,8);
		$rdel_utk_sgrp_id=substr($_,439,8);
		$rdel_utk_spoe=substr($_,448,8);
		$rdel_utk_spclass=substr($_,457,8);
		$rdel_utk_user_id=substr($_,466,8);
		$rdel_utk_grp_id=substr($_,475,8);
		$rdel_utk_dft_grp=substr($_,484,1);
		$rdel_utk_dft_secl=substr($_,489,1);
		$rdel_appc_link=substr($_,494,16);
		$rdel_res_name=substr($_,511,255);
		$rdel_specified=substr($_,767,1024);
		$rdel_utk_netw=substr($_,1792,8);
		$rdel_x500_subject=substr($_,1801,255);
		$rdel_x500_issuer=substr($_,2057,255);
		$rv=$insert{rdelete}->execute($rdel_event_type,$rdel_event_qual,$rdel_time_written,$rdel_date_written,$rdel_system_smfid,$rdel_violation,$rdel_user_ndfnd,$rdel_user_warning,$rdel_evt_user_id,$rdel_evt_grp_id,$rdel_auth_normal,$rdel_auth_special,$rdel_auth_oper,$rdel_auth_audit,$rdel_auth_exit,$rdel_auth_failsft,$rdel_auth_bypass,$rdel_auth_trusted,$rdel_log_class,$rdel_log_user,$rdel_log_special,$rdel_log_access,$rdel_log_racinit,$rdel_log_always,$rdel_log_cmdviol,$rdel_log_global,$rdel_term_level,$rdel_backout_fail,$rdel_prof_same,$rdel_term,$rdel_job_name,$rdel_read_time,$rdel_read_date,$rdel_smf_user_id,$rdel_log_level,$rdel_log_vmevent,$rdel_log_logopt,$rdel_log_secl,$rdel_log_compatm,$rdel_log_applaud,$rdel_log_nonomvs,$rdel_log_omvsnprv,$rdel_auth_omvssu,$rdel_auth_omvssys,$rdel_usr_secl,$rdel_racf_version,$rdel_class,$rdel_own_id,$rdel_user_name,$rdel_secl,$rdel_utk_encr,$rdel_utk_pre19,$rdel_utk_verprof,$rdel_utk_njeunusr,$rdel_utk_logusr,$rdel_utk_special,$rdel_utk_default,$rdel_utk_unknusr,$rdel_utk_error,$rdel_utk_trusted,$rdel_utk_sesstype,$rdel_utk_surrogat,$rdel_utk_remote,$rdel_utk_priv,$rdel_utk_secl,$rdel_utk_execnode,$rdel_utk_suser_id,$rdel_utk_snode,$rdel_utk_sgrp_id,$rdel_utk_spoe,$rdel_utk_spclass,$rdel_utk_user_id,$rdel_utk_grp_id,$rdel_utk_dft_grp,$rdel_utk_dft_secl,$rdel_appc_link,$rdel_res_name,$rdel_specified,$rdel_utk_netw,$rdel_x500_subject,$rdel_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rdelete"}++;
		next;
	}

	if ($rectype eq 'REMOVE  ') {
		$rem_event_type=substr($_,0,8);
		$rem_event_qual=substr($_,9,8);
		$rem_time_written=substr($_,18,8);
		if ($rem_time_written  eq ' ' x length($rem_time_written )) {
			undef $rem_time_written ;
		}
		$rem_date_written=substr($_,27,10);
		if ($rem_date_written  eq ' ' x length($rem_date_written )) {
			undef $rem_date_written ;
		}
		$rem_system_smfid=substr($_,38,4);
		$rem_violation=substr($_,43,1);
		$rem_user_ndfnd=substr($_,48,1);
		$rem_user_warning=substr($_,53,1);
		$rem_evt_user_id=substr($_,58,8);
		$rem_evt_grp_id=substr($_,67,8);
		$rem_auth_normal=substr($_,76,1);
		$rem_auth_special=substr($_,81,1);
		$rem_auth_oper=substr($_,86,1);
		$rem_auth_audit=substr($_,91,1);
		$rem_auth_exit=substr($_,96,1);
		$rem_auth_failsft=substr($_,101,1);
		$rem_auth_bypass=substr($_,106,1);
		$rem_auth_trusted=substr($_,111,1);
		$rem_log_class=substr($_,116,1);
		$rem_log_user=substr($_,121,1);
		$rem_log_special=substr($_,126,1);
		$rem_log_access=substr($_,131,1);
		$rem_log_racinit=substr($_,136,1);
		$rem_log_always=substr($_,141,1);
		$rem_log_cmdviol=substr($_,146,1);
		$rem_log_global=substr($_,151,1);
		$rem_term_level=substr($_,156,3);
		if ($rem_term_level  eq ' ' x length($rem_term_level )) {
			undef $rem_term_level ;
		}
		$rem_backout_fail=substr($_,160,1);
		$rem_prof_same=substr($_,165,1);
		$rem_term=substr($_,170,8);
		$rem_job_name=substr($_,179,8);
		$rem_read_time=substr($_,188,8);
		if ($rem_read_time  eq ' ' x length($rem_read_time )) {
			undef $rem_read_time ;
		}
		$rem_read_date=substr($_,197,10);
		if ($rem_read_date  eq ' ' x length($rem_read_date )) {
			undef $rem_read_date ;
		}
		$rem_smf_user_id=substr($_,208,8);
		$rem_log_level=substr($_,217,1);
		$rem_log_vmevent=substr($_,222,1);
		$rem_log_logopt=substr($_,227,1);
		$rem_log_secl=substr($_,232,1);
		$rem_log_compatm=substr($_,237,1);
		$rem_log_applaud=substr($_,242,1);
		$rem_log_nonomvs=substr($_,247,1);
		$rem_log_omvsnprv=substr($_,252,1);
		$rem_auth_omvssu=substr($_,257,1);
		$rem_auth_omvssys=substr($_,262,1);
		$rem_usr_secl=substr($_,267,8);
		$rem_racf_version=substr($_,276,4);
		$rem_own_id=substr($_,281,8);
		$rem_user_name=substr($_,290,20);
		$rem_utk_encr=substr($_,311,1);
		$rem_utk_pre19=substr($_,316,1);
		$rem_utk_verprof=substr($_,321,1);
		$rem_utk_njeunusr=substr($_,326,1);
		$rem_utk_logusr=substr($_,331,1);
		$rem_utk_special=substr($_,336,1);
		$rem_utk_default=substr($_,341,1);
		$rem_utk_unknusr=substr($_,346,1);
		$rem_utk_error=substr($_,351,1);
		$rem_utk_trusted=substr($_,356,1);
		$rem_utk_sesstype=substr($_,361,8);
		$rem_utk_surrogat=substr($_,370,1);
		$rem_utk_remote=substr($_,375,1);
		$rem_utk_priv=substr($_,380,1);
		$rem_utk_secl=substr($_,385,8);
		$rem_utk_execnode=substr($_,394,8);
		$rem_utk_suser_id=substr($_,403,8);
		$rem_utk_snode=substr($_,412,8);
		$rem_utk_sgrp_id=substr($_,421,8);
		$rem_utk_spoe=substr($_,430,8);
		$rem_utk_spclass=substr($_,439,8);
		$rem_utk_user_id=substr($_,448,8);
		$rem_utk_grp_id=substr($_,457,8);
		$rem_utk_dft_grp=substr($_,466,1);
		$rem_utk_dft_secl=substr($_,471,1);
		$rem_appc_link=substr($_,476,16);
		$rem_user_id=substr($_,493,8);
		$rem_specified=substr($_,502,1024);
		$rem_failed=substr($_,1527,1024);
		$rem_utk_netw=substr($_,2552,8);
		$rem_x500_subject=substr($_,2561,255);
		$rem_x500_issuer=substr($_,2817,255);
		$rv=$insert{remove}->execute($rem_event_type,$rem_event_qual,$rem_time_written,$rem_date_written,$rem_system_smfid,$rem_violation,$rem_user_ndfnd,$rem_user_warning,$rem_evt_user_id,$rem_evt_grp_id,$rem_auth_normal,$rem_auth_special,$rem_auth_oper,$rem_auth_audit,$rem_auth_exit,$rem_auth_failsft,$rem_auth_bypass,$rem_auth_trusted,$rem_log_class,$rem_log_user,$rem_log_special,$rem_log_access,$rem_log_racinit,$rem_log_always,$rem_log_cmdviol,$rem_log_global,$rem_term_level,$rem_backout_fail,$rem_prof_same,$rem_term,$rem_job_name,$rem_read_time,$rem_read_date,$rem_smf_user_id,$rem_log_level,$rem_log_vmevent,$rem_log_logopt,$rem_log_secl,$rem_log_compatm,$rem_log_applaud,$rem_log_nonomvs,$rem_log_omvsnprv,$rem_auth_omvssu,$rem_auth_omvssys,$rem_usr_secl,$rem_racf_version,$rem_own_id,$rem_user_name,$rem_utk_encr,$rem_utk_pre19,$rem_utk_verprof,$rem_utk_njeunusr,$rem_utk_logusr,$rem_utk_special,$rem_utk_default,$rem_utk_unknusr,$rem_utk_error,$rem_utk_trusted,$rem_utk_sesstype,$rem_utk_surrogat,$rem_utk_remote,$rem_utk_priv,$rem_utk_secl,$rem_utk_execnode,$rem_utk_suser_id,$rem_utk_snode,$rem_utk_sgrp_id,$rem_utk_spoe,$rem_utk_spclass,$rem_utk_user_id,$rem_utk_grp_id,$rem_utk_dft_grp,$rem_utk_dft_secl,$rem_appc_link,$rem_user_id,$rem_specified,$rem_failed,$rem_utk_netw,$rem_x500_subject,$rem_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"remove"}++;
		next;
	}

	if ($rectype eq 'RENAMEDS') {
		$ren_event_type=substr($_,0,8);
		$ren_event_qual=substr($_,9,8);
		$ren_time_written=substr($_,18,8);
		if ($ren_time_written  eq ' ' x length($ren_time_written )) {
			undef $ren_time_written ;
		}
		$ren_date_written=substr($_,27,10);
		if ($ren_date_written  eq ' ' x length($ren_date_written )) {
			undef $ren_date_written ;
		}
		$ren_system_smfid=substr($_,38,4);
		$ren_violation=substr($_,43,1);
		$ren_user_ndfnd=substr($_,48,1);
		$ren_user_warning=substr($_,53,1);
		$ren_evt_user_id=substr($_,58,8);
		$ren_evt_grp_id=substr($_,67,8);
		$ren_auth_normal=substr($_,76,1);
		$ren_auth_special=substr($_,81,1);
		$ren_auth_oper=substr($_,86,1);
		$ren_auth_audit=substr($_,91,1);
		$ren_auth_exit=substr($_,96,1);
		$ren_auth_failsft=substr($_,101,1);
		$ren_auth_bypass=substr($_,106,1);
		$ren_auth_trusted=substr($_,111,1);
		$ren_log_class=substr($_,116,1);
		$ren_log_user=substr($_,121,1);
		$ren_log_special=substr($_,126,1);
		$ren_log_access=substr($_,131,1);
		$ren_log_racinit=substr($_,136,1);
		$ren_log_always=substr($_,141,1);
		$ren_log_cmdviol=substr($_,146,1);
		$ren_log_global=substr($_,151,1);
		$ren_term_level=substr($_,156,3);
		if ($ren_term_level  eq ' ' x length($ren_term_level )) {
			undef $ren_term_level ;
		}
		$ren_backout_fail=substr($_,160,1);
		$ren_prof_same=substr($_,165,1);
		$ren_term=substr($_,170,8);
		$ren_job_name=substr($_,179,8);
		$ren_read_time=substr($_,188,8);
		if ($ren_read_time  eq ' ' x length($ren_read_time )) {
			undef $ren_read_time ;
		}
		$ren_read_date=substr($_,197,10);
		if ($ren_read_date  eq ' ' x length($ren_read_date )) {
			undef $ren_read_date ;
		}
		$ren_smf_user_id=substr($_,208,8);
		$ren_log_level=substr($_,217,1);
		$ren_log_vmevent=substr($_,222,1);
		$ren_log_logopt=substr($_,227,1);
		$ren_log_secl=substr($_,232,1);
		$ren_log_compatm=substr($_,237,1);
		$ren_log_applaud=substr($_,242,1);
		$ren_log_nonomvs=substr($_,247,1);
		$ren_log_omvsnprv=substr($_,252,1);
		$ren_auth_omvssu=substr($_,257,1);
		$ren_auth_omvssys=substr($_,262,1);
		$ren_usr_secl=substr($_,267,8);
		$ren_racf_version=substr($_,276,4);
		$ren_res_name=substr($_,281,255);
		$ren_new_res_name=substr($_,537,255);
		$ren_level=substr($_,793,3);
		if ($ren_level  eq ' ' x length($ren_level )) {
			undef $ren_level ;
		}
		$ren_vol=substr($_,797,6);
		$ren_class=substr($_,804,8);
		$ren_own_id=substr($_,813,8);
		$ren_logstr=substr($_,822,255);
		$ren_user_name=substr($_,1078,20);
		$ren_utk_encr=substr($_,1099,1);
		$ren_utk_pre19=substr($_,1104,1);
		$ren_utk_verprof=substr($_,1109,1);
		$ren_utk_njeunusr=substr($_,1114,1);
		$ren_utk_logusr=substr($_,1119,1);
		$ren_utk_special=substr($_,1124,1);
		$ren_utk_default=substr($_,1129,1);
		$ren_utk_unknusr=substr($_,1134,1);
		$ren_utk_error=substr($_,1139,1);
		$ren_utk_trusted=substr($_,1144,1);
		$ren_utk_sesstype=substr($_,1149,8);
		$ren_utk_surrogat=substr($_,1158,1);
		$ren_utk_remote=substr($_,1163,1);
		$ren_utk_priv=substr($_,1168,1);
		$ren_utk_secl=substr($_,1173,8);
		$ren_utk_execnode=substr($_,1182,8);
		$ren_utk_suser_id=substr($_,1191,8);
		$ren_utk_snode=substr($_,1200,8);
		$ren_utk_sgrp_id=substr($_,1209,8);
		$ren_utk_spoe=substr($_,1218,8);
		$ren_utk_spclass=substr($_,1227,8);
		$ren_utk_user_id=substr($_,1236,8);
		$ren_utk_grp_id=substr($_,1245,8);
		$ren_utk_dft_grp=substr($_,1254,1);
		$ren_utk_dft_secl=substr($_,1259,1);
		$ren_appc_link=substr($_,1264,16);
		$ren_specified=substr($_,1281,1024);
		$ren_utk_netw=substr($_,2306,8);
		$ren_x500_subject=substr($_,2315,255);
		$ren_x500_issuer=substr($_,2571,255);
		$rv=$insert{renameds}->execute($ren_event_type,$ren_event_qual,$ren_time_written,$ren_date_written,$ren_system_smfid,$ren_violation,$ren_user_ndfnd,$ren_user_warning,$ren_evt_user_id,$ren_evt_grp_id,$ren_auth_normal,$ren_auth_special,$ren_auth_oper,$ren_auth_audit,$ren_auth_exit,$ren_auth_failsft,$ren_auth_bypass,$ren_auth_trusted,$ren_log_class,$ren_log_user,$ren_log_special,$ren_log_access,$ren_log_racinit,$ren_log_always,$ren_log_cmdviol,$ren_log_global,$ren_term_level,$ren_backout_fail,$ren_prof_same,$ren_term,$ren_job_name,$ren_read_time,$ren_read_date,$ren_smf_user_id,$ren_log_level,$ren_log_vmevent,$ren_log_logopt,$ren_log_secl,$ren_log_compatm,$ren_log_applaud,$ren_log_nonomvs,$ren_log_omvsnprv,$ren_auth_omvssu,$ren_auth_omvssys,$ren_usr_secl,$ren_racf_version,$ren_res_name,$ren_new_res_name,$ren_level,$ren_vol,$ren_class,$ren_own_id,$ren_logstr,$ren_user_name,$ren_utk_encr,$ren_utk_pre19,$ren_utk_verprof,$ren_utk_njeunusr,$ren_utk_logusr,$ren_utk_special,$ren_utk_default,$ren_utk_unknusr,$ren_utk_error,$ren_utk_trusted,$ren_utk_sesstype,$ren_utk_surrogat,$ren_utk_remote,$ren_utk_priv,$ren_utk_secl,$ren_utk_execnode,$ren_utk_suser_id,$ren_utk_snode,$ren_utk_sgrp_id,$ren_utk_spoe,$ren_utk_spclass,$ren_utk_user_id,$ren_utk_grp_id,$ren_utk_dft_grp,$ren_utk_dft_secl,$ren_appc_link,$ren_specified,$ren_utk_netw,$ren_x500_subject,$ren_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"renameds"}++;
		next;
	}

	if ($rectype eq 'RENAMEF ') {
		$renf_event_type=substr($_,0,8);
		$renf_event_qual=substr($_,9,8);
		$renf_time_written=substr($_,18,8);
		if ($renf_time_written  eq ' ' x length($renf_time_written )) {
			undef $renf_time_written ;
		}
		$renf_date_written=substr($_,27,10);
		if ($renf_date_written  eq ' ' x length($renf_date_written )) {
			undef $renf_date_written ;
		}
		$renf_system_smfid=substr($_,38,4);
		$renf_violation=substr($_,43,1);
		$renf_user_ndfnd=substr($_,48,1);
		$renf_user_warning=substr($_,53,1);
		$renf_evt_user_id=substr($_,58,8);
		$renf_evt_grp_id=substr($_,67,8);
		$renf_auth_normal=substr($_,76,1);
		$renf_auth_special=substr($_,81,1);
		$renf_auth_oper=substr($_,86,1);
		$renf_auth_audit=substr($_,91,1);
		$renf_auth_exit=substr($_,96,1);
		$renf_auth_failsft=substr($_,101,1);
		$renf_auth_bypass=substr($_,106,1);
		$renf_auth_trusted=substr($_,111,1);
		$renf_log_class=substr($_,116,1);
		$renf_log_user=substr($_,121,1);
		$renf_log_special=substr($_,126,1);
		$renf_log_access=substr($_,131,1);
		$renf_log_racinit=substr($_,136,1);
		$renf_log_always=substr($_,141,1);
		$renf_log_cmdviol=substr($_,146,1);
		$renf_log_global=substr($_,151,1);
		$renf_term_level=substr($_,156,3);
		if ($renf_term_level  eq ' ' x length($renf_term_level )) {
			undef $renf_term_level ;
		}
		$renf_backout_fail=substr($_,160,1);
		$renf_prof_same=substr($_,165,1);
		$renf_term=substr($_,170,8);
		$renf_job_name=substr($_,179,8);
		$renf_read_time=substr($_,188,8);
		if ($renf_read_time  eq ' ' x length($renf_read_time )) {
			undef $renf_read_time ;
		}
		$renf_read_date=substr($_,197,10);
		if ($renf_read_date  eq ' ' x length($renf_read_date )) {
			undef $renf_read_date ;
		}
		$renf_smf_user_id=substr($_,208,8);
		$renf_log_level=substr($_,217,1);
		$renf_log_vmevent=substr($_,222,1);
		$renf_log_logopt=substr($_,227,1);
		$renf_log_secl=substr($_,232,1);
		$renf_log_compatm=substr($_,237,1);
		$renf_log_applaud=substr($_,242,1);
		$renf_log_nonomvs=substr($_,247,1);
		$renf_log_omvsnprv=substr($_,252,1);
		$renf_auth_omvssu=substr($_,257,1);
		$renf_auth_omvssys=substr($_,262,1);
		$renf_usr_secl=substr($_,267,8);
		$renf_racf_version=substr($_,276,4);
		$renf_class=substr($_,281,8);
		$renf_user_name=substr($_,290,20);
		$renf_utk_encr=substr($_,311,1);
		$renf_utk_pre19=substr($_,316,1);
		$renf_utk_verprof=substr($_,321,1);
		$renf_utk_njeunusr=substr($_,326,1);
		$renf_utk_logusr=substr($_,331,1);
		$renf_utk_special=substr($_,336,1);
		$renf_utk_default=substr($_,341,1);
		$renf_utk_unknusr=substr($_,346,1);
		$renf_utk_error=substr($_,351,1);
		$renf_utk_trusted=substr($_,356,1);
		$renf_utk_sesstype=substr($_,361,8);
		$renf_utk_surrogat=substr($_,370,1);
		$renf_utk_remote=substr($_,375,1);
		$renf_utk_priv=substr($_,380,1);
		$renf_utk_secl=substr($_,385,8);
		$renf_utk_execnode=substr($_,394,8);
		$renf_utk_suser_id=substr($_,403,8);
		$renf_utk_snode=substr($_,412,8);
		$renf_utk_sgrp_id=substr($_,421,8);
		$renf_utk_spoe=substr($_,430,8);
		$renf_utk_spclass=substr($_,439,8);
		$renf_utk_user_id=substr($_,448,8);
		$renf_utk_grp_id=substr($_,457,8);
		$renf_utk_dft_grp=substr($_,466,1);
		$renf_utk_dft_secl=substr($_,471,1);
		$renf_appc_link=substr($_,476,16);
		$renf_audit_code=substr($_,493,11);
		$renf_old_real_uid=substr($_,505,10);
		if ($renf_old_real_uid  eq ' ' x length($renf_old_real_uid )) {
			undef $renf_old_real_uid ;
		}
		$renf_old_eff_uid=substr($_,516,10);
		if ($renf_old_eff_uid  eq ' ' x length($renf_old_eff_uid )) {
			undef $renf_old_eff_uid ;
		}
		$renf_old_saved_uid=substr($_,527,10);
		if ($renf_old_saved_uid eq ' ' x length($renf_old_saved_uid)) {
			undef $renf_old_saved_uid;
		}
		$renf_old_real_gid=substr($_,538,10);
		if ($renf_old_real_gid  eq ' ' x length($renf_old_real_gid )) {
			undef $renf_old_real_gid ;
		}
		$renf_old_eff_gid=substr($_,549,10);
		if ($renf_old_eff_gid  eq ' ' x length($renf_old_eff_gid )) {
			undef $renf_old_eff_gid ;
		}
		$renf_old_saved_gid=substr($_,560,10);
		if ($renf_old_saved_gid eq ' ' x length($renf_old_saved_gid)) {
			undef $renf_old_saved_gid;
		}
		$renf_path_name=substr($_,571,1023);
		$renf_file_id=substr($_,1595,32);
		$renf_file_own_uid=substr($_,1628,10);
		if ($renf_file_own_uid  eq ' ' x length($renf_file_own_uid )) {
			undef $renf_file_own_uid ;
		}
		$renf_file_own_gid=substr($_,1639,10);
		if ($renf_file_own_gid  eq ' ' x length($renf_file_own_gid )) {
			undef $renf_file_own_gid ;
		}
		$renf_path2=substr($_,1650,1023);
		$renf_file_id2=substr($_,2674,32);
		$renf_owner_uid=substr($_,2707,10);
		if ($renf_owner_uid  eq ' ' x length($renf_owner_uid )) {
			undef $renf_owner_uid ;
		}
		$renf_owner_gid=substr($_,2718,10);
		if ($renf_owner_gid  eq ' ' x length($renf_owner_gid )) {
			undef $renf_owner_gid ;
		}
		$renf_path_type=substr($_,2729,4);
		$renf_last_deleted=substr($_,2734,1);
		$renf_filepool=substr($_,2739,8);
		$renf_filespace=substr($_,2748,8);
		$renf_inode=substr($_,2757,10);
		if ($renf_inode  eq ' ' x length($renf_inode )) {
			undef $renf_inode ;
		}
		$renf_scid=substr($_,2768,10);
		if ($renf_scid  eq ' ' x length($renf_scid )) {
			undef $renf_scid ;
		}
		$renf_filepool2=substr($_,2779,8);
		$renf_filespace2=substr($_,2788,8);
		$renf_inode2=substr($_,2797,10);
		if ($renf_inode2  eq ' ' x length($renf_inode2 )) {
			undef $renf_inode2 ;
		}
		$renf_scid2=substr($_,2808,10);
		if ($renf_scid2  eq ' ' x length($renf_scid2 )) {
			undef $renf_scid2 ;
		}
		$renf_dce_link=substr($_,2819,16);
		$renf_auth_type=substr($_,2836,13);
		$renf_dflt_process=substr($_,2850,1);
		$renf_utk_netw=substr($_,2855,8);
		$renf_x500_subject=substr($_,2864,255);
		$renf_x500_issuer=substr($_,3120,255);
		$rv=$insert{renamef}->execute($renf_event_type,$renf_event_qual,$renf_time_written,$renf_date_written,$renf_system_smfid,$renf_violation,$renf_user_ndfnd,$renf_user_warning,$renf_evt_user_id,$renf_evt_grp_id,$renf_auth_normal,$renf_auth_special,$renf_auth_oper,$renf_auth_audit,$renf_auth_exit,$renf_auth_failsft,$renf_auth_bypass,$renf_auth_trusted,$renf_log_class,$renf_log_user,$renf_log_special,$renf_log_access,$renf_log_racinit,$renf_log_always,$renf_log_cmdviol,$renf_log_global,$renf_term_level,$renf_backout_fail,$renf_prof_same,$renf_term,$renf_job_name,$renf_read_time,$renf_read_date,$renf_smf_user_id,$renf_log_level,$renf_log_vmevent,$renf_log_logopt,$renf_log_secl,$renf_log_compatm,$renf_log_applaud,$renf_log_nonomvs,$renf_log_omvsnprv,$renf_auth_omvssu,$renf_auth_omvssys,$renf_usr_secl,$renf_racf_version,$renf_class,$renf_user_name,$renf_utk_encr,$renf_utk_pre19,$renf_utk_verprof,$renf_utk_njeunusr,$renf_utk_logusr,$renf_utk_special,$renf_utk_default,$renf_utk_unknusr,$renf_utk_error,$renf_utk_trusted,$renf_utk_sesstype,$renf_utk_surrogat,$renf_utk_remote,$renf_utk_priv,$renf_utk_secl,$renf_utk_execnode,$renf_utk_suser_id,$renf_utk_snode,$renf_utk_sgrp_id,$renf_utk_spoe,$renf_utk_spclass,$renf_utk_user_id,$renf_utk_grp_id,$renf_utk_dft_grp,$renf_utk_dft_secl,$renf_appc_link,$renf_audit_code,$renf_old_real_uid,$renf_old_eff_uid,$renf_old_saved_uid,$renf_old_real_gid,$renf_old_eff_gid,$renf_old_saved_gid,$renf_path_name,$renf_file_id,$renf_file_own_uid,$renf_file_own_gid,$renf_path2,$renf_file_id2,$renf_owner_uid,$renf_owner_gid,$renf_path_type,$renf_last_deleted,$renf_filepool,$renf_filespace,$renf_inode,$renf_scid,$renf_filepool2,$renf_filespace2,$renf_inode2,$renf_scid2,$renf_dce_link,$renf_auth_type,$renf_dflt_process,$renf_utk_netw,$renf_x500_subject,$renf_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"renamef"}++;
		next;
	}

	if ($rectype eq 'RMDIR   ') {
		$rdir_event_type=substr($_,0,8);
		$rdir_event_qual=substr($_,9,8);
		$rdir_time_written=substr($_,18,8);
		if ($rdir_time_written  eq ' ' x length($rdir_time_written )) {
			undef $rdir_time_written ;
		}
		$rdir_date_written=substr($_,27,10);
		if ($rdir_date_written  eq ' ' x length($rdir_date_written )) {
			undef $rdir_date_written ;
		}
		$rdir_system_smfid=substr($_,38,4);
		$rdir_violation=substr($_,43,1);
		$rdir_user_ndfnd=substr($_,48,1);
		$rdir_user_warning=substr($_,53,1);
		$rdir_evt_user_id=substr($_,58,8);
		$rdir_evt_grp_id=substr($_,67,8);
		$rdir_auth_normal=substr($_,76,1);
		$rdir_auth_special=substr($_,81,1);
		$rdir_auth_oper=substr($_,86,1);
		$rdir_auth_audit=substr($_,91,1);
		$rdir_auth_exit=substr($_,96,1);
		$rdir_auth_failsft=substr($_,101,1);
		$rdir_auth_bypass=substr($_,106,1);
		$rdir_auth_trusted=substr($_,111,1);
		$rdir_log_class=substr($_,116,1);
		$rdir_log_user=substr($_,121,1);
		$rdir_log_special=substr($_,126,1);
		$rdir_log_access=substr($_,131,1);
		$rdir_log_racinit=substr($_,136,1);
		$rdir_log_always=substr($_,141,1);
		$rdir_log_cmdviol=substr($_,146,1);
		$rdir_log_global=substr($_,151,1);
		$rdir_term_level=substr($_,156,3);
		if ($rdir_term_level  eq ' ' x length($rdir_term_level )) {
			undef $rdir_term_level ;
		}
		$rdir_backout_fail=substr($_,160,1);
		$rdir_prof_same=substr($_,165,1);
		$rdir_term=substr($_,170,8);
		$rdir_job_name=substr($_,179,8);
		$rdir_read_time=substr($_,188,8);
		if ($rdir_read_time  eq ' ' x length($rdir_read_time )) {
			undef $rdir_read_time ;
		}
		$rdir_read_date=substr($_,197,10);
		if ($rdir_read_date  eq ' ' x length($rdir_read_date )) {
			undef $rdir_read_date ;
		}
		$rdir_smf_user_id=substr($_,208,8);
		$rdir_log_level=substr($_,217,1);
		$rdir_log_vmevent=substr($_,222,1);
		$rdir_log_logopt=substr($_,227,1);
		$rdir_log_secl=substr($_,232,1);
		$rdir_log_compatm=substr($_,237,1);
		$rdir_log_applaud=substr($_,242,1);
		$rdir_log_nonomvs=substr($_,247,1);
		$rdir_log_omvsnprv=substr($_,252,1);
		$rdir_auth_omvssu=substr($_,257,1);
		$rdir_auth_omvssys=substr($_,262,1);
		$rdir_usr_secl=substr($_,267,8);
		$rdir_racf_version=substr($_,276,4);
		$rdir_class=substr($_,281,8);
		$rdir_user_name=substr($_,290,20);
		$rdir_utk_encr=substr($_,311,1);
		$rdir_utk_pre19=substr($_,316,1);
		$rdir_utk_verprof=substr($_,321,1);
		$rdir_utk_njeunusr=substr($_,326,1);
		$rdir_utk_logusr=substr($_,331,1);
		$rdir_utk_special=substr($_,336,1);
		$rdir_utk_default=substr($_,341,1);
		$rdir_utk_unknusr=substr($_,346,1);
		$rdir_utk_error=substr($_,351,1);
		$rdir_utk_trusted=substr($_,356,1);
		$rdir_utk_sesstype=substr($_,361,8);
		$rdir_utk_surrogat=substr($_,370,1);
		$rdir_utk_remote=substr($_,375,1);
		$rdir_utk_priv=substr($_,380,1);
		$rdir_utk_secl=substr($_,385,8);
		$rdir_utk_execnode=substr($_,394,8);
		$rdir_utk_suser_id=substr($_,403,8);
		$rdir_utk_snode=substr($_,412,8);
		$rdir_utk_sgrp_id=substr($_,421,8);
		$rdir_utk_spoe=substr($_,430,8);
		$rdir_utk_spclass=substr($_,439,8);
		$rdir_utk_user_id=substr($_,448,8);
		$rdir_utk_grp_id=substr($_,457,8);
		$rdir_utk_dft_grp=substr($_,466,1);
		$rdir_utk_dft_secl=substr($_,471,1);
		$rdir_appc_link=substr($_,476,16);
		$rdir_audit_code=substr($_,493,11);
		$rdir_old_real_uid=substr($_,505,10);
		if ($rdir_old_real_uid  eq ' ' x length($rdir_old_real_uid )) {
			undef $rdir_old_real_uid ;
		}
		$rdir_old_eff_uid=substr($_,516,10);
		if ($rdir_old_eff_uid  eq ' ' x length($rdir_old_eff_uid )) {
			undef $rdir_old_eff_uid ;
		}
		$rdir_old_saved_uid=substr($_,527,10);
		if ($rdir_old_saved_uid eq ' ' x length($rdir_old_saved_uid)) {
			undef $rdir_old_saved_uid;
		}
		$rdir_old_real_gid=substr($_,538,10);
		if ($rdir_old_real_gid  eq ' ' x length($rdir_old_real_gid )) {
			undef $rdir_old_real_gid ;
		}
		$rdir_old_eff_gid=substr($_,549,10);
		if ($rdir_old_eff_gid  eq ' ' x length($rdir_old_eff_gid )) {
			undef $rdir_old_eff_gid ;
		}
		$rdir_old_saved_gid=substr($_,560,10);
		if ($rdir_old_saved_gid eq ' ' x length($rdir_old_saved_gid)) {
			undef $rdir_old_saved_gid;
		}
		$rdir_path_name=substr($_,571,1023);
		$rdir_file_id=substr($_,1595,32);
		$rdir_file_own_uid=substr($_,1628,10);
		if ($rdir_file_own_uid  eq ' ' x length($rdir_file_own_uid )) {
			undef $rdir_file_own_uid ;
		}
		$rdir_file_own_gid=substr($_,1639,10);
		if ($rdir_file_own_gid  eq ' ' x length($rdir_file_own_gid )) {
			undef $rdir_file_own_gid ;
		}
		$rdir_filepool=substr($_,1650,8);
		$rdir_filespace=substr($_,1659,8);
		$rdir_inode=substr($_,1668,10);
		if ($rdir_inode  eq ' ' x length($rdir_inode )) {
			undef $rdir_inode ;
		}
		$rdir_scid=substr($_,1679,10);
		if ($rdir_scid  eq ' ' x length($rdir_scid )) {
			undef $rdir_scid ;
		}
		$rdir_dce_link=substr($_,1690,16);
		$rdir_auth_type=substr($_,1707,13);
		$rdir_dflt_process=substr($_,1721,1);
		$rdir_utk_netw=substr($_,1726,8);
		$rdir_x500_subject=substr($_,1735,255);
		$rdir_x500_issuer=substr($_,1991,255);
		$rv=$insert{rmdir}->execute($rdir_event_type,$rdir_event_qual,$rdir_time_written,$rdir_date_written,$rdir_system_smfid,$rdir_violation,$rdir_user_ndfnd,$rdir_user_warning,$rdir_evt_user_id,$rdir_evt_grp_id,$rdir_auth_normal,$rdir_auth_special,$rdir_auth_oper,$rdir_auth_audit,$rdir_auth_exit,$rdir_auth_failsft,$rdir_auth_bypass,$rdir_auth_trusted,$rdir_log_class,$rdir_log_user,$rdir_log_special,$rdir_log_access,$rdir_log_racinit,$rdir_log_always,$rdir_log_cmdviol,$rdir_log_global,$rdir_term_level,$rdir_backout_fail,$rdir_prof_same,$rdir_term,$rdir_job_name,$rdir_read_time,$rdir_read_date,$rdir_smf_user_id,$rdir_log_level,$rdir_log_vmevent,$rdir_log_logopt,$rdir_log_secl,$rdir_log_compatm,$rdir_log_applaud,$rdir_log_nonomvs,$rdir_log_omvsnprv,$rdir_auth_omvssu,$rdir_auth_omvssys,$rdir_usr_secl,$rdir_racf_version,$rdir_class,$rdir_user_name,$rdir_utk_encr,$rdir_utk_pre19,$rdir_utk_verprof,$rdir_utk_njeunusr,$rdir_utk_logusr,$rdir_utk_special,$rdir_utk_default,$rdir_utk_unknusr,$rdir_utk_error,$rdir_utk_trusted,$rdir_utk_sesstype,$rdir_utk_surrogat,$rdir_utk_remote,$rdir_utk_priv,$rdir_utk_secl,$rdir_utk_execnode,$rdir_utk_suser_id,$rdir_utk_snode,$rdir_utk_sgrp_id,$rdir_utk_spoe,$rdir_utk_spclass,$rdir_utk_user_id,$rdir_utk_grp_id,$rdir_utk_dft_grp,$rdir_utk_dft_secl,$rdir_appc_link,$rdir_audit_code,$rdir_old_real_uid,$rdir_old_eff_uid,$rdir_old_saved_uid,$rdir_old_real_gid,$rdir_old_eff_gid,$rdir_old_saved_gid,$rdir_path_name,$rdir_file_id,$rdir_file_own_uid,$rdir_file_own_gid,$rdir_filepool,$rdir_filespace,$rdir_inode,$rdir_scid,$rdir_dce_link,$rdir_auth_type,$rdir_dflt_process,$rdir_utk_netw,$rdir_x500_subject,$rdir_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rmdir"}++;
		next;
	}

	if ($rectype eq 'RPKIEXPT') {
		$rpke_event_type=substr($_,0,8);
		$rpke_event_qual=substr($_,9,8);
		$rpke_time_written=substr($_,18,8);
		if ($rpke_time_written  eq ' ' x length($rpke_time_written )) {
			undef $rpke_time_written ;
		}
		$rpke_date_written=substr($_,27,10);
		if ($rpke_date_written  eq ' ' x length($rpke_date_written )) {
			undef $rpke_date_written ;
		}
		$rpke_system_smfid=substr($_,38,4);
		$rpke_violation=substr($_,43,1);
		$rpke_user_ndfnd=substr($_,48,1);
		$rpke_user_warning=substr($_,53,1);
		$rpke_evt_user_id=substr($_,58,8);
		$rpke_evt_grp_id=substr($_,67,8);
		$rpke_auth_normal=substr($_,76,1);
		$rpke_auth_special=substr($_,81,1);
		$rpke_auth_oper=substr($_,86,1);
		$rpke_auth_audit=substr($_,91,1);
		$rpke_auth_exit=substr($_,96,1);
		$rpke_auth_failsft=substr($_,101,1);
		$rpke_auth_bypass=substr($_,106,1);
		$rpke_auth_trusted=substr($_,111,1);
		$rpke_log_class=substr($_,116,1);
		$rpke_log_user=substr($_,121,1);
		$rpke_log_special=substr($_,126,1);
		$rpke_log_access=substr($_,131,1);
		$rpke_log_racinit=substr($_,136,1);
		$rpke_log_always=substr($_,141,1);
		$rpke_log_cmdviol=substr($_,146,1);
		$rpke_log_global=substr($_,151,1);
		$rpke_term_level=substr($_,156,3);
		if ($rpke_term_level  eq ' ' x length($rpke_term_level )) {
			undef $rpke_term_level ;
		}
		$rpke_backout_fail=substr($_,160,1);
		$rpke_prof_same=substr($_,165,1);
		$rpke_term=substr($_,170,8);
		$rpke_job_name=substr($_,179,8);
		$rpke_read_time=substr($_,188,8);
		if ($rpke_read_time  eq ' ' x length($rpke_read_time )) {
			undef $rpke_read_time ;
		}
		$rpke_read_date=substr($_,197,10);
		if ($rpke_read_date  eq ' ' x length($rpke_read_date )) {
			undef $rpke_read_date ;
		}
		$rpke_smf_user_id=substr($_,208,8);
		$rpke_log_level=substr($_,217,1);
		$rpke_log_vmevent=substr($_,222,1);
		$rpke_log_logopt=substr($_,227,1);
		$rpke_log_secl=substr($_,232,1);
		$rpke_log_compatm=substr($_,237,1);
		$rpke_log_applaud=substr($_,242,1);
		$rpke_log_nonomvs=substr($_,247,1);
		$rpke_log_omvsnprv=substr($_,252,1);
		$rpke_auth_omvssu=substr($_,257,1);
		$rpke_auth_omvssys=substr($_,262,1);
		$rpke_usr_secl=substr($_,267,8);
		$rpke_racf_version=substr($_,276,4);
		$rpke_logstring=substr($_,281,255);
		$rpke_user_name=substr($_,537,20);
		$rpke_utk_encr=substr($_,558,1);
		$rpke_utk_pre19=substr($_,563,1);
		$rpke_utk_verprof=substr($_,568,1);
		$rpke_utk_njeunusr=substr($_,573,1);
		$rpke_utk_logusr=substr($_,578,1);
		$rpke_utk_special=substr($_,583,1);
		$rpke_utk_default=substr($_,588,1);
		$rpke_utk_unknusr=substr($_,593,1);
		$rpke_utk_error=substr($_,598,1);
		$rpke_utk_trusted=substr($_,603,1);
		$rpke_utk_sesstype=substr($_,608,8);
		$rpke_utk_surrogat=substr($_,617,1);
		$rpke_utk_remote=substr($_,622,1);
		$rpke_utk_priv=substr($_,627,1);
		$rpke_utk_secl=substr($_,632,8);
		$rpke_utk_execnode=substr($_,641,8);
		$rpke_utk_suser_id=substr($_,650,8);
		$rpke_utk_snode=substr($_,659,8);
		$rpke_utk_sgrp_id=substr($_,668,8);
		$rpke_utk_spoe=substr($_,677,8);
		$rpke_utk_spclass=substr($_,686,8);
		$rpke_utk_user_id=substr($_,695,8);
		$rpke_utk_grp_id=substr($_,704,8);
		$rpke_utk_dft_grp=substr($_,713,1);
		$rpke_utk_dft_secl=substr($_,718,1);
		$rpke_utk_netw=substr($_,723,8);
		$rpke_x500_subject=substr($_,732,255);
		$rpke_x500_issuer=substr($_,988,255);
		$rpke_target_userid=substr($_,1244,8);
		$rpke_target_label=substr($_,1253,32);
		$rpke_cert_id=substr($_,1286,56);
		$rpke_pass_phrase=substr($_,1343,1);
		$rv=$insert{rpkiexpt}->execute($rpke_event_type,$rpke_event_qual,$rpke_time_written,$rpke_date_written,$rpke_system_smfid,$rpke_violation,$rpke_user_ndfnd,$rpke_user_warning,$rpke_evt_user_id,$rpke_evt_grp_id,$rpke_auth_normal,$rpke_auth_special,$rpke_auth_oper,$rpke_auth_audit,$rpke_auth_exit,$rpke_auth_failsft,$rpke_auth_bypass,$rpke_auth_trusted,$rpke_log_class,$rpke_log_user,$rpke_log_special,$rpke_log_access,$rpke_log_racinit,$rpke_log_always,$rpke_log_cmdviol,$rpke_log_global,$rpke_term_level,$rpke_backout_fail,$rpke_prof_same,$rpke_term,$rpke_job_name,$rpke_read_time,$rpke_read_date,$rpke_smf_user_id,$rpke_log_level,$rpke_log_vmevent,$rpke_log_logopt,$rpke_log_secl,$rpke_log_compatm,$rpke_log_applaud,$rpke_log_nonomvs,$rpke_log_omvsnprv,$rpke_auth_omvssu,$rpke_auth_omvssys,$rpke_usr_secl,$rpke_racf_version,$rpke_logstring,$rpke_user_name,$rpke_utk_encr,$rpke_utk_pre19,$rpke_utk_verprof,$rpke_utk_njeunusr,$rpke_utk_logusr,$rpke_utk_special,$rpke_utk_default,$rpke_utk_unknusr,$rpke_utk_error,$rpke_utk_trusted,$rpke_utk_sesstype,$rpke_utk_surrogat,$rpke_utk_remote,$rpke_utk_priv,$rpke_utk_secl,$rpke_utk_execnode,$rpke_utk_suser_id,$rpke_utk_snode,$rpke_utk_sgrp_id,$rpke_utk_spoe,$rpke_utk_spclass,$rpke_utk_user_id,$rpke_utk_grp_id,$rpke_utk_dft_grp,$rpke_utk_dft_secl,$rpke_utk_netw,$rpke_x500_subject,$rpke_x500_issuer,$rpke_target_userid,$rpke_target_label,$rpke_cert_id,$rpke_pass_phrase);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rpkiexpt"}++;
		next;
	}

	if ($rectype eq 'RPKIGENC') {
		$rpkg_event_type=substr($_,0,8);
		$rpkg_event_qual=substr($_,9,8);
		$rpkg_time_written=substr($_,18,8);
		if ($rpkg_time_written  eq ' ' x length($rpkg_time_written )) {
			undef $rpkg_time_written ;
		}
		$rpkg_date_written=substr($_,27,10);
		if ($rpkg_date_written  eq ' ' x length($rpkg_date_written )) {
			undef $rpkg_date_written ;
		}
		$rpkg_system_smfid=substr($_,38,4);
		$rpkg_violation=substr($_,43,1);
		$rpkg_user_ndfnd=substr($_,48,1);
		$rpkg_user_warning=substr($_,53,1);
		$rpkg_evt_user_id=substr($_,58,8);
		$rpkg_evt_grp_id=substr($_,67,8);
		$rpkg_auth_normal=substr($_,76,1);
		$rpkg_auth_special=substr($_,81,1);
		$rpkg_auth_oper=substr($_,86,1);
		$rpkg_auth_audit=substr($_,91,1);
		$rpkg_auth_exit=substr($_,96,1);
		$rpkg_auth_failsft=substr($_,101,1);
		$rpkg_auth_bypass=substr($_,106,1);
		$rpkg_auth_trusted=substr($_,111,1);
		$rpkg_log_class=substr($_,116,1);
		$rpkg_log_user=substr($_,121,1);
		$rpkg_log_special=substr($_,126,1);
		$rpkg_log_access=substr($_,131,1);
		$rpkg_log_racinit=substr($_,136,1);
		$rpkg_log_always=substr($_,141,1);
		$rpkg_log_cmdviol=substr($_,146,1);
		$rpkg_log_global=substr($_,151,1);
		$rpkg_term_level=substr($_,156,3);
		if ($rpkg_term_level  eq ' ' x length($rpkg_term_level )) {
			undef $rpkg_term_level ;
		}
		$rpkg_backout_fail=substr($_,160,1);
		$rpkg_prof_same=substr($_,165,1);
		$rpkg_term=substr($_,170,8);
		$rpkg_job_name=substr($_,179,8);
		$rpkg_read_time=substr($_,188,8);
		if ($rpkg_read_time  eq ' ' x length($rpkg_read_time )) {
			undef $rpkg_read_time ;
		}
		$rpkg_read_date=substr($_,197,10);
		if ($rpkg_read_date  eq ' ' x length($rpkg_read_date )) {
			undef $rpkg_read_date ;
		}
		$rpkg_smf_user_id=substr($_,208,8);
		$rpkg_log_level=substr($_,217,1);
		$rpkg_log_vmevent=substr($_,222,1);
		$rpkg_log_logopt=substr($_,227,1);
		$rpkg_log_secl=substr($_,232,1);
		$rpkg_log_compatm=substr($_,237,1);
		$rpkg_log_applaud=substr($_,242,1);
		$rpkg_log_nonomvs=substr($_,247,1);
		$rpkg_log_omvsnprv=substr($_,252,1);
		$rpkg_auth_omvssu=substr($_,257,1);
		$rpkg_auth_omvssys=substr($_,262,1);
		$rpkg_usr_secl=substr($_,267,8);
		$rpkg_racf_version=substr($_,276,4);
		$rpkg_logstring=substr($_,281,255);
		$rpkg_user_name=substr($_,537,20);
		$rpkg_utk_encr=substr($_,558,1);
		$rpkg_utk_pre19=substr($_,563,1);
		$rpkg_utk_verprof=substr($_,568,1);
		$rpkg_utk_njeunusr=substr($_,573,1);
		$rpkg_utk_logusr=substr($_,578,1);
		$rpkg_utk_special=substr($_,583,1);
		$rpkg_utk_default=substr($_,588,1);
		$rpkg_utk_unknusr=substr($_,593,1);
		$rpkg_utk_error=substr($_,598,1);
		$rpkg_utk_trusted=substr($_,603,1);
		$rpkg_utk_sesstype=substr($_,608,8);
		$rpkg_utk_surrogat=substr($_,617,1);
		$rpkg_utk_remote=substr($_,622,1);
		$rpkg_utk_priv=substr($_,627,1);
		$rpkg_utk_secl=substr($_,632,8);
		$rpkg_utk_execnode=substr($_,641,8);
		$rpkg_utk_suser_id=substr($_,650,8);
		$rpkg_utk_snode=substr($_,659,8);
		$rpkg_utk_sgrp_id=substr($_,668,8);
		$rpkg_utk_spoe=substr($_,677,8);
		$rpkg_utk_spclass=substr($_,686,8);
		$rpkg_utk_user_id=substr($_,695,8);
		$rpkg_utk_grp_id=substr($_,704,8);
		$rpkg_utk_dft_grp=substr($_,713,1);
		$rpkg_utk_dft_secl=substr($_,718,1);
		$rpkg_serial_number=substr($_,723,255);
		$rpkg_issuers_dn=substr($_,979,255);
		$rpkg_utk_netw=substr($_,1235,8);
		$rpkg_x500_subject=substr($_,1244,255);
		$rpkg_x500_issuer=substr($_,1500,255);
		$rpkg_keyusage=substr($_,1756,64);
		$rpkg_notbefor_date=substr($_,1821,10);
		$rpkg_notafter_date=substr($_,1832,10);
		$rpkg_target_userid=substr($_,1843,8);
		$rpkg_target_label=substr($_,1852,32);
		$rpkg_signwith=substr($_,1885,45);
		$rpkg_subjects_dn=substr($_,1931,255);
		$rpkg_alt_ip=substr($_,2187,64);
		$rpkg_alt_uri=substr($_,2252,255);
		$rpkg_alt_email=substr($_,2508,100);
		$rpkg_alt_domain=substr($_,2609,100);
		$rpkg_cert_id=substr($_,2710,56);
		$rpkg_hostid_map=substr($_,2767,1024);
		$rpkg_requestor=substr($_,3792,32);
		$rpkg_pass_phrase=substr($_,3825,1);
		$rpkg_notify_email=substr($_,3830,64);
		$rv=$insert{rpkigenc}->execute($rpkg_event_type,$rpkg_event_qual,$rpkg_time_written,$rpkg_date_written,$rpkg_system_smfid,$rpkg_violation,$rpkg_user_ndfnd,$rpkg_user_warning,$rpkg_evt_user_id,$rpkg_evt_grp_id,$rpkg_auth_normal,$rpkg_auth_special,$rpkg_auth_oper,$rpkg_auth_audit,$rpkg_auth_exit,$rpkg_auth_failsft,$rpkg_auth_bypass,$rpkg_auth_trusted,$rpkg_log_class,$rpkg_log_user,$rpkg_log_special,$rpkg_log_access,$rpkg_log_racinit,$rpkg_log_always,$rpkg_log_cmdviol,$rpkg_log_global,$rpkg_term_level,$rpkg_backout_fail,$rpkg_prof_same,$rpkg_term,$rpkg_job_name,$rpkg_read_time,$rpkg_read_date,$rpkg_smf_user_id,$rpkg_log_level,$rpkg_log_vmevent,$rpkg_log_logopt,$rpkg_log_secl,$rpkg_log_compatm,$rpkg_log_applaud,$rpkg_log_nonomvs,$rpkg_log_omvsnprv,$rpkg_auth_omvssu,$rpkg_auth_omvssys,$rpkg_usr_secl,$rpkg_racf_version,$rpkg_logstring,$rpkg_user_name,$rpkg_utk_encr,$rpkg_utk_pre19,$rpkg_utk_verprof,$rpkg_utk_njeunusr,$rpkg_utk_logusr,$rpkg_utk_special,$rpkg_utk_default,$rpkg_utk_unknusr,$rpkg_utk_error,$rpkg_utk_trusted,$rpkg_utk_sesstype,$rpkg_utk_surrogat,$rpkg_utk_remote,$rpkg_utk_priv,$rpkg_utk_secl,$rpkg_utk_execnode,$rpkg_utk_suser_id,$rpkg_utk_snode,$rpkg_utk_sgrp_id,$rpkg_utk_spoe,$rpkg_utk_spclass,$rpkg_utk_user_id,$rpkg_utk_grp_id,$rpkg_utk_dft_grp,$rpkg_utk_dft_secl,$rpkg_serial_number,$rpkg_issuers_dn,$rpkg_utk_netw,$rpkg_x500_subject,$rpkg_x500_issuer,$rpkg_keyusage,$rpkg_notbefor_date,$rpkg_notafter_date,$rpkg_target_userid,$rpkg_target_label,$rpkg_signwith,$rpkg_subjects_dn,$rpkg_alt_ip,$rpkg_alt_uri,$rpkg_alt_email,$rpkg_alt_domain,$rpkg_cert_id,$rpkg_hostid_map,$rpkg_requestor,$rpkg_pass_phrase,$rpkg_notify_email);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rpkigenc"}++;
		next;
	}

	if ($rectype eq 'RPKIREAD') {
		$rpkr_event_type=substr($_,0,8);
		$rpkr_event_qual=substr($_,9,8);
		$rpkr_time_written=substr($_,18,8);
		if ($rpkr_time_written  eq ' ' x length($rpkr_time_written )) {
			undef $rpkr_time_written ;
		}
		$rpkr_date_written=substr($_,27,10);
		if ($rpkr_date_written  eq ' ' x length($rpkr_date_written )) {
			undef $rpkr_date_written ;
		}
		$rpkr_system_smfid=substr($_,38,4);
		$rpkr_violation=substr($_,43,1);
		$rpkr_user_ndfnd=substr($_,48,1);
		$rpkr_user_warning=substr($_,53,1);
		$rpkr_evt_user_id=substr($_,58,8);
		$rpkr_evt_grp_id=substr($_,67,8);
		$rpkr_auth_normal=substr($_,76,1);
		$rpkr_auth_special=substr($_,81,1);
		$rpkr_auth_oper=substr($_,86,1);
		$rpkr_auth_audit=substr($_,91,1);
		$rpkr_auth_exit=substr($_,96,1);
		$rpkr_auth_failsft=substr($_,101,1);
		$rpkr_auth_bypass=substr($_,106,1);
		$rpkr_auth_trusted=substr($_,111,1);
		$rpkr_log_class=substr($_,116,1);
		$rpkr_log_user=substr($_,121,1);
		$rpkr_log_special=substr($_,126,1);
		$rpkr_log_access=substr($_,131,1);
		$rpkr_log_racinit=substr($_,136,1);
		$rpkr_log_always=substr($_,141,1);
		$rpkr_log_cmdviol=substr($_,146,1);
		$rpkr_log_global=substr($_,151,1);
		$rpkr_term_level=substr($_,156,3);
		if ($rpkr_term_level  eq ' ' x length($rpkr_term_level )) {
			undef $rpkr_term_level ;
		}
		$rpkr_backout_fail=substr($_,160,1);
		$rpkr_prof_same=substr($_,165,1);
		$rpkr_term=substr($_,170,8);
		$rpkr_job_name=substr($_,179,8);
		$rpkr_read_time=substr($_,188,8);
		if ($rpkr_read_time  eq ' ' x length($rpkr_read_time )) {
			undef $rpkr_read_time ;
		}
		$rpkr_read_date=substr($_,197,10);
		if ($rpkr_read_date  eq ' ' x length($rpkr_read_date )) {
			undef $rpkr_read_date ;
		}
		$rpkr_smf_user_id=substr($_,208,8);
		$rpkr_log_level=substr($_,217,1);
		$rpkr_log_vmevent=substr($_,222,1);
		$rpkr_log_logopt=substr($_,227,1);
		$rpkr_log_secl=substr($_,232,1);
		$rpkr_log_compatm=substr($_,237,1);
		$rpkr_log_applaud=substr($_,242,1);
		$rpkr_log_nonomvs=substr($_,247,1);
		$rpkr_log_omvsnprv=substr($_,252,1);
		$rpkr_auth_omvssu=substr($_,257,1);
		$rpkr_auth_omvssys=substr($_,262,1);
		$rpkr_usr_secl=substr($_,267,8);
		$rpkr_racf_version=substr($_,276,4);
		$rpkr_appl=substr($_,281,8);
		$rpkr_logstring=substr($_,290,255);
		$rpkr_user_name=substr($_,546,20);
		$rpkr_utk_encr=substr($_,567,1);
		$rpkr_utk_pre19=substr($_,572,1);
		$rpkr_utk_verprof=substr($_,577,1);
		$rpkr_utk_njeunusr=substr($_,582,1);
		$rpkr_utk_logusr=substr($_,587,1);
		$rpkr_utk_special=substr($_,592,1);
		$rpkr_utk_default=substr($_,597,1);
		$rpkr_utk_unknusr=substr($_,602,1);
		$rpkr_utk_error=substr($_,607,1);
		$rpkr_utk_trusted=substr($_,612,1);
		$rpkr_utk_sesstype=substr($_,617,8);
		$rpkr_utk_surrogat=substr($_,626,1);
		$rpkr_utk_remote=substr($_,631,1);
		$rpkr_utk_priv=substr($_,636,1);
		$rpkr_utk_secl=substr($_,641,8);
		$rpkr_utk_execnode=substr($_,650,8);
		$rpkr_utk_suser_id=substr($_,659,8);
		$rpkr_utk_snode=substr($_,668,8);
		$rpkr_utk_sgrp_id=substr($_,677,8);
		$rpkr_utk_spoe=substr($_,686,8);
		$rpkr_utk_spclass=substr($_,695,8);
		$rpkr_utk_user_id=substr($_,704,8);
		$rpkr_utk_grp_id=substr($_,713,8);
		$rpkr_utk_dft_grp=substr($_,722,1);
		$rpkr_utk_dft_secl=substr($_,727,1);
		$rpkr_serial_number=substr($_,732,255);
		$rpkr_issuers_dn=substr($_,988,255);
		$rpkr_utk_netw=substr($_,1244,8);
		$rpkr_x500_subject=substr($_,1253,255);
		$rpkr_x500_issuer=substr($_,1509,255);
		$rpkr_keyusage=substr($_,1765,64);
		$rpkr_notbefor_date=substr($_,1830,10);
		$rpkr_notafter_date=substr($_,1841,10);
		$rpkr_subjects_dn=substr($_,1852,255);
		$rpkr_cert_id=substr($_,2108,56);
		$rpkr_requestor=substr($_,2165,32);
		$rpkr_status=substr($_,2198,32);
		$rpkr_creation_date=substr($_,2231,10);
		$rpkr_last_mod_date=substr($_,2242,10);
		$rpkr_prev_serial=substr($_,2253,255);
		$rpkr_notify_email=substr($_,2509,64);
		$rv=$insert{rpkiread}->execute($rpkr_event_type,$rpkr_event_qual,$rpkr_time_written,$rpkr_date_written,$rpkr_system_smfid,$rpkr_violation,$rpkr_user_ndfnd,$rpkr_user_warning,$rpkr_evt_user_id,$rpkr_evt_grp_id,$rpkr_auth_normal,$rpkr_auth_special,$rpkr_auth_oper,$rpkr_auth_audit,$rpkr_auth_exit,$rpkr_auth_failsft,$rpkr_auth_bypass,$rpkr_auth_trusted,$rpkr_log_class,$rpkr_log_user,$rpkr_log_special,$rpkr_log_access,$rpkr_log_racinit,$rpkr_log_always,$rpkr_log_cmdviol,$rpkr_log_global,$rpkr_term_level,$rpkr_backout_fail,$rpkr_prof_same,$rpkr_term,$rpkr_job_name,$rpkr_read_time,$rpkr_read_date,$rpkr_smf_user_id,$rpkr_log_level,$rpkr_log_vmevent,$rpkr_log_logopt,$rpkr_log_secl,$rpkr_log_compatm,$rpkr_log_applaud,$rpkr_log_nonomvs,$rpkr_log_omvsnprv,$rpkr_auth_omvssu,$rpkr_auth_omvssys,$rpkr_usr_secl,$rpkr_racf_version,$rpkr_appl,$rpkr_logstring,$rpkr_user_name,$rpkr_utk_encr,$rpkr_utk_pre19,$rpkr_utk_verprof,$rpkr_utk_njeunusr,$rpkr_utk_logusr,$rpkr_utk_special,$rpkr_utk_default,$rpkr_utk_unknusr,$rpkr_utk_error,$rpkr_utk_trusted,$rpkr_utk_sesstype,$rpkr_utk_surrogat,$rpkr_utk_remote,$rpkr_utk_priv,$rpkr_utk_secl,$rpkr_utk_execnode,$rpkr_utk_suser_id,$rpkr_utk_snode,$rpkr_utk_sgrp_id,$rpkr_utk_spoe,$rpkr_utk_spclass,$rpkr_utk_user_id,$rpkr_utk_grp_id,$rpkr_utk_dft_grp,$rpkr_utk_dft_secl,$rpkr_serial_number,$rpkr_issuers_dn,$rpkr_utk_netw,$rpkr_x500_subject,$rpkr_x500_issuer,$rpkr_keyusage,$rpkr_notbefor_date,$rpkr_notafter_date,$rpkr_subjects_dn,$rpkr_cert_id,$rpkr_requestor,$rpkr_status,$rpkr_creation_date,$rpkr_last_mod_date,$rpkr_prev_serial,$rpkr_notify_email);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rpkiread"}++;
		next;
	}

	if ($rectype eq 'RPKIUPDC') {
		$rpkc_event_type=substr($_,0,8);
		$rpkc_event_qual=substr($_,9,8);
		$rpkc_time_written=substr($_,18,8);
		if ($rpkc_time_written  eq ' ' x length($rpkc_time_written )) {
			undef $rpkc_time_written ;
		}
		$rpkc_date_written=substr($_,27,10);
		if ($rpkc_date_written  eq ' ' x length($rpkc_date_written )) {
			undef $rpkc_date_written ;
		}
		$rpkc_system_smfid=substr($_,38,4);
		$rpkc_violation=substr($_,43,1);
		$rpkc_user_ndfnd=substr($_,48,1);
		$rpkc_user_warning=substr($_,53,1);
		$rpkc_evt_user_id=substr($_,58,8);
		$rpkc_evt_grp_id=substr($_,67,8);
		$rpkc_auth_normal=substr($_,76,1);
		$rpkc_auth_special=substr($_,81,1);
		$rpkc_auth_oper=substr($_,86,1);
		$rpkc_auth_audit=substr($_,91,1);
		$rpkc_auth_exit=substr($_,96,1);
		$rpkc_auth_failsft=substr($_,101,1);
		$rpkc_auth_bypass=substr($_,106,1);
		$rpkc_auth_trusted=substr($_,111,1);
		$rpkc_log_class=substr($_,116,1);
		$rpkc_log_user=substr($_,121,1);
		$rpkc_log_special=substr($_,126,1);
		$rpkc_log_access=substr($_,131,1);
		$rpkc_log_racinit=substr($_,136,1);
		$rpkc_log_always=substr($_,141,1);
		$rpkc_log_cmdviol=substr($_,146,1);
		$rpkc_log_global=substr($_,151,1);
		$rpkc_term_level=substr($_,156,3);
		if ($rpkc_term_level  eq ' ' x length($rpkc_term_level )) {
			undef $rpkc_term_level ;
		}
		$rpkc_backout_fail=substr($_,160,1);
		$rpkc_prof_same=substr($_,165,1);
		$rpkc_term=substr($_,170,8);
		$rpkc_job_name=substr($_,179,8);
		$rpkc_read_time=substr($_,188,8);
		if ($rpkc_read_time  eq ' ' x length($rpkc_read_time )) {
			undef $rpkc_read_time ;
		}
		$rpkc_read_date=substr($_,197,10);
		if ($rpkc_read_date  eq ' ' x length($rpkc_read_date )) {
			undef $rpkc_read_date ;
		}
		$rpkc_smf_user_id=substr($_,208,8);
		$rpkc_log_level=substr($_,217,1);
		$rpkc_log_vmevent=substr($_,222,1);
		$rpkc_log_logopt=substr($_,227,1);
		$rpkc_log_secl=substr($_,232,1);
		$rpkc_log_compatm=substr($_,237,1);
		$rpkc_log_applaud=substr($_,242,1);
		$rpkc_log_nonomvs=substr($_,247,1);
		$rpkc_log_omvsnprv=substr($_,252,1);
		$rpkc_auth_omvssu=substr($_,257,1);
		$rpkc_auth_omvssys=substr($_,262,1);
		$rpkc_usr_secl=substr($_,267,8);
		$rpkc_racf_version=substr($_,276,4);
		$rpkc_logstring=substr($_,281,255);
		$rpkc_user_name=substr($_,537,20);
		$rpkc_utk_encr=substr($_,558,1);
		$rpkc_utk_pre19=substr($_,563,1);
		$rpkc_utk_verprof=substr($_,568,1);
		$rpkc_utk_njeunusr=substr($_,573,1);
		$rpkc_utk_logusr=substr($_,578,1);
		$rpkc_utk_special=substr($_,583,1);
		$rpkc_utk_default=substr($_,588,1);
		$rpkc_utk_unknusr=substr($_,593,1);
		$rpkc_utk_error=substr($_,598,1);
		$rpkc_utk_trusted=substr($_,603,1);
		$rpkc_utk_sesstype=substr($_,608,8);
		$rpkc_utk_surrogat=substr($_,617,1);
		$rpkc_utk_remote=substr($_,622,1);
		$rpkc_utk_priv=substr($_,627,1);
		$rpkc_utk_secl=substr($_,632,8);
		$rpkc_utk_execnode=substr($_,641,8);
		$rpkc_utk_suser_id=substr($_,650,8);
		$rpkc_utk_snode=substr($_,659,8);
		$rpkc_utk_sgrp_id=substr($_,668,8);
		$rpkc_utk_spoe=substr($_,677,8);
		$rpkc_utk_spclass=substr($_,686,8);
		$rpkc_utk_user_id=substr($_,695,8);
		$rpkc_utk_grp_id=substr($_,704,8);
		$rpkc_utk_dft_grp=substr($_,713,1);
		$rpkc_utk_dft_secl=substr($_,718,1);
		$rpkc_serial_number=substr($_,723,255);
		$rpkc_utk_netw=substr($_,979,8);
		$rpkc_x500_subject=substr($_,988,255);
		$rpkc_x500_issuer=substr($_,1244,255);
		$rpkc_action=substr($_,1500,16);
		$rpkc_action_com=substr($_,1517,64);
		$rpkc_revoke_rsn=substr($_,1582,32);
		$rv=$insert{rpkiupdc}->execute($rpkc_event_type,$rpkc_event_qual,$rpkc_time_written,$rpkc_date_written,$rpkc_system_smfid,$rpkc_violation,$rpkc_user_ndfnd,$rpkc_user_warning,$rpkc_evt_user_id,$rpkc_evt_grp_id,$rpkc_auth_normal,$rpkc_auth_special,$rpkc_auth_oper,$rpkc_auth_audit,$rpkc_auth_exit,$rpkc_auth_failsft,$rpkc_auth_bypass,$rpkc_auth_trusted,$rpkc_log_class,$rpkc_log_user,$rpkc_log_special,$rpkc_log_access,$rpkc_log_racinit,$rpkc_log_always,$rpkc_log_cmdviol,$rpkc_log_global,$rpkc_term_level,$rpkc_backout_fail,$rpkc_prof_same,$rpkc_term,$rpkc_job_name,$rpkc_read_time,$rpkc_read_date,$rpkc_smf_user_id,$rpkc_log_level,$rpkc_log_vmevent,$rpkc_log_logopt,$rpkc_log_secl,$rpkc_log_compatm,$rpkc_log_applaud,$rpkc_log_nonomvs,$rpkc_log_omvsnprv,$rpkc_auth_omvssu,$rpkc_auth_omvssys,$rpkc_usr_secl,$rpkc_racf_version,$rpkc_logstring,$rpkc_user_name,$rpkc_utk_encr,$rpkc_utk_pre19,$rpkc_utk_verprof,$rpkc_utk_njeunusr,$rpkc_utk_logusr,$rpkc_utk_special,$rpkc_utk_default,$rpkc_utk_unknusr,$rpkc_utk_error,$rpkc_utk_trusted,$rpkc_utk_sesstype,$rpkc_utk_surrogat,$rpkc_utk_remote,$rpkc_utk_priv,$rpkc_utk_secl,$rpkc_utk_execnode,$rpkc_utk_suser_id,$rpkc_utk_snode,$rpkc_utk_sgrp_id,$rpkc_utk_spoe,$rpkc_utk_spclass,$rpkc_utk_user_id,$rpkc_utk_grp_id,$rpkc_utk_dft_grp,$rpkc_utk_dft_secl,$rpkc_serial_number,$rpkc_utk_netw,$rpkc_x500_subject,$rpkc_x500_issuer,$rpkc_action,$rpkc_action_com,$rpkc_revoke_rsn);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rpkiupdc"}++;
		next;
	}

	if ($rectype eq 'RPKIUPDR') {
		$rpku_event_type=substr($_,0,8);
		$rpku_event_qual=substr($_,9,8);
		$rpku_time_written=substr($_,18,8);
		if ($rpku_time_written  eq ' ' x length($rpku_time_written )) {
			undef $rpku_time_written ;
		}
		$rpku_date_written=substr($_,27,10);
		if ($rpku_date_written  eq ' ' x length($rpku_date_written )) {
			undef $rpku_date_written ;
		}
		$rpku_system_smfid=substr($_,38,4);
		$rpku_violation=substr($_,43,1);
		$rpku_user_ndfnd=substr($_,48,1);
		$rpku_user_warning=substr($_,53,1);
		$rpku_evt_user_id=substr($_,58,8);
		$rpku_evt_grp_id=substr($_,67,8);
		$rpku_auth_normal=substr($_,76,1);
		$rpku_auth_special=substr($_,81,1);
		$rpku_auth_oper=substr($_,86,1);
		$rpku_auth_audit=substr($_,91,1);
		$rpku_auth_exit=substr($_,96,1);
		$rpku_auth_failsft=substr($_,101,1);
		$rpku_auth_bypass=substr($_,106,1);
		$rpku_auth_trusted=substr($_,111,1);
		$rpku_log_class=substr($_,116,1);
		$rpku_log_user=substr($_,121,1);
		$rpku_log_special=substr($_,126,1);
		$rpku_log_access=substr($_,131,1);
		$rpku_log_racinit=substr($_,136,1);
		$rpku_log_always=substr($_,141,1);
		$rpku_log_cmdviol=substr($_,146,1);
		$rpku_log_global=substr($_,151,1);
		$rpku_term_level=substr($_,156,3);
		if ($rpku_term_level  eq ' ' x length($rpku_term_level )) {
			undef $rpku_term_level ;
		}
		$rpku_backout_fail=substr($_,160,1);
		$rpku_prof_same=substr($_,165,1);
		$rpku_term=substr($_,170,8);
		$rpku_job_name=substr($_,179,8);
		$rpku_read_time=substr($_,188,8);
		if ($rpku_read_time  eq ' ' x length($rpku_read_time )) {
			undef $rpku_read_time ;
		}
		$rpku_read_date=substr($_,197,10);
		if ($rpku_read_date  eq ' ' x length($rpku_read_date )) {
			undef $rpku_read_date ;
		}
		$rpku_smf_user_id=substr($_,208,8);
		$rpku_log_level=substr($_,217,1);
		$rpku_log_vmevent=substr($_,222,1);
		$rpku_log_logopt=substr($_,227,1);
		$rpku_log_secl=substr($_,232,1);
		$rpku_log_compatm=substr($_,237,1);
		$rpku_log_applaud=substr($_,242,1);
		$rpku_log_nonomvs=substr($_,247,1);
		$rpku_log_omvsnprv=substr($_,252,1);
		$rpku_auth_omvssu=substr($_,257,1);
		$rpku_auth_omvssys=substr($_,262,1);
		$rpku_usr_secl=substr($_,267,8);
		$rpku_racf_version=substr($_,276,4);
		$rpku_logstring=substr($_,281,255);
		$rpku_user_name=substr($_,537,20);
		$rpku_utk_encr=substr($_,558,1);
		$rpku_utk_pre19=substr($_,563,1);
		$rpku_utk_verprof=substr($_,568,1);
		$rpku_utk_njeunusr=substr($_,573,1);
		$rpku_utk_logusr=substr($_,578,1);
		$rpku_utk_special=substr($_,583,1);
		$rpku_utk_default=substr($_,588,1);
		$rpku_utk_unknusr=substr($_,593,1);
		$rpku_utk_error=substr($_,598,1);
		$rpku_utk_trusted=substr($_,603,1);
		$rpku_utk_sesstype=substr($_,608,8);
		$rpku_utk_surrogat=substr($_,617,1);
		$rpku_utk_remote=substr($_,622,1);
		$rpku_utk_priv=substr($_,627,1);
		$rpku_utk_secl=substr($_,632,8);
		$rpku_utk_execnode=substr($_,641,8);
		$rpku_utk_suser_id=substr($_,650,8);
		$rpku_utk_snode=substr($_,659,8);
		$rpku_utk_sgrp_id=substr($_,668,8);
		$rpku_utk_spoe=substr($_,677,8);
		$rpku_utk_spclass=substr($_,686,8);
		$rpku_utk_user_id=substr($_,695,8);
		$rpku_utk_grp_id=substr($_,704,8);
		$rpku_utk_dft_grp=substr($_,713,1);
		$rpku_utk_dft_secl=substr($_,718,1);
		$rpku_utk_netw=substr($_,723,8);
		$rpku_x500_subject=substr($_,732,255);
		$rpku_x500_issuer=substr($_,988,255);
		$rpku_keyusage=substr($_,1244,64);
		$rpku_notbefor_date=substr($_,1309,10);
		$rpku_notafter_date=substr($_,1320,10);
		$rpku_subjects_dn=substr($_,1331,255);
		$rpku_alt_ip=substr($_,1587,64);
		$rpku_alt_uri=substr($_,1652,255);
		$rpku_alt_email=substr($_,1908,100);
		$rpku_alt_domain=substr($_,2009,100);
		$rpku_cert_id=substr($_,2110,56);
		$rpku_hostid_map=substr($_,2167,1024);
		$rpku_action=substr($_,3192,16);
		$rpku_action_com=substr($_,3209,64);
		$rv=$insert{rpkiupdr}->execute($rpku_event_type,$rpku_event_qual,$rpku_time_written,$rpku_date_written,$rpku_system_smfid,$rpku_violation,$rpku_user_ndfnd,$rpku_user_warning,$rpku_evt_user_id,$rpku_evt_grp_id,$rpku_auth_normal,$rpku_auth_special,$rpku_auth_oper,$rpku_auth_audit,$rpku_auth_exit,$rpku_auth_failsft,$rpku_auth_bypass,$rpku_auth_trusted,$rpku_log_class,$rpku_log_user,$rpku_log_special,$rpku_log_access,$rpku_log_racinit,$rpku_log_always,$rpku_log_cmdviol,$rpku_log_global,$rpku_term_level,$rpku_backout_fail,$rpku_prof_same,$rpku_term,$rpku_job_name,$rpku_read_time,$rpku_read_date,$rpku_smf_user_id,$rpku_log_level,$rpku_log_vmevent,$rpku_log_logopt,$rpku_log_secl,$rpku_log_compatm,$rpku_log_applaud,$rpku_log_nonomvs,$rpku_log_omvsnprv,$rpku_auth_omvssu,$rpku_auth_omvssys,$rpku_usr_secl,$rpku_racf_version,$rpku_logstring,$rpku_user_name,$rpku_utk_encr,$rpku_utk_pre19,$rpku_utk_verprof,$rpku_utk_njeunusr,$rpku_utk_logusr,$rpku_utk_special,$rpku_utk_default,$rpku_utk_unknusr,$rpku_utk_error,$rpku_utk_trusted,$rpku_utk_sesstype,$rpku_utk_surrogat,$rpku_utk_remote,$rpku_utk_priv,$rpku_utk_secl,$rpku_utk_execnode,$rpku_utk_suser_id,$rpku_utk_snode,$rpku_utk_sgrp_id,$rpku_utk_spoe,$rpku_utk_spclass,$rpku_utk_user_id,$rpku_utk_grp_id,$rpku_utk_dft_grp,$rpku_utk_dft_secl,$rpku_utk_netw,$rpku_x500_subject,$rpku_x500_issuer,$rpku_keyusage,$rpku_notbefor_date,$rpku_notafter_date,$rpku_subjects_dn,$rpku_alt_ip,$rpku_alt_uri,$rpku_alt_email,$rpku_alt_domain,$rpku_cert_id,$rpku_hostid_map,$rpku_action,$rpku_action_com);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rpkiupdr"}++;
		next;
	}

	if ($rectype eq 'RVARY   ') {
		$rvar_event_type=substr($_,0,8);
		$rvar_event_qual=substr($_,9,8);
		$rvar_time_written=substr($_,18,8);
		if ($rvar_time_written  eq ' ' x length($rvar_time_written )) {
			undef $rvar_time_written ;
		}
		$rvar_date_written=substr($_,27,10);
		if ($rvar_date_written  eq ' ' x length($rvar_date_written )) {
			undef $rvar_date_written ;
		}
		$rvar_system_smfid=substr($_,38,4);
		$rvar_violation=substr($_,43,1);
		$rvar_user_ndfnd=substr($_,48,1);
		$rvar_user_warning=substr($_,53,1);
		$rvar_evt_user_id=substr($_,58,8);
		$rvar_evt_grp_id=substr($_,67,8);
		$rvar_auth_normal=substr($_,76,1);
		$rvar_auth_special=substr($_,81,1);
		$rvar_auth_oper=substr($_,86,1);
		$rvar_auth_audit=substr($_,91,1);
		$rvar_auth_exit=substr($_,96,1);
		$rvar_auth_failsft=substr($_,101,1);
		$rvar_auth_bypass=substr($_,106,1);
		$rvar_auth_trusted=substr($_,111,1);
		$rvar_log_class=substr($_,116,1);
		$rvar_log_user=substr($_,121,1);
		$rvar_log_special=substr($_,126,1);
		$rvar_log_access=substr($_,131,1);
		$rvar_log_racinit=substr($_,136,1);
		$rvar_log_always=substr($_,141,1);
		$rvar_log_cmdviol=substr($_,146,1);
		$rvar_log_global=substr($_,151,1);
		$rvar_term_level=substr($_,156,3);
		if ($rvar_term_level  eq ' ' x length($rvar_term_level )) {
			undef $rvar_term_level ;
		}
		$rvar_backout_fail=substr($_,160,1);
		$rvar_prof_same=substr($_,165,1);
		$rvar_term=substr($_,170,8);
		$rvar_job_name=substr($_,179,8);
		$rvar_read_time=substr($_,188,8);
		if ($rvar_read_time  eq ' ' x length($rvar_read_time )) {
			undef $rvar_read_time ;
		}
		$rvar_read_date=substr($_,197,10);
		if ($rvar_read_date  eq ' ' x length($rvar_read_date )) {
			undef $rvar_read_date ;
		}
		$rvar_smf_user_id=substr($_,208,8);
		$rvar_log_level=substr($_,217,1);
		$rvar_log_vmevent=substr($_,222,1);
		$rvar_log_logopt=substr($_,227,1);
		$rvar_log_secl=substr($_,232,1);
		$rvar_log_compatm=substr($_,237,1);
		$rvar_log_applaud=substr($_,242,1);
		$rvar_log_nonomvs=substr($_,247,1);
		$rvar_log_omvsnprv=substr($_,252,1);
		$rvar_auth_omvssu=substr($_,257,1);
		$rvar_auth_omvssys=substr($_,262,1);
		$rvar_usr_secl=substr($_,267,8);
		$rvar_racf_version=substr($_,276,4);
		$rvar_user_name=substr($_,281,20);
		$rvar_utk_encr=substr($_,302,1);
		$rvar_utk_pre19=substr($_,307,1);
		$rvar_utk_verprof=substr($_,312,1);
		$rvar_utk_njeunusr=substr($_,317,1);
		$rvar_utk_logusr=substr($_,322,1);
		$rvar_utk_special=substr($_,327,1);
		$rvar_utk_default=substr($_,332,1);
		$rvar_utk_unknusr=substr($_,337,1);
		$rvar_utk_error=substr($_,342,1);
		$rvar_utk_trusted=substr($_,347,1);
		$rvar_utk_sesstype=substr($_,352,8);
		$rvar_utk_surrogat=substr($_,361,1);
		$rvar_utk_remove=substr($_,366,1);
		$rvar_utk_priv=substr($_,371,1);
		$rvar_utk_secl=substr($_,376,8);
		$rvar_utk_execnode=substr($_,385,8);
		$rvar_utk_suser_id=substr($_,394,8);
		$rvar_utk_snode=substr($_,403,8);
		$rvar_utk_sgrp_id=substr($_,412,8);
		$rvar_utk_spoe=substr($_,421,8);
		$rvar_utk_spclass=substr($_,430,8);
		$rvar_utk_user_id=substr($_,439,8);
		$rvar_utk_grp_id=substr($_,448,8);
		$rvar_utk_dft_grp=substr($_,457,1);
		$rvar_utk_dft_secl=substr($_,462,1);
		$rvar_appc_link=substr($_,467,16);
		$rvar_specified=substr($_,484,1024);
		$rvar_failed=substr($_,1509,1024);
		$rvar_utk_netw=substr($_,2534,8);
		$rvar_x500_subject=substr($_,2543,255);
		$rvar_x500_issuer=substr($_,2799,255);
		$rv=$insert{rvary}->execute($rvar_event_type,$rvar_event_qual,$rvar_time_written,$rvar_date_written,$rvar_system_smfid,$rvar_violation,$rvar_user_ndfnd,$rvar_user_warning,$rvar_evt_user_id,$rvar_evt_grp_id,$rvar_auth_normal,$rvar_auth_special,$rvar_auth_oper,$rvar_auth_audit,$rvar_auth_exit,$rvar_auth_failsft,$rvar_auth_bypass,$rvar_auth_trusted,$rvar_log_class,$rvar_log_user,$rvar_log_special,$rvar_log_access,$rvar_log_racinit,$rvar_log_always,$rvar_log_cmdviol,$rvar_log_global,$rvar_term_level,$rvar_backout_fail,$rvar_prof_same,$rvar_term,$rvar_job_name,$rvar_read_time,$rvar_read_date,$rvar_smf_user_id,$rvar_log_level,$rvar_log_vmevent,$rvar_log_logopt,$rvar_log_secl,$rvar_log_compatm,$rvar_log_applaud,$rvar_log_nonomvs,$rvar_log_omvsnprv,$rvar_auth_omvssu,$rvar_auth_omvssys,$rvar_usr_secl,$rvar_racf_version,$rvar_user_name,$rvar_utk_encr,$rvar_utk_pre19,$rvar_utk_verprof,$rvar_utk_njeunusr,$rvar_utk_logusr,$rvar_utk_special,$rvar_utk_default,$rvar_utk_unknusr,$rvar_utk_error,$rvar_utk_trusted,$rvar_utk_sesstype,$rvar_utk_surrogat,$rvar_utk_remove,$rvar_utk_priv,$rvar_utk_secl,$rvar_utk_execnode,$rvar_utk_suser_id,$rvar_utk_snode,$rvar_utk_sgrp_id,$rvar_utk_spoe,$rvar_utk_spclass,$rvar_utk_user_id,$rvar_utk_grp_id,$rvar_utk_dft_grp,$rvar_utk_dft_secl,$rvar_appc_link,$rvar_specified,$rvar_failed,$rvar_utk_netw,$rvar_x500_subject,$rvar_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"rvary"}++;
		next;
	}

	if ($rectype eq 'SETEGID ') {
		$segi_event_type=substr($_,0,8);
		$segi_event_qual=substr($_,9,8);
		$segi_time_written=substr($_,18,8);
		if ($segi_time_written  eq ' ' x length($segi_time_written )) {
			undef $segi_time_written ;
		}
		$segi_date_written=substr($_,27,10);
		if ($segi_date_written  eq ' ' x length($segi_date_written )) {
			undef $segi_date_written ;
		}
		$segi_system_smfid=substr($_,38,4);
		$segi_violation=substr($_,43,1);
		$segi_user_ndfnd=substr($_,48,1);
		$segi_user_warning=substr($_,53,1);
		$segi_evt_user_id=substr($_,58,8);
		$segi_evt_grp_id=substr($_,67,8);
		$segi_auth_normal=substr($_,76,1);
		$segi_auth_special=substr($_,81,1);
		$segi_auth_oper=substr($_,86,1);
		$segi_auth_audit=substr($_,91,1);
		$segi_auth_exit=substr($_,96,1);
		$segi_auth_failsft=substr($_,101,1);
		$segi_auth_bypass=substr($_,106,1);
		$segi_auth_trusted=substr($_,111,1);
		$segi_log_class=substr($_,116,1);
		$segi_log_user=substr($_,121,1);
		$segi_log_special=substr($_,126,1);
		$segi_log_access=substr($_,131,1);
		$segi_log_racinit=substr($_,136,1);
		$segi_log_always=substr($_,141,1);
		$segi_log_cmdviol=substr($_,146,1);
		$segi_log_global=substr($_,151,1);
		$segi_term_level=substr($_,156,3);
		if ($segi_term_level  eq ' ' x length($segi_term_level )) {
			undef $segi_term_level ;
		}
		$segi_backout_fail=substr($_,160,1);
		$segi_prof_same=substr($_,165,1);
		$segi_term=substr($_,170,8);
		$segi_job_name=substr($_,179,8);
		$segi_read_time=substr($_,188,8);
		if ($segi_read_time  eq ' ' x length($segi_read_time )) {
			undef $segi_read_time ;
		}
		$segi_read_date=substr($_,197,10);
		if ($segi_read_date  eq ' ' x length($segi_read_date )) {
			undef $segi_read_date ;
		}
		$segi_smf_user_id=substr($_,208,8);
		$segi_log_level=substr($_,217,1);
		$segi_log_vmevent=substr($_,222,1);
		$segi_log_logopt=substr($_,227,1);
		$segi_log_secl=substr($_,232,1);
		$segi_log_compatm=substr($_,237,1);
		$segi_log_applaud=substr($_,242,1);
		$segi_log_nonomvs=substr($_,247,1);
		$segi_log_omvsnprv=substr($_,252,1);
		$segi_auth_omvssu=substr($_,257,1);
		$segi_auth_omvssys=substr($_,262,1);
		$segi_usr_secl=substr($_,267,8);
		$segi_racf_version=substr($_,276,4);
		$segi_class=substr($_,281,8);
		$segi_user_name=substr($_,290,20);
		$segi_utk_encr=substr($_,311,1);
		$segi_utk_pre19=substr($_,316,1);
		$segi_utk_verprof=substr($_,321,1);
		$segi_utk_njeunusr=substr($_,326,1);
		$segi_utk_logusr=substr($_,331,1);
		$segi_utk_special=substr($_,336,1);
		$segi_utk_default=substr($_,341,1);
		$segi_utk_unknusr=substr($_,346,1);
		$segi_utk_error=substr($_,351,1);
		$segi_utk_trusted=substr($_,356,1);
		$segi_utk_sesstype=substr($_,361,8);
		$segi_utk_surrogat=substr($_,370,1);
		$segi_utk_remote=substr($_,375,1);
		$segi_utk_priv=substr($_,380,1);
		$segi_utk_secl=substr($_,385,8);
		$segi_utk_execnode=substr($_,394,8);
		$segi_utk_suser_id=substr($_,403,8);
		$segi_utk_snode=substr($_,412,8);
		$segi_utk_sgrp_id=substr($_,421,8);
		$segi_utk_spoe=substr($_,430,8);
		$segi_utk_spclass=substr($_,439,8);
		$segi_utk_user_id=substr($_,448,8);
		$segi_utk_grp_id=substr($_,457,8);
		$segi_utk_dft_grp=substr($_,466,1);
		$segi_utk_dft_secl=substr($_,471,1);
		$segi_appc_link=substr($_,476,16);
		$segi_audit_code=substr($_,493,11);
		$segi_old_real_uid=substr($_,505,10);
		if ($segi_old_real_uid  eq ' ' x length($segi_old_real_uid )) {
			undef $segi_old_real_uid ;
		}
		$segi_old_eff_uid=substr($_,516,10);
		if ($segi_old_eff_uid  eq ' ' x length($segi_old_eff_uid )) {
			undef $segi_old_eff_uid ;
		}
		$segi_old_saved_uid=substr($_,527,10);
		if ($segi_old_saved_uid eq ' ' x length($segi_old_saved_uid)) {
			undef $segi_old_saved_uid;
		}
		$segi_old_real_gid=substr($_,538,10);
		if ($segi_old_real_gid  eq ' ' x length($segi_old_real_gid )) {
			undef $segi_old_real_gid ;
		}
		$segi_old_eff_gid=substr($_,549,10);
		if ($segi_old_eff_gid  eq ' ' x length($segi_old_eff_gid )) {
			undef $segi_old_eff_gid ;
		}
		$segi_old_saved_gid=substr($_,560,10);
		if ($segi_old_saved_gid eq ' ' x length($segi_old_saved_gid)) {
			undef $segi_old_saved_gid;
		}
		$segi_new_real_gid=substr($_,571,10);
		if ($segi_new_real_gid  eq ' ' x length($segi_new_real_gid )) {
			undef $segi_new_real_gid ;
		}
		$segi_new_eff_gid=substr($_,582,10);
		if ($segi_new_eff_gid  eq ' ' x length($segi_new_eff_gid )) {
			undef $segi_new_eff_gid ;
		}
		$segi_new_saved_gid=substr($_,593,10);
		if ($segi_new_saved_gid eq ' ' x length($segi_new_saved_gid)) {
			undef $segi_new_saved_gid;
		}
		$segi_gid=substr($_,604,10);
		if ($segi_gid  eq ' ' x length($segi_gid )) {
			undef $segi_gid ;
		}
		$segi_dflt_process=substr($_,615,1);
		$segi_utk_netw=substr($_,620,8);
		$segi_x500_subject=substr($_,629,255);
		$segi_x500_issuer=substr($_,885,255);
		$rv=$insert{setegid}->execute($segi_event_type,$segi_event_qual,$segi_time_written,$segi_date_written,$segi_system_smfid,$segi_violation,$segi_user_ndfnd,$segi_user_warning,$segi_evt_user_id,$segi_evt_grp_id,$segi_auth_normal,$segi_auth_special,$segi_auth_oper,$segi_auth_audit,$segi_auth_exit,$segi_auth_failsft,$segi_auth_bypass,$segi_auth_trusted,$segi_log_class,$segi_log_user,$segi_log_special,$segi_log_access,$segi_log_racinit,$segi_log_always,$segi_log_cmdviol,$segi_log_global,$segi_term_level,$segi_backout_fail,$segi_prof_same,$segi_term,$segi_job_name,$segi_read_time,$segi_read_date,$segi_smf_user_id,$segi_log_level,$segi_log_vmevent,$segi_log_logopt,$segi_log_secl,$segi_log_compatm,$segi_log_applaud,$segi_log_nonomvs,$segi_log_omvsnprv,$segi_auth_omvssu,$segi_auth_omvssys,$segi_usr_secl,$segi_racf_version,$segi_class,$segi_user_name,$segi_utk_encr,$segi_utk_pre19,$segi_utk_verprof,$segi_utk_njeunusr,$segi_utk_logusr,$segi_utk_special,$segi_utk_default,$segi_utk_unknusr,$segi_utk_error,$segi_utk_trusted,$segi_utk_sesstype,$segi_utk_surrogat,$segi_utk_remote,$segi_utk_priv,$segi_utk_secl,$segi_utk_execnode,$segi_utk_suser_id,$segi_utk_snode,$segi_utk_sgrp_id,$segi_utk_spoe,$segi_utk_spclass,$segi_utk_user_id,$segi_utk_grp_id,$segi_utk_dft_grp,$segi_utk_dft_secl,$segi_appc_link,$segi_audit_code,$segi_old_real_uid,$segi_old_eff_uid,$segi_old_saved_uid,$segi_old_real_gid,$segi_old_eff_gid,$segi_old_saved_gid,$segi_new_real_gid,$segi_new_eff_gid,$segi_new_saved_gid,$segi_gid,$segi_dflt_process,$segi_utk_netw,$segi_x500_subject,$segi_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setegid"}++;
		next;
	}

	if ($rectype eq 'SETEUID ') {
		$seui_event_type=substr($_,0,8);
		$seui_event_qual=substr($_,9,8);
		$seui_time_written=substr($_,18,8);
		if ($seui_time_written  eq ' ' x length($seui_time_written )) {
			undef $seui_time_written ;
		}
		$seui_date_written=substr($_,27,10);
		if ($seui_date_written  eq ' ' x length($seui_date_written )) {
			undef $seui_date_written ;
		}
		$seui_system_smfid=substr($_,38,4);
		$seui_violation=substr($_,43,1);
		$seui_user_ndfnd=substr($_,48,1);
		$seui_user_warning=substr($_,53,1);
		$seui_evt_user_id=substr($_,58,8);
		$seui_evt_grp_id=substr($_,67,8);
		$seui_auth_normal=substr($_,76,1);
		$seui_auth_special=substr($_,81,1);
		$seui_auth_oper=substr($_,86,1);
		$seui_auth_audit=substr($_,91,1);
		$seui_auth_exit=substr($_,96,1);
		$seui_auth_failsft=substr($_,101,1);
		$seui_auth_bypass=substr($_,106,1);
		$seui_auth_trusted=substr($_,111,1);
		$seui_log_class=substr($_,116,1);
		$seui_log_user=substr($_,121,1);
		$seui_log_special=substr($_,126,1);
		$seui_log_access=substr($_,131,1);
		$seui_log_racinit=substr($_,136,1);
		$seui_log_always=substr($_,141,1);
		$seui_log_cmdviol=substr($_,146,1);
		$seui_log_global=substr($_,151,1);
		$seui_term_level=substr($_,156,3);
		if ($seui_term_level  eq ' ' x length($seui_term_level )) {
			undef $seui_term_level ;
		}
		$seui_backout_fail=substr($_,160,1);
		$seui_prof_same=substr($_,165,1);
		$seui_term=substr($_,170,8);
		$seui_job_name=substr($_,179,8);
		$seui_read_time=substr($_,188,8);
		if ($seui_read_time  eq ' ' x length($seui_read_time )) {
			undef $seui_read_time ;
		}
		$seui_read_date=substr($_,197,10);
		if ($seui_read_date  eq ' ' x length($seui_read_date )) {
			undef $seui_read_date ;
		}
		$seui_smf_user_id=substr($_,208,8);
		$seui_log_level=substr($_,217,1);
		$seui_log_vmevent=substr($_,222,1);
		$seui_log_logopt=substr($_,227,1);
		$seui_log_secl=substr($_,232,1);
		$seui_log_compatm=substr($_,237,1);
		$seui_log_applaud=substr($_,242,1);
		$seui_log_nonomvs=substr($_,247,1);
		$seui_log_omvsnprv=substr($_,252,1);
		$seui_auth_omvssu=substr($_,257,1);
		$seui_auth_omvssys=substr($_,262,1);
		$seui_usr_secl=substr($_,267,8);
		$seui_racf_version=substr($_,276,4);
		$seui_class=substr($_,281,8);
		$seui_user_name=substr($_,290,20);
		$seui_utk_encr=substr($_,311,1);
		$seui_utk_pre19=substr($_,316,1);
		$seui_utk_verprof=substr($_,321,1);
		$seui_utk_njeunusr=substr($_,326,1);
		$seui_utk_logusr=substr($_,331,1);
		$seui_utk_special=substr($_,336,1);
		$seui_utk_default=substr($_,341,1);
		$seui_utk_unknusr=substr($_,346,1);
		$seui_utk_error=substr($_,351,1);
		$seui_utk_trusted=substr($_,356,1);
		$seui_utk_sesstype=substr($_,361,8);
		$seui_utk_surrogat=substr($_,370,1);
		$seui_utk_remote=substr($_,375,1);
		$seui_utk_priv=substr($_,380,1);
		$seui_utk_secl=substr($_,385,8);
		$seui_utk_execnode=substr($_,394,8);
		$seui_utk_suser_id=substr($_,403,8);
		$seui_utk_snode=substr($_,412,8);
		$seui_utk_sgrp_id=substr($_,421,8);
		$seui_utk_spoe=substr($_,430,8);
		$seui_utk_spclass=substr($_,439,8);
		$seui_utk_user_id=substr($_,448,8);
		$seui_utk_grp_id=substr($_,457,8);
		$seui_utk_dft_grp=substr($_,466,1);
		$seui_utk_dft_secl=substr($_,471,1);
		$seui_appc_link=substr($_,476,16);
		$seui_audit_code=substr($_,493,11);
		$seui_old_real_uid=substr($_,505,10);
		if ($seui_old_real_uid  eq ' ' x length($seui_old_real_uid )) {
			undef $seui_old_real_uid ;
		}
		$seui_old_eff_uid=substr($_,516,10);
		if ($seui_old_eff_uid  eq ' ' x length($seui_old_eff_uid )) {
			undef $seui_old_eff_uid ;
		}
		$seui_old_saved_uid=substr($_,527,10);
		if ($seui_old_saved_uid eq ' ' x length($seui_old_saved_uid)) {
			undef $seui_old_saved_uid;
		}
		$seui_old_real_gid=substr($_,538,10);
		if ($seui_old_real_gid  eq ' ' x length($seui_old_real_gid )) {
			undef $seui_old_real_gid ;
		}
		$seui_old_eff_gid=substr($_,549,10);
		if ($seui_old_eff_gid  eq ' ' x length($seui_old_eff_gid )) {
			undef $seui_old_eff_gid ;
		}
		$seui_old_saved_gid=substr($_,560,10);
		if ($seui_old_saved_gid eq ' ' x length($seui_old_saved_gid)) {
			undef $seui_old_saved_gid;
		}
		$seui_new_real_uid=substr($_,571,10);
		if ($seui_new_real_uid  eq ' ' x length($seui_new_real_uid )) {
			undef $seui_new_real_uid ;
		}
		$seui_new_eff_uid=substr($_,582,10);
		if ($seui_new_eff_uid  eq ' ' x length($seui_new_eff_uid )) {
			undef $seui_new_eff_uid ;
		}
		$seui_new_saved_uid=substr($_,593,10);
		if ($seui_new_saved_uid eq ' ' x length($seui_new_saved_uid)) {
			undef $seui_new_saved_uid;
		}
		$seui_uid=substr($_,604,10);
		if ($seui_uid  eq ' ' x length($seui_uid )) {
			undef $seui_uid ;
		}
		$seui_dflt_process=substr($_,615,1);
		$seui_utk_netw=substr($_,620,8);
		$seui_x500_subject=substr($_,629,255);
		$seui_x500_issuer=substr($_,885,255);
		$rv=$insert{seteuid}->execute($seui_event_type,$seui_event_qual,$seui_time_written,$seui_date_written,$seui_system_smfid,$seui_violation,$seui_user_ndfnd,$seui_user_warning,$seui_evt_user_id,$seui_evt_grp_id,$seui_auth_normal,$seui_auth_special,$seui_auth_oper,$seui_auth_audit,$seui_auth_exit,$seui_auth_failsft,$seui_auth_bypass,$seui_auth_trusted,$seui_log_class,$seui_log_user,$seui_log_special,$seui_log_access,$seui_log_racinit,$seui_log_always,$seui_log_cmdviol,$seui_log_global,$seui_term_level,$seui_backout_fail,$seui_prof_same,$seui_term,$seui_job_name,$seui_read_time,$seui_read_date,$seui_smf_user_id,$seui_log_level,$seui_log_vmevent,$seui_log_logopt,$seui_log_secl,$seui_log_compatm,$seui_log_applaud,$seui_log_nonomvs,$seui_log_omvsnprv,$seui_auth_omvssu,$seui_auth_omvssys,$seui_usr_secl,$seui_racf_version,$seui_class,$seui_user_name,$seui_utk_encr,$seui_utk_pre19,$seui_utk_verprof,$seui_utk_njeunusr,$seui_utk_logusr,$seui_utk_special,$seui_utk_default,$seui_utk_unknusr,$seui_utk_error,$seui_utk_trusted,$seui_utk_sesstype,$seui_utk_surrogat,$seui_utk_remote,$seui_utk_priv,$seui_utk_secl,$seui_utk_execnode,$seui_utk_suser_id,$seui_utk_snode,$seui_utk_sgrp_id,$seui_utk_spoe,$seui_utk_spclass,$seui_utk_user_id,$seui_utk_grp_id,$seui_utk_dft_grp,$seui_utk_dft_secl,$seui_appc_link,$seui_audit_code,$seui_old_real_uid,$seui_old_eff_uid,$seui_old_saved_uid,$seui_old_real_gid,$seui_old_eff_gid,$seui_old_saved_gid,$seui_new_real_uid,$seui_new_eff_uid,$seui_new_saved_uid,$seui_uid,$seui_dflt_process,$seui_utk_netw,$seui_x500_subject,$seui_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"seteuid"}++;
		next;
	}

	if ($rectype eq 'SETFACL ') {
		$sacl_event_type=substr($_,0,8);
		$sacl_event_qual=substr($_,9,8);
		$sacl_time_written=substr($_,18,8);
		if ($sacl_time_written  eq ' ' x length($sacl_time_written )) {
			undef $sacl_time_written ;
		}
		$sacl_date_written=substr($_,27,10);
		if ($sacl_date_written  eq ' ' x length($sacl_date_written )) {
			undef $sacl_date_written ;
		}
		$sacl_system_smfid=substr($_,38,4);
		$sacl_violation=substr($_,43,1);
		$sacl_user_ndfnd=substr($_,48,1);
		$sacl_user_warning=substr($_,53,1);
		$sacl_evt_user_id=substr($_,58,8);
		$sacl_evt_grp_id=substr($_,67,8);
		$sacl_auth_normal=substr($_,76,1);
		$sacl_auth_special=substr($_,81,1);
		$sacl_auth_oper=substr($_,86,1);
		$sacl_auth_audit=substr($_,91,1);
		$sacl_auth_exit=substr($_,96,1);
		$sacl_auth_failsft=substr($_,101,1);
		$sacl_auth_bypass=substr($_,106,1);
		$sacl_auth_trusted=substr($_,111,1);
		$sacl_log_class=substr($_,116,1);
		$sacl_log_user=substr($_,121,1);
		$sacl_log_special=substr($_,126,1);
		$sacl_log_access=substr($_,131,1);
		$sacl_log_racinit=substr($_,136,1);
		$sacl_log_always=substr($_,141,1);
		$sacl_log_cmdviol=substr($_,146,1);
		$sacl_log_global=substr($_,151,1);
		$sacl_term_level=substr($_,156,3);
		if ($sacl_term_level  eq ' ' x length($sacl_term_level )) {
			undef $sacl_term_level ;
		}
		$sacl_backout_fail=substr($_,160,1);
		$sacl_prof_same=substr($_,165,1);
		$sacl_term=substr($_,170,8);
		$sacl_job_name=substr($_,179,8);
		$sacl_read_time=substr($_,188,8);
		if ($sacl_read_time  eq ' ' x length($sacl_read_time )) {
			undef $sacl_read_time ;
		}
		$sacl_read_date=substr($_,197,10);
		if ($sacl_read_date  eq ' ' x length($sacl_read_date )) {
			undef $sacl_read_date ;
		}
		$sacl_smf_user_id=substr($_,208,8);
		$sacl_log_level=substr($_,217,1);
		$sacl_log_vmevent=substr($_,222,1);
		$sacl_log_logopt=substr($_,227,1);
		$sacl_log_secl=substr($_,232,1);
		$sacl_log_compatm=substr($_,237,1);
		$sacl_log_applaud=substr($_,242,1);
		$sacl_log_nonomvs=substr($_,247,1);
		$sacl_log_omvsnprv=substr($_,252,1);
		$sacl_auth_omvssu=substr($_,257,1);
		$sacl_auth_omvssys=substr($_,262,1);
		$sacl_usr_secl=substr($_,267,8);
		$sacl_racf_version=substr($_,276,4);
		$sacl_class=substr($_,281,8);
		$sacl_user_name=substr($_,290,20);
		$sacl_utk_encr=substr($_,311,1);
		$sacl_utk_pre19=substr($_,316,1);
		$sacl_utk_verprof=substr($_,321,1);
		$sacl_utk_njeunusr=substr($_,326,1);
		$sacl_utk_logusr=substr($_,331,1);
		$sacl_utk_special=substr($_,336,1);
		$sacl_utk_default=substr($_,341,1);
		$sacl_utk_unknusr=substr($_,346,1);
		$sacl_utk_error=substr($_,351,1);
		$sacl_utk_trusted=substr($_,356,1);
		$sacl_utk_sesstype=substr($_,361,8);
		$sacl_utk_surrogat=substr($_,370,1);
		$sacl_utk_remote=substr($_,375,1);
		$sacl_utk_priv=substr($_,380,1);
		$sacl_utk_secl=substr($_,385,8);
		$sacl_utk_execnode=substr($_,394,8);
		$sacl_utk_suser_id=substr($_,403,8);
		$sacl_utk_snode=substr($_,412,8);
		$sacl_utk_sgrp_id=substr($_,421,8);
		$sacl_utk_spoe=substr($_,430,8);
		$sacl_utk_spclass=substr($_,439,8);
		$sacl_utk_user_id=substr($_,448,8);
		$sacl_utk_grp_id=substr($_,457,8);
		$sacl_utk_dft_grp=substr($_,466,1);
		$sacl_utk_dft_secl=substr($_,471,1);
		$sacl_appc_link=substr($_,476,16);
		$sacl_audit_code=substr($_,493,11);
		$sacl_old_real_uid=substr($_,505,10);
		if ($sacl_old_real_uid  eq ' ' x length($sacl_old_real_uid )) {
			undef $sacl_old_real_uid ;
		}
		$sacl_old_eff_uid=substr($_,516,10);
		if ($sacl_old_eff_uid  eq ' ' x length($sacl_old_eff_uid )) {
			undef $sacl_old_eff_uid ;
		}
		$sacl_old_saved_uid=substr($_,527,10);
		if ($sacl_old_saved_uid eq ' ' x length($sacl_old_saved_uid)) {
			undef $sacl_old_saved_uid;
		}
		$sacl_old_real_gid=substr($_,538,10);
		if ($sacl_old_real_gid  eq ' ' x length($sacl_old_real_gid )) {
			undef $sacl_old_real_gid ;
		}
		$sacl_old_eff_gid=substr($_,549,10);
		if ($sacl_old_eff_gid  eq ' ' x length($sacl_old_eff_gid )) {
			undef $sacl_old_eff_gid ;
		}
		$sacl_old_saved_gid=substr($_,560,10);
		if ($sacl_old_saved_gid eq ' ' x length($sacl_old_saved_gid)) {
			undef $sacl_old_saved_gid;
		}
		$sacl_path_name=substr($_,571,1023);
		$sacl_file_id=substr($_,1595,32);
		$sacl_file_own_uid=substr($_,1628,10);
		if ($sacl_file_own_uid  eq ' ' x length($sacl_file_own_uid )) {
			undef $sacl_file_own_uid ;
		}
		$sacl_file_own_gid=substr($_,1639,10);
		if ($sacl_file_own_gid  eq ' ' x length($sacl_file_own_gid )) {
			undef $sacl_file_own_gid ;
		}
		$sacl_filepool=substr($_,1650,8);
		$sacl_filespace=substr($_,1659,8);
		$sacl_inode=substr($_,1668,10);
		if ($sacl_inode  eq ' ' x length($sacl_inode )) {
			undef $sacl_inode ;
		}
		$sacl_scid=substr($_,1679,10);
		if ($sacl_scid  eq ' ' x length($sacl_scid )) {
			undef $sacl_scid ;
		}
		$sacl_dce_link=substr($_,1690,16);
		$sacl_auth_type=substr($_,1707,13);
		$sacl_dflt_process=substr($_,1721,1);
		$sacl_utk_netw=substr($_,1726,8);
		$sacl_x500_subject=substr($_,1735,255);
		$sacl_x500_issuer=substr($_,1991,255);
		$sacl_acl_type=substr($_,2247,8);
		$sacl_optype=substr($_,2256,8);
		$sacl_entry_type=substr($_,2265,3);
		$sacl_entry_id=substr($_,2269,10);
		$sacl_old_read=substr($_,2280,1);
		$sacl_old_write=substr($_,2285,1);
		$sacl_old_execute=substr($_,2290,1);
		$sacl_new_read=substr($_,2295,1);
		$sacl_new_write=substr($_,2300,1);
		$sacl_new_execute=substr($_,2305,1);
		$rv=$insert{setfacl}->execute($sacl_event_type,$sacl_event_qual,$sacl_time_written,$sacl_date_written,$sacl_system_smfid,$sacl_violation,$sacl_user_ndfnd,$sacl_user_warning,$sacl_evt_user_id,$sacl_evt_grp_id,$sacl_auth_normal,$sacl_auth_special,$sacl_auth_oper,$sacl_auth_audit,$sacl_auth_exit,$sacl_auth_failsft,$sacl_auth_bypass,$sacl_auth_trusted,$sacl_log_class,$sacl_log_user,$sacl_log_special,$sacl_log_access,$sacl_log_racinit,$sacl_log_always,$sacl_log_cmdviol,$sacl_log_global,$sacl_term_level,$sacl_backout_fail,$sacl_prof_same,$sacl_term,$sacl_job_name,$sacl_read_time,$sacl_read_date,$sacl_smf_user_id,$sacl_log_level,$sacl_log_vmevent,$sacl_log_logopt,$sacl_log_secl,$sacl_log_compatm,$sacl_log_applaud,$sacl_log_nonomvs,$sacl_log_omvsnprv,$sacl_auth_omvssu,$sacl_auth_omvssys,$sacl_usr_secl,$sacl_racf_version,$sacl_class,$sacl_user_name,$sacl_utk_encr,$sacl_utk_pre19,$sacl_utk_verprof,$sacl_utk_njeunusr,$sacl_utk_logusr,$sacl_utk_special,$sacl_utk_default,$sacl_utk_unknusr,$sacl_utk_error,$sacl_utk_trusted,$sacl_utk_sesstype,$sacl_utk_surrogat,$sacl_utk_remote,$sacl_utk_priv,$sacl_utk_secl,$sacl_utk_execnode,$sacl_utk_suser_id,$sacl_utk_snode,$sacl_utk_sgrp_id,$sacl_utk_spoe,$sacl_utk_spclass,$sacl_utk_user_id,$sacl_utk_grp_id,$sacl_utk_dft_grp,$sacl_utk_dft_secl,$sacl_appc_link,$sacl_audit_code,$sacl_old_real_uid,$sacl_old_eff_uid,$sacl_old_saved_uid,$sacl_old_real_gid,$sacl_old_eff_gid,$sacl_old_saved_gid,$sacl_path_name,$sacl_file_id,$sacl_file_own_uid,$sacl_file_own_gid,$sacl_filepool,$sacl_filespace,$sacl_inode,$sacl_scid,$sacl_dce_link,$sacl_auth_type,$sacl_dflt_process,$sacl_utk_netw,$sacl_x500_subject,$sacl_x500_issuer,$sacl_acl_type,$sacl_optype,$sacl_entry_type,$sacl_entry_id,$sacl_old_read,$sacl_old_write,$sacl_old_execute,$sacl_new_read,$sacl_new_write,$sacl_new_execute);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setfacl"}++;
		next;
	}

	if ($rectype eq 'SETGID  ') {
		$sgi_event_type=substr($_,0,8);
		$sgi_event_qual=substr($_,9,8);
		$sgi_time_written=substr($_,18,8);
		if ($sgi_time_written  eq ' ' x length($sgi_time_written )) {
			undef $sgi_time_written ;
		}
		$sgi_date_written=substr($_,27,10);
		if ($sgi_date_written  eq ' ' x length($sgi_date_written )) {
			undef $sgi_date_written ;
		}
		$sgi_system_smfid=substr($_,38,4);
		$sgi_violation=substr($_,43,1);
		$sgi_user_ndfnd=substr($_,48,1);
		$sgi_user_warning=substr($_,53,1);
		$sgi_evt_user_id=substr($_,58,8);
		$sgi_evt_grp_id=substr($_,67,8);
		$sgi_auth_normal=substr($_,76,1);
		$sgi_auth_special=substr($_,81,1);
		$sgi_auth_oper=substr($_,86,1);
		$sgi_auth_audit=substr($_,91,1);
		$sgi_auth_exit=substr($_,96,1);
		$sgi_auth_failsft=substr($_,101,1);
		$sgi_auth_bypass=substr($_,106,1);
		$sgi_auth_trusted=substr($_,111,1);
		$sgi_log_class=substr($_,116,1);
		$sgi_log_user=substr($_,121,1);
		$sgi_log_special=substr($_,126,1);
		$sgi_log_access=substr($_,131,1);
		$sgi_log_racinit=substr($_,136,1);
		$sgi_log_always=substr($_,141,1);
		$sgi_log_cmdviol=substr($_,146,1);
		$sgi_log_global=substr($_,151,1);
		$sgi_term_level=substr($_,156,3);
		if ($sgi_term_level  eq ' ' x length($sgi_term_level )) {
			undef $sgi_term_level ;
		}
		$sgi_backout_fail=substr($_,160,1);
		$sgi_prof_same=substr($_,165,1);
		$sgi_term=substr($_,170,8);
		$sgi_job_name=substr($_,179,8);
		$sgi_read_time=substr($_,188,8);
		if ($sgi_read_time  eq ' ' x length($sgi_read_time )) {
			undef $sgi_read_time ;
		}
		$sgi_read_date=substr($_,197,10);
		if ($sgi_read_date  eq ' ' x length($sgi_read_date )) {
			undef $sgi_read_date ;
		}
		$sgi_smf_user_id=substr($_,208,8);
		$sgi_log_level=substr($_,217,1);
		$sgi_log_vmevent=substr($_,222,1);
		$sgi_log_logopt=substr($_,227,1);
		$sgi_log_secl=substr($_,232,1);
		$sgi_log_compatm=substr($_,237,1);
		$sgi_log_applaud=substr($_,242,1);
		$sgi_log_nonomvs=substr($_,247,1);
		$sgi_log_omvsnprv=substr($_,252,1);
		$sgi_auth_omvssu=substr($_,257,1);
		$sgi_auth_omvssys=substr($_,262,1);
		$sgi_usr_secl=substr($_,267,8);
		$sgi_racf_version=substr($_,276,4);
		$sgi_class=substr($_,281,8);
		$sgi_user_name=substr($_,290,20);
		$sgi_utk_encr=substr($_,311,1);
		$sgi_utk_pre19=substr($_,316,1);
		$sgi_utk_verprof=substr($_,321,1);
		$sgi_utk_njeunusr=substr($_,326,1);
		$sgi_utk_logusr=substr($_,331,1);
		$sgi_utk_special=substr($_,336,1);
		$sgi_utk_default=substr($_,341,1);
		$sgi_utk_unknusr=substr($_,346,1);
		$sgi_utk_error=substr($_,351,1);
		$sgi_utk_trusted=substr($_,356,1);
		$sgi_utk_sesstype=substr($_,361,8);
		$sgi_utk_surrogat=substr($_,370,1);
		$sgi_utk_remote=substr($_,375,1);
		$sgi_utk_priv=substr($_,380,1);
		$sgi_utk_secl=substr($_,385,8);
		$sgi_utk_execnode=substr($_,394,8);
		$sgi_utk_suser_id=substr($_,403,8);
		$sgi_utk_snode=substr($_,412,8);
		$sgi_utk_sgrp_id=substr($_,421,8);
		$sgi_utk_spoe=substr($_,430,8);
		$sgi_utk_spclass=substr($_,439,8);
		$sgi_utk_user_id=substr($_,448,8);
		$sgi_utk_grp_id=substr($_,457,8);
		$sgi_utk_dft_grp=substr($_,466,1);
		$sgi_utk_dft_secl=substr($_,471,1);
		$sgi_appc_link=substr($_,476,16);
		$sgi_audit_code=substr($_,493,11);
		$sgi_old_real_uid=substr($_,505,10);
		if ($sgi_old_real_uid  eq ' ' x length($sgi_old_real_uid )) {
			undef $sgi_old_real_uid ;
		}
		$sgi_old_eff_uid=substr($_,516,10);
		if ($sgi_old_eff_uid  eq ' ' x length($sgi_old_eff_uid )) {
			undef $sgi_old_eff_uid ;
		}
		$sgi_old_saved_uid=substr($_,527,10);
		if ($sgi_old_saved_uid  eq ' ' x length($sgi_old_saved_uid )) {
			undef $sgi_old_saved_uid ;
		}
		$sgi_old_real_gid=substr($_,538,10);
		if ($sgi_old_real_gid  eq ' ' x length($sgi_old_real_gid )) {
			undef $sgi_old_real_gid ;
		}
		$sgi_old_eff_gid=substr($_,549,10);
		if ($sgi_old_eff_gid  eq ' ' x length($sgi_old_eff_gid )) {
			undef $sgi_old_eff_gid ;
		}
		$sgi_old_saved_gid=substr($_,560,10);
		if ($sgi_old_saved_gid  eq ' ' x length($sgi_old_saved_gid )) {
			undef $sgi_old_saved_gid ;
		}
		$sgi_new_real_gid=substr($_,571,10);
		if ($sgi_new_real_gid  eq ' ' x length($sgi_new_real_gid )) {
			undef $sgi_new_real_gid ;
		}
		$sgi_new_eff_gid=substr($_,582,10);
		if ($sgi_new_eff_gid  eq ' ' x length($sgi_new_eff_gid )) {
			undef $sgi_new_eff_gid ;
		}
		$sgi_new_saved_gid=substr($_,593,10);
		if ($sgi_new_saved_gid  eq ' ' x length($sgi_new_saved_gid )) {
			undef $sgi_new_saved_gid ;
		}
		$sgi_gid=substr($_,604,10);
		if ($sgi_gid  eq ' ' x length($sgi_gid )) {
			undef $sgi_gid ;
		}
		$sgi_dflt_process=substr($_,615,1);
		$sgi_utk_netw=substr($_,620,8);
		$sgi_x500_subject=substr($_,629,255);
		$sgi_x500_issuer=substr($_,885,255);
		$rv=$insert{setgid}->execute($sgi_event_type,$sgi_event_qual,$sgi_time_written,$sgi_date_written,$sgi_system_smfid,$sgi_violation,$sgi_user_ndfnd,$sgi_user_warning,$sgi_evt_user_id,$sgi_evt_grp_id,$sgi_auth_normal,$sgi_auth_special,$sgi_auth_oper,$sgi_auth_audit,$sgi_auth_exit,$sgi_auth_failsft,$sgi_auth_bypass,$sgi_auth_trusted,$sgi_log_class,$sgi_log_user,$sgi_log_special,$sgi_log_access,$sgi_log_racinit,$sgi_log_always,$sgi_log_cmdviol,$sgi_log_global,$sgi_term_level,$sgi_backout_fail,$sgi_prof_same,$sgi_term,$sgi_job_name,$sgi_read_time,$sgi_read_date,$sgi_smf_user_id,$sgi_log_level,$sgi_log_vmevent,$sgi_log_logopt,$sgi_log_secl,$sgi_log_compatm,$sgi_log_applaud,$sgi_log_nonomvs,$sgi_log_omvsnprv,$sgi_auth_omvssu,$sgi_auth_omvssys,$sgi_usr_secl,$sgi_racf_version,$sgi_class,$sgi_user_name,$sgi_utk_encr,$sgi_utk_pre19,$sgi_utk_verprof,$sgi_utk_njeunusr,$sgi_utk_logusr,$sgi_utk_special,$sgi_utk_default,$sgi_utk_unknusr,$sgi_utk_error,$sgi_utk_trusted,$sgi_utk_sesstype,$sgi_utk_surrogat,$sgi_utk_remote,$sgi_utk_priv,$sgi_utk_secl,$sgi_utk_execnode,$sgi_utk_suser_id,$sgi_utk_snode,$sgi_utk_sgrp_id,$sgi_utk_spoe,$sgi_utk_spclass,$sgi_utk_user_id,$sgi_utk_grp_id,$sgi_utk_dft_grp,$sgi_utk_dft_secl,$sgi_appc_link,$sgi_audit_code,$sgi_old_real_uid,$sgi_old_eff_uid,$sgi_old_saved_uid,$sgi_old_real_gid,$sgi_old_eff_gid,$sgi_old_saved_gid,$sgi_new_real_gid,$sgi_new_eff_gid,$sgi_new_saved_gid,$sgi_gid,$sgi_dflt_process,$sgi_utk_netw,$sgi_x500_subject,$sgi_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setgid"}++;
		next;
	}

	if ($rectype eq 'SETGROUP') {
		$setg_event_type=substr($_,0,8);
		$setg_event_qual=substr($_,9,8);
		$setg_time_written=substr($_,18,8);
		if ($setg_time_written  eq ' ' x length($setg_time_written )) {
			undef $setg_time_written ;
		}
		$setg_date_written=substr($_,27,10);
		if ($setg_date_written  eq ' ' x length($setg_date_written )) {
			undef $setg_date_written ;
		}
		$setg_system_smfid=substr($_,38,4);
		$setg_violation=substr($_,43,1);
		$setg_user_ndfnd=substr($_,48,1);
		$setg_user_warning=substr($_,53,1);
		$setg_evt_user_id=substr($_,58,8);
		$setg_evt_grp_id=substr($_,67,8);
		$setg_auth_normal=substr($_,76,1);
		$setg_auth_special=substr($_,81,1);
		$setg_auth_oper=substr($_,86,1);
		$setg_auth_audit=substr($_,91,1);
		$setg_auth_exit=substr($_,96,1);
		$setg_auth_failsft=substr($_,101,1);
		$setg_auth_bypass=substr($_,106,1);
		$setg_auth_trusted=substr($_,111,1);
		$setg_log_class=substr($_,116,1);
		$setg_log_user=substr($_,121,1);
		$setg_log_special=substr($_,126,1);
		$setg_log_access=substr($_,131,1);
		$setg_log_racinit=substr($_,136,1);
		$setg_log_always=substr($_,141,1);
		$setg_log_cmdviol=substr($_,146,1);
		$setg_log_global=substr($_,151,1);
		$setg_term_level=substr($_,156,3);
		if ($setg_term_level  eq ' ' x length($setg_term_level )) {
			undef $setg_term_level ;
		}
		$setg_backout_fail=substr($_,160,1);
		$setg_prof_same=substr($_,165,1);
		$setg_term=substr($_,170,8);
		$setg_job_name=substr($_,179,8);
		$setg_read_time=substr($_,188,8);
		if ($setg_read_time  eq ' ' x length($setg_read_time )) {
			undef $setg_read_time ;
		}
		$setg_read_date=substr($_,197,10);
		if ($setg_read_date  eq ' ' x length($setg_read_date )) {
			undef $setg_read_date ;
		}
		$setg_smf_user_id=substr($_,208,8);
		$setg_log_level=substr($_,217,1);
		$setg_log_vmevent=substr($_,222,1);
		$setg_log_logopt=substr($_,227,1);
		$setg_log_secl=substr($_,232,1);
		$setg_log_compatm=substr($_,237,1);
		$setg_log_applaud=substr($_,242,1);
		$setg_log_nonomvs=substr($_,247,1);
		$setg_log_omvsnprv=substr($_,252,1);
		$setg_auth_omvssu=substr($_,257,1);
		$setg_auth_omvssys=substr($_,262,1);
		$setg_usr_secl=substr($_,267,8);
		$setg_racf_version=substr($_,276,4);
		$setg_class=substr($_,281,8);
		$setg_user_name=substr($_,290,20);
		$setg_utk_encr=substr($_,311,1);
		$setg_utk_pre19=substr($_,316,1);
		$setg_utk_verprof=substr($_,321,1);
		$setg_utk_njeunusr=substr($_,326,1);
		$setg_utk_logusr=substr($_,331,1);
		$setg_utk_special=substr($_,336,1);
		$setg_utk_default=substr($_,341,1);
		$setg_utk_unknusr=substr($_,346,1);
		$setg_utk_error=substr($_,351,1);
		$setg_utk_trusted=substr($_,356,1);
		$setg_utk_sesstype=substr($_,361,8);
		$setg_utk_surrogat=substr($_,370,1);
		$setg_utk_remote=substr($_,375,1);
		$setg_utk_priv=substr($_,380,1);
		$setg_utk_secl=substr($_,385,8);
		$setg_utk_execnode=substr($_,394,8);
		$setg_utk_suser_id=substr($_,403,8);
		$setg_utk_snode=substr($_,412,8);
		$setg_utk_sgrp_id=substr($_,421,8);
		$setg_utk_spoe=substr($_,430,8);
		$setg_utk_spclass=substr($_,439,8);
		$setg_utk_user_id=substr($_,448,8);
		$setg_utk_grp_id=substr($_,457,8);
		$setg_utk_dft_grp=substr($_,466,1);
		$setg_utk_dft_secl=substr($_,471,1);
		$setg_appc_link=substr($_,476,16);
		$setg_audit_code=substr($_,493,11);
		$setg_old_real_uid=substr($_,505,10);
		if ($setg_old_real_uid  eq ' ' x length($setg_old_real_uid )) {
			undef $setg_old_real_uid ;
		}
		$setg_old_eff_uid=substr($_,516,10);
		if ($setg_old_eff_uid  eq ' ' x length($setg_old_eff_uid )) {
			undef $setg_old_eff_uid ;
		}
		$setg_old_saved_uid=substr($_,527,10);
		if ($setg_old_saved_uid eq ' ' x length($setg_old_saved_uid)) {
			undef $setg_old_saved_uid;
		}
		$setg_old_real_gid=substr($_,538,10);
		if ($setg_old_real_gid  eq ' ' x length($setg_old_real_gid )) {
			undef $setg_old_real_gid ;
		}
		$setg_old_eff_gid=substr($_,549,10);
		if ($setg_old_eff_gid  eq ' ' x length($setg_old_eff_gid )) {
			undef $setg_old_eff_gid ;
		}
		$setg_old_saved_gid=substr($_,560,10);
		if ($setg_old_saved_gid eq ' ' x length($setg_old_saved_gid)) {
			undef $setg_old_saved_gid;
		}
		$setg_dce_link=substr($_,571,16);
		$setg_auth_type=substr($_,588,13);
		$setg_dflt_process=substr($_,602,1);
		$setg_utk_netw=substr($_,607,8);
		$setg_x500_subject=substr($_,616,255);
		$setg_x500_issuer=substr($_,872,255);
		$rv=$insert{setgroup}->execute($setg_event_type,$setg_event_qual,$setg_time_written,$setg_date_written,$setg_system_smfid,$setg_violation,$setg_user_ndfnd,$setg_user_warning,$setg_evt_user_id,$setg_evt_grp_id,$setg_auth_normal,$setg_auth_special,$setg_auth_oper,$setg_auth_audit,$setg_auth_exit,$setg_auth_failsft,$setg_auth_bypass,$setg_auth_trusted,$setg_log_class,$setg_log_user,$setg_log_special,$setg_log_access,$setg_log_racinit,$setg_log_always,$setg_log_cmdviol,$setg_log_global,$setg_term_level,$setg_backout_fail,$setg_prof_same,$setg_term,$setg_job_name,$setg_read_time,$setg_read_date,$setg_smf_user_id,$setg_log_level,$setg_log_vmevent,$setg_log_logopt,$setg_log_secl,$setg_log_compatm,$setg_log_applaud,$setg_log_nonomvs,$setg_log_omvsnprv,$setg_auth_omvssu,$setg_auth_omvssys,$setg_usr_secl,$setg_racf_version,$setg_class,$setg_user_name,$setg_utk_encr,$setg_utk_pre19,$setg_utk_verprof,$setg_utk_njeunusr,$setg_utk_logusr,$setg_utk_special,$setg_utk_default,$setg_utk_unknusr,$setg_utk_error,$setg_utk_trusted,$setg_utk_sesstype,$setg_utk_surrogat,$setg_utk_remote,$setg_utk_priv,$setg_utk_secl,$setg_utk_execnode,$setg_utk_suser_id,$setg_utk_snode,$setg_utk_sgrp_id,$setg_utk_spoe,$setg_utk_spclass,$setg_utk_user_id,$setg_utk_grp_id,$setg_utk_dft_grp,$setg_utk_dft_secl,$setg_appc_link,$setg_audit_code,$setg_old_real_uid,$setg_old_eff_uid,$setg_old_saved_uid,$setg_old_real_gid,$setg_old_eff_gid,$setg_old_saved_gid,$setg_dce_link,$setg_auth_type,$setg_dflt_process,$setg_utk_netw,$setg_x500_subject,$setg_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setgroup"}++;
		next;
	}

	if ($rectype eq 'SETROPTS') {
		$setr_event_type=substr($_,0,8);
		$setr_event_qual=substr($_,9,8);
		$setr_time_written=substr($_,18,8);
		if ($setr_time_written  eq ' ' x length($setr_time_written )) {
			undef $setr_time_written ;
		}
		$setr_date_written=substr($_,27,10);
		if ($setr_date_written  eq ' ' x length($setr_date_written )) {
			undef $setr_date_written ;
		}
		$setr_system_smfid=substr($_,38,4);
		$setr_violation=substr($_,43,1);
		$setr_user_ndfnd=substr($_,48,1);
		$setr_user_warning=substr($_,53,1);
		$setr_evt_user_id=substr($_,58,8);
		$setr_evt_grp_id=substr($_,67,8);
		$setr_auth_normal=substr($_,76,1);
		$setr_auth_special=substr($_,81,1);
		$setr_auth_oper=substr($_,86,1);
		$setr_auth_audit=substr($_,91,1);
		$setr_auth_exit=substr($_,96,1);
		$setr_auth_failsft=substr($_,101,1);
		$setr_auth_bypass=substr($_,106,1);
		$setr_auth_trusted=substr($_,111,1);
		$setr_log_class=substr($_,116,1);
		$setr_log_user=substr($_,121,1);
		$setr_log_special=substr($_,126,1);
		$setr_log_access=substr($_,131,1);
		$setr_log_racinit=substr($_,136,1);
		$setr_log_always=substr($_,141,1);
		$setr_log_cmdviol=substr($_,146,1);
		$setr_log_global=substr($_,151,1);
		$setr_term_level=substr($_,156,3);
		if ($setr_term_level  eq ' ' x length($setr_term_level )) {
			undef $setr_term_level ;
		}
		$setr_backout_fail=substr($_,160,1);
		$setr_prof_same=substr($_,165,1);
		$setr_term=substr($_,170,8);
		$setr_job_name=substr($_,179,8);
		$setr_read_time=substr($_,188,8);
		if ($setr_read_time  eq ' ' x length($setr_read_time )) {
			undef $setr_read_time ;
		}
		$setr_read_date=substr($_,197,10);
		if ($setr_read_date  eq ' ' x length($setr_read_date )) {
			undef $setr_read_date ;
		}
		$setr_smf_user_id=substr($_,208,8);
		$setr_log_level=substr($_,217,1);
		$setr_log_vmevent=substr($_,222,1);
		$setr_log_logopt=substr($_,227,1);
		$setr_log_secl=substr($_,232,1);
		$setr_log_compatm=substr($_,237,1);
		$setr_log_applaud=substr($_,242,1);
		$setr_log_nonomvs=substr($_,247,1);
		$setr_log_omvsnprv=substr($_,252,1);
		$setr_auth_omvssu=substr($_,257,1);
		$setr_auth_omvssys=substr($_,262,1);
		$setr_usr_secl=substr($_,267,8);
		$setr_racf_version=substr($_,276,4);
		$setr_user_name=substr($_,281,20);
		$setr_utk_encr=substr($_,302,1);
		$setr_utk_pre19=substr($_,307,1);
		$setr_utk_verprof=substr($_,312,1);
		$setr_utk_njeunusr=substr($_,317,1);
		$setr_utk_logusr=substr($_,322,1);
		$setr_utk_special=substr($_,327,1);
		$setr_utk_default=substr($_,332,1);
		$setr_utk_unknusr=substr($_,337,1);
		$setr_utk_error=substr($_,342,1);
		$setr_utk_trusted=substr($_,347,1);
		$setr_utk_sesstype=substr($_,352,8);
		$setr_utk_surrogat=substr($_,361,1);
		$setr_utk_remove=substr($_,366,1);
		$setr_utk_priv=substr($_,371,1);
		$setr_utk_secl=substr($_,376,8);
		$setr_utk_execnode=substr($_,385,8);
		$setr_utk_suser_id=substr($_,394,8);
		$setr_utk_snode=substr($_,403,8);
		$setr_utk_sgrp_id=substr($_,412,8);
		$setr_utk_spoe=substr($_,421,8);
		$setr_utk_spclass=substr($_,430,8);
		$setr_utk_user_id=substr($_,439,8);
		$setr_utk_grp_id=substr($_,448,8);
		$setr_utk_dft_grp=substr($_,457,1);
		$setr_utk_dft_secl=substr($_,462,1);
		$setr_appc_link=substr($_,467,16);
		$setr_specified=substr($_,484,1024);
		$setr_failed=substr($_,1509,1024);
		$setr_utk_netw=substr($_,2534,8);
		$setr_x500_subject=substr($_,2543,255);
		$setr_x500_issuer=substr($_,2799,255);
		$rv=$insert{setropts}->execute($setr_event_type,$setr_event_qual,$setr_time_written,$setr_date_written,$setr_system_smfid,$setr_violation,$setr_user_ndfnd,$setr_user_warning,$setr_evt_user_id,$setr_evt_grp_id,$setr_auth_normal,$setr_auth_special,$setr_auth_oper,$setr_auth_audit,$setr_auth_exit,$setr_auth_failsft,$setr_auth_bypass,$setr_auth_trusted,$setr_log_class,$setr_log_user,$setr_log_special,$setr_log_access,$setr_log_racinit,$setr_log_always,$setr_log_cmdviol,$setr_log_global,$setr_term_level,$setr_backout_fail,$setr_prof_same,$setr_term,$setr_job_name,$setr_read_time,$setr_read_date,$setr_smf_user_id,$setr_log_level,$setr_log_vmevent,$setr_log_logopt,$setr_log_secl,$setr_log_compatm,$setr_log_applaud,$setr_log_nonomvs,$setr_log_omvsnprv,$setr_auth_omvssu,$setr_auth_omvssys,$setr_usr_secl,$setr_racf_version,$setr_user_name,$setr_utk_encr,$setr_utk_pre19,$setr_utk_verprof,$setr_utk_njeunusr,$setr_utk_logusr,$setr_utk_special,$setr_utk_default,$setr_utk_unknusr,$setr_utk_error,$setr_utk_trusted,$setr_utk_sesstype,$setr_utk_surrogat,$setr_utk_remove,$setr_utk_priv,$setr_utk_secl,$setr_utk_execnode,$setr_utk_suser_id,$setr_utk_snode,$setr_utk_sgrp_id,$setr_utk_spoe,$setr_utk_spclass,$setr_utk_user_id,$setr_utk_grp_id,$setr_utk_dft_grp,$setr_utk_dft_secl,$setr_appc_link,$setr_specified,$setr_failed,$setr_utk_netw,$setr_x500_subject,$setr_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setropts"}++;
		next;
	}

	if ($rectype eq 'SETUID  ') {
		$sui_event_type=substr($_,0,8);
		$sui_event_qual=substr($_,9,8);
		$sui_time_written=substr($_,18,8);
		if ($sui_time_written  eq ' ' x length($sui_time_written )) {
			undef $sui_time_written ;
		}
		$sui_date_written=substr($_,27,10);
		if ($sui_date_written  eq ' ' x length($sui_date_written )) {
			undef $sui_date_written ;
		}
		$sui_system_smfid=substr($_,38,4);
		$sui_violation=substr($_,43,1);
		$sui_user_ndfnd=substr($_,48,1);
		$sui_user_warning=substr($_,53,1);
		$sui_evt_user_id=substr($_,58,8);
		$sui_evt_grp_id=substr($_,67,8);
		$sui_auth_normal=substr($_,76,1);
		$sui_auth_special=substr($_,81,1);
		$sui_auth_oper=substr($_,86,1);
		$sui_auth_audit=substr($_,91,1);
		$sui_auth_exit=substr($_,96,1);
		$sui_auth_failsft=substr($_,101,1);
		$sui_auth_bypass=substr($_,106,1);
		$sui_auth_trusted=substr($_,111,1);
		$sui_log_class=substr($_,116,1);
		$sui_log_user=substr($_,121,1);
		$sui_log_special=substr($_,126,1);
		$sui_log_access=substr($_,131,1);
		$sui_log_racinit=substr($_,136,1);
		$sui_log_always=substr($_,141,1);
		$sui_log_cmdviol=substr($_,146,1);
		$sui_log_global=substr($_,151,1);
		$sui_term_level=substr($_,156,3);
		if ($sui_term_level  eq ' ' x length($sui_term_level )) {
			undef $sui_term_level ;
		}
		$sui_backout_fail=substr($_,160,1);
		$sui_prof_same=substr($_,165,1);
		$sui_term=substr($_,170,8);
		$sui_job_name=substr($_,179,8);
		$sui_read_time=substr($_,188,8);
		if ($sui_read_time  eq ' ' x length($sui_read_time )) {
			undef $sui_read_time ;
		}
		$sui_read_date=substr($_,197,10);
		if ($sui_read_date  eq ' ' x length($sui_read_date )) {
			undef $sui_read_date ;
		}
		$sui_smf_user_id=substr($_,208,8);
		$sui_log_level=substr($_,217,1);
		$sui_log_vmevent=substr($_,222,1);
		$sui_log_logopt=substr($_,227,1);
		$sui_log_secl=substr($_,232,1);
		$sui_log_compatm=substr($_,237,1);
		$sui_log_applaud=substr($_,242,1);
		$sui_log_nonomvs=substr($_,247,1);
		$sui_log_omvsnprv=substr($_,252,1);
		$sui_auth_omvssu=substr($_,257,1);
		$sui_auth_omvssys=substr($_,262,1);
		$sui_usr_secl=substr($_,267,8);
		$sui_racf_version=substr($_,276,4);
		$sui_class=substr($_,281,8);
		$sui_user_name=substr($_,290,20);
		$sui_utk_encr=substr($_,311,1);
		$sui_utk_pre19=substr($_,316,1);
		$sui_utk_verprof=substr($_,321,1);
		$sui_utk_njeunusr=substr($_,326,1);
		$sui_utk_logusr=substr($_,331,1);
		$sui_utk_special=substr($_,336,1);
		$sui_utk_default=substr($_,341,1);
		$sui_utk_unknusr=substr($_,346,1);
		$sui_utk_error=substr($_,351,1);
		$sui_utk_trusted=substr($_,356,1);
		$sui_utk_sesstype=substr($_,361,8);
		$sui_utk_surrogat=substr($_,370,1);
		$sui_utk_remote=substr($_,375,1);
		$sui_utk_priv=substr($_,380,1);
		$sui_utk_secl=substr($_,385,8);
		$sui_utk_execnode=substr($_,394,8);
		$sui_utk_suser_id=substr($_,403,8);
		$sui_utk_snode=substr($_,412,8);
		$sui_utk_sgrp_id=substr($_,421,8);
		$sui_utk_spoe=substr($_,430,8);
		$sui_utk_spclass=substr($_,439,8);
		$sui_utk_user_id=substr($_,448,8);
		$sui_utk_grp_id=substr($_,457,8);
		$sui_utk_dft_grp=substr($_,466,1);
		$sui_utk_dft_secl=substr($_,471,1);
		$sui_appc_link=substr($_,476,16);
		$sui_audit_code=substr($_,493,11);
		$sui_old_real_uid=substr($_,505,10);
		if ($sui_old_real_uid  eq ' ' x length($sui_old_real_uid )) {
			undef $sui_old_real_uid ;
		}
		$sui_old_eff_uid=substr($_,516,10);
		if ($sui_old_eff_uid  eq ' ' x length($sui_old_eff_uid )) {
			undef $sui_old_eff_uid ;
		}
		$sui_old_saved_uid=substr($_,527,10);
		if ($sui_old_saved_uid  eq ' ' x length($sui_old_saved_uid )) {
			undef $sui_old_saved_uid ;
		}
		$sui_old_real_gid=substr($_,538,10);
		if ($sui_old_real_gid  eq ' ' x length($sui_old_real_gid )) {
			undef $sui_old_real_gid ;
		}
		$sui_old_eff_gid=substr($_,549,10);
		if ($sui_old_eff_gid  eq ' ' x length($sui_old_eff_gid )) {
			undef $sui_old_eff_gid ;
		}
		$sui_old_saved_gid=substr($_,560,10);
		if ($sui_old_saved_gid  eq ' ' x length($sui_old_saved_gid )) {
			undef $sui_old_saved_gid ;
		}
		$sui_new_real_uid=substr($_,571,10);
		if ($sui_new_real_uid  eq ' ' x length($sui_new_real_uid )) {
			undef $sui_new_real_uid ;
		}
		$sui_new_eff_uid=substr($_,582,10);
		if ($sui_new_eff_uid  eq ' ' x length($sui_new_eff_uid )) {
			undef $sui_new_eff_uid ;
		}
		$sui_new_saved_uid=substr($_,593,10);
		if ($sui_new_saved_uid  eq ' ' x length($sui_new_saved_uid )) {
			undef $sui_new_saved_uid ;
		}
		$sui_uid=substr($_,604,10);
		if ($sui_uid  eq ' ' x length($sui_uid )) {
			undef $sui_uid ;
		}
		$sui_dflt_process=substr($_,615,1);
		$sui_utk_netw=substr($_,620,8);
		$sui_x500_subject=substr($_,629,255);
		$sui_x500_issuer=substr($_,885,255);
		$rv=$insert{setuid}->execute($sui_event_type,$sui_event_qual,$sui_time_written,$sui_date_written,$sui_system_smfid,$sui_violation,$sui_user_ndfnd,$sui_user_warning,$sui_evt_user_id,$sui_evt_grp_id,$sui_auth_normal,$sui_auth_special,$sui_auth_oper,$sui_auth_audit,$sui_auth_exit,$sui_auth_failsft,$sui_auth_bypass,$sui_auth_trusted,$sui_log_class,$sui_log_user,$sui_log_special,$sui_log_access,$sui_log_racinit,$sui_log_always,$sui_log_cmdviol,$sui_log_global,$sui_term_level,$sui_backout_fail,$sui_prof_same,$sui_term,$sui_job_name,$sui_read_time,$sui_read_date,$sui_smf_user_id,$sui_log_level,$sui_log_vmevent,$sui_log_logopt,$sui_log_secl,$sui_log_compatm,$sui_log_applaud,$sui_log_nonomvs,$sui_log_omvsnprv,$sui_auth_omvssu,$sui_auth_omvssys,$sui_usr_secl,$sui_racf_version,$sui_class,$sui_user_name,$sui_utk_encr,$sui_utk_pre19,$sui_utk_verprof,$sui_utk_njeunusr,$sui_utk_logusr,$sui_utk_special,$sui_utk_default,$sui_utk_unknusr,$sui_utk_error,$sui_utk_trusted,$sui_utk_sesstype,$sui_utk_surrogat,$sui_utk_remote,$sui_utk_priv,$sui_utk_secl,$sui_utk_execnode,$sui_utk_suser_id,$sui_utk_snode,$sui_utk_sgrp_id,$sui_utk_spoe,$sui_utk_spclass,$sui_utk_user_id,$sui_utk_grp_id,$sui_utk_dft_grp,$sui_utk_dft_secl,$sui_appc_link,$sui_audit_code,$sui_old_real_uid,$sui_old_eff_uid,$sui_old_saved_uid,$sui_old_real_gid,$sui_old_eff_gid,$sui_old_saved_gid,$sui_new_real_uid,$sui_new_eff_uid,$sui_new_saved_uid,$sui_uid,$sui_dflt_process,$sui_utk_netw,$sui_x500_subject,$sui_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"setuid"}++;
		next;
	}

	if ($rectype eq 'SYMLINK ') {
		$syml_event_type=substr($_,0,8);
		$syml_event_qual=substr($_,9,8);
		$syml_time_written=substr($_,18,8);
		if ($syml_time_written  eq ' ' x length($syml_time_written )) {
			undef $syml_time_written ;
		}
		$syml_date_written=substr($_,27,10);
		if ($syml_date_written  eq ' ' x length($syml_date_written )) {
			undef $syml_date_written ;
		}
		$syml_system_smfid=substr($_,38,4);
		$syml_violation=substr($_,43,1);
		$syml_user_ndfnd=substr($_,48,1);
		$syml_user_warning=substr($_,53,1);
		$syml_evt_user_id=substr($_,58,8);
		$syml_evt_grp_id=substr($_,67,8);
		$syml_auth_normal=substr($_,76,1);
		$syml_auth_special=substr($_,81,1);
		$syml_auth_oper=substr($_,86,1);
		$syml_auth_audit=substr($_,91,1);
		$syml_auth_exit=substr($_,96,1);
		$syml_auth_failsft=substr($_,101,1);
		$syml_auth_bypass=substr($_,106,1);
		$syml_auth_trusted=substr($_,111,1);
		$syml_log_class=substr($_,116,1);
		$syml_log_user=substr($_,121,1);
		$syml_log_special=substr($_,126,1);
		$syml_log_access=substr($_,131,1);
		$syml_log_racinit=substr($_,136,1);
		$syml_log_always=substr($_,141,1);
		$syml_log_cmdviol=substr($_,146,1);
		$syml_log_global=substr($_,151,1);
		$syml_term_level=substr($_,156,3);
		if ($syml_term_level  eq ' ' x length($syml_term_level )) {
			undef $syml_term_level ;
		}
		$syml_backout_fail=substr($_,160,1);
		$syml_prof_same=substr($_,165,1);
		$syml_term=substr($_,170,8);
		$syml_job_name=substr($_,179,8);
		$syml_read_time=substr($_,188,8);
		if ($syml_read_time  eq ' ' x length($syml_read_time )) {
			undef $syml_read_time ;
		}
		$syml_read_date=substr($_,197,10);
		if ($syml_read_date  eq ' ' x length($syml_read_date )) {
			undef $syml_read_date ;
		}
		$syml_smf_user_id=substr($_,208,8);
		$syml_log_level=substr($_,217,1);
		$syml_log_vmevent=substr($_,222,1);
		$syml_log_logopt=substr($_,227,1);
		$syml_log_secl=substr($_,232,1);
		$syml_log_compatm=substr($_,237,1);
		$syml_log_applaud=substr($_,242,1);
		$syml_log_nonomvs=substr($_,247,1);
		$syml_log_omvsnprv=substr($_,252,1);
		$syml_auth_omvssu=substr($_,257,1);
		$syml_auth_omvssys=substr($_,262,1);
		$syml_usr_secl=substr($_,267,8);
		$syml_racf_version=substr($_,276,4);
		$syml_class=substr($_,281,8);
		$syml_user_name=substr($_,290,20);
		$syml_utk_encr=substr($_,311,1);
		$syml_utk_pre19=substr($_,316,1);
		$syml_utk_verprof=substr($_,321,1);
		$syml_utk_njeunusr=substr($_,326,1);
		$syml_utk_logusr=substr($_,331,1);
		$syml_utk_special=substr($_,336,1);
		$syml_utk_default=substr($_,341,1);
		$syml_utk_unknusr=substr($_,346,1);
		$syml_utk_error=substr($_,351,1);
		$syml_utk_trusted=substr($_,356,1);
		$syml_utk_sesstype=substr($_,361,8);
		$syml_utk_surrogat=substr($_,370,1);
		$syml_utk_remote=substr($_,375,1);
		$syml_utk_priv=substr($_,380,1);
		$syml_utk_secl=substr($_,385,8);
		$syml_utk_execnode=substr($_,394,8);
		$syml_utk_suser_id=substr($_,403,8);
		$syml_utk_snode=substr($_,412,8);
		$syml_utk_sgrp_id=substr($_,421,8);
		$syml_utk_spoe=substr($_,430,8);
		$syml_utk_spclass=substr($_,439,8);
		$syml_utk_user_id=substr($_,448,8);
		$syml_utk_grp_id=substr($_,457,8);
		$syml_utk_dft_grp=substr($_,466,1);
		$syml_utk_dft_secl=substr($_,471,1);
		$syml_appc_link=substr($_,476,16);
		$syml_audit_code=substr($_,493,11);
		$syml_old_real_uid=substr($_,505,10);
		if ($syml_old_real_uid  eq ' ' x length($syml_old_real_uid )) {
			undef $syml_old_real_uid ;
		}
		$syml_old_eff_uid=substr($_,516,10);
		if ($syml_old_eff_uid  eq ' ' x length($syml_old_eff_uid )) {
			undef $syml_old_eff_uid ;
		}
		$syml_old_saved_uid=substr($_,527,10);
		if ($syml_old_saved_uid eq ' ' x length($syml_old_saved_uid)) {
			undef $syml_old_saved_uid;
		}
		$syml_old_real_gid=substr($_,538,10);
		if ($syml_old_real_gid  eq ' ' x length($syml_old_real_gid )) {
			undef $syml_old_real_gid ;
		}
		$syml_old_eff_gid=substr($_,549,10);
		if ($syml_old_eff_gid  eq ' ' x length($syml_old_eff_gid )) {
			undef $syml_old_eff_gid ;
		}
		$syml_old_saved_gid=substr($_,560,10);
		if ($syml_old_saved_gid eq ' ' x length($syml_old_saved_gid)) {
			undef $syml_old_saved_gid;
		}
		$syml_path_name=substr($_,571,1023);
		$syml_file_id=substr($_,1595,32);
		$syml_file_own_uid=substr($_,1628,10);
		if ($syml_file_own_uid  eq ' ' x length($syml_file_own_uid )) {
			undef $syml_file_own_uid ;
		}
		$syml_file_own_gid=substr($_,1639,10);
		if ($syml_file_own_gid  eq ' ' x length($syml_file_own_gid )) {
			undef $syml_file_own_gid ;
		}
		$syml_symlink_data=substr($_,1650,1023);
		$syml_filepool=substr($_,2674,8);
		$syml_filespace=substr($_,2683,8);
		$syml_inode=substr($_,2692,10);
		if ($syml_inode  eq ' ' x length($syml_inode )) {
			undef $syml_inode ;
		}
		$syml_scid=substr($_,2703,10);
		if ($syml_scid  eq ' ' x length($syml_scid )) {
			undef $syml_scid ;
		}
		$syml_dflt_process=substr($_,2714,1);
		$syml_utk_netw=substr($_,2719,8);
		$syml_x500_subject=substr($_,2728,255);
		$syml_x500_issuer=substr($_,2984,255);
		$rv=$insert{symlink}->execute($syml_event_type,$syml_event_qual,$syml_time_written,$syml_date_written,$syml_system_smfid,$syml_violation,$syml_user_ndfnd,$syml_user_warning,$syml_evt_user_id,$syml_evt_grp_id,$syml_auth_normal,$syml_auth_special,$syml_auth_oper,$syml_auth_audit,$syml_auth_exit,$syml_auth_failsft,$syml_auth_bypass,$syml_auth_trusted,$syml_log_class,$syml_log_user,$syml_log_special,$syml_log_access,$syml_log_racinit,$syml_log_always,$syml_log_cmdviol,$syml_log_global,$syml_term_level,$syml_backout_fail,$syml_prof_same,$syml_term,$syml_job_name,$syml_read_time,$syml_read_date,$syml_smf_user_id,$syml_log_level,$syml_log_vmevent,$syml_log_logopt,$syml_log_secl,$syml_log_compatm,$syml_log_applaud,$syml_log_nonomvs,$syml_log_omvsnprv,$syml_auth_omvssu,$syml_auth_omvssys,$syml_usr_secl,$syml_racf_version,$syml_class,$syml_user_name,$syml_utk_encr,$syml_utk_pre19,$syml_utk_verprof,$syml_utk_njeunusr,$syml_utk_logusr,$syml_utk_special,$syml_utk_default,$syml_utk_unknusr,$syml_utk_error,$syml_utk_trusted,$syml_utk_sesstype,$syml_utk_surrogat,$syml_utk_remote,$syml_utk_priv,$syml_utk_secl,$syml_utk_execnode,$syml_utk_suser_id,$syml_utk_snode,$syml_utk_sgrp_id,$syml_utk_spoe,$syml_utk_spclass,$syml_utk_user_id,$syml_utk_grp_id,$syml_utk_dft_grp,$syml_utk_dft_secl,$syml_appc_link,$syml_audit_code,$syml_old_real_uid,$syml_old_eff_uid,$syml_old_saved_uid,$syml_old_real_gid,$syml_old_eff_gid,$syml_old_saved_gid,$syml_path_name,$syml_file_id,$syml_file_own_uid,$syml_file_own_gid,$syml_symlink_data,$syml_filepool,$syml_filespace,$syml_inode,$syml_scid,$syml_dflt_process,$syml_utk_netw,$syml_x500_subject,$syml_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"symlink"}++;
		next;
	}

	if ($rectype eq 'TERMOEDP') {
		$toep_event_type=substr($_,0,8);
		$toep_event_qual=substr($_,9,8);
		$toep_time_written=substr($_,18,8);
		if ($toep_time_written  eq ' ' x length($toep_time_written )) {
			undef $toep_time_written ;
		}
		$toep_date_written=substr($_,27,10);
		if ($toep_date_written  eq ' ' x length($toep_date_written )) {
			undef $toep_date_written ;
		}
		$toep_system_smfid=substr($_,38,4);
		$toep_violation=substr($_,43,1);
		$toep_user_ndfnd=substr($_,48,1);
		$toep_user_warning=substr($_,53,1);
		$toep_evt_user_id=substr($_,58,8);
		$toep_evt_grp_id=substr($_,67,8);
		$toep_auth_normal=substr($_,76,1);
		$toep_auth_special=substr($_,81,1);
		$toep_auth_oper=substr($_,86,1);
		$toep_auth_audit=substr($_,91,1);
		$toep_auth_exit=substr($_,96,1);
		$toep_auth_failsft=substr($_,101,1);
		$toep_auth_bypass=substr($_,106,1);
		$toep_auth_trusted=substr($_,111,1);
		$toep_log_class=substr($_,116,1);
		$toep_log_user=substr($_,121,1);
		$toep_log_special=substr($_,126,1);
		$toep_log_access=substr($_,131,1);
		$toep_log_racinit=substr($_,136,1);
		$toep_log_always=substr($_,141,1);
		$toep_log_cmdviol=substr($_,146,1);
		$toep_log_global=substr($_,151,1);
		$toep_term_level=substr($_,156,3);
		if ($toep_term_level  eq ' ' x length($toep_term_level )) {
			undef $toep_term_level ;
		}
		$toep_backout_fail=substr($_,160,1);
		$toep_prof_same=substr($_,165,1);
		$toep_term=substr($_,170,8);
		$toep_job_name=substr($_,179,8);
		$toep_read_time=substr($_,188,8);
		if ($toep_read_time  eq ' ' x length($toep_read_time )) {
			undef $toep_read_time ;
		}
		$toep_read_date=substr($_,197,10);
		if ($toep_read_date  eq ' ' x length($toep_read_date )) {
			undef $toep_read_date ;
		}
		$toep_smf_user_id=substr($_,208,8);
		$toep_log_level=substr($_,217,1);
		$toep_log_vmevent=substr($_,222,1);
		$toep_log_logopt=substr($_,227,1);
		$toep_log_secl=substr($_,232,1);
		$toep_log_compatm=substr($_,237,1);
		$toep_log_applaud=substr($_,242,1);
		$toep_log_nonomvs=substr($_,247,1);
		$toep_log_omvsnprv=substr($_,252,1);
		$toep_auth_omvssu=substr($_,257,1);
		$toep_auth_omvssys=substr($_,262,1);
		$toep_usr_secl=substr($_,267,8);
		$toep_racf_version=substr($_,276,4);
		$toep_class=substr($_,281,8);
		$toep_user_name=substr($_,290,20);
		$toep_utk_encr=substr($_,311,1);
		$toep_utk_pre19=substr($_,316,1);
		$toep_utk_verprof=substr($_,321,1);
		$toep_utk_njeunusr=substr($_,326,1);
		$toep_utk_logusr=substr($_,331,1);
		$toep_utk_special=substr($_,336,1);
		$toep_utk_default=substr($_,341,1);
		$toep_utk_unknusr=substr($_,346,1);
		$toep_utk_error=substr($_,351,1);
		$toep_utk_trusted=substr($_,356,1);
		$toep_utk_sesstype=substr($_,361,8);
		$toep_utk_surrogat=substr($_,370,1);
		$toep_utk_remote=substr($_,375,1);
		$toep_utk_priv=substr($_,380,1);
		$toep_utk_secl=substr($_,385,8);
		$toep_utk_execnode=substr($_,394,8);
		$toep_utk_suser_id=substr($_,403,8);
		$toep_utk_snode=substr($_,412,8);
		$toep_utk_sgrp_id=substr($_,421,8);
		$toep_utk_spoe=substr($_,430,8);
		$toep_utk_spclass=substr($_,439,8);
		$toep_utk_user_id=substr($_,448,8);
		$toep_utk_grp_id=substr($_,457,8);
		$toep_utk_dft_grp=substr($_,466,1);
		$toep_utk_dft_secl=substr($_,471,1);
		$toep_appc_link=substr($_,476,16);
		$toep_audit_code=substr($_,493,11);
		$toep_old_real_uid=substr($_,505,10);
		if ($toep_old_real_uid  eq ' ' x length($toep_old_real_uid )) {
			undef $toep_old_real_uid ;
		}
		$toep_old_eff_uid=substr($_,516,10);
		if ($toep_old_eff_uid  eq ' ' x length($toep_old_eff_uid )) {
			undef $toep_old_eff_uid ;
		}
		$toep_old_saved_uid=substr($_,527,10);
		if ($toep_old_saved_uid eq ' ' x length($toep_old_saved_uid)) {
			undef $toep_old_saved_uid;
		}
		$toep_old_real_gid=substr($_,538,10);
		if ($toep_old_real_gid  eq ' ' x length($toep_old_real_gid )) {
			undef $toep_old_real_gid ;
		}
		$toep_old_eff_gid=substr($_,549,10);
		if ($toep_old_eff_gid  eq ' ' x length($toep_old_eff_gid )) {
			undef $toep_old_eff_gid ;
		}
		$toep_old_saved_gid=substr($_,560,10);
		if ($toep_old_saved_gid eq ' ' x length($toep_old_saved_gid)) {
			undef $toep_old_saved_gid;
		}
		$toep_dflt_process=substr($_,571,1);
		$toep_utk_netw=substr($_,576,8);
		$toep_x500_subject=substr($_,585,255);
		$toep_x500_issuer=substr($_,841,255);
		$rv=$insert{termoedp}->execute($toep_event_type,$toep_event_qual,$toep_time_written,$toep_date_written,$toep_system_smfid,$toep_violation,$toep_user_ndfnd,$toep_user_warning,$toep_evt_user_id,$toep_evt_grp_id,$toep_auth_normal,$toep_auth_special,$toep_auth_oper,$toep_auth_audit,$toep_auth_exit,$toep_auth_failsft,$toep_auth_bypass,$toep_auth_trusted,$toep_log_class,$toep_log_user,$toep_log_special,$toep_log_access,$toep_log_racinit,$toep_log_always,$toep_log_cmdviol,$toep_log_global,$toep_term_level,$toep_backout_fail,$toep_prof_same,$toep_term,$toep_job_name,$toep_read_time,$toep_read_date,$toep_smf_user_id,$toep_log_level,$toep_log_vmevent,$toep_log_logopt,$toep_log_secl,$toep_log_compatm,$toep_log_applaud,$toep_log_nonomvs,$toep_log_omvsnprv,$toep_auth_omvssu,$toep_auth_omvssys,$toep_usr_secl,$toep_racf_version,$toep_class,$toep_user_name,$toep_utk_encr,$toep_utk_pre19,$toep_utk_verprof,$toep_utk_njeunusr,$toep_utk_logusr,$toep_utk_special,$toep_utk_default,$toep_utk_unknusr,$toep_utk_error,$toep_utk_trusted,$toep_utk_sesstype,$toep_utk_surrogat,$toep_utk_remote,$toep_utk_priv,$toep_utk_secl,$toep_utk_execnode,$toep_utk_suser_id,$toep_utk_snode,$toep_utk_sgrp_id,$toep_utk_spoe,$toep_utk_spclass,$toep_utk_user_id,$toep_utk_grp_id,$toep_utk_dft_grp,$toep_utk_dft_secl,$toep_appc_link,$toep_audit_code,$toep_old_real_uid,$toep_old_eff_uid,$toep_old_saved_uid,$toep_old_real_gid,$toep_old_eff_gid,$toep_old_saved_gid,$toep_dflt_process,$toep_utk_netw,$toep_x500_subject,$toep_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"termoedp"}++;
		next;
	}

	if ($rectype eq 'UMNTFSYS') {
		$ufs_event_type=substr($_,0,8);
		$ufs_event_qual=substr($_,9,8);
		$ufs_time_written=substr($_,18,8);
		if ($ufs_time_written  eq ' ' x length($ufs_time_written )) {
			undef $ufs_time_written ;
		}
		$ufs_date_written=substr($_,27,10);
		if ($ufs_date_written  eq ' ' x length($ufs_date_written )) {
			undef $ufs_date_written ;
		}
		$ufs_system_smfid=substr($_,38,4);
		$ufs_violation=substr($_,43,1);
		$ufs_user_ndfnd=substr($_,48,1);
		$ufs_user_warning=substr($_,53,1);
		$ufs_evt_user_id=substr($_,58,8);
		$ufs_evt_grp_id=substr($_,67,8);
		$ufs_auth_normal=substr($_,76,1);
		$ufs_auth_special=substr($_,81,1);
		$ufs_auth_oper=substr($_,86,1);
		$ufs_auth_audit=substr($_,91,1);
		$ufs_auth_exit=substr($_,96,1);
		$ufs_auth_failsft=substr($_,101,1);
		$ufs_auth_bypass=substr($_,106,1);
		$ufs_auth_trusted=substr($_,111,1);
		$ufs_log_class=substr($_,116,1);
		$ufs_log_user=substr($_,121,1);
		$ufs_log_special=substr($_,126,1);
		$ufs_log_access=substr($_,131,1);
		$ufs_log_racinit=substr($_,136,1);
		$ufs_log_always=substr($_,141,1);
		$ufs_log_cmdviol=substr($_,146,1);
		$ufs_log_global=substr($_,151,1);
		$ufs_term_level=substr($_,156,3);
		if ($ufs_term_level  eq ' ' x length($ufs_term_level )) {
			undef $ufs_term_level ;
		}
		$ufs_backout_fail=substr($_,160,1);
		$ufs_prof_same=substr($_,165,1);
		$ufs_term=substr($_,170,8);
		$ufs_job_name=substr($_,179,8);
		$ufs_read_time=substr($_,188,8);
		if ($ufs_read_time  eq ' ' x length($ufs_read_time )) {
			undef $ufs_read_time ;
		}
		$ufs_read_date=substr($_,197,10);
		if ($ufs_read_date  eq ' ' x length($ufs_read_date )) {
			undef $ufs_read_date ;
		}
		$ufs_smf_user_id=substr($_,208,8);
		$ufs_log_level=substr($_,217,1);
		$ufs_log_vmevent=substr($_,222,1);
		$ufs_log_logopt=substr($_,227,1);
		$ufs_log_secl=substr($_,232,1);
		$ufs_log_compatm=substr($_,237,1);
		$ufs_log_applaud=substr($_,242,1);
		$ufs_log_nonomvs=substr($_,247,1);
		$ufs_log_omvsnprv=substr($_,252,1);
		$ufs_auth_omvssu=substr($_,257,1);
		$ufs_auth_omvssys=substr($_,262,1);
		$ufs_usr_secl=substr($_,267,8);
		$ufs_racf_version=substr($_,276,4);
		$ufs_class=substr($_,281,8);
		$ufs_user_name=substr($_,290,20);
		$ufs_utk_encr=substr($_,311,1);
		$ufs_utk_pre19=substr($_,316,1);
		$ufs_utk_verprof=substr($_,321,1);
		$ufs_utk_njeunusr=substr($_,326,1);
		$ufs_utk_logusr=substr($_,331,1);
		$ufs_utk_special=substr($_,336,1);
		$ufs_utk_default=substr($_,341,1);
		$ufs_utk_unknusr=substr($_,346,1);
		$ufs_utk_error=substr($_,351,1);
		$ufs_utk_trusted=substr($_,356,1);
		$ufs_utk_sesstype=substr($_,361,8);
		$ufs_utk_surrogat=substr($_,370,1);
		$ufs_utk_remote=substr($_,375,1);
		$ufs_utk_priv=substr($_,380,1);
		$ufs_utk_secl=substr($_,385,8);
		$ufs_utk_execnode=substr($_,394,8);
		$ufs_utk_suser_id=substr($_,403,8);
		$ufs_utk_snode=substr($_,412,8);
		$ufs_utk_sgrp_id=substr($_,421,8);
		$ufs_utk_spoe=substr($_,430,8);
		$ufs_utk_spclass=substr($_,439,8);
		$ufs_utk_user_id=substr($_,448,8);
		$ufs_utk_grp_id=substr($_,457,8);
		$ufs_utk_dft_grp=substr($_,466,1);
		$ufs_utk_dft_secl=substr($_,471,1);
		$ufs_appc_link=substr($_,476,16);
		$ufs_audit_code=substr($_,493,11);
		$ufs_old_real_uid=substr($_,505,10);
		if ($ufs_old_real_uid  eq ' ' x length($ufs_old_real_uid )) {
			undef $ufs_old_real_uid ;
		}
		$ufs_old_eff_uid=substr($_,516,10);
		if ($ufs_old_eff_uid  eq ' ' x length($ufs_old_eff_uid )) {
			undef $ufs_old_eff_uid ;
		}
		$ufs_old_saved_uid=substr($_,527,10);
		if ($ufs_old_saved_uid  eq ' ' x length($ufs_old_saved_uid )) {
			undef $ufs_old_saved_uid ;
		}
		$ufs_old_real_gid=substr($_,538,10);
		if ($ufs_old_real_gid  eq ' ' x length($ufs_old_real_gid )) {
			undef $ufs_old_real_gid ;
		}
		$ufs_old_eff_gid=substr($_,549,10);
		if ($ufs_old_eff_gid  eq ' ' x length($ufs_old_eff_gid )) {
			undef $ufs_old_eff_gid ;
		}
		$ufs_old_saved_gid=substr($_,560,10);
		if ($ufs_old_saved_gid  eq ' ' x length($ufs_old_saved_gid )) {
			undef $ufs_old_saved_gid ;
		}
		$ufs_path_name=substr($_,571,1023);
		$ufs_file_id=substr($_,1595,32);
		$ufs_file_own_uid=substr($_,1628,10);
		if ($ufs_file_own_uid  eq ' ' x length($ufs_file_own_uid )) {
			undef $ufs_file_own_uid ;
		}
		$ufs_file_own_gid=substr($_,1639,10);
		if ($ufs_file_own_gid  eq ' ' x length($ufs_file_own_gid )) {
			undef $ufs_file_own_gid ;
		}
		$ufs_hfs_ds_name=substr($_,1650,44);
		$ufs_dce_link=substr($_,1695,16);
		$ufs_auth_type=substr($_,1712,13);
		$ufs_dflt_process=substr($_,1726,1);
		$ufs_utk_netw=substr($_,1731,8);
		$ufs_x500_subject=substr($_,1740,255);
		$ufs_x500_issuer=substr($_,1996,255);
		$rv=$insert{umntfsys}->execute($ufs_event_type,$ufs_event_qual,$ufs_time_written,$ufs_date_written,$ufs_system_smfid,$ufs_violation,$ufs_user_ndfnd,$ufs_user_warning,$ufs_evt_user_id,$ufs_evt_grp_id,$ufs_auth_normal,$ufs_auth_special,$ufs_auth_oper,$ufs_auth_audit,$ufs_auth_exit,$ufs_auth_failsft,$ufs_auth_bypass,$ufs_auth_trusted,$ufs_log_class,$ufs_log_user,$ufs_log_special,$ufs_log_access,$ufs_log_racinit,$ufs_log_always,$ufs_log_cmdviol,$ufs_log_global,$ufs_term_level,$ufs_backout_fail,$ufs_prof_same,$ufs_term,$ufs_job_name,$ufs_read_time,$ufs_read_date,$ufs_smf_user_id,$ufs_log_level,$ufs_log_vmevent,$ufs_log_logopt,$ufs_log_secl,$ufs_log_compatm,$ufs_log_applaud,$ufs_log_nonomvs,$ufs_log_omvsnprv,$ufs_auth_omvssu,$ufs_auth_omvssys,$ufs_usr_secl,$ufs_racf_version,$ufs_class,$ufs_user_name,$ufs_utk_encr,$ufs_utk_pre19,$ufs_utk_verprof,$ufs_utk_njeunusr,$ufs_utk_logusr,$ufs_utk_special,$ufs_utk_default,$ufs_utk_unknusr,$ufs_utk_error,$ufs_utk_trusted,$ufs_utk_sesstype,$ufs_utk_surrogat,$ufs_utk_remote,$ufs_utk_priv,$ufs_utk_secl,$ufs_utk_execnode,$ufs_utk_suser_id,$ufs_utk_snode,$ufs_utk_sgrp_id,$ufs_utk_spoe,$ufs_utk_spclass,$ufs_utk_user_id,$ufs_utk_grp_id,$ufs_utk_dft_grp,$ufs_utk_dft_secl,$ufs_appc_link,$ufs_audit_code,$ufs_old_real_uid,$ufs_old_eff_uid,$ufs_old_saved_uid,$ufs_old_real_gid,$ufs_old_eff_gid,$ufs_old_saved_gid,$ufs_path_name,$ufs_file_id,$ufs_file_own_uid,$ufs_file_own_gid,$ufs_hfs_ds_name,$ufs_dce_link,$ufs_auth_type,$ufs_dflt_process,$ufs_utk_netw,$ufs_x500_subject,$ufs_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"umntfsys"}++;
		next;
	}

	if ($rectype eq 'UNLINK  ') {
		$unl_event_type=substr($_,0,8);
		$unl_event_qual=substr($_,9,8);
		$unl_time_written=substr($_,18,8);
		if ($unl_time_written  eq ' ' x length($unl_time_written )) {
			undef $unl_time_written ;
		}
		$unl_date_written=substr($_,27,10);
		if ($unl_date_written  eq ' ' x length($unl_date_written )) {
			undef $unl_date_written ;
		}
		$unl_system_smfid=substr($_,38,4);
		$unl_violation=substr($_,43,1);
		$unl_user_ndfnd=substr($_,48,1);
		$unl_user_warning=substr($_,53,1);
		$unl_evt_user_id=substr($_,58,8);
		$unl_evt_grp_id=substr($_,67,8);
		$unl_auth_normal=substr($_,76,1);
		$unl_auth_special=substr($_,81,1);
		$unl_auth_oper=substr($_,86,1);
		$unl_auth_audit=substr($_,91,1);
		$unl_auth_exit=substr($_,96,1);
		$unl_auth_failsft=substr($_,101,1);
		$unl_auth_bypass=substr($_,106,1);
		$unl_auth_trusted=substr($_,111,1);
		$unl_log_class=substr($_,116,1);
		$unl_log_user=substr($_,121,1);
		$unl_log_special=substr($_,126,1);
		$unl_log_access=substr($_,131,1);
		$unl_log_racinit=substr($_,136,1);
		$unl_log_always=substr($_,141,1);
		$unl_log_cmdviol=substr($_,146,1);
		$unl_log_global=substr($_,151,1);
		$unl_term_level=substr($_,156,3);
		if ($unl_term_level  eq ' ' x length($unl_term_level )) {
			undef $unl_term_level ;
		}
		$unl_backout_fail=substr($_,160,1);
		$unl_prof_same=substr($_,165,1);
		$unl_term=substr($_,170,8);
		$unl_job_name=substr($_,179,8);
		$unl_read_time=substr($_,188,8);
		if ($unl_read_time  eq ' ' x length($unl_read_time )) {
			undef $unl_read_time ;
		}
		$unl_read_date=substr($_,197,10);
		if ($unl_read_date  eq ' ' x length($unl_read_date )) {
			undef $unl_read_date ;
		}
		$unl_smf_user_id=substr($_,208,8);
		$unl_log_level=substr($_,217,1);
		$unl_log_vmevent=substr($_,222,1);
		$unl_log_logopt=substr($_,227,1);
		$unl_log_secl=substr($_,232,1);
		$unl_log_compatm=substr($_,237,1);
		$unl_log_applaud=substr($_,242,1);
		$unl_log_nonomvs=substr($_,247,1);
		$unl_log_omvsnprv=substr($_,252,1);
		$unl_auth_omvssu=substr($_,257,1);
		$unl_auth_omvssys=substr($_,262,1);
		$unl_usr_secl=substr($_,267,8);
		$unl_racf_version=substr($_,276,4);
		$unl_class=substr($_,281,8);
		$unl_user_name=substr($_,290,20);
		$unl_utk_encr=substr($_,311,1);
		$unl_utk_pre19=substr($_,316,1);
		$unl_utk_verprof=substr($_,321,1);
		$unl_utk_njeunusr=substr($_,326,1);
		$unl_utk_logusr=substr($_,331,1);
		$unl_utk_special=substr($_,336,1);
		$unl_utk_default=substr($_,341,1);
		$unl_utk_unknusr=substr($_,346,1);
		$unl_utk_error=substr($_,351,1);
		$unl_utk_trusted=substr($_,356,1);
		$unl_utk_sesstype=substr($_,361,8);
		$unl_utk_surrogat=substr($_,370,1);
		$unl_utk_remote=substr($_,375,1);
		$unl_utk_priv=substr($_,380,1);
		$unl_utk_secl=substr($_,385,8);
		$unl_utk_execnode=substr($_,394,8);
		$unl_utk_suser_id=substr($_,403,8);
		$unl_utk_snode=substr($_,412,8);
		$unl_utk_sgrp_id=substr($_,421,8);
		$unl_utk_spoe=substr($_,430,8);
		$unl_utk_spclass=substr($_,439,8);
		$unl_utk_user_id=substr($_,448,8);
		$unl_utk_grp_id=substr($_,457,8);
		$unl_utk_dft_grp=substr($_,466,1);
		$unl_utk_dft_secl=substr($_,471,1);
		$unl_appc_link=substr($_,476,16);
		$unl_audit_code=substr($_,493,11);
		$unl_old_real_uid=substr($_,505,10);
		if ($unl_old_real_uid  eq ' ' x length($unl_old_real_uid )) {
			undef $unl_old_real_uid ;
		}
		$unl_old_eff_uid=substr($_,516,10);
		if ($unl_old_eff_uid  eq ' ' x length($unl_old_eff_uid )) {
			undef $unl_old_eff_uid ;
		}
		$unl_old_saved_uid=substr($_,527,10);
		if ($unl_old_saved_uid  eq ' ' x length($unl_old_saved_uid )) {
			undef $unl_old_saved_uid ;
		}
		$unl_old_real_gid=substr($_,538,10);
		if ($unl_old_real_gid  eq ' ' x length($unl_old_real_gid )) {
			undef $unl_old_real_gid ;
		}
		$unl_old_eff_gid=substr($_,549,10);
		if ($unl_old_eff_gid  eq ' ' x length($unl_old_eff_gid )) {
			undef $unl_old_eff_gid ;
		}
		$unl_old_saved_gid=substr($_,560,10);
		if ($unl_old_saved_gid  eq ' ' x length($unl_old_saved_gid )) {
			undef $unl_old_saved_gid ;
		}
		$unl_path_name=substr($_,571,1023);
		$unl_file_id=substr($_,1595,32);
		$unl_file_own_uid=substr($_,1628,10);
		if ($unl_file_own_uid  eq ' ' x length($unl_file_own_uid )) {
			undef $unl_file_own_uid ;
		}
		$unl_file_own_gid=substr($_,1639,10);
		if ($unl_file_own_gid  eq ' ' x length($unl_file_own_gid )) {
			undef $unl_file_own_gid ;
		}
		$unl_last_deleted=substr($_,1650,1);
		$unl_filepool=substr($_,1655,8);
		$unl_filespace=substr($_,1664,8);
		$unl_inode=substr($_,1673,10);
		if ($unl_inode  eq ' ' x length($unl_inode )) {
			undef $unl_inode ;
		}
		$unl_scid=substr($_,1684,10);
		if ($unl_scid  eq ' ' x length($unl_scid )) {
			undef $unl_scid ;
		}
		$unl_dce_link=substr($_,1695,16);
		$unl_auth_type=substr($_,1712,13);
		$unl_dflt_process=substr($_,1726,1);
		$unl_utk_netw=substr($_,1731,8);
		$unl_x500_subject=substr($_,1740,255);
		$unl_x500_issuer=substr($_,1996,255);
		$rv=$insert{unlink}->execute($unl_event_type,$unl_event_qual,$unl_time_written,$unl_date_written,$unl_system_smfid,$unl_violation,$unl_user_ndfnd,$unl_user_warning,$unl_evt_user_id,$unl_evt_grp_id,$unl_auth_normal,$unl_auth_special,$unl_auth_oper,$unl_auth_audit,$unl_auth_exit,$unl_auth_failsft,$unl_auth_bypass,$unl_auth_trusted,$unl_log_class,$unl_log_user,$unl_log_special,$unl_log_access,$unl_log_racinit,$unl_log_always,$unl_log_cmdviol,$unl_log_global,$unl_term_level,$unl_backout_fail,$unl_prof_same,$unl_term,$unl_job_name,$unl_read_time,$unl_read_date,$unl_smf_user_id,$unl_log_level,$unl_log_vmevent,$unl_log_logopt,$unl_log_secl,$unl_log_compatm,$unl_log_applaud,$unl_log_nonomvs,$unl_log_omvsnprv,$unl_auth_omvssu,$unl_auth_omvssys,$unl_usr_secl,$unl_racf_version,$unl_class,$unl_user_name,$unl_utk_encr,$unl_utk_pre19,$unl_utk_verprof,$unl_utk_njeunusr,$unl_utk_logusr,$unl_utk_special,$unl_utk_default,$unl_utk_unknusr,$unl_utk_error,$unl_utk_trusted,$unl_utk_sesstype,$unl_utk_surrogat,$unl_utk_remote,$unl_utk_priv,$unl_utk_secl,$unl_utk_execnode,$unl_utk_suser_id,$unl_utk_snode,$unl_utk_sgrp_id,$unl_utk_spoe,$unl_utk_spclass,$unl_utk_user_id,$unl_utk_grp_id,$unl_utk_dft_grp,$unl_utk_dft_secl,$unl_appc_link,$unl_audit_code,$unl_old_real_uid,$unl_old_eff_uid,$unl_old_saved_uid,$unl_old_real_gid,$unl_old_eff_gid,$unl_old_saved_gid,$unl_path_name,$unl_file_id,$unl_file_own_uid,$unl_file_own_gid,$unl_last_deleted,$unl_filepool,$unl_filespace,$unl_inode,$unl_scid,$unl_dce_link,$unl_auth_type,$unl_dflt_process,$unl_utk_netw,$unl_x500_subject,$unl_x500_issuer);
		if (! defined($rv)) {
			$dbh->rollback;
			$dbh->disconnect;
			die $dbh->errstr;
		}
		$inserts{"unlink"}++;
		next;
	}

}
$dbh->commit;
$dbh->disconnect;
