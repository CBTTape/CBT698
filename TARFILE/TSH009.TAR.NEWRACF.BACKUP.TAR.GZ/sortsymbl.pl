#!/usr/bin/perl
use strict;
use warnings;
while(<>) {
	chomp;
	next if /^\*/;
	print $_,"\n";
}
