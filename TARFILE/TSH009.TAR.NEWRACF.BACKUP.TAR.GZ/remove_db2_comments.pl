#!/usr/bin/perl
# Remove DB2 and SPFUI comments
use strict;
use warnings;
undef $/;
my $file=<>; #read in the entire file! "slurp" mode.
$file =~ s/--.*?$//gm; # DB2 comments
$file =~ s/\/\*.*?\*\///gs; #SPFUI comments - can span lines!
$file =~ s/\s*$//gm; #remove trailing blanks
print $file;
