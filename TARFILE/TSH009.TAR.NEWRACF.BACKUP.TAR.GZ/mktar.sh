#!/bin/sh
ls *.pl *.txt *.psql *.sh >newracf.files
tar chzvf newracf.backup.tar.gz --files-from=newracf.files 
rm newracf.files
