#!/bin/sh
dropdb racf
createdb racf
psql <irradutb.psql
psql <racdbutb.psql
psql <create_jobinit_index.psql
psql <create_jobstart-jobend_views.psql
psql <create_and_load_viol.psql
echo
echo "You may now run the racdbuld.pl and/or irraduld.pl Perl programs"
echo "After running racdbuld.pl, remember to run the command:"
echo "psql <create_and_load_auth_ids.psql"
