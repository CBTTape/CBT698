#!/usr/bin/perl
use strict;
use warnings;
my $tot_records=0;
my $tot_rectype=0;
my $rectype;
my %rectype;
while (<>) {
	$rectype=substr($_,1,4);
	$rectype{$rectype}=0 unless defined $rectype{$rectype};
#	if (! defined $rectype{$rectype})  { $rectype{$rectype} = 0;}
	$rectype{$rectype}++;
	$tot_records++;
}
for $rectype (sort keys %rectype) {
	print "record type:",$rectype," = ",$rectype{$rectype},"\n";
	$tot_rectype=$tot_rectype+$rectype{$rectype};
}
print "total records=",$tot_rectype," lines read=",$tot_records,"\n";
