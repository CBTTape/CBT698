#!/usr/bin/perl
use strict;
use warnings;
use bytes;
my %count;
my $rectype;
my $table;
while (<>) {
	$rectype = substr($_,0,8);
	$count{$rectype}++;
}
for $table (sort keys %count) {
	print "Table:$table record count:$count{$table}\n";
}
