#!/usr/bin/perl
# Remove DB2 comments
use strict;
use warnings;
while (<>) {
	chomp;
	$_ =~ tr /\015//d;
	print "$_\n";
}
